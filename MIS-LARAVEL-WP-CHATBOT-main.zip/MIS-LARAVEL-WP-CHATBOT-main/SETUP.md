# MIS Chatbot — Setup & Deployment Guide

AI-powered WhatsApp + Web chatbot for business data (sales, expenses, ledger, calendar, call logs). Built with Laravel 11 + OpenAI GPT-4o + MySQL.

---

## Prerequisites

- PHP 8.2+ with extensions: pgsql, pdo_mysql, mbstring, curl, openssl, gd, zip, bcmath
- Composer 2.x
- MySQL 8.0+ (or MariaDB 10.6+)
- OpenAI API key (GPT-4o access)
- WhatsApp Business API gateway (app.mis.work or similar)
- Google Cloud project (for Calendar OAuth)
- Domain + hosting (tested on Hostinger Premium)

---

## Local Development Setup

```bash
# 1. Clone the repo
git clone https://github.com/saranshrajput01/mis-chatbot-php.git
cd mis-chatbot-php

# 2. Install dependencies
composer install

# 3. Setup environment
cp .env.example .env
php artisan key:generate

# 4. Edit .env with your credentials (see .env.example for descriptions)

# 5. Create MySQL database and run migrations
php artisan migrate

# 6. Start dev server
php artisan serve
```

Open `http://localhost:8000/login` — you're live.

---

## Production Deployment (Hostinger)

### 1. Server Setup

```bash
# SSH into server
ssh -i ~/.ssh/your_key -p 65002 username@server_ip

# Create directory
mkdir -p ~/domains/your-domain.com/laravel
```

### 2. Upload Code

```bash
# From local machine — tar and stream (no git on server needed)
cd ~/Desktop/mis-chatbot-php
tar czf - --exclude=vendor --exclude=node_modules --exclude=.git --exclude='storage/logs/*.log' . | \
  ssh -i ~/.ssh/your_key -p 65002 username@server_ip \
  "cd ~/domains/your-domain.com/laravel && tar xzf -"
```

### 3. Server Install

```bash
# On server
cd ~/domains/your-domain.com/laravel

# Create required directories
mkdir -p storage/logs storage/framework/{cache,sessions,views} bootstrap/cache
chmod -R 775 storage bootstrap/cache

# Install dependencies
composer install --no-dev --optimize-autoloader

# Setup .env (copy from local or create fresh)
# Edit with production values (APP_ENV=production, APP_DEBUG=false, real DB creds, etc.)

# Run migrations
php artisan migrate --force

# Generate tokens for existing tenants
php artisan tenants:backfill-tokens

# Clear caches
php artisan config:clear && php artisan route:clear && php artisan view:clear
```

### 4. Webroot Setup (Hostinger Split Deployment)

Hostinger forces webroot to `public_html/`. Copy static files there:

```bash
cp public/*.html ~/domains/your-domain.com/public_html/
cp -r public/assets ~/domains/your-domain.com/public_html/
cp public/.htaccess ~/domains/your-domain.com/public_html/
```

Create `public_html/index.php`:

```php
<?php
ini_set("log_errors", "1");
ini_set("error_log", __DIR__ . "/../laravel/storage/logs/php_errors.log");
ini_set("output_buffering", "0");
$root = __DIR__ . "/../laravel";
require $root . "/vendor/autoload.php";
if (file_exists($root . "/.env")) {
    \Dotenv\Dotenv::createImmutable($root)->safeLoad();
}
(require_once $root . "/bootstrap/app.php")
    ->handleRequest(\Illuminate\Http\Request::capture());
```

Lock it: `chmod 444 public_html/index.php`

### 5. Cron Job

Add in hPanel → Advanced → Cron Jobs:

```
* * * * * cd /home/username/domains/your-domain.com/laravel && php artisan schedule:run >> /dev/null 2>&1
```

This enables:
- Auto sheet sync every 15 minutes
- External API sync every 30 minutes
- Meeting reminders every minute
- Daily schedule at 8 AM IST
- Cache warming every 5 minutes

### 6. WhatsApp Webhook

In your WhatsApp gateway dashboard (app.mis.work):
- **Webhook URL:** `https://your-domain.com/whatsapp`
- **Event:** message
- **Method:** POST_JSON

### 7. Google Calendar OAuth

In Google Cloud Console → APIs & Services → Credentials:
- Add redirect URI: `https://your-domain.com/api/tenant/calendar/callback`

---

## Architecture Overview

```
User (WhatsApp/Web) → Webhook/API → TenantRouter
                                        ├── AI Orchestrator (GPT-4o function-calling)
                                        │     ├── query_database → SQL Pipeline
                                        │     ├── query_external_api → ExternalApiService
                                        │     ├── search_knowledge → PdfKnowledgeService
                                        │     ├── manage_calendar → CalendarQueryHandler
                                        │     ├── get_ledger → LedgerQueryHandler
                                        │     └── direct_answer → GPT response
                                        ├── Query Memory (cached SQL, self-learning)
                                        ├── Access Control (OWNER/TEAM/CLIENT)
                                        └── Smart Formatter (WhatsApp-optimized output)
```

---

## Key Configuration

| Config | Purpose |
|--------|---------|
| `SUPER_ADMIN_PHONES` | Full access to admin panel + all tenants |
| `WA_ACCESS_TOKEN` | WhatsApp gateway API key |
| `OPENAI_API_KEY` | Powers all AI (SQL gen, formatting, orchestration) |
| `ADMIN_API_KEY` | Protects `/api/admin/*` endpoints |
| `CHAT_TOKEN_SECRET` | Signs chat auth tokens (HMAC-SHA256) |
| `GOOGLE_CLIENT_ID/SECRET` | Calendar OAuth flow |
| `GMAIL_APP_PASSWORD` | Meeting notifications via email |

---

## Admin Panel

Access at `https://your-domain.com/admin` (super admin phones only).

Features:
- Add/remove clients
- Connect Google Sheets per client
- Manage team members + permissions
- Edit AI prompts per tenant
- Force sync / view sync status

---

## Multi-Tenant Flow

1. Super admin adds client (phone + name) via Admin Panel
2. Client connects Google Sheet(s) via Settings page
3. System auto-syncs sheet data to MySQL every 15 minutes
4. Users query via WhatsApp or Web chatbot
5. AI generates SQL, fetches data, formats response
6. Access control filters data per user role

---

## Important Notes

- **NEVER use Hostinger GIT "Redeploy"** — it targets public_html
- **Always `chmod 444 public_html/index.php`** after deploy
- **Deploy via tar over SSH** (not git clone — repo is private)
- **DO NOT use `config:cache`** if `web.php` has closure routes
- **LiteSpeed compatibility:** Don't use `response()->file()` or `display_errors`
- After adding new PHP classes: `composer dump-autoload -o`

---

## Useful Commands

```bash
# Force sync all tenants
php artisan tinker --execute="\App\Services\Sheets\TenantSyncService::syncAllTenants(['force'=>true]);"

# Sync external APIs (call logs, delegation, etc.)
php artisan sync:external-apis

# Run eval test suite
php artisan eval:run

# Clear all caches
php artisan cache:clear && php artisan config:clear && php artisan route:clear
```

---

## Support

- **Live site:** https://mis-chatbot.in
- **GitHub:** https://github.com/saranshrajput01/mis-chatbot-php
