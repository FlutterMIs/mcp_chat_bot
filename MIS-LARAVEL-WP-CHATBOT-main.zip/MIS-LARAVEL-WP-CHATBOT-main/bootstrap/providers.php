<?php

use App\Providers\AiServiceProvider;
use App\Providers\AppServiceProvider;
use App\Providers\ChatServiceProvider;
use App\Providers\EventServiceProvider;

return [
    AppServiceProvider::class,
    AiServiceProvider::class,
    ChatServiceProvider::class,
    EventServiceProvider::class,
];
