<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->api(prepend: [
            \Illuminate\Http\Middleware\HandleCors::class,
        ]);

        $middleware->throttleApi('60,1');

        // Custom middleware aliases
        $middleware->alias([
            'chat-auth'   => \App\Http\Middleware\ChatAuthGate::class,
            'admin-auth'  => \App\Http\Middleware\AdminAuthGate::class,
            'super-admin' => \App\Http\Middleware\SuperAdminGate::class,
        ]);

        // External webhooks (WhatsApp / Meta) don't carry CSRF tokens.
        // Exclude them so POST /whatsapp doesn't get a 419 page.
        $middleware->validateCsrfTokens(except: [
            'whatsapp',
            'wa-hook-da33cc854dfae176',
            'wh/*',
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
