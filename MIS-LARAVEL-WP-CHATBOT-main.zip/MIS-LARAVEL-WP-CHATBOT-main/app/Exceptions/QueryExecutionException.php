<?php

declare(strict_types=1);

namespace App\Exceptions;

use Exception;

class QueryExecutionException extends Exception
{
    public function __construct(string $sql, string $error)
    {
        parent::__construct("Query failed: {$error} | SQL: {$sql}");
    }

    public function render(): \Illuminate\Http\JsonResponse
    {
        return response()->json([
            'reply' => '⚠️ Could not execute the query. Please rephrase.',
            'type'  => 'text',
            'error' => 'query_execution_failed',
        ], 500);
    }
}
