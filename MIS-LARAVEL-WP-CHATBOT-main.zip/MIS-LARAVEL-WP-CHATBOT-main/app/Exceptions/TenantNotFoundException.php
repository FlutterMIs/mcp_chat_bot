<?php

declare(strict_types=1);

namespace App\Exceptions;

use Exception;

class TenantNotFoundException extends Exception
{
    public function __construct(string $phone)
    {
        parent::__construct("No tenant found for phone: {$phone}");
    }

    public function render(): \Illuminate\Http\JsonResponse
    {
        return response()->json(['error' => 'Phone not registered'], 404);
    }
}
