<?php

declare(strict_types=1);

namespace App\Contracts\WhatsApp;

interface WhatsAppClientInterface
{
    public function sendText(string $to, string $message, ?string $tenantId = null): bool;

    public function sendDocument(string $to, string $filePath, string $caption, ?string $tenantId = null): bool;

    public function sendImageByUrl(string $to, string $url, ?string $tenantId = null): bool;

    public function downloadAudio(string $url): ?string;
}
