<?php

declare(strict_types=1);

namespace App\Contracts\AI;

interface AiClientInterface
{
    /**
     * Send a chat completion request.
     *
     * @param  array  $messages  [{role, content}]
     * @param  array  $options   [model?, max_tokens?, temperature?, tools?]
     * @return array{ok: bool, content?: string, tool_calls?: array, error?: string}
     */
    public function chat(array $messages, array $options = []): array;
}
