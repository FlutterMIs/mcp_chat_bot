<?php

declare(strict_types=1);

namespace App\Contracts\Chat;

interface ResponseFormatterInterface
{
    /**
     * Format query result rows into a human-readable reply.
     *
     * @param  array  $rows          Raw SQL result rows
     * @param  array  $columnsMeta   Column metadata (name, role, type)
     * @param  string $tenantId
     * @param  ?string $formatInstruction  AI-provided format hint
     * @return string  Formatted reply text
     */
    public function format(array $rows, array $columnsMeta, string $tenantId, ?string $formatInstruction = null): string;
}
