<?php

declare(strict_types=1);

namespace App\Enums;

enum QueryMode: string
{
    case Data = 'data';
    case Chart = 'chart';
    case Pivot = 'pivot';
    case Image = 'images';
    case Ledger = 'ledger';
    case Calendar = 'calendar';
    case ExternalApi = 'external_api';
    case PdfKnowledge = 'pdf';

    public function needsSql(): bool
    {
        return in_array($this, [self::Data, self::Chart, self::Pivot, self::Image]);
    }
}
