<?php

declare(strict_types=1);

namespace App\Enums;

enum ChatIntent: string
{
    case Greeting = 'GREETING';
    case Ignore = 'IGNORE';
    case IgnoreOfftopic = 'IGNORE_OFFTOPIC';
    case DataQuery = 'DATA_QUERY';
    case Calendar = 'CALENDAR';
    case Ledger = 'LEDGER';
    case ExternalApi = 'EXTERNAL_API';
    case PdfKnowledge = 'PDF_KNOWLEDGE';
    case Chart = 'CHART_QUERY';
    case Pivot = 'PIVOT_QUERY';
    case Image = 'IMAGE_QUERY';
    case SwitchDb = 'SWITCH_DB';
    case DirectAnswer = 'DIRECT_ANSWER';

    public function shouldProcess(): bool
    {
        return ! in_array($this, [self::Greeting, self::Ignore, self::IgnoreOfftopic]);
    }

    public function isDataRelated(): bool
    {
        return in_array($this, [
            self::DataQuery,
            self::Chart,
            self::Pivot,
            self::Image,
        ]);
    }
}
