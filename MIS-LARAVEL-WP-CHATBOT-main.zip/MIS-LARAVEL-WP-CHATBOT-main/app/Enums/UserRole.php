<?php

declare(strict_types=1);

namespace App\Enums;

enum UserRole: string
{
    case SuperAdmin = 'super_admin';
    case Owner = 'owner';
    case Team = 'team';
    case Client = 'client';

    public function hasFullAccess(): bool
    {
        return in_array($this, [self::SuperAdmin, self::Owner]);
    }

    public function canManageTeam(): bool
    {
        return in_array($this, [self::SuperAdmin, self::Owner]);
    }

    public function canAccessAdmin(): bool
    {
        return $this === self::SuperAdmin;
    }
}
