<?php

declare(strict_types=1);

namespace App\Enums;

enum WaKeyMode: string
{
    case Shared = 'shared';
    case Own = 'own';
}
