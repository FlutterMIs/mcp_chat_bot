<?php

declare(strict_types=1);

namespace App\Services\Cache;

use App\Services\Dashboard\DashboardEngine;
use App\Services\Dashboard\PageEngine;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Pre-computes dashboard + page data for active tenants so users
 * always hit warm cache (<100ms). Runs every 5 min via scheduler.
 */
final class CacheWarmer
{
    private const PAGE_KINDS = ['sales', 'outstanding', 'stock', 'ledger'];

    public static function warm(): void
    {
        $tenants = DB::table('tenants')
            ->select('id', 'name')
            ->where('proper_tables_created', true)
            ->whereNotIn('status', ['paused', 'cancelled'])
            ->get();

        $warmed = 0;

        foreach ($tenants as $tenant) {
            try {
                // Dashboard (default range = month)
                $key = "dashboard:{$tenant->id}:month";
                $data = DashboardEngine::build($tenant->id, ['range' => 'month']);
                Cache::put($key, $data, 600);

                // Each page (default opts = no filters)
                foreach (self::PAGE_KINDS as $kind) {
                    $opts = [];
                    $pageKey = "page:{$tenant->id}:{$kind}:" . md5(json_encode($opts));
                    $pageData = PageEngine::build($tenant->id, $kind, $opts);
                    Cache::put($pageKey, $pageData, 600);
                }

                $warmed++;
            } catch (Throwable $e) {
                Log::warning("[CACHE-WARM] failed for {$tenant->name}: " . $e->getMessage());
            }
        }

        Log::info("[CACHE-WARM] warmed {$warmed}/" . $tenants->count() . " tenants");
    }
}
