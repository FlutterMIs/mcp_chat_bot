<?php

declare(strict_types=1);

namespace App\Services\AI;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

/**
 * SchemaIntelligence — generates and caches a column dictionary for a tenant's schema.
 * Auto-called after every sheet sync to keep the dictionary fresh.
 */
final class SchemaIntelligence
{
    private const CACHE_TTL = 86400; // 24 hours

    /**
     * Generate schema intelligence (column dictionary) from tables_metadata.
     *
     * @param  string  $tenantId
     * @param  array  $metadata  tables_metadata array
     */
    public static function generate(string $tenantId, array $metadata): void
    {
        $dictionary = [];
        foreach ($metadata as $table) {
            $tableName = $table['pg_table'] ?? '';
            $sourceName = $table['source_name'] ?? $tableName;
            foreach (($table['columns'] ?? []) as $col) {
                $pgName = $col['pg_name'] ?? '';
                if ($pgName === '' || ($col['role'] ?? '') === 'date_actual') continue;
                $dictionary[] = [
                    'table' => $tableName,
                    'source_table' => $sourceName,
                    'column' => $pgName,
                    'original' => $col['original'] ?? $pgName,
                    'type' => $col['pg_type'] ?? 'TEXT',
                    'role' => $col['role'] ?? 'text',
                    'samples' => array_slice($col['samples'] ?? [], 0, 2),
                ];
            }
        }

        $cacheKey = "schema_intel:{$tenantId}";
        Cache::put($cacheKey, $dictionary, self::CACHE_TTL);
        Log::info("[SCHEMA INTEL] generated for tenant {$tenantId}: " . count($dictionary) . ' columns');
    }

    /**
     * Retrieve cached schema intelligence for a tenant.
     */
    public static function get(string $tenantId): ?array
    {
        return Cache::get("schema_intel:{$tenantId}");
    }

    /** Alias for get() */
    public static function getForTenant(string $tenantId): ?array
    {
        return self::get($tenantId);
    }

    /**
     * Inject column dictionary into SQL prompt messages.
     */
    public static function injectIntoPrompt(array $dictionary, array $messages): array
    {
        if (empty($dictionary)) return $messages;

        $lines = [];
        foreach (array_slice($dictionary, 0, 50) as $col) {
            $desc = "{$col['table']}.{$col['column']} ({$col['type']}/{$col['role']})";
            if (!empty($col['original']) && $col['original'] !== $col['column']) {
                $desc .= " — originally \"{$col['original']}\"";
            }
            if (!empty($col['samples'])) {
                $desc .= ' e.g. ' . implode(', ', array_slice($col['samples'], 0, 2));
            }
            $lines[] = $desc;
        }

        $content = "COLUMN DICTIONARY (use this to pick correct columns):\n" . implode("\n", $lines);
        array_splice($messages, 1, 0, [['role' => 'user', 'content' => $content]]);
        return $messages;
    }
}
