<?php

declare(strict_types=1);

namespace App\Services\AI;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * OpenAI API wrapper with automatic key fallback.
 * Tries each key in config('mis.openai_api_keys') until one succeeds.
 */
final class OpenAIClient
{
    /**
     * Call chat completions with automatic key rotation on 429/401 errors.
     * @return array|null  response JSON or null on total failure
     */
    public static function chatCompletion(array $params, int $timeout = 30): ?array
    {
        $keys = config('mis.openai_api_keys', []);
        if (empty($keys)) {
            $single = (string) config('mis.openai_api_key', '');
            $keys = $single !== '' ? [$single] : [];
        }
        if (empty($keys)) return null;

        foreach ($keys as $key) {
            $key = trim($key);
            if ($key === '') continue;

            try {
                $resp = Http::withToken($key)->timeout($timeout)
                    ->post('https://api.openai.com/v1/chat/completions', $params);

                if ($resp->ok()) return $resp->json();

                // 429 (rate limit) or 401 (invalid key) → try next key
                if (in_array($resp->status(), [429, 401], true)) {
                    Log::warning("[OPENAI] key …" . substr($key, -4) . " got {$resp->status()}, trying next");
                    continue;
                }

                // Other errors (500, 503) — return null, don't try other keys
                Log::warning("[OPENAI] status={$resp->status()} body=" . substr($resp->body(), 0, 200));
                return null;
            } catch (Throwable $e) {
                Log::warning("[OPENAI] key …" . substr($key, -4) . " error: " . $e->getMessage());
                continue;
            }
        }

        Log::error("[OPENAI] all keys exhausted");
        return null;
    }
}
