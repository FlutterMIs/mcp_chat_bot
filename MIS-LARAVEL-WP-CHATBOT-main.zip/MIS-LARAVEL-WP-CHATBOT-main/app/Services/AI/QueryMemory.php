<?php

declare(strict_types=1);

namespace App\Services\AI;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

final class QueryMemory
{
    private const FILLER_WORDS = [
        'show me', 'show', 'please', 'btao', 'batao', 'dikhao', 'do', 'bata',
        'tell me', 'give me', 'get me', 'find', 'fetch', 'list', 'display',
        'mujhe', 'mera', 'mere', 'what is', 'what are', 'kya hai', 'kya he',
        'can you', 'could you', 'i want', 'i need',
    ];

    public static function normalizeQuery(string $query): string
    {
        $q = mb_strtolower(trim($query));
        $q = preg_replace('/[^\w\s]/u', '', $q);
        foreach (self::FILLER_WORDS as $filler) {
            $q = preg_replace('/\b' . preg_quote($filler, '/') . '\b/u', '', $q);
        }
        return trim(preg_replace('/\s+/', ' ', $q));
    }

    public static function hash(string $tenantId, string $normalized): string
    {
        return hash('sha256', $tenantId . ':' . $normalized);
    }

    public static function lookup(string $tenantId, string $query): ?array
    {
        try {
            $normalized = self::normalizeQuery($query);
            $h = self::hash($tenantId, $normalized);
            $row = DB::selectOne(
                "SELECT sql_used, confidence, times_used FROM query_memory WHERE tenant_id = ? AND query_hash = ? AND is_valid = 1 LIMIT 1",
                [$tenantId, $h]
            );
            if (!$row) return null;
            return [
                'sql' => $row->sql_used,
                'confidence' => (float) $row->confidence,
                'times_used' => (int) $row->times_used,
            ];
        } catch (Throwable $e) {
            Log::warning('[QueryMemory::lookup] ' . $e->getMessage());
            return null;
        }
    }

    public static function save(string $tenantId, string $query, string $sql, ?string $resultSummary = null): void
    {
        try {
            $normalized = self::normalizeQuery($query);
            $h = self::hash($tenantId, $normalized);
            DB::statement(
                "INSERT INTO query_memory (tenant_id, query_hash, query_text, sql_used, result_summary, last_used_at)
                 VALUES (?, ?, ?, ?, ?, NOW())
                 ON DUPLICATE KEY UPDATE
                    times_used = times_used + 1,
                    last_used_at = NOW(),
                    confidence = LEAST(confidence + 0.1, 1.0),
                    sql_used = VALUES(sql_used),
                    result_summary = VALUES(result_summary)",
                [$tenantId, $h, mb_substr($query, 0, 500), $sql, $resultSummary ? mb_substr($resultSummary, 0, 500) : null]
            );
        } catch (Throwable $e) {
            Log::warning('[QueryMemory::save] ' . $e->getMessage());
        }
    }

    public static function invalidate(string $tenantId, string $query): void
    {
        try {
            $normalized = self::normalizeQuery($query);
            $h = self::hash($tenantId, $normalized);
            DB::statement(
                "UPDATE query_memory SET is_valid = 0 WHERE tenant_id = ? AND query_hash = ?",
                [$tenantId, $h]
            );
        } catch (Throwable $e) {
            Log::warning('[QueryMemory::invalidate] ' . $e->getMessage());
        }
    }

    public static function getRecentSuccessful(string $tenantId, int $limit = 5): array
    {
        try {
            return DB::select(
                "SELECT query_text, sql_used FROM query_memory WHERE tenant_id = ? AND is_valid = 1 ORDER BY last_used_at DESC LIMIT ?",
                [$tenantId, $limit]
            );
        } catch (Throwable $e) {
            Log::warning('[QueryMemory::getRecentSuccessful] ' . $e->getMessage());
            return [];
        }
    }
}
