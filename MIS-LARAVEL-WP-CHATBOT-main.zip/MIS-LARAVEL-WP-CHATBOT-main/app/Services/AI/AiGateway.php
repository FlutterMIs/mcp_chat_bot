<?php

declare(strict_types=1);

namespace App\Services\AI;

use App\Models\Tenant;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * AiGateway — single entry point for all AI calls.
 * Resolves per-tenant vendor/model/key, falls back to .env for super admins.
 */
final class AiGateway
{
    /** Chunks per embeddings API call — bounds request/response payload size. */
    private const EMBED_BATCH_SIZE = 50;

    /**
     * Per-request memoization of resolve() — a single inbound WhatsApp message can
     * trigger several chat() calls (SQL generation attempts, formatter, sub-handlers),
     * each previously re-running the tenant lookup query. Safe to cache for the
     * lifetime of the request since the tenant's AI config cannot change mid-request.
     *
     * @var array<string, array>
     */
    private static array $resolveCache = [];

    /**
     * Send a chat completion request using the tenant's configured AI provider.
     *
     * @param  string|null  $tenantId  Tenant UUID (null = use .env fallback)
     * @param  list<array{role: string, content: string}>  $messages  OpenAI-style messages
     * @param  array{temperature?: float, max_tokens?: int, json?: bool}  $opts
     * @return array{ok: bool, content: string, error?: string}
     */
    public static function chat(?string $tenantId, array $messages, array $opts = []): array
    {
        $config = self::resolve($tenantId);
        if (!$config['ok']) {
            return ['ok' => false, 'content' => '', 'error' => $config['error']];
        }

        return match ($config['vendor']) {
            'gemini' => self::callGemini($config['key'], $config['model'], $messages, $opts),
            default  => self::callOpenAI($config['key'], $config['model'], $messages, $opts),
        };
    }

    /**
     * Describe the AI config that WOULD be used for a tenant — for read-only display
     * in the UI ("which model is running"). Never exposes the key itself, only whether
     * the tenant uses its own key, the shared/env key, or has none configured.
     *
     * @return array{ok: bool, vendor: ?string, model: ?string, source: string, error?: string}
     *         source ∈ 'own_key' | 'shared' | 'none'
     */
    public static function describe(?string $tenantId): array
    {
        // Distinguish own-key vs shared before resolve() collapses both into config.
        $source = 'none';
        if ($tenantId !== null) {
            $tenant = Tenant::query()->select(['id', 'phone', 'ai_api_key'])->find($tenantId);
            if ($tenant && $tenant->ai_api_key && self::decryptKey($tenant->ai_api_key)) {
                $source = 'own_key';
            } elseif ($tenant && in_array($tenant->phone, config('mis.super_admin_phones', []), true)) {
                $source = 'shared';
            }
        } else {
            $source = 'shared';
        }

        $config = self::resolve($tenantId);
        if (! $config['ok']) {
            return ['ok' => false, 'vendor' => null, 'model' => null, 'source' => 'none', 'error' => $config['error']];
        }

        return [
            'ok'     => true,
            'vendor' => $config['vendor'],
            'model'  => $config['model'],
            'source' => $source === 'none' ? 'shared' : $source,
        ];
    }

    /**
     * Resolve AI config for a tenant. Returns vendor/model/key or error.
     */
    private static function resolve(?string $tenantId): array
    {
        // No tenant → use .env fallback (super admin context)
        if ($tenantId === null) {
            return self::envFallback();
        }

        if (array_key_exists($tenantId, self::$resolveCache)) {
            return self::$resolveCache[$tenantId];
        }

        $tenant = Tenant::query()->select(['id', 'phone', 'ai_vendor', 'ai_model', 'ai_api_key'])->find($tenantId);
        if (!$tenant) {
            return self::$resolveCache[$tenantId] = self::envFallback();
        }

        // Tenant has own key configured
        if ($tenant->ai_api_key) {
            $key = self::decryptKey($tenant->ai_api_key);
            if ($key) {
                return self::$resolveCache[$tenantId] = [
                    'ok' => true,
                    'vendor' => $tenant->ai_vendor ?? 'openai',
                    'model' => $tenant->ai_model ?? self::defaultModel($tenant->ai_vendor ?? 'openai'),
                    'key' => $key,
                ];
            }
        }

        // No tenant key → check if super admin
        $superPhones = config('mis.super_admin_phones', []);
        if (in_array($tenant->phone, $superPhones, true)) {
            return self::$resolveCache[$tenantId] = self::envFallback();
        }

        // Not super admin + no key = error
        return self::$resolveCache[$tenantId] = ['ok' => false, 'error' => '⚠️ AI not configured. Please add your AI key in Settings → AI Configuration.'];
    }

    /**
     * Compute an embedding vector for text using OpenAI's text-embedding-3-small.
     * Returns null (never throws) for tenants on a non-OpenAI vendor, with no key
     * configured, or on any API failure — callers must treat this as best-effort
     * and fall back to non-embedding retrieval.
     *
     * @return list<float>|null
     */
    public static function embed(?string $tenantId, string $text): ?array
    {
        $config = self::resolve($tenantId);
        if (!$config['ok'] || $config['vendor'] !== 'openai') {
            return null;
        }

        try {
            $resp = Http::withToken($config['key'])->timeout(15)->post('https://api.openai.com/v1/embeddings', [
                'model' => 'text-embedding-3-small',
                'input' => mb_substr($text, 0, 8000),
            ]);

            if (!$resp->ok()) {
                Log::warning("[AI GW] embeddings {$resp->status()}: ".($resp->json('error.message') ?? 'unknown'));
                return null;
            }

            $vector = $resp->json('data.0.embedding');
            return is_array($vector) ? array_map('floatval', $vector) : null;
        } catch (Throwable $e) {
            Log::warning("[AI GW] embeddings exception: {$e->getMessage()}");
            return null;
        }
    }

    /**
     * Batch version of embed() — computes embeddings for many chunks in as few API
     * round-trips as possible (OpenAI's embeddings endpoint accepts an array `input`).
     * This is what keeps indexing a large document safe on hosting with no queue/
     * background workers: N chunks becomes ceil(N / EMBED_BATCH_SIZE) HTTP calls in
     * this request instead of N sequential ones, which is what previously risked
     * timing out the upload request for anything but small documents.
     *
     * @param  list<string>  $texts
     * @return list<list<float>|null>  Same length/order as $texts; null per-item on failure.
     */
    public static function embedBatch(?string $tenantId, array $texts): array
    {
        if (empty($texts)) return [];

        $config = self::resolve($tenantId);
        if (!$config['ok'] || $config['vendor'] !== 'openai') {
            return array_fill(0, count($texts), null);
        }

        $results = [];
        foreach (array_chunk($texts, self::EMBED_BATCH_SIZE) as $batch) {
            $inputs = array_map(fn($t) => mb_substr($t, 0, 8000), $batch);

            try {
                $resp = Http::withToken($config['key'])->timeout(30)->post('https://api.openai.com/v1/embeddings', [
                    'model' => 'text-embedding-3-small',
                    'input' => $inputs,
                ]);

                if (!$resp->ok()) {
                    Log::warning("[AI GW] embeddings batch {$resp->status()}: ".($resp->json('error.message') ?? 'unknown'));
                    array_push($results, ...array_fill(0, count($batch), null));
                    continue;
                }

                // OpenAI returns items with an `index` field matching request order —
                // don't assume response order matches request order.
                $byIndex = [];
                foreach ($resp->json('data') ?? [] as $item) {
                    $vector = $item['embedding'] ?? null;
                    $byIndex[$item['index']] = is_array($vector) ? array_map('floatval', $vector) : null;
                }

                for ($i = 0; $i < count($batch); $i++) {
                    $results[] = $byIndex[$i] ?? null;
                }
            } catch (Throwable $e) {
                Log::warning("[AI GW] embeddings batch exception: {$e->getMessage()}");
                array_push($results, ...array_fill(0, count($batch), null));
            }
        }

        return $results;
    }

    private static function envFallback(): array
    {
        $key = (string) config('mis.openai_api_key', '');
        if ($key === '') {
            return ['ok' => false, 'error' => 'No AI key configured.'];
        }
        return ['ok' => true, 'vendor' => 'openai', 'model' => 'gpt-4o-mini', 'key' => $key];
    }

    private static function defaultModel(string $vendor): string
    {
        return match ($vendor) {
            'gemini' => 'gemini-1.5-flash',
            default  => 'gpt-4o-mini',
        };
    }

    private static function decryptKey(string $encrypted): ?string
    {
        try {
            return Crypt::decryptString($encrypted);
        } catch (Throwable) {
            // Key might be stored plain (legacy) — try as-is
            return str_starts_with($encrypted, 'sk-') || str_starts_with($encrypted, 'AI') ? $encrypted : null;
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // OPENAI
    // ═══════════════════════════════════════════════════════════════

    private static function callOpenAI(string $key, string $model, array $messages, array $opts): array
    {
        try {
            $body = [
                'model' => $model,
                'messages' => $messages,
                'temperature' => $opts['temperature'] ?? 0.3,
                'max_tokens' => $opts['max_tokens'] ?? 2000,
            ];
            if (!empty($opts['json'])) {
                $body['response_format'] = ['type' => 'json_object'];
            }

            $resp = Http::withToken($key)->timeout($opts['timeout'] ?? 30)->post('https://api.openai.com/v1/chat/completions', $body);

            if (!$resp->ok()) {
                $err = $resp->json('error.message') ?? "OpenAI error {$resp->status()}";
                Log::warning("[AI GW] OpenAI {$resp->status()}: {$err}");
                return ['ok' => false, 'content' => '', 'error' => $err];
            }

            $content = $resp->json('choices.0.message.content') ?? '';
            return ['ok' => true, 'content' => trim($content)];
        } catch (Throwable $e) {
            Log::warning("[AI GW] OpenAI exception: {$e->getMessage()}");
            return ['ok' => false, 'content' => '', 'error' => $e->getMessage()];
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // GEMINI
    // ═══════════════════════════════════════════════════════════════

    private static function callGemini(string $key, string $model, array $messages, array $opts): array
    {
        try {
            // Translate OpenAI messages → Gemini format
            $systemText = '';
            $contents = [];
            foreach ($messages as $msg) {
                if ($msg['role'] === 'system') {
                    $systemText .= $msg['content'] . "\n";
                } else {
                    $role = $msg['role'] === 'assistant' ? 'model' : 'user';
                    $contents[] = ['role' => $role, 'parts' => [['text' => $msg['content']]]];
                }
            }

            $body = ['contents' => $contents];
            if ($systemText !== '') {
                $body['system_instruction'] = ['parts' => [['text' => trim($systemText)]]];
            }
            $body['generationConfig'] = [
                'temperature' => $opts['temperature'] ?? 0.3,
                'maxOutputTokens' => $opts['max_tokens'] ?? 2000,
            ];

            $url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$key}";
            $resp = Http::timeout(30)->post($url, $body);

            if (!$resp->ok()) {
                $err = $resp->json('error.message') ?? "Gemini error {$resp->status()}";
                Log::warning("[AI GW] Gemini {$resp->status()}: {$err}");
                return ['ok' => false, 'content' => '', 'error' => $err];
            }

            $content = $resp->json('candidates.0.content.parts.0.text') ?? '';
            return ['ok' => true, 'content' => trim($content)];
        } catch (Throwable $e) {
            Log::warning("[AI GW] Gemini exception: {$e->getMessage()}");
            return ['ok' => false, 'content' => '', 'error' => $e->getMessage()];
        }
    }
}
