<?php

declare(strict_types=1);

namespace App\Services\AI;

use App\Models\Tenant;
use App\Services\Chat\ExternalApiService;
use App\Services\Chat\PdfKnowledgeService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * AiOrchestrator — GPT-4o decides intent, data source, query, and format dynamically.
 * Uses OpenAI function-calling (tools) to let GPT pick the right action.
 * Falls back to TenantRouter's existing pipeline for SQL execution + self-heal.
 */
final class AiOrchestrator
{
    /**
     * Decide what tool/action to use for a user query.
     * Returns a structured decision that TenantRouter can execute.
     *
     * @return array{tool: string, params: array, format_instruction?: string}|null
     */
    public static function decide(
        string $tenantId,
        string $query,
        array $tablesMeta,
        array $conversationHistory = [],
        ?array $externalApiAvailable = null
    ): ?array {
        $tools = self::buildToolDefinitions($tablesMeta, $externalApiAvailable);
        $systemPrompt = self::buildSystemPrompt($tablesMeta);

        $messages = [
            ['role' => 'system', 'content' => $systemPrompt],
        ];

        // Add conversation history for context
        foreach (array_slice($conversationHistory, -5) as $turn) {
            $messages[] = $turn;
        }

        $messages[] = ['role' => 'user', 'content' => $query];

        try {
            $result = self::callWithTools($tenantId, $messages, $tools);
            if ($result === null) return null;

            return $result;
        } catch (Throwable $e) {
            Log::warning('[AI ORCHESTRATOR] decision failed: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Format raw data based on user's original question using GPT.
     */
    public static function formatResponse(
        string $tenantId,
        string $userQuery,
        mixed $rawData,
        ?string $formatInstruction = null,
        bool $webMode = false
    ): ?string {
        $dataStr = is_string($rawData) ? $rawData : json_encode($rawData, JSON_UNESCAPED_UNICODE);

        // Cap data to prevent token overflow
        if (strlen($dataStr) > 15000) {
            $dataStr = mb_substr($dataStr, 0, 15000) . '...(truncated)';
        }

        // Web (dashboard chat panel) vs WhatsApp persona + formatting rules.
        $persona = $webMode
            ? 'You are a helpful, precise data assistant replying inside a web dashboard chat panel.'
            : 'You are a warm, conversational WhatsApp business assistant.';
        $generalRules = $webMode
            ? "- Use standard Markdown: **bold** for key values, `-`/`1.` for lists, `[label](url)` for links\n- Speak directly and naturally to the user\n- Respond in the same language the user used\n- Only output the formatted message, no extra commentary"
            : "- Use WhatsApp *bold* (not markdown **bold**)\n- Speak directly and naturally to the user\n- Respond in the same language the user used\n- Only output the formatted message, no extra commentary";

        if ($formatInstruction && str_contains($formatInstruction, 'CRITICAL CUSTOM FORMAT')) {
            // Tenant has a custom format — make it the primary instruction
            $system = "{$persona} Format the data EXACTLY as instructed below. Do NOT deviate from this format.\n{$formatInstruction}\n\nGeneral rules:\n{$generalRules}";
        } else {
            // Check if tenant has custom format even when orchestrator didn't pass it
            $tenantFormat = \App\Models\TenantPrompt::getFormatInstruction($tenantId, $webMode);
            if ($tenantFormat) {
                $system = "{$persona} Format the data EXACTLY as instructed below. Do NOT deviate from this format.\n{$tenantFormat}" . ($formatInstruction ? "\n\nAdditional hint: {$formatInstruction}" : "") . "\n\nGeneral rules:\n{$generalRules}";
            } elseif ($webMode) {
                $system = "{$persona} Format the data to answer the user's question precisely.\n\nRules:\n- Respond in a clear, helpful tone (e.g., 'Here is the information I found...', 'As requested, here is the total...') rather than a dry list.\n- Use standard Markdown: **bold** for key values, `-`/`1.` for lists, `[label](url)` for links\n- Only include fields/data the user asked about\n- If user said 'without X' or 'only Y', strictly follow that\n- Respond in the same language the user used\n- Be concise but complete\n- Number items in lists\n- Add a brief summary/total at the end if applicable\n- Do NOT add robotic commentary or explanations";
                if ($formatInstruction) {
                    $system .= "\n\nAdditional instruction: {$formatInstruction}";
                }
            } else {
                $system = "{$persona} Format the data to answer the user's question precisely.\n\nRules:\n- Respond in a warm, polite, and helpful tone (e.g., use phrases like 'Here is the information I found...', 'As requested, here is the total...') rather than a dry list.\n- Use WhatsApp formatting: *bold* for key values, emojis as bullets\n- Only include fields/data the user asked about\n- If user said 'without X' or 'only Y', strictly follow that\n- Respond in the same language the user used\n- Be concise but complete\n- Number items in lists\n- Add a brief summary/total at the end if applicable\n- Do NOT add robotic commentary or explanations";
                if ($formatInstruction) {
                    $system .= "\n\nAdditional instruction: {$formatInstruction}";
                }
            }
        }

        $messages = [
            ['role' => 'system', 'content' => $system],
            ['role' => 'user', 'content' => "User's question: \"{$userQuery}\"\n\nData:\n{$dataStr}"],
        ];

        $result = AiGateway::chat($tenantId, $messages, ['max_tokens' => 3000, 'timeout' => 15]);
        if ($result['ok'] && !empty($result['content'])) {
            return $result['content'];
        }

        return null;
    }

    private static function callWithTools(string $tenantId, array $messages, array $tools): ?array
    {
        $config = self::resolveKey($tenantId);
        if (!$config) return null;

        $body = [
            'model'       => 'gpt-4o-mini',
            'messages'    => $messages,
            'tools'       => $tools,
            'tool_choice' => 'auto',
            'temperature' => 0,
        ];

        $resp = \Illuminate\Support\Facades\Http::withToken($config['key'])
            ->timeout(20)
            ->post('https://api.openai.com/v1/chat/completions', $body);

        if (!$resp->ok()) {
            Log::warning('[AI ORCHESTRATOR] API error: ' . $resp->status());
            return null;
        }

        $data = $resp->json();
        $choice = $data['choices'][0] ?? null;
        if (!$choice) return null;

        $msg = $choice['message'] ?? [];

        // If GPT chose a tool call
        $toolCalls = $msg['tool_calls'] ?? [];
        if (!empty($toolCalls)) {
            $call = $toolCalls[0]; // Take first tool call
            $fn = $call['function'] ?? [];
            $name = $fn['name'] ?? '';
            $args = json_decode($fn['arguments'] ?? '{}', true) ?: [];

            return [
                'tool'   => $name,
                'params' => $args,
                'format_instruction' => $args['format_instruction'] ?? null,
            ];
        }

        // GPT chose to respond directly (no tool needed)
        $content = $msg['content'] ?? '';
        if ($content) {
            return [
                'tool'   => 'direct_answer',
                'params' => ['answer' => $content],
            ];
        }

        return null;
    }

    private static function resolveKey(string $tenantId): ?array
    {
        // Try tenant's own key first
        $tenant = Tenant::query()->select(['ai_api_key', 'ai_vendor'])->find($tenantId);
        if ($tenant && $tenant->ai_api_key) {
            try {
                $key = \Illuminate\Support\Facades\Crypt::decryptString($tenant->ai_api_key);
                return ['key' => $key, 'vendor' => $tenant->ai_vendor ?? 'openai'];
            } catch (Throwable $e) {
                // Try as plain key
                return ['key' => $tenant->ai_api_key, 'vendor' => $tenant->ai_vendor ?? 'openai'];
            }
        }

        // Fallback to .env key
        $key = config('mis.openai_api_key', '');
        if ($key) return ['key' => $key, 'vendor' => 'openai'];

        return null;
    }

    private static function buildSystemPrompt(array $tablesMeta): string
    {
        $tables = $tablesMeta['tabs'] ?? $tablesMeta;
        $schemaDesc = "Available database tables:\n";
        foreach ($tables as $tab) {
            $name = $tab['pg_table'] ?? $tab['source_name'] ?? 'unknown';
            $cols = array_map(fn($c) => ($c['pg_column'] ?? $c['name'] ?? '') . ' (' . ($c['pg_type'] ?? 'text') . ')', $tab['columns'] ?? []);
            $schemaDesc .= "- {$name}: " . implode(', ', array_slice($cols, 0, 20)) . "\n";
        }

        return "You are an intelligent data assistant. Based on the user's question, decide which tool to use.\n\n{$schemaDesc}\n\nDecision rules:\n- For data queries (sales, expenses, amounts, counts, lists from database) → use 'query_database'\n- For delegation/checklist/call logs/leads/visiting cards → use 'query_external_api'\n- For questions about company SOPs, policies, website content → use 'search_knowledge'\n- For calendar/meeting/scheduling → use 'manage_calendar'\n- For ledger/khata/account statements → use 'get_ledger'\n- For charts/graphs/visuals → use 'query_database' with chart format\n- Treat short follow-ups to your OWN previous question (e.g. 'both', 'one by one', 'in table form', 'yes', a table/column name you just asked about) as a continuation of that data request → use 'query_database' (or the relevant data tool), NEVER answer them directly.\n- Only respond directly (no tool) for pure greetings, thanks/small talk, or when you must ask the user a genuine clarifying question. Never respond directly to anything that references records, amounts, balances, tables, or 'data' in any form.\n\nCRITICAL: You must NEVER invent, fabricate, guess, or use placeholder/sample/dummy/example data or numbers. If you do not have real data, you MUST call a tool to fetch it — do not answer with made-up rows, names, or figures under any circumstance.\n\nAlways include a 'format_instruction' that tells how to present the result based on what the user asked. For example if user says 'without timestamp', include 'exclude timestamp fields'. If user says 'in Hindi', include 'respond in Hindi'.";
    }

    private static function buildToolDefinitions(array $tablesMeta, ?array $externalApis): array
    {
        $tables = $tablesMeta['tabs'] ?? $tablesMeta;
        $tableNames = array_map(fn($t) => $t['pg_table'] ?? $t['source_name'] ?? '', $tables);

        $tools = [
            [
                'type' => 'function',
                'function' => [
                    'name' => 'query_database',
                    'description' => 'Query the connected MySQL database for business data (sales, expenses, invoices, customers, items, receipts, etc.)',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'intent' => [
                                'type' => 'string',
                                'description' => 'What the user wants: aggregate (total/count/average), list (show records), compare (two periods/entities), or filter (specific criteria)',
                            ],
                            'natural_query' => [
                                'type' => 'string',
                                'description' => 'Clean rephrased version of user query for SQL generation',
                            ],
                            'format_instruction' => [
                                'type' => 'string',
                                'description' => 'How to format the response. E.g., "exclude task_id and timestamp", "show only name and amount", "respond in Hindi", "summarize briefly"',
                            ],
                            'chart_type' => [
                                'type' => 'string',
                                'enum' => ['none', 'bar', 'pie', 'line', 'doughnut'],
                                'description' => 'If user wants a visual/chart/graph, specify type. Otherwise "none"',
                            ],
                        ],
                        'required' => ['intent', 'natural_query', 'format_instruction'],
                    ],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'query_external_api',
                    'description' => 'Query external business APIs for delegation tasks, checklist, call logs, leads, visiting cards, follow-ups',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'api_type' => [
                                'type' => 'string',
                                'enum' => ['delegation', 'checklist', 'call', 'lead', 'follow', 'visiting'],
                                'description' => 'Which API to query',
                            ],
                            'format_instruction' => [
                                'type' => 'string',
                                'description' => 'How to format the result. E.g., "show only pending tasks with assignee names", "exclude timestamps"',
                            ],
                        ],
                        'required' => ['api_type', 'format_instruction'],
                    ],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'search_knowledge',
                    'description' => 'Search indexed PDFs and website content for company information, SOPs, policies, product details',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'search_query' => [
                                'type' => 'string',
                                'description' => 'What to search for in the knowledge base',
                            ],
                        ],
                        'required' => ['search_query'],
                    ],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'manage_calendar',
                    'description' => 'Book, view, cancel, or reschedule meetings/appointments on Google Calendar',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'action' => [
                                'type' => 'string',
                                'enum' => ['book', 'view', 'cancel', 'reschedule'],
                                'description' => 'Calendar action to perform',
                            ],
                            'details' => [
                                'type' => 'string',
                                'description' => 'Full natural language details for the calendar action',
                            ],
                        ],
                        'required' => ['action', 'details'],
                    ],
                ],
            ],
            [
                'type' => 'function',
                'function' => [
                    'name' => 'get_ledger',
                    'description' => 'Get account ledger/khata/statement for a specific party/person/company',
                    'parameters' => [
                        'type' => 'object',
                        'properties' => [
                            'party_name' => [
                                'type' => 'string',
                                'description' => 'Name of the party/person/company whose ledger to fetch',
                            ],
                        ],
                        'required' => ['party_name'],
                    ],
                ],
            ],
        ];

        return $tools;
    }
}
