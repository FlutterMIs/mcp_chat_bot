<?php

declare(strict_types=1);

namespace App\Services\AI;

/**
 * DisambiguationService — heuristic detection of ambiguous terms in user queries.
 * Returns a clarification question if ambiguity is detected, null otherwise.
 */
final class DisambiguationService
{
    private static array $amountKeywords = ['amount', 'amt', 'total_amount', 'amount_with_gst', 'taxable_value', 'with_gst_amount', 'net_amount'];
    private static array $dateKeywords = ['date', 'c_date', 'invoice_date', 'bill_date', 'due_date', 'payment_date', 'order_date', 'delivery_date'];

    /**
     * Check if the query has ambiguous terms given the table schema.
     *
     * @param  string  $query  User's natural language query
     * @param  array  $tablesMeta  tables_metadata array
     * @return string|null  Clarification question or null
     */
    public static function check(string $query, array $tablesMeta): ?string
    {
        $q = mb_strtolower(trim($query));
        $allColumns = self::extractAllColumns($tablesMeta);

        // Check amount ambiguity — only when user SPECIFICALLY asks about "amount" alone without clear context
        if (preg_match('/\b(amount|amt)\b/i', $q) && !preg_match('/\b(sales|total|net|gst|pending|received|taxable)\s*(amount|amt)\b/i', $q) && !preg_match('/\b(amount|amt)\s*(with|without|before|after|including)\b/i', $q)) {
            $amountCols = array_filter($allColumns, fn($c) => preg_match('/amount|amt|total_amount|amount_with_gst|taxable_value|with_gst|net_amount/i', $c));
            if (count($amountCols) > 1) {
                $options = implode(', ', array_unique(array_values($amountCols)));
                return "Amount ka matlab: {$options} — kaunsa amount chahiye? (e.g. total amount, taxable value, amount with GST)";
            }
        }

        // Check date ambiguity
        if (preg_match('/\bdate\b|\btarikh\b|\bkab\b/', $q) && !preg_match('/this month|last month|today|yesterday|aaj|kal|is mahine|pichle/i', $q)) {
            $dateCols = array_filter($allColumns, fn($c) => preg_match('/date/i', $c) && !preg_match('/_actual$/', $c));
            if (count($dateCols) > 1) {
                $options = implode(', ', array_unique(array_values($dateCols)));
                return "Multiple date columns available: {$options} — kaunsi date se filter karna hai?";
            }
        }

        // Check table ambiguity — query term matches multiple table names
        $tableNames = array_map(fn($t) => mb_strtolower($t['source_name'] ?? $t['pg_table'] ?? ''), $tablesMeta);
        $words = preg_split('/\s+/', $q);
        foreach ($words as $w) {
            if (strlen($w) < 4) continue;
            $matching = array_filter($tableNames, fn($t) => str_contains($t, $w));
            if (count($matching) > 1) {
                $opts = implode(', ', array_values($matching));
                return "'{$w}' multiple tables me hai: {$opts} — kaunsi table se data chahiye?";
            }
        }

        return null;
    }

    /**
     * Structured version of the "table ambiguity" branch of check() — returns the
     * matched keyword + the full candidate table metadata (not just names), so a
     * caller can persist a pending-disambiguation state and later run a real query
     * against whichever table(s) the user picks.
     *
     * @param  array  $tablesMeta  tables_metadata array
     * @return array{term: string, tables: list<array<string, mixed>>}|null
     */
    public static function checkTables(string $query, array $tablesMeta): ?array
    {
        $q = mb_strtolower(trim($query));
        $words = preg_split('/\s+/', $q) ?: [];

        foreach ($words as $w) {
            if (strlen($w) < 4) continue;
            $matches = [];
            foreach ($tablesMeta as $t) {
                $name = mb_strtolower((string) ($t['source_name'] ?? $t['pg_table'] ?? ''));
                if ($name !== '' && str_contains($name, $w)) {
                    $matches[] = $t;
                }
            }
            if (count($matches) > 1) {
                return ['term' => $w, 'tables' => $matches];
            }
        }

        return null;
    }

    /**
     * Extract all column pg_names from tables metadata.
     */
    private static function extractAllColumns(array $tablesMeta): array
    {
        $cols = [];
        foreach ($tablesMeta as $t) {
            foreach (($t['columns'] ?? []) as $c) {
                $name = $c['pg_name'] ?? '';
                if ($name !== '' && ($c['role'] ?? '') !== 'date_actual') {
                    $cols[] = $name;
                }
            }
        }
        return $cols;
    }
}
