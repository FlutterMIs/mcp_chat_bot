<?php

declare(strict_types=1);

namespace App\Services\AI;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

final class ResultValidator
{
    public static function validate(array $rows, string $query, string $sql, array $tablesMeta): array
    {
        $ok = ['valid' => true, 'issue' => null, 'suggestion' => null];

        // Extract table name from SQL
        $table = self::extractTable($sql);
        if (!$table) return $ok;

        // Check: zero rows but table has data
        if (count($rows) === 0) {
            if (self::tableHasData($table)) {
                return ['valid' => false, 'issue' => 'zero_rows_nonempty_table', 'suggestion' => 'Retry with different column or looser filter'];
            }
            return $ok;
        }

        // Check: single aggregate = 0
        if (count($rows) === 1) {
            $row = is_object($rows[0]) ? get_object_vars($rows[0]) : (array) $rows[0];
            if (count($row) <= 2) {
                foreach ($row as $v) {
                    if ($v !== null && is_numeric($v) && (float) $v === 0.0 && self::tableHasData($table)) {
                        return ['valid' => false, 'issue' => 'aggregate_zero', 'suggestion' => 'Try alternative amount column (e.g. taxable_value instead of amount_with_gst)'];
                    }
                }
            }
        }

        // Check: type mismatch — user asked count but got SUM
        $lq = mb_strtolower($query);
        $asksCount = (bool) preg_match('/\b(kitne|kitni|how many|count|number of|total number)\b/i', $lq);
        if ($asksCount && count($rows) === 1) {
            $row = is_object($rows[0]) ? get_object_vars($rows[0]) : (array) $rows[0];
            $val = reset($row);
            if (is_numeric($val) && (float) $val > 1000 && preg_match('/\bSUM\b/i', $sql)) {
                return ['valid' => false, 'issue' => 'type_mismatch_count_vs_sum', 'suggestion' => 'Use COUNT instead of SUM'];
            }
        }

        return $ok;
    }

    public static function retryWithAlternative(string $sql, array $tablesMeta, string $issue): ?string
    {
        switch ($issue) {
            case 'aggregate_zero':
                // Swap amount columns. Word-boundary matched (not stripos/str_ireplace
                // substring matching) so a column like `discount_amount` or `sale_amount`
                // doesn't get its "amount" substring corrupted into
                // `discounttaxable_value` — \b doesn't fire inside a snake_case identifier
                // since `_` is a word character, but WOULD fire inside a bare `amount`
                // that isn't part of a longer identifier.
                $swaps = [
                    'amount_with_gst' => 'taxable_value',
                    'taxable_value' => 'amount_with_gst',
                    'total_amount' => 'net_amount',
                    'net_amount' => 'total_amount',
                    'amount' => 'taxable_value',
                ];
                foreach ($swaps as $from => $to) {
                    $pattern = '/\b' . preg_quote($from, '/') . '\b/i';
                    if (preg_match($pattern, $sql)) {
                        return preg_replace($pattern, $to, $sql);
                    }
                }
                return null;

            case 'type_mismatch_count_vs_sum':
                // Replace SUM(...) with COUNT(DISTINCT ...)
                $rewritten = preg_replace('/SUM\(([^)]+)\)/i', 'COUNT(DISTINCT $1)', $sql);
                return $rewritten !== $sql ? $rewritten : null;

            case 'zero_rows_nonempty_table':
                // Loosen LIKE patterns
                if (preg_match("/(LIKE\s+'%[^']+%')/i", $sql)) {
                    // Already has wildcards, try removing date filters
                    $rewritten = preg_replace('/\s+AND\s+\w+_actual\s*(>=|<=|=|<|>)\s*[^\s)]+/i', '', $sql);
                    return $rewritten !== $sql ? $rewritten : null;
                }
                return null;

            default:
                return null;
        }
    }

    private static function extractTable(string $sql): ?string
    {
        if (preg_match('/\bFROM\s+[`"]?(\w+)[`"]?/i', $sql, $m)) {
            return $m[1];
        }
        return null;
    }

    private static function tableHasData(string $table): bool
    {
        try {
            $result = DB::select("SELECT 1 FROM `{$table}` LIMIT 1");
            return count($result) > 0;
        } catch (\Throwable) {
            return false;
        }
    }
}
