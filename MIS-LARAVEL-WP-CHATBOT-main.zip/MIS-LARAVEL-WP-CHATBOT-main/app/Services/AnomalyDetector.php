<?php

declare(strict_types=1);

namespace App\Services;

/**
 * AnomalyDetector — z-score-based outlier detection on KPI sparkline arrays.
 *
 * Port of Node helpers/anomaly.js (Phase 22 Sprint 3B). Pure static methods,
 * no DB / state. Used by DashboardEngine to flag KPIs whose latest value
 * deviates significantly from the trailing-window mean.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/anomaly.js
 */
final class AnomalyDetector
{
    /**
     * Detect anomaly on the LAST point of a sparkline.
     *
     * @param  array<int|float>  $sparkline  daily values, oldest → newest
     * @param  array{threshold?: float, minPoints?: int}  $opts
     * @return array{flagged: bool, sigma: float, reason: string, last: float, mean: float, std: float}|null
     *         null when the sparkline is too short to produce a reliable signal.
     */
    public static function detect(array $sparkline, array $opts = []): ?array
    {
        $minPoints = $opts['minPoints'] ?? 7;
        if (count($sparkline) < $minPoints) {
            return null;
        }

        $threshold = $opts['threshold'] ?? 2.0;

        // Sanitize: cast to float, replace non-numeric / NaN with 0
        $arr = array_map(static fn ($v) => is_numeric($v) ? (float) $v : 0.0, $sparkline);
        $last = $arr[count($arr) - 1];

        // Reference set: all points EXCEPT the last (we judge the last vs prior pattern)
        $ref = array_slice($arr, 0, -1);
        $mu  = self::mean($ref);
        $std = self::stdDev($ref, $mu);

        if ($std === 0.0) {
            // Flat history — only flag if last differs
            if ($last !== $mu) {
                return [
                    'flagged' => true,
                    'sigma'   => INF,
                    'reason'  => 'today ('.self::fmt($last).') breaks a flat history of '.self::fmt($mu),
                    'last'    => $last,
                    'mean'    => $mu,
                    'std'     => 0.0,
                ];
            }

            return [
                'flagged' => false,
                'sigma'   => 0.0,
                'reason'  => 'flat history',
                'last'    => $last,
                'mean'    => $mu,
                'std'     => 0.0,
            ];
        }

        $sigma    = ($last - $mu) / $std;
        $absSigma = abs($sigma);

        // Special case: today is 0 but every prior day was non-zero — flag it
        // even if sigma calculation is misleading (could be load-time-of-day effect)
        $allHistoryNonZero = ! empty($ref) && array_reduce($ref, static fn ($c, $v) => $c && $v > 0, true);
        if ($last === 0.0 && $allHistoryNonZero && $mu > 0) {
            return [
                'flagged' => true,
                'sigma'   => -INF,
                'reason'  => 'today is zero — no activity recorded',
                'last'    => $last,
                'mean'    => $mu,
                'std'     => $std,
            ];
        }

        if ($absSigma >= $threshold) {
            $dir = $sigma > 0 ? 'above' : 'below';

            return [
                'flagged' => true,
                'sigma'   => $sigma,
                'reason'  => sprintf(
                    'today is %.1fσ %s the %d-day average',
                    $absSigma,
                    $dir,
                    count($ref)
                ),
                'last'    => $last,
                'mean'    => $mu,
                'std'     => $std,
            ];
        }

        return [
            'flagged' => false,
            'sigma'   => $sigma,
            'reason'  => 'within normal range',
            'last'    => $last,
            'mean'    => $mu,
            'std'     => $std,
        ];
    }

    /** @param  array<int|float>  $arr */
    public static function mean(array $arr): float
    {
        $n = count($arr);
        if ($n === 0) {
            return 0.0;
        }

        return array_sum($arr) / $n;
    }

    /**
     * Sample standard deviation (n-1 divisor — matches Node implementation).
     *
     * @param  array<int|float>  $arr
     */
    public static function stdDev(array $arr, ?float $precomputedMean = null): float
    {
        $n = count($arr);
        if ($n < 2) {
            return 0.0;
        }

        $mu = $precomputedMean ?? self::mean($arr);
        $sumSq = 0.0;
        foreach ($arr as $v) {
            $d = $v - $mu;
            $sumSq += $d * $d;
        }

        return sqrt($sumSq / ($n - 1));
    }

    /** Indian-currency formatter for human-readable anomaly reasons. */
    private static function fmt(float $n): string
    {
        if (! is_finite($n)) {
            return '—';
        }
        $abs = abs($n);
        if ($abs >= 1e7) {
            return '₹'.number_format($n / 1e7, 2).' Cr';
        }
        if ($abs >= 1e5) {
            return '₹'.number_format($n / 1e5, 2).' L';
        }
        if ($abs >= 1e3) {
            return '₹'.number_format($n / 1e3, 2).' K';
        }

        return (string) (int) round($n);
    }
}
