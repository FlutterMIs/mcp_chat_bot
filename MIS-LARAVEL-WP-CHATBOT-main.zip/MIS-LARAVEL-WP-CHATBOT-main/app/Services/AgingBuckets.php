<?php

declare(strict_types=1);

namespace App\Services;

use Carbon\CarbonImmutable;

/**
 * AgingBuckets — pure outstanding-aging classifier.
 *
 * Slides rows of {amount, date, party?} into 4 age buckets:
 *   0-30 / 31-60 / 61-90 / 90+
 *
 * Used by /api/page/outstanding to summarise unpaid invoices. Pure static
 * methods — no DB, no I/O, trivially unit-testable.
 *
 * Port of Node helpers/aging-buckets.js.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/aging-buckets.js
 */
final class AgingBuckets
{
    public const BUCKETS = ['0-30', '31-60', '61-90', '90+'];

    /**
     * Classify a single age-in-days into a bucket label.
     * Negative or non-numeric ages collapse to '0-30'.
     */
    public static function bucketOf(int|float|null $days): string
    {
        if (! is_finite((float) $days) || $days < 0) {
            return '0-30';
        }
        if ($days <= 30) return '0-30';
        if ($days <= 60) return '31-60';
        if ($days <= 90) return '61-90';

        return '90+';
    }

    /**
     * Compute aging summary across an array of rows.
     *
     * @param  iterable<array<string, mixed>|object>  $rows
     * @return array{
     *     buckets: array<string, float>,
     *     counts:  array<string, int>,
     *     total:   float,
     *     totalCount: int,
     *     asOf:    string,
     *     oldest:  array{age: int, amount: float, party: ?string}|null,
     * }
     */
    public static function compute(iterable $rows, string|null $asOf = null): array
    {
        $ref = $asOf ? CarbonImmutable::parse($asOf) : CarbonImmutable::today();
        $refMs = $ref->getTimestampMs();

        $buckets = ['0-30' => 0.0, '31-60' => 0.0, '61-90' => 0.0, '90+' => 0.0];
        $counts  = ['0-30' => 0,   '31-60' => 0,   '61-90' => 0,   '90+' => 0];
        $total = 0.0;
        $totalCount = 0;
        $oldest = null;

        foreach ($rows as $r) {
            $row = is_object($r) ? get_object_vars($r) : $r;
            $amount = (float) ($row['amount'] ?? 0);
            if ($amount <= 0) {
                continue;
            }

            $dateStr = (string) ($row['date'] ?? '');
            try {
                $d = $dateStr !== '' ? CarbonImmutable::parse($dateStr) : null;
            } catch (\Throwable) {
                continue;
            }
            if ($d === null) {
                continue;
            }

            $ageDays = (int) floor(($refMs - $d->getTimestampMs()) / 86_400_000);
            $b = self::bucketOf($ageDays);
            $buckets[$b] += $amount;
            $counts[$b]  += 1;
            $total += $amount;
            $totalCount += 1;

            if ($oldest === null || $ageDays > $oldest['age']) {
                $oldest = [
                    'age'    => $ageDays,
                    'amount' => $amount,
                    'party'  => isset($row['party']) ? (string) $row['party'] : null,
                ];
            }
        }

        // Round bucket sums to 2 dp for cleaner display
        foreach (self::BUCKETS as $k) {
            $buckets[$k] = round($buckets[$k], 2);
        }

        return [
            'buckets'    => $buckets,
            'counts'     => $counts,
            'total'      => round($total, 2),
            'totalCount' => $totalCount,
            'asOf'       => $ref->toDateString(),
            'oldest'     => $oldest,
        ];
    }

    /**
     * Group rows by party with their total outstanding + bucket distribution.
     * Used for the "Top Defaulters" view.
     *
     * @param  iterable<array<string, mixed>|object>  $rows
     * @return list<array{
     *     party: string,
     *     total: float,
     *     count: int,
     *     oldest_age: int,
     *     buckets: array<string, float>,
     * }>
     */
    public static function topDefaulters(iterable $rows, string|null $asOf = null, int $limit = 10): array
    {
        $ref = $asOf ? CarbonImmutable::parse($asOf) : CarbonImmutable::today();
        $refMs = $ref->getTimestampMs();
        $byParty = [];

        foreach ($rows as $r) {
            $row = is_object($r) ? get_object_vars($r) : $r;
            $amount = (float) ($row['amount'] ?? 0);
            if ($amount <= 0) {
                continue;
            }

            $party = trim((string) ($row['party'] ?? ''));
            if ($party === '' || $party === 'NA') {
                continue;
            }

            $dateStr = (string) ($row['date'] ?? '');
            try {
                $d = $dateStr !== '' ? CarbonImmutable::parse($dateStr) : null;
            } catch (\Throwable) {
                continue;
            }
            if ($d === null) {
                continue;
            }

            $ageDays = (int) floor(($refMs - $d->getTimestampMs()) / 86_400_000);

            if (! isset($byParty[$party])) {
                $byParty[$party] = [
                    'party'      => $party,
                    'total'      => 0.0,
                    'count'      => 0,
                    'oldest_age' => 0,
                    'buckets'    => ['0-30' => 0.0, '31-60' => 0.0, '61-90' => 0.0, '90+' => 0.0],
                ];
            }
            $e = &$byParty[$party];
            $e['total'] += $amount;
            $e['count'] += 1;
            if ($ageDays > $e['oldest_age']) {
                $e['oldest_age'] = $ageDays;
            }
            $e['buckets'][self::bucketOf($ageDays)] += $amount;
            unset($e);
        }

        // Round + sort + truncate
        $out = array_values($byParty);
        foreach ($out as &$e) {
            $e['total'] = round($e['total'], 2);
            foreach ($e['buckets'] as $k => $v) {
                $e['buckets'][$k] = round($v, 2);
            }
        }
        unset($e);

        usort($out, static fn ($a, $b) => $b['total'] <=> $a['total']);

        return array_slice($out, 0, $limit);
    }
}
