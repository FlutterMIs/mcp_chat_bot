<?php

declare(strict_types=1);

namespace App\Services\Dashboard;

use Carbon\CarbonImmutable;

/**
 * DateRange — convert a range label ('today' | 'week' | 'month' | 'quarter' |
 * 'year' | 'all') into a {from, to, label} window, plus compute the matching
 * previous window of equal length for delta_pct comparison.
 *
 * Port of Node helpers/dashboard-engine.js → computeDateRange + previousRange.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/dashboard-engine.js
 */
final class DateRange
{
    /**
     * @return array{from: ?string, to: ?string, label: string}
     *         from/to are ISO YYYY-MM-DD strings or null for the 'all' range.
     */
    public static function compute(string $range = 'month'): array
    {
        $range = strtolower(trim($range));

        if ($range === 'all') {
            return ['from' => null, 'to' => null, 'label' => 'All-time'];
        }

        $today = CarbonImmutable::today();
        $start = match ($range) {
            'today'   => $today,
            'week'    => $today->subDays(6),
            'month'   => $today->subDays(29),
            'quarter' => $today->subDays(89),
            'year'    => $today->subDays(364),
            default   => $today->subDays(29), // unknown → default to month
        };

        return [
            'from'  => $start->toDateString(),
            'to'    => $today->toDateString(),
            'label' => $range,
        ];
    }

    /**
     * Compute the equal-length window immediately preceding the given range.
     *
     * @param  array{from: ?string, to: ?string, label?: string}  $dr
     * @return array{from: ?string, to: ?string}
     */
    public static function previous(array $dr): array
    {
        if (empty($dr['from']) || empty($dr['to'])) {
            return ['from' => null, 'to' => null];
        }

        $from = CarbonImmutable::parse($dr['from'])->startOfDay();
        $to   = CarbonImmutable::parse($dr['to'])->startOfDay();
        $days = $from->diffInDays($to) + 1;

        $prevTo   = $from->subDay();
        $prevFrom = $prevTo->subDays($days - 1);

        return [
            'from' => $prevFrom->toDateString(),
            'to'   => $prevTo->toDateString(),
        ];
    }
}
