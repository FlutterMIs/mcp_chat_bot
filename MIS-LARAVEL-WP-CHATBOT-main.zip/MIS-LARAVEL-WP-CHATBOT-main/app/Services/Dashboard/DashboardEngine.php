<?php

declare(strict_types=1);

namespace App\Services\Dashboard;

use App\Models\Tenant;
use App\Services\AnomalyDetector;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * DashboardEngine — main orchestrator that produces a dashboard payload for
 * any tenant given their tables_metadata.
 *
 * Reads tenant.tables_metadata, classifies each table by role, resolves the
 * best column per role, picks widgets the data can support, and runs each
 * widget's SQL sequentially (Postgres connection pool — sequential is fast).
 *
 * Public API:
 *   DashboardEngine::build(string $tenantId, array $opts = ['range' => 'month']): array
 *
 * Returns:
 *   {
 *     tenant:        { id, name },
 *     range:         label,
 *     date_range:    { from, to, label },
 *     prev_range:    { from, to },
 *     detected_roles: [...],
 *     widgets:       [ { id, kind, chartKind, title, accent, icon, ok, data, error } ],
 *     generated_at:  ISO timestamp,
 *     elapsed_ms:    ?int (set by caller / controller)
 *   }
 *
 * Port of Node helpers/dashboard-engine.js → buildDashboard + runWidget.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/dashboard-engine.js
 */
final class DashboardEngine
{
    /** @param  array{range?: string}  $opts */
    public static function build(string $tenantId, array $opts = []): array
    {
        // 1. Load tenant
        $tenant = Tenant::query()
            ->select(['id', 'name', 'phone', 'tables_metadata', 'schema_json'])
            ->where('id', $tenantId)
            ->first();

        if (! $tenant) {
            return ['error' => 'Tenant not found', 'widgets' => []];
        }

        $tablesMeta = $tenant->tables_metadata ?? [];
        if (! is_array($tablesMeta) || count($tablesMeta) === 0) {
            return [
                'tenant'  => ['id' => $tenant->id, 'name' => $tenant->name],
                'widgets' => [],
                'empty'   => true,
                'message' => 'No data tables yet. Sync your sheet to populate the dashboard.',
            ];
        }

        // 2. Classify each tenant table + resolve columns per role
        // When two tables map to the same role, keep the one with more rows.
        $roles = [];
        foreach ($tablesMeta as $meta) {
            $kind = TableClassifier::classify($meta);
            if ($kind === 'other') {
                continue;
            }
            $cols = TableClassifier::resolveColumns($meta, $kind);
            $rowCount = (int) ($meta['row_count'] ?? 0);

            if (! isset($roles[$kind]) || $rowCount > (int) ($roles[$kind]['table']['row_count'] ?? 0)) {
                $roles[$kind] = ['table' => $meta, 'cols' => $cols];
            }
        }

        // 3. Compute date ranges
        $dr     = DateRange::compute($opts['range'] ?? 'month');
        $prevDr = DateRange::previous($dr);

        // 4. Pick widgets that can be built (sorted by priority desc)
        $candidates = array_filter(
            WidgetCatalog::all(),
            static fn (array $w): bool => self::safeRequires($w, $roles)
        );
        usort($candidates, static fn (array $a, array $b): int => ($b['priority'] ?? 0) <=> ($a['priority'] ?? 0));

        // KPI cap (4 most relevant) — charts/tables uncapped
        $kpis   = array_slice(array_values(array_filter($candidates, static fn ($w) => $w['kind'] === 'kpi')), 0, 4);
        $charts = array_values(array_filter($candidates, static fn ($w) => $w['kind'] === 'chart'));
        $tables = array_values(array_filter($candidates, static fn ($w) => $w['kind'] === 'table'));
        $widgets = array_merge($kpis, $charts, $tables);

        // 5. Run each widget sequentially (Postgres pool is fast for sequential queries)
        $results = [];
        foreach ($widgets as $w) {
            $results[] = self::runWidget($w, $roles, $dr, $prevDr);
        }

        // 6. Shape final payload
        $shaped = [];
        foreach ($widgets as $i => $w) {
            $shaped[] = [
                'id'        => $w['id'],
                'kind'      => $w['kind'],
                'chartKind' => $w['chartKind'] ?? null,
                'title'     => $w['title'],
                'accent'    => $w['accent'] ?? null,
                'icon'      => $w['icon'] ?? null,
                'ok'        => $results[$i]['ok'],
                'data'      => $results[$i]['data'] ?? null,
                'error'     => $results[$i]['error'] ?? null,
            ];
        }

        return [
            'tenant'         => ['id' => $tenant->id, 'name' => $tenant->name],
            'range'          => $dr['label'],
            'date_range'     => $dr,
            'prev_range'     => $prevDr,
            'detected_roles' => array_keys($roles),
            'widgets'        => $shaped,
            'generated_at'   => CarbonImmutable::now('UTC')->toIso8601String(),
        ];
    }

    /**
     * Defensive wrapper around widget->requires(), returns false on any throwable.
     *
     * @param  array<string, mixed>  $widget
     * @param  array<string, mixed>  $roles
     */
    private static function safeRequires(array $widget, array $roles): bool
    {
        try {
            return (bool) ($widget['requires'])($roles);
        } catch (Throwable) {
            return false;
        }
    }

    /**
     * Run a single widget's SQL spec → produce its data payload.
     *
     * @param  array<string, mixed>  $widget
     * @param  array<string, mixed>  $roles
     * @param  array{from: ?string, to: ?string, label: string}  $dr
     * @param  array{from: ?string, to: ?string}  $prevDr
     * @return array{ok: bool, data?: array, error?: string}
     */
    private static function runWidget(array $widget, array $roles, array $dr, array $prevDr): array
    {
        try {
            $spec = ($widget['build'])($roles, $dr, $prevDr);

            $mainRows = self::runSql($spec['sql_main']);

            $prevRows = null;
            if (! empty($spec['sql_prev'])) {
                $prevRows = self::runSqlSafe($spec['sql_prev']);
            }

            $sparkRows = null;
            if (! empty($spec['sql_spark'])) {
                $sparkRows = self::runSqlSafe($spec['sql_spark']);
            }

            return match ($widget['kind']) {
                'kpi'   => self::shapeKpi($spec, $mainRows, $prevRows, $sparkRows, $dr),
                'chart' => self::shapeChart($spec, $mainRows),
                'table' => self::shapeTable($spec, $mainRows),
                default => ['ok' => true, 'data' => ['rows' => $mainRows]],
            };
        } catch (Throwable $e) {
            Log::warning('DashboardEngine widget failed', [
                'widget_id' => $widget['id'] ?? 'unknown',
                'error'     => $e->getMessage(),
            ]);

            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }

    /**
     * @param  array<string, mixed>  $spec
     * @param  list<\stdClass>       $mainRows
     * @param  list<\stdClass>|null  $prevRows
     * @param  list<\stdClass>|null  $sparkRows
     * @param  array{from: ?string, to: ?string}  $dr
     * @return array{ok: true, data: array<string, mixed>}
     */
    private static function shapeKpi(array $spec, array $mainRows, ?array $prevRows, ?array $sparkRows, array $dr): array
    {
        $value = isset($mainRows[0]) ? (float) ($mainRows[0]->v ?? 0) : 0.0;
        $prev  = $prevRows !== null && isset($prevRows[0]) ? (float) ($prevRows[0]->v ?? 0) : null;
        $deltaPct = ($prev !== null && $prev > 0)
            ? (($value - $prev) / $prev) * 100
            : null;

        // Build sparkline + parallel date labels.
        // Pad every day in the range with zero so the chart shows true daily
        // rhythm instead of skipping gap days.
        $spark = null;
        $sparkDates = null;
        if ($sparkRows !== null && ! empty($dr['from']) && ! empty($dr['to'])) {
            $map = [];
            foreach ($sparkRows as $row) {
                $key = substr((string) ($row->day ?? ''), 0, 10);
                if ($key !== '') {
                    $map[$key] = (float) ($row->v ?? 0);
                }
            }
            $spark = [];
            $sparkDates = [];
            $cur = CarbonImmutable::parse($dr['from'].'T00:00:00Z');
            $end = CarbonImmutable::parse($dr['to'].'T00:00:00Z');
            $safety = 400;
            while ($cur->lessThanOrEqualTo($end) && $safety-- > 0) {
                $key = $cur->toDateString();
                $sparkDates[] = $key;
                $spark[] = $map[$key] ?? 0;
                $cur = $cur->addDay();
            }
        } elseif ($sparkRows !== null) {
            $spark      = array_map(static fn ($row) => (float) ($row->v ?? 0), $sparkRows);
            $sparkDates = array_map(static fn ($row) => substr((string) ($row->day ?? ''), 0, 10), $sparkRows);
        }

        return [
            'ok'   => true,
            'data' => [
                'value'           => $value,
                'prev'            => $prev,
                'delta_pct'       => $deltaPct,
                'format'          => $spec['format'] ?? 'num',
                'sparkline'       => $spark,
                'sparkline_dates' => $sparkDates,
                'anomaly'         => $spark !== null
                    ? AnomalyDetector::detect($spark, ['threshold' => 2, 'minPoints' => 7])
                    : null,
            ],
        ];
    }

    /**
     * @param  array<string, mixed>  $spec
     * @param  list<\stdClass>       $mainRows
     * @return array{ok: true, data: array<string, mixed>}
     */
    private static function shapeChart(array $spec, array $mainRows): array
    {
        $transformed = isset($spec['transform']) && is_callable($spec['transform'])
            ? ($spec['transform'])($mainRows)
            : ['labels' => [], 'data' => []];

        return [
            'ok'   => true,
            'data' => array_merge($transformed, ['format' => $spec['format'] ?? 'num']),
        ];
    }

    /**
     * @param  array<string, mixed>  $spec
     * @param  list<\stdClass>       $mainRows
     * @return array{ok: true, data: array<string, mixed>}
     */
    private static function shapeTable(array $spec, array $mainRows): array
    {
        return [
            'ok'   => true,
            'data' => [
                'rows'   => $mainRows,
                'format' => $spec['format'] ?? 'num',
                'meta'   => $spec['meta'] ?? [],
            ],
        ];
    }

    /**
     * Run a SELECT query through Laravel's pgsql connection. Returns list of
     * stdClass rows (matching Node's supabase.rpc('execute_sql') shape — array
     * of objects keyed by aliased column names).
     *
     * @return list<\stdClass>
     */
    private static function runSql(string $sql): array
    {
        return DB::select($sql);
    }

    /**
     * Variant that swallows errors (used for sql_prev + sql_spark — they're
     * optional and a failure shouldn't tank the whole widget).
     *
     * @return list<\stdClass>|null
     */
    private static function runSqlSafe(string $sql): ?array
    {
        try {
            return DB::select($sql);
        } catch (Throwable $e) {
            Log::info('DashboardEngine optional SQL failed', ['sql' => $sql, 'error' => $e->getMessage()]);

            return null;
        }
    }
}
