<?php

declare(strict_types=1);

namespace App\Services\Dashboard;

use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * BriefingService — produce a 3-sentence AI-generated business briefing.
 *
 * Calls OpenAI gpt-4o-mini with a compact summary built from a dashboard
 * payload (KPIs + top customers/items). Result cached for 1 hour per
 * (tenant_id, range) pair.
 *
 * Returns one of:
 *   ['briefing' => string, 'cached' => bool]
 *   ['briefing' => string, 'error' => true]   ← graceful degradation
 *   ['briefing' => string, 'empty' => true]   ← tenant has no data
 *
 * Port of Node server.js → /api/briefing handler + _briefingFromDash helper.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~lines 3556+)
 */
final class BriefingService
{
    /** Cache TTL — 1 hour. Briefing rarely needs fresher than that. */
    private const CACHE_TTL_SECONDS = 3600;

    /** OpenAI request timeout — must beat WhatsApp webhook 20s budget. */
    private const REQUEST_TIMEOUT_SECONDS = 20;

    /**
     * Generate (or fetch cached) briefing for a tenant.
     *
     * @return array<string, mixed>
     */
    public static function generate(string $tenantId, string $range = 'month'): array
    {
        $cacheKey = "briefing:$tenantId:$range";
        $cached = Cache::get($cacheKey);
        if (is_string($cached) && $cached !== '') {
            return ['briefing' => $cached, 'cached' => true];
        }

        // Build dashboard payload first — we summarise from the same data
        // the user is looking at on screen, ensuring the briefing always
        // reflects what's currently rendered.
        $dash = DashboardEngine::build($tenantId, ['range' => $range]);

        if (! empty($dash['empty'])) {
            return [
                'briefing' => $dash['message'] ?? 'No data yet — sync your sheet to populate insights.',
                'empty'    => true,
            ];
        }
        if (! empty($dash['error'])) {
            return [
                'briefing' => 'Briefing unavailable — could not load tenant data.',
                'error'    => true,
            ];
        }

        $summary = self::summariseFromDash($dash);
        $text = self::buildTemplateBriefing($summary);

        Cache::put($cacheKey, $text, self::CACHE_TTL_SECONDS);

        return ['briefing' => $text, 'cached' => false];
    }

    /**
     * Template-based briefing — no AI call needed.
     * Produces a 2-3 sentence summary from dashboard KPIs.
     */
    private static function buildTemplateBriefing(array $summary): string
    {
        $parts = [];
        $tenant = $summary['tenant'] ?? 'Your business';
        $range = $summary['range'] ?? 'month';

        $kpis = $summary['kpis'] ?? [];
        // Headline: total sales
        if (isset($kpis['total_sales']['value'])) {
            $val = $kpis['total_sales']['value'];
            $formatted = self::compactCurrency($val);
            $delta = $kpis['total_sales']['delta_pct'] ?? null;
            $line = "{$tenant}: {$formatted} in sales this {$range}";
            if ($delta !== null && $delta != 0) {
                $dir = $delta > 0 ? '↑' : '↓';
                $line .= " ({$dir}" . abs(round($delta)) . "% vs previous)";
            }
            $parts[] = $line . '.';
        }

        // Outstanding
        if (isset($kpis['outstanding']['value'])) {
            $val = $kpis['outstanding']['value'];
            $parts[] = 'Outstanding: ' . self::compactCurrency($val) . '.';
        }

        // Top customer
        $topCustomers = $summary['top']['customers'] ?? [];
        if (! empty($topCustomers)) {
            $top = $topCustomers[0];
            $parts[] = 'Top customer: ' . ($top['party'] ?? 'N/A') . ' (' . self::compactCurrency($top['total'] ?? 0) . ').';
        }

        return implode(' ', $parts) ?: "{$tenant} dashboard loaded — check your KPIs above for details.";
    }

    private static function compactCurrency($n): string
    {
        $n = (float) $n;
        $abs = abs($n);
        $sign = $n < 0 ? '-' : '';
        if ($abs >= 1e7) return $sign . '₹' . round($abs / 1e7, 2) . ' Cr';
        if ($abs >= 1e5) return $sign . '₹' . round($abs / 1e5, 2) . ' L';
        if ($abs >= 1e3) return $sign . '₹' . round($abs / 1e3, 1) . ' K';
        return $sign . '₹' . round($abs);
    }

    /**
     * Compact LLM-friendly summary of a dashboard payload.
     * Keeps only the fields actually useful for a 3-sentence briefing —
     * no PII risk, no superfluous numbers.
     *
     * @param  array<string, mixed>  $dash
     * @return array<string, mixed>
     */
    private static function summariseFromDash(array $dash): array
    {
        $widgets = array_values(array_filter(
            $dash['widgets'] ?? [],
            static fn ($w) => ! empty($w['ok'])
        ));

        $out = [
            'tenant'    => $dash['tenant']['name']         ?? null,
            'range'     => $dash['range']                  ?? null,
            'date_from' => $dash['date_range']['from']     ?? null,
            'date_to'   => $dash['date_range']['to']       ?? null,
            'prev_from' => $dash['prev_range']['from']     ?? null,
            'prev_to'   => $dash['prev_range']['to']       ?? null,
            'kpis'      => [],
            'top'       => [],
        ];

        foreach ($widgets as $w) {
            if (($w['kind'] ?? null) === 'kpi') {
                $key = str_replace('kpi.', '', (string) ($w['id'] ?? ''));
                $out['kpis'][$key] = [
                    'title'     => $w['title'] ?? null,
                    'value'     => $w['data']['value']      ?? null,
                    'prev'      => $w['data']['prev']       ?? null,
                    'delta_pct' => $w['data']['delta_pct']  ?? null,
                    'format'    => $w['data']['format']     ?? null,
                ];
            } elseif (($w['id'] ?? null) === 'table.top_customers') {
                $rows = $w['data']['rows'] ?? [];
                $out['top']['customers'] = array_map(
                    static fn ($r) => [
                        'party' => $r->party ?? ($r['party'] ?? null),
                        'total' => $r->total ?? ($r['total'] ?? null),
                    ],
                    array_slice($rows, 0, 5)
                );
            } elseif (($w['id'] ?? null) === 'table.top_items') {
                $rows = $w['data']['rows'] ?? [];
                $out['top']['items'] = array_map(
                    static fn ($r) => [
                        'item'  => $r->item  ?? ($r['item']  ?? null),
                        'total' => $r->total ?? ($r['total'] ?? null),
                    ],
                    array_slice($rows, 0, 5)
                );
            }
        }

        return $out;
    }

    private static function buildPrompt(array $summary): string
    {
        $json = json_encode($summary, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);

        return <<<PROMPT
You are a concise business analyst writing a 3-sentence briefing for a tenant's dashboard. Use the JSON below to summarise (1) the headline result for the period, (2) the most notable change vs the previous period, and (3) one observation worth attention (top customer, anomaly, or trend). Use Indian currency formatting (₹ X.XX Cr / L / K). Keep total under 60 words. Reply in plain text, no markdown, no headings, no bullet lists.

DATA:
$json
PROMPT;
    }
}
