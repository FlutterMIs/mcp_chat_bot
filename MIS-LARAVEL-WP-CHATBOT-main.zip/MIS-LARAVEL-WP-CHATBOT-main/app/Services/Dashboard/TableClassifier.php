<?php

declare(strict_types=1);

namespace App\Services\Dashboard;

/**
 * TableClassifier — given a tenant's tables_metadata entry, classifies what
 * the table represents (sales/purchases/outstanding/stock/etc.) and resolves
 * the best column for each role (date, amount, party, item, qty, city, id).
 *
 * Port of Node helpers/dashboard-engine.js → classifyTable + pickColumn +
 * resolveTableColumns. Pure static methods, no DB / state.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/dashboard-engine.js
 */
final class TableClassifier
{
    /**
     * Classify a single tables_metadata entry by role.
     *
     * @param  array{source_name?: string, pg_table?: string, columns?: array<int, array<string, mixed>>}  $meta
     * @return string  one of: sales | purchases | outstanding | payments | stock | ledger | expenses | leads | other
     */
    public static function classify(array $meta): string
    {
        $name = strtolower((string) ($meta['source_name'] ?? $meta['pg_table'] ?? ''));

        if (preg_match('/(^|_)sale|invoic|billing|confirmation/', $name))  return 'sales';
        if (preg_match('/(^|_)purchas|buy|vendor_inv/', $name))           return 'purchases';
        if (preg_match('/outstand|pending|receivab|debt|due|aging/', $name)) return 'outstanding';
        if (preg_match('/payment|collect|remit/', $name))                 return 'payments';
        if (preg_match('/stock|inventor/', $name))                        return 'stock';
        if (preg_match('/ledger|account|^balance$/', $name))              return 'ledger';
        if (preg_match('/expens|cost/', $name))                           return 'expenses';
        if (preg_match('/lead|prospect/', $name))                         return 'leads';

        // Heuristic fallback — date + party + currency = sales
        $cols = $meta['columns'] ?? [];
        $hasDate     = self::anyColumn($cols, fn ($c) => str_contains((string) ($c['role'] ?? ''), 'date'));
        $hasCurrency = self::anyColumn($cols, fn ($c) => ($c['role'] ?? null) === 'currency');
        $hasEntity   = self::anyColumn($cols, fn ($c) => ($c['role'] ?? null) === 'entity');
        if ($hasDate && $hasCurrency && $hasEntity) return 'sales';

        return 'other';
    }

    /**
     * Score-based column picker. Higher score = better fit.
     *
     * @param  array{columns?: array<int, array<string, mixed>>}  $table
     * @param  array{
     *     role?: string,
     *     namesBoost?: array<int, array{0: string, 1: int|float}>,
     *     namesPenalty?: array<int, array{0: string, 1: int|float}>,
     *     requirePgType?: string,
     * }  $spec
     * @return array<string, mixed>|null  the chosen column row, with `_score` key added; null if none qualify
     */
    public static function pickColumn(array $table, array $spec = []): ?array
    {
        $cols = $table['columns'] ?? [];
        $best = null;
        $bestScore = 0;

        foreach ($cols as $c) {
            $score = 0;
            $pg = strtolower((string) ($c['pg_name'] ?? $c['name'] ?? ''));

            if (! empty($spec['role']) && ($c['role'] ?? null) === $spec['role']) {
                $score += 10;
            }

            foreach ($spec['namesBoost'] ?? [] as [$pattern, $pts]) {
                if (preg_match('/'.$pattern.'/', $pg)) {
                    $score += (int) $pts;
                }
            }

            foreach ($spec['namesPenalty'] ?? [] as [$pattern, $pts]) {
                if (preg_match('/'.$pattern.'/', $pg)) {
                    $score -= (int) $pts;
                }
            }

            if (! empty($spec['requirePgType']) && ($c['pg_type'] ?? null) !== $spec['requirePgType']) {
                $score = 0;
            }

            if ($score > $bestScore) {
                $bestScore = $score;
                $best = $c;
            }
        }

        if ($best === null) {
            return null;
        }

        return $best + ['_score' => $bestScore];
    }

    /**
     * Resolve the best column per role for a sales/purchases-shaped table.
     *
     * @param  array<string, mixed>  $table  one tables_metadata entry
     * @param  string  $kind  'sales' | 'purchases' | etc.
     * @return array<string, ?array<string, mixed>>  map of role → column metadata or null
     */
    public static function resolveColumns(array $table, string $kind): array
    {
        $isPurchase = $kind === 'purchases';
        $cols = [];

        // Date — prefer DATE-typed *_actual columns over text date strings
        $cols['date'] = self::pickColumn($table, [
            'role'           => 'date_actual',
            'requirePgType'  => 'DATE',
            'namesBoost'     => [
                ['c_date_actual$', 6],
                ['invoice_date_actual$', 6],
                ['bill_date_actual$', 5],
                ['^date_actual$', 4],
                ['timestamp_actual$', 1],
            ],
        ]) ?? self::pickColumn($table, [
            'role'       => 'date',
            'namesBoost' => [['c_date$', 4], ['invoice_date$', 4]],
        ]);

        // Amount — prefer "amount" / "total" / "with_gst_amount", penalise tax components
        $cols['amount'] = self::pickColumn($table, [
            'role'       => 'currency',
            'namesBoost' => [
                ['^amount$', 8], ['^total$', 8], ['^net_amount$', 7],
                ['^grand_total$', 7], ['with_gst_amount$', 6],
                ['invoice_amount$', 6], ['^total_amount$', 6],
            ],
            'namesPenalty' => [
                ['cgst|sgst|igst|cess|tcs|tds|tax|round', 10],
                ['discount|cd|^rate$|^price$|^credit_days$', 6],
            ],
        ]);

        // Party / customer / supplier
        $cols['party'] = self::pickColumn($table, [
            'role'       => 'entity',
            'namesBoost' => $isPurchase
                ? [['party.*name|partyname', 10], ['supplier.*name|supplier', 8], ['vendor', 7]]
                : [['party.*name|partyname', 10], ['customer', 8], ['invoice_to', 8], ['client', 6]],
            'namesPenalty' => [
                ['sales_person|salesman|rep_name|transport|item_name|product_name|contact_person', 10],
            ],
        ]);

        // Item / product
        $cols['item'] = self::pickColumn($table, [
            'role'       => 'entity',
            'namesBoost' => [['item.*name|itemname', 10], ['product', 8], ['sku', 6]],
            'namesPenalty' => [['party|customer|supplier|sales_person|transport', 10]],
        ]);

        // Quantity
        $cols['qty'] = self::pickColumn($table, [
            'role'       => 'quantity',
            'namesBoost' => [['^qty$|^quantity$', 8]],
        ]);

        // Location
        $cols['city'] = self::pickColumn($table, [
            'role'       => 'location',
            'namesBoost' => [['^city$|town', 8], ['state', 6]],
        ]);

        // Voucher / id
        $cols['id'] = self::pickColumn($table, [
            'role'       => 'id',
            'namesBoost' => [['voucher.*num', 8], ['invoice_num', 8], ['bill_num', 6], ['vchno', 6]],
        ]);

        return $cols;
    }

    /** @param  array<int, array<string, mixed>>  $cols */
    private static function anyColumn(array $cols, callable $pred): bool
    {
        foreach ($cols as $c) {
            if ($pred($c)) {
                return true;
            }
        }

        return false;
    }
}
