<?php

declare(strict_types=1);

namespace App\Services\Dashboard;

use App\Models\Tenant;
use App\Services\AgingBuckets;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * PageEngine — drill-down page data builder.
 *
 * Reuses TableClassifier (classify + resolveColumns) from DashboardEngine so
 * any tenant whose tables are understood for the dashboard automatically
 * works here too. Each page is a focused deep-dive on ONE business role:
 *
 *   • sales       — direct from sales table (KPIs + 4 charts + paginated invoices)
 *   • outstanding — derived from PURCHASES with empty paymentdate (aging buckets + top defaulters)
 *   • stock       — running balance per item: Σ purchases_qty − Σ sales_qty (weighted-avg price)
 *   • ledger      — party-centric: Σ sales(party) − Σ purchases(party) = net balance + timeline
 *
 * Each page gracefully returns `{empty: true, message}` when required role
 * tables are missing on the tenant.
 *
 * Port of Node helpers/page-engine.js.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/page-engine.js
 */
final class PageEngine
{
    /**
     * Public dispatcher. Returns combined tenant + page payload.
     *
     * @param  array<string, mixed>  $opts
     * @return array<string, mixed>
     */
    public static function build(string $tenantId, string $page, array $opts = []): array
    {
        $tenant = Tenant::query()
            ->select(['id', 'name', 'phone', 'tables_metadata'])
            ->where('id', $tenantId)
            ->first();
        if (! $tenant) {
            return ['error' => 'Tenant not found'];
        }

        $tablesMeta = $tenant->tables_metadata ?? [];
        if (! is_array($tablesMeta)) {
            $tablesMeta = [];
        }

        // Reuse the same classification path the dashboard uses
        $roles = [];
        foreach ($tablesMeta as $meta) {
            $kind = TableClassifier::classify($meta);
            if ($kind === 'other') {
                continue;
            }
            $cols = TableClassifier::resolveColumns($meta, $kind);
            $rowCount = (int) ($meta['row_count'] ?? 0);
            if (! isset($roles[$kind]) || $rowCount > (int) ($roles[$kind]['table']['row_count'] ?? 0)) {
                $roles[$kind] = ['table' => $meta, 'cols' => $cols];
            }
        }

        try {
            $payload = match (strtolower($page)) {
                'sales'       => self::buildSales($roles, $opts),
                'outstanding' => self::buildOutstanding($roles, $opts),
                'stock'       => self::buildStock($roles, $opts),
                'ledger'      => self::buildLedger($roles, $opts),
                default       => ['error' => "Unknown page: $page"],
            };
        } catch (Throwable $e) {
            Log::error('PageEngine failed', ['page' => $page, 'tenant' => $tenantId, 'error' => $e->getMessage()]);

            return ['error' => $e->getMessage(), 'page' => $page];
        }

        if (isset($payload['error'])) {
            return $payload;
        }

        return array_merge(
            ['tenant' => ['id' => $tenant->id, 'name' => $tenant->name]],
            $payload
        );
    }

    // ──────────────── 1. SALES PAGE ────────────────

    /**
     * @param  array<string, mixed>  $roles
     * @param  array<string, mixed>  $opts
     * @return array<string, mixed>
     */
    private static function buildSales(array $roles, array $opts): array
    {
        $r = $roles['sales'] ?? null;
        if (! $r || empty($r['cols']['amount']) || empty($r['cols']['date'])) {
            return ['empty' => true, 'page' => 'sales', 'message' => 'No sales data on this tenant.'];
        }

        $t  = $r['table']['pg_table'];
        $a  = $r['cols']['amount']['pg_name'];
        $d  = $r['cols']['date']['pg_name'];
        $p  = $r['cols']['party']['pg_name'] ?? null;
        $it = $r['cols']['item']['pg_name']  ?? null;
        $id = $r['cols']['id']['pg_name']    ?? null;

        // Best-effort city column discovery (not in standard role map)
        $cityCol = null;
        foreach (($r['table']['columns'] ?? []) as $c) {
            $name = (string) ($c['pg_name'] ?? $c['name'] ?? '');
            if (preg_match('/city/i', $name)) {
                $cityCol = $c['pg_name'] ?? null;
                break;
            }
        }

        $dr = self::dateRange($opts);
        $partyQ = trim((string) ($opts['q'] ?? ''));
        $pageNum = max(1, (int) ($opts['page'] ?? 1));
        $pageSize = 20;
        $offset = ($pageNum - 1) * $pageSize;

        $partyFilter = ($partyQ !== '' && $p) ? "AND $p LIKE '%".self::escSql($partyQ)."%'" : '';
        $distinctId = $id ? "COUNT(DISTINCT $id)" : 'COUNT(*)';

        // KPI block
        $kpiSql = "
            SELECT
              COALESCE(SUM($a+0), 0) AS total,
              $distinctId AS count_inv,
              ".($p ? "COUNT(DISTINCT $p)" : '0')." AS unique_parties,
              COALESCE(SUM($a+0) / NULLIF($distinctId, 0), 0) AS avg_inv
            FROM $t ".self::whereDate($d, $dr)." $partyFilter";
        $kpiRows = self::runSql($kpiSql);

        // Trend
        $trendSql = "
            SELECT DATE($d) AS day, COALESCE(SUM($a+0), 0) AS v
            FROM $t ".self::whereDate($d, $dr)." $partyFilter
            GROUP BY day ORDER BY day";
        $trendRows = self::runSql($trendSql);

        // Top parties
        $topPartiesRows = $p ? self::runSql("
            SELECT $p AS label, COALESCE(SUM($a+0), 0) AS v
            FROM $t ".self::whereDate($d, $dr)." AND $p IS NOT NULL $partyFilter
            GROUP BY $p ORDER BY v DESC LIMIT 8") : [];

        // Top items
        $topItemsRows = $it ? self::runSql("
            SELECT $it AS label, COALESCE(SUM($a+0), 0) AS v
            FROM $t ".self::whereDate($d, $dr)." AND $it IS NOT NULL $partyFilter
            GROUP BY $it ORDER BY v DESC LIMIT 8") : [];

        // By city
        $byCityRows = $cityCol ? self::runSql("
            SELECT $cityCol AS label, COALESCE(SUM($a+0), 0) AS v
            FROM $t ".self::whereDate($d, $dr)." AND $cityCol IS NOT NULL AND $cityCol <> 'NA' $partyFilter
            GROUP BY $cityCol ORDER BY v DESC LIMIT 8") : [];

        // Paginated invoices
        $invoiceSql = "
            SELECT
              $d AS day,
              ".($id ? $id : 'NULL')." AS voucher,
              ".($p  ? $p  : 'NULL')." AS party,
              ".($it ? $it : 'NULL')." AS item,
              ($a+0) AS amount
            FROM $t ".self::whereDate($d, $dr)." $partyFilter
            ORDER BY $d DESC, $a DESC
            LIMIT $pageSize OFFSET $offset";
        $invoiceRows = self::runSql($invoiceSql);

        // Total count for pagination
        $totalCountRow = self::runSql("
            SELECT COUNT(*) AS c FROM $t ".self::whereDate($d, $dr)." $partyFilter");

        $kpi = $kpiRows[0] ?? null;

        return [
            'page'   => 'sales',
            'range'  => $dr,
            'filter' => ['q' => $partyQ, 'page' => $pageNum, 'pageSize' => $pageSize],
            'kpis'   => [
                'total_sales'    => ['value' => (float) ($kpi->total ?? 0),          'format' => 'inr'],
                'invoice_count'  => ['value' => (float) ($kpi->count_inv ?? 0),      'format' => 'num'],
                'unique_parties' => ['value' => (float) ($kpi->unique_parties ?? 0), 'format' => 'num'],
                'avg_invoice'    => ['value' => (float) ($kpi->avg_inv ?? 0),        'format' => 'inr'],
            ],
            'charts' => [
                'trend'       => self::shapeChart($trendRows, 'day'),
                'top_parties' => self::shapeChart($topPartiesRows, 'label'),
                'top_items'   => self::shapeChart($topItemsRows, 'label'),
                'by_city'     => self::shapeChart($byCityRows, 'label'),
            ],
            'invoices' => [
                'rows' => array_map(static fn ($row) => [
                    'date'    => $row->day ?? null,
                    'voucher' => $row->voucher ?? null,
                    'party'   => $row->party ?? null,
                    'item'    => $row->item ?? null,
                    'amount'  => (float) ($row->amount ?? 0),
                ], $invoiceRows),
                'total'    => (int) ($totalCountRow[0]->c ?? 0),
                'page'     => $pageNum,
                'pageSize' => $pageSize,
            ],
        ];
    }

    // ──────────────── 2. OUTSTANDING PAGE ────────────────

    /**
     * @param  array<string, mixed>  $roles
     * @param  array<string, mixed>  $opts
     * @return array<string, mixed>
     */
    private static function buildOutstanding(array $roles, array $opts): array
    {
        $r = $roles['purchases'] ?? null;
        if (! $r || empty($r['cols']['amount']) || empty($r['cols']['date'])) {
            return [
                'empty'   => true,
                'page'    => 'outstanding',
                'message' => 'No purchase data on this tenant — outstanding cannot be derived.',
            ];
        }

        $t = $r['table']['pg_table'];
        $a = $r['cols']['amount']['pg_name'];
        $d = $r['cols']['date']['pg_name'];
        $p = $r['cols']['party']['pg_name'] ?? null;

        // Best-effort paymentdate column discovery
        $payColName = null;
        foreach (($r['table']['columns'] ?? []) as $c) {
            $name = (string) ($c['pg_name'] ?? $c['name'] ?? '');
            if (preg_match('/pay.*date|paid|payment_date/i', $name)) {
                $payColName = $c['pg_name'] ?? null;
                break;
            }
        }

        $asOf = (string) ($opts['as_of'] ?? CarbonImmutable::today()->toDateString());
        $unpaidWhere = $payColName
            ? "($payColName IS NULL OR $payColName = '' OR $payColName = 'NA')"
            : '1=1';

        // Pull all unpaid rows (capped at 5000)
        $rows = self::runSql("
            SELECT
              $d AS date,
              ".($p ? $p : 'NULL')." AS party,
              ($a+0) AS amount
            FROM $t
            WHERE $unpaidWhere
              AND $d IS NOT NULL
              AND $a IS NOT NULL
              AND ($a+0) > 0
            LIMIT 5000");

        // Pure helpers handle aging summary + top defaulters
        $summary = AgingBuckets::compute($rows, $asOf);
        $top = AgingBuckets::topDefaulters($rows, $asOf, 10);

        // 90-day rolling outstanding trend (new unpaid bills per day)
        $trendRows = self::runSql("
            SELECT DATE($d) AS day, COALESCE(SUM($a+0), 0) AS v
            FROM $t
            WHERE $unpaidWhere
              AND DATE($d) >= DATE_SUB('$asOf', INTERVAL 90 DAY)
            GROUP BY day ORDER BY day");

        return [
            'page'                 => 'outstanding',
            'asOf'                 => $asOf,
            'has_payment_tracking' => $payColName !== null,
            'kpis' => [
                'total_outstanding' => ['value' => $summary['total'],            'format' => 'inr'],
                'unpaid_count'      => ['value' => $summary['totalCount'],       'format' => 'num'],
                'bucket_90plus'     => ['value' => $summary['buckets']['90+'] ?? 0, 'format' => 'inr'],
                'oldest_age'        => ['value' => $summary['oldest']['age'] ?? 0,  'format' => 'num'],
            ],
            'aging'         => $summary,
            'top_defaulters' => $top,
            'trend' => self::shapeChart($trendRows, 'day'),
        ];
    }

    // ──────────────── 3. STOCK PAGE ────────────────

    /**
     * @param  array<string, mixed>  $roles
     * @param  array<string, mixed>  $opts
     * @return array<string, mixed>
     */
    private static function buildStock(array $roles, array $opts): array
    {
        $sales = $roles['sales'] ?? null;
        $purch = $roles['purchases'] ?? null;
        if (! $purch || empty($purch['cols']['item']) || empty($purch['cols']['qty'])) {
            return [
                'empty'   => true,
                'page'    => 'stock',
                'message' => 'No item-level purchase data on this tenant — stock cannot be derived.',
            ];
        }

        $pt = $purch['table']['pg_table'];
        $pi = $purch['cols']['item']['pg_name'];
        $pq = $purch['cols']['qty']['pg_name'];
        $pd = $purch['cols']['date']['pg_name']   ?? null;
        $pa = $purch['cols']['amount']['pg_name'] ?? null;

        $hasSales = $sales && ! empty($sales['cols']['item']) && ! empty($sales['cols']['qty']);
        $st = $hasSales ? $sales['table']['pg_table']     : null;
        $si = $hasSales ? $sales['cols']['item']['pg_name'] : null;
        $sq = $hasSales ? $sales['cols']['qty']['pg_name']  : null;
        $sd = $hasSales ? ($sales['cols']['date']['pg_name'] ?? null) : null;

        // Tax-line filter — exclude Tally pseudo-items (CGST, IGST, Round-off)
        $taxFilter = "
            AND $pi NOT LIKE '%cgst%'
            AND $pi NOT LIKE '%sgst%'
            AND $pi NOT LIKE '%igst%'
            AND $pi NOT LIKE '%cess%'
            AND $pi NOT LIKE '%round%'
            AND $pi NOT LIKE '%discount%'";
        $salesTaxFilter = $hasSales ? "
            AND $si NOT LIKE '%cgst%'
            AND $si NOT LIKE '%sgst%'
            AND $si NOT LIKE '%igst%'
            AND $si NOT LIKE '%cess%'
            AND $si NOT LIKE '%round%'
            AND $si NOT LIKE '%discount%'" : '';

        $salesCte = $hasSales ? "
            , sales_agg AS (
              SELECT $si AS item,
                     COALESCE(SUM($sq+0), 0) AS sold_qty,
                     MAX(".($sd ? "DATE($sd)" : 'NULL').") AS last_sale_at
              FROM $st
              WHERE $si IS NOT NULL AND $si <> 'NA'
                $salesTaxFilter
              GROUP BY $si
            )" : '';
        $salesJoin = $hasSales ? 'LEFT JOIN sales_agg s ON s.item = p.item' : '';
        $soldQtyExpr = $hasSales ? 'COALESCE(s.sold_qty, 0)' : '0';
        $lastSaleExpr = $hasSales ? 's.last_sale_at' : 'NULL';

        // Weighted avg price = SUM(amount) / SUM(qty); stock value floors at 0
        $sql = "
            WITH purch_agg AS (
              SELECT $pi AS item,
                     COALESCE(SUM($pq+0), 0) AS bought_qty,
                     COALESCE(SUM(".($pa ? "($pa+0)" : '0')."), 0) AS bought_amt,
                     CASE WHEN COALESCE(SUM($pq+0), 0) > 0
                          THEN COALESCE(SUM(".($pa ? "($pa+0)" : '0')."), 0) / SUM($pq+0)
                          ELSE 0 END AS avg_price,
                     MAX(".($pd ? "DATE($pd)" : 'NULL').") AS last_purch_at
              FROM $pt
              WHERE $pi IS NOT NULL AND $pi <> 'NA'
                $taxFilter
              GROUP BY $pi
            )
            $salesCte
            SELECT p.item,
                   p.bought_qty,
                   $soldQtyExpr AS sold_qty,
                   (p.bought_qty - $soldQtyExpr) AS balance_qty,
                   p.avg_price,
                   GREATEST(0, (p.bought_qty - $soldQtyExpr) * p.avg_price) AS stock_value,
                   p.last_purch_at,
                   $lastSaleExpr AS last_sale_at
            FROM purch_agg p
            $salesJoin
            ORDER BY stock_value DESC
            LIMIT 200";

        $rows = self::runSql($sql);

        $items = array_map(static fn ($r) => [
            'item'           => $r->item ?? null,
            'bought_qty'     => (float) ($r->bought_qty ?? 0),
            'sold_qty'       => (float) ($r->sold_qty ?? 0),
            'balance_qty'    => (float) ($r->balance_qty ?? 0),
            'avg_price'      => (float) ($r->avg_price ?? 0),
            'stock_value'    => (float) ($r->stock_value ?? 0),
            'last_purch_at'  => $r->last_purch_at ?? null,
            'last_sale_at'   => $r->last_sale_at ?? null,
        ], $rows);

        // Aggregations
        $totalValue = array_sum(array_map(
            static fn ($x) => $x['stock_value'] > 0 ? $x['stock_value'] : 0,
            $items
        ));
        $lowStock = array_values(array_filter($items, static fn ($x) => $x['balance_qty'] <= 0));

        $today = CarbonImmutable::today();
        $slow = [];
        foreach ($items as $x) {
            if ($x['balance_qty'] <= 0) continue;
            $last = null;
            if ($x['last_sale_at']) {
                try { $last = CarbonImmutable::parse($x['last_sale_at']); } catch (\Throwable) { /* ignore */ }
            }
            if ($last === null) {
                $slow[] = $x;
                continue;
            }
            $days = (int) $last->diffInDays($today);
            if ($days >= 30) {
                $slow[] = $x;
            }
        }
        $slow = array_slice($slow, 0, 20);

        $topValue = array_values(array_filter($items, static fn ($x) => $x['stock_value'] > 0));
        $topValue = array_slice($topValue, 0, 10);

        return [
            'page'           => 'stock',
            'has_sales_data' => $hasSales,
            'kpis' => [
                'total_value'       => ['value' => round($totalValue, 2),    'format' => 'inr'],
                'sku_count'         => ['value' => count($items),            'format' => 'num'],
                'low_stock_count'   => ['value' => count($lowStock),         'format' => 'num'],
                'slow_moving_count' => ['value' => count($slow),             'format' => 'num'],
            ],
            'top_value_items' => $topValue,
            'low_stock'       => array_slice($lowStock, 0, 20),
            'slow_moving'     => $slow,
            'items_table'     => array_slice($items, 0, 100),
        ];
    }

    // ──────────────── 4. LEDGER PAGE ────────────────

    /**
     * @param  array<string, mixed>  $roles
     * @param  array<string, mixed>  $opts
     * @return array<string, mixed>
     */
    private static function buildLedger(array $roles, array $opts): array
    {
        $sales = $roles['sales'] ?? null;
        $purch = $roles['purchases'] ?? null;
        if ((! $sales || empty($sales['cols']['party'])) && (! $purch || empty($purch['cols']['party']))) {
            return [
                'empty'   => true,
                'page'    => 'ledger',
                'message' => 'No party-level data on this tenant — ledger cannot be derived.',
            ];
        }

        $partyQ = trim((string) ($opts['party'] ?? $opts['q'] ?? ''));

        // 1. Top-50 parties summary (always shown)
        $salesCte = ($sales && ! empty($sales['cols']['party'])) ? "
            SELECT {$sales['cols']['party']['pg_name']} AS party,
                   COALESCE(SUM({$sales['cols']['amount']['pg_name']}+0), 0) AS sales_amt,
                   COUNT(*) AS sales_count
            FROM {$sales['table']['pg_table']}
            WHERE {$sales['cols']['party']['pg_name']} IS NOT NULL AND {$sales['cols']['party']['pg_name']} <> 'NA'
            GROUP BY {$sales['cols']['party']['pg_name']}
        " : "SELECT NULL AS party, 0 AS sales_amt, 0 AS sales_count FROM DUAL WHERE FALSE";

        $purchCte = ($purch && ! empty($purch['cols']['party'])) ? "
            SELECT {$purch['cols']['party']['pg_name']} AS party,
                   COALESCE(SUM({$purch['cols']['amount']['pg_name']}+0), 0) AS purch_amt,
                   COUNT(*) AS purch_count
            FROM {$purch['table']['pg_table']}
            WHERE {$purch['cols']['party']['pg_name']} IS NOT NULL AND {$purch['cols']['party']['pg_name']} <> 'NA'
            GROUP BY {$purch['cols']['party']['pg_name']}
        " : "SELECT NULL AS party, 0 AS purch_amt, 0 AS purch_count FROM DUAL WHERE FALSE";

        // MySQL doesn't have FULL OUTER JOIN — simulate with LEFT JOIN + UNION
        $summarySql = "
            WITH s AS ($salesCte), p AS ($purchCte)
            SELECT COALESCE(s.party, p.party) AS party,
                   COALESCE(s.sales_amt, 0)   AS sales_amt,
                   COALESCE(p.purch_amt, 0)   AS purch_amt,
                   (COALESCE(s.sales_amt, 0) - COALESCE(p.purch_amt, 0)) AS net_balance,
                   COALESCE(s.sales_count, 0) AS sales_count,
                   COALESCE(p.purch_count, 0) AS purch_count
            FROM s
            LEFT JOIN p ON s.party = p.party
            WHERE COALESCE(s.party, p.party) IS NOT NULL
            UNION
            SELECT p.party,
                   0 AS sales_amt,
                   COALESCE(p.purch_amt, 0) AS purch_amt,
                   (0 - COALESCE(p.purch_amt, 0)) AS net_balance,
                   0 AS sales_count,
                   COALESCE(p.purch_count, 0) AS purch_count
            FROM p
            LEFT JOIN s ON s.party = p.party
            WHERE s.party IS NULL AND p.party IS NOT NULL
            ORDER BY ABS(net_balance) DESC
            LIMIT 50";
        $summaryRows = self::runSql($summarySql);

        $summary = array_map(static fn ($r) => [
            'party'        => $r->party ?? null,
            'sales_amt'    => (float) ($r->sales_amt ?? 0),
            'purch_amt'    => (float) ($r->purch_amt ?? 0),
            'net_balance'  => (float) ($r->net_balance ?? 0),
            'sales_count'  => (int) ($r->sales_count ?? 0),
            'purch_count'  => (int) ($r->purch_count ?? 0),
        ], $summaryRows);

        // 2. If party search provided → fetch detail (true totals via aggregates + recent 100 txns)
        $partyDetail = null;
        if ($partyQ !== '') {
            $escaped = self::escSql($partyQ);

            $salesTotal = 0.0;
            $salesCount = 0;
            if ($sales && ! empty($sales['cols']['party'])) {
                $aggRows = self::runSql("
                    SELECT COALESCE(SUM({$sales['cols']['amount']['pg_name']}+0), 0) AS total,
                           COUNT(*) AS cnt
                    FROM {$sales['table']['pg_table']}
                    WHERE {$sales['cols']['party']['pg_name']} LIKE '%$escaped%'");
                $salesTotal = (float) ($aggRows[0]->total ?? 0);
                $salesCount = (int) ($aggRows[0]->cnt ?? 0);
            }

            $purchTotal = 0.0;
            $purchCount = 0;
            if ($purch && ! empty($purch['cols']['party'])) {
                $aggRows = self::runSql("
                    SELECT COALESCE(SUM({$purch['cols']['amount']['pg_name']}+0), 0) AS total,
                           COUNT(*) AS cnt
                    FROM {$purch['table']['pg_table']}
                    WHERE {$purch['cols']['party']['pg_name']} LIKE '%$escaped%'");
                $purchTotal = (float) ($aggRows[0]->total ?? 0);
                $purchCount = (int) ($aggRows[0]->cnt ?? 0);
            }

            // Recent 100 transactions per side for the timeline
            $allTxn = [];
            if ($sales && ! empty($sales['cols']['party'])) {
                $txnRows = self::runSql("
                    SELECT 'sale' AS kind,
                           {$sales['cols']['date']['pg_name']} AS date,
                           ".($sales['cols']['id']['pg_name']   ?? 'NULL')." AS voucher,
                           ({$sales['cols']['amount']['pg_name']}+0) AS amount,
                           ".($sales['cols']['item']['pg_name'] ?? 'NULL')." AS item,
                           {$sales['cols']['party']['pg_name']} AS party
                    FROM {$sales['table']['pg_table']}
                    WHERE {$sales['cols']['party']['pg_name']} LIKE '%$escaped%'
                    ORDER BY {$sales['cols']['date']['pg_name']} DESC
                    LIMIT 100");
                foreach ($txnRows as $row) $allTxn[] = $row;
            }
            if ($purch && ! empty($purch['cols']['party'])) {
                $txnRows = self::runSql("
                    SELECT 'purchase' AS kind,
                           {$purch['cols']['date']['pg_name']} AS date,
                           ".($purch['cols']['id']['pg_name']   ?? 'NULL')." AS voucher,
                           ({$purch['cols']['amount']['pg_name']}+0) AS amount,
                           ".($purch['cols']['item']['pg_name'] ?? 'NULL')." AS item,
                           {$purch['cols']['party']['pg_name']} AS party
                    FROM {$purch['table']['pg_table']}
                    WHERE {$purch['cols']['party']['pg_name']} LIKE '%$escaped%'
                    ORDER BY {$purch['cols']['date']['pg_name']} DESC
                    LIMIT 100");
                foreach ($txnRows as $row) $allTxn[] = $row;
            }

            usort($allTxn, static fn ($a, $b) => strcmp((string) ($b->date ?? ''), (string) ($a->date ?? '')));
            $allTxn = array_slice($allTxn, 0, 100);

            $partyDetail = [
                'query'              => $partyQ,
                'matched_count'      => $salesCount + $purchCount,
                'transactions_shown' => count($allTxn),
                'sales_total'        => round($salesTotal, 2),
                'purchases_total'    => round($purchTotal, 2),
                'net_balance'        => round($salesTotal - $purchTotal, 2),
                'transactions'       => $allTxn,
            ];
        }

        return [
            'page'         => 'ledger',
            'summary'      => $summary,
            'party_detail' => $partyDetail,
        ];
    }

    // ──────────────── HELPERS ────────────────

    /**
     * Run a SELECT through Laravel's pgsql connection. Returns list of stdClass.
     *
     * @return list<\stdClass>
     */
    private static function runSql(string $sql): array
    {
        return DB::select($sql);
    }

    /**
     * Build `WHERE col BETWEEN 'from' AND 'to'` or `WHERE 1=1` (so downstream
     * AND clauses always compose).
     *
     * @param  array{from: ?string, to: ?string}  $dr
     */
    private static function whereDate(string $col, array $dr): string
    {
        if (empty($dr['from'])) {
            return 'WHERE 1=1';
        }

        return "WHERE $col BETWEEN '{$dr['from']}' AND '{$dr['to']}'";
    }

    /**
     * Page-engine date range. Honors opts.from + opts.to; falls back to last 90d.
     *
     * @param  array<string, mixed>  $opts
     * @return array{from: string, to: string}
     */
    private static function dateRange(array $opts): array
    {
        if (! empty($opts['from']) && ! empty($opts['to'])) {
            return ['from' => (string) $opts['from'], 'to' => (string) $opts['to']];
        }
        $today = CarbonImmutable::today();

        return ['from' => $today->subDays(89)->toDateString(), 'to' => $today->toDateString()];
    }

    /**
     * Escape single quotes for safe SQL string interpolation.
     */
    private static function escSql(string $s): string
    {
        return str_replace("'", "''", $s);
    }

    /**
     * Convert {label,v} rows into Chart.js-friendly {labels[], data[], format} shape.
     *
     * @param  list<\stdClass>  $rows
     */
    private static function shapeChart(array $rows, string $labelKey): array
    {
        return [
            'labels' => array_map(static fn ($r) => (string) ($r->$labelKey ?? 'Unknown'), $rows),
            'data'   => array_map(static fn ($r) => (float) ($r->v ?? 0), $rows),
            'format' => 'inr',
        ];
    }
}
