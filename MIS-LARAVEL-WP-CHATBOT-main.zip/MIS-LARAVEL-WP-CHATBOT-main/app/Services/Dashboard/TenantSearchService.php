<?php

declare(strict_types=1);

namespace App\Services\Dashboard;

use App\Models\Tenant;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * TenantSearchService — pg_trgm-powered spotlight search across a tenant's
 * own data tables (customers, suppliers, items, invoices).
 *
 * Reuses TableClassifier so any tenant whose tables we understand for the
 * dashboard automatically gets searched. Per-kind ILIKE prefix/substring +
 * trigram similarity, deduped by (kind,label), with a kind-priority boost so
 * customers/suppliers appear above equally-scored items.
 *
 * Returns:
 *   {
 *     results: [
 *       { kind: 'customer'|'supplier'|'item'|'invoice', label, score, link? }
 *     ],
 *     elapsed_ms: ?int (set by caller)
 *   }
 *
 * Port of Node server.js → searchTenantData() (~lines 4444-4548).
 */
final class TenantSearchService
{
    /** Lower bound for trigram similarity / ILIKE-substring score. */
    private const MIN_SCORE = 0.18;

    /** Per-kind UI ordering nudge — customers > suppliers > invoices > items. */
    private const KIND_BOOST = [
        'customer' => 0.05,
        'supplier' => 0.04,
        'invoice'  => 0.02,
        'item'     => 0.0,
    ];

    /**
     * @return array{results: list<array<string, mixed>>}
     */
    public static function search(string $tenantId, string $q, int $limit = 20): array
    {
        $tenant = Tenant::query()
            ->select(['id', 'name', 'tables_metadata'])
            ->where('id', $tenantId)
            ->first();
        if (! $tenant) {
            return ['results' => [], 'error' => 'Tenant not found'];
        }

        $tablesMeta = $tenant->tables_metadata ?? [];
        if (! is_array($tablesMeta)) {
            $tablesMeta = [];
        }

        // Classify tables into roles map (sales, purchases, etc.)
        $roles = [];
        foreach ($tablesMeta as $meta) {
            $kind = TableClassifier::classify($meta);
            if ($kind === 'other') continue;
            $cols = TableClassifier::resolveColumns($meta, $kind);
            $rowCount = (int) ($meta['row_count'] ?? 0);
            if (! isset($roles[$kind]) || $rowCount > (int) ($roles[$kind]['table']['row_count'] ?? 0)) {
                $roles[$kind] = ['table' => $meta, 'cols' => $cols];
            }
        }

        $queryEsc = self::escSql($q);
        $perKindLimit = 6;
        $jobs = [];

        // Build search jobs based on which roles exist
        if (isset($roles['sales'])) {
            self::addJob($jobs, 'customer', $roles['sales']['table'], $roles['sales']['cols']['party'] ?? null, $queryEsc, $perKindLimit);
            self::addJob($jobs, 'item',     $roles['sales']['table'], $roles['sales']['cols']['item']  ?? null, $queryEsc, $perKindLimit);
            self::addJob($jobs, 'invoice',  $roles['sales']['table'], $roles['sales']['cols']['id']    ?? null, $queryEsc, $perKindLimit, isIdLike: true);
        }
        if (isset($roles['purchases'])) {
            self::addJob($jobs, 'supplier', $roles['purchases']['table'], $roles['purchases']['cols']['party'] ?? null, $queryEsc, $perKindLimit);
            // Only fall back to purchase items if there's no sales table to search items on
            if (! isset($roles['sales'])) {
                self::addJob($jobs, 'item', $roles['purchases']['table'], $roles['purchases']['cols']['item'] ?? null, $queryEsc, $perKindLimit);
            }
        }

        // Run every job sequentially — same trade-off as DashboardEngine
        $results = [];
        $seen = [];
        foreach ($jobs as $job) {
            try {
                $rows = DB::select($job['sql']);
            } catch (Throwable $e) {
                Log::info('Search subquery failed', ['kind' => $job['kind'], 'error' => $e->getMessage()]);
                continue;
            }
            foreach ($rows as $row) {
                $label = trim((string) ($row->label ?? ''));
                if ($label === '') continue;

                $key = $job['kind'].'::'.strtolower($label);
                if (isset($seen[$key])) continue;
                $seen[$key] = true;

                $score = (float) ($row->score ?? 0);
                if ($score < self::MIN_SCORE) continue;

                $results[] = [
                    'kind'  => $job['kind'],
                    'label' => $label,
                    'score' => round($score, 2),
                ];
            }
        }

        // Apply kind-priority boost when sorting (doesn't mutate stored score)
        usort($results, static function (array $a, array $b): int {
            $sa = $a['score'] + (self::KIND_BOOST[$a['kind']] ?? 0);
            $sb = $b['score'] + (self::KIND_BOOST[$b['kind']] ?? 0);

            return $sb <=> $sa;
        });

        $top = array_slice($results, 0, $limit);

        // Decorate with deep links — frontend uses these to wire spotlight clicks
        foreach ($top as &$r) {
            $r['link'] = match ($r['kind']) {
                'customer', 'supplier' => '/ledger?q='.rawurlencode($r['label']),
                'invoice' => '/sales?q='.rawurlencode($r['label']),
                'item'    => '/stock',
                default   => null,
            };
        }
        unset($r);

        return ['results' => $top];
    }

    /**
     * Build the SQL for a single search job and append to the queue.
     *
     * @param  list<array{kind: string, sql: string}>  $jobs
     * @param  array<string, mixed>|null  $colMeta
     */
    private static function addJob(
        array &$jobs,
        string $kind,
        array $table,
        ?array $colMeta,
        string $queryEsc,
        int $perKindLimit,
        bool $isIdLike = false,
    ): void {
        if ($colMeta === null || empty($colMeta['pg_name'])) {
            return;
        }
        $tName = $table['pg_table'];
        $cName = $colMeta['pg_name'];
        $rowLimit = $perKindLimit * 2;

        // MySQL is case-insensitive with utf8mb4_unicode_ci, so LIKE works like ILIKE
        $sql = "
            SELECT DISTINCT $cName AS label,
              CASE WHEN $cName LIKE '$queryEsc%'  THEN 1.0
                   WHEN $cName LIKE '%$queryEsc%' THEN 0.7
                   ELSE 0 END AS score
            FROM $tName
            WHERE $cName IS NOT NULL AND $cName LIKE '%$queryEsc%'
            ORDER BY score DESC
            LIMIT $rowLimit";

        $jobs[] = ['kind' => $kind, 'sql' => $sql];
    }

    /** Escape single quotes for safe SQL string interpolation. */
    private static function escSql(string $s): string
    {
        return str_replace("'", "''", $s);
    }
}
