<?php

declare(strict_types=1);

namespace App\Services\Dashboard;

/**
 * WidgetCatalog — declares all 13 dashboard widgets.
 *
 * Each widget entry is an associative array with:
 *   id        — stable widget identifier ('kpi.total_sales' etc.)
 *   kind      — 'kpi' | 'chart' | 'table'
 *   chartKind — 'line' | 'donut' | 'bar' (chart widgets only)
 *   title     — human-facing title
 *   accent    — visual hue token for KPI cards
 *   icon      — lucide icon name
 *   priority  — higher = picked first when multiple of same kind compete
 *   requires  — Closure(roles): bool — returns true if this widget can be built
 *   build     — Closure(roles, dr, prevDr): array{
 *                  sql_main: string,
 *                  sql_prev?: ?string,
 *                  sql_spark?: ?string,
 *                  format: string,
 *                  transform?: Closure(rows): array,
 *                  meta?: array
 *               }
 *
 * Port of Node helpers/dashboard-engine.js → WIDGET_CATALOG.
 * Closures kept inline to mirror the Node code 1:1 — see Phase 23C critical
 * gotcha #4 in PROJECT_ROADMAP.md for future refactor to class-string runners.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/dashboard-engine.js
 */
final class WidgetCatalog
{
    /**
     * @return list<array<string, mixed>>
     */
    public static function all(): array
    {
        return [
            // ─────────────── KPIs ───────────────────────────────────────
            self::kpi(
                id: 'kpi.total_sales',
                title: 'Total Sales',
                accent: 'emerald',
                icon: 'trending-up',
                priority: 100,
                role: 'sales',
                requireExtra: ['amount', 'date'],
                amountKey: 'amount',
                dateKey: 'date',
            ),
            self::kpi(
                id: 'kpi.total_purchases',
                title: 'Total Purchases',
                accent: 'amber',
                icon: 'shopping-cart',
                priority: 90,
                role: 'purchases',
                requireExtra: ['amount', 'date'],
                amountKey: 'amount',
                dateKey: 'date',
            ),

            // Invoice count — uses COUNT(DISTINCT id) when id column exists
            [
                'id'       => 'kpi.invoice_count',
                'kind'     => 'kpi',
                'title'    => 'Invoices',
                'accent'   => 'indigo',
                'icon'     => 'receipt',
                'priority' => 80,
                'requires' => static fn (array $r): bool => isset($r['sales']) && ! empty($r['sales']['cols']['date']),
                'build'    => static function (array $r, array $dr, array $prevDr): array {
                    $t  = $r['sales']['table']['pg_table'];
                    $d  = $r['sales']['cols']['date']['pg_name'];
                    $id = $r['sales']['cols']['id']['pg_name'] ?? null;
                    $distinct = $id ? "COUNT(DISTINCT $id)" : 'COUNT(*)';

                    return [
                        'sql_main' => "SELECT $distinct AS v FROM $t ".self::whereDate($d, $dr),
                        'sql_prev' => $prevDr['from'] !== null
                            ? "SELECT $distinct AS v FROM $t ".self::whereDate($d, $prevDr)
                            : null,
                        'sql_spark' => "SELECT DATE($d) AS day, $distinct AS v FROM $t "
                            .self::whereDate($d, $dr).' GROUP BY day ORDER BY day',
                        'format' => 'num',
                    ];
                },
            ],

            // Unique customers
            [
                'id'       => 'kpi.unique_customers',
                'kind'     => 'kpi',
                'title'    => 'Active Customers',
                'accent'   => 'violet',
                'icon'     => 'users',
                'priority' => 70,
                'requires' => static fn (array $r): bool => isset($r['sales'])
                    && ! empty($r['sales']['cols']['party'])
                    && ! empty($r['sales']['cols']['date']),
                'build' => static function (array $r, array $dr, array $prevDr): array {
                    $t = $r['sales']['table']['pg_table'];
                    $p = $r['sales']['cols']['party']['pg_name'];
                    $d = $r['sales']['cols']['date']['pg_name'];

                    return [
                        'sql_main' => "SELECT COUNT(DISTINCT $p) AS v FROM $t ".self::whereDate($d, $dr)." AND $p IS NOT NULL",
                        'sql_prev' => $prevDr['from'] !== null
                            ? "SELECT COUNT(DISTINCT $p) AS v FROM $t ".self::whereDate($d, $prevDr)." AND $p IS NOT NULL"
                            : null,
                        'sql_spark' => "SELECT DATE($d) AS day, COUNT(DISTINCT $p) AS v FROM $t "
                            .self::whereDate($d, $dr)." AND $p IS NOT NULL GROUP BY day ORDER BY day",
                        'format' => 'num',
                    ];
                },
            ],

            // Avg invoice value
            [
                'id'       => 'kpi.avg_invoice',
                'kind'     => 'kpi',
                'title'    => 'Avg Invoice Value',
                'accent'   => 'cyan',
                'icon'     => 'calculator',
                'priority' => 60,
                'requires' => static fn (array $r): bool => isset($r['sales'])
                    && ! empty($r['sales']['cols']['amount'])
                    && ! empty($r['sales']['cols']['date'])
                    && ! empty($r['sales']['cols']['id']),
                'build' => static function (array $r, array $dr, array $prevDr): array {
                    $t  = $r['sales']['table']['pg_table'];
                    $a  = $r['sales']['cols']['amount']['pg_name'];
                    $d  = $r['sales']['cols']['date']['pg_name'];
                    $id = $r['sales']['cols']['id']['pg_name'];
                    $sql = static fn (array $range): string => "
                        SELECT COALESCE(SUM($a+0), 0) / NULLIF(COUNT(DISTINCT $id), 0) AS v
                        FROM $t ".self::whereDate($d, $range);

                    return [
                        'sql_main' => $sql($dr),
                        'sql_prev' => $prevDr['from'] !== null ? $sql($prevDr) : null,
                        'format'   => 'inr',
                    ];
                },
            ],

            // Total outstanding (no date filter)
            [
                'id'       => 'kpi.total_outstanding',
                'kind'     => 'kpi',
                'title'    => 'Outstanding',
                'accent'   => 'rose',
                'icon'     => 'hourglass',
                'priority' => 95,
                'requires' => static fn (array $r): bool => isset($r['outstanding'])
                    && ! empty($r['outstanding']['cols']['amount']),
                'build' => static function (array $r): array {
                    $t = $r['outstanding']['table']['pg_table'];
                    $a = $r['outstanding']['cols']['amount']['pg_name'];

                    return [
                        'sql_main' => "SELECT COALESCE(SUM($a+0), 0) AS v FROM $t",
                        'format'   => 'inr',
                    ];
                },
            ],

            // ─────────────── CHARTS ─────────────────────────────────────
            [
                'id'        => 'chart.sales_trend',
                'kind'      => 'chart',
                'chartKind' => 'line',
                'title'     => 'Sales Trend',
                'priority'  => 100,
                'requires'  => static fn (array $r): bool => isset($r['sales'])
                    && ! empty($r['sales']['cols']['amount'])
                    && ! empty($r['sales']['cols']['date']),
                'build' => static function (array $r, array $dr): array {
                    $t = $r['sales']['table']['pg_table'];
                    $a = $r['sales']['cols']['amount']['pg_name'];
                    $d = $r['sales']['cols']['date']['pg_name'];

                    return [
                        'sql_main' => "
                            SELECT DATE($d) AS day, COALESCE(SUM($a+0), 0) AS v
                            FROM $t ".self::whereDate($d, $dr)."
                            GROUP BY day ORDER BY day",
                        'format'    => 'inr',
                        'transform' => static fn (array $rows): array => [
                            'labels' => array_map(static fn ($row) => $row->day ?? null, $rows),
                            'data'   => array_map(static fn ($row) => (float) ($row->v ?? 0), $rows),
                        ],
                    ];
                },
            ],

            [
                'id'        => 'chart.purchases_trend',
                'kind'      => 'chart',
                'chartKind' => 'line',
                'title'     => 'Purchases Trend',
                'priority'  => 80,
                'requires'  => static fn (array $r): bool => isset($r['purchases'])
                    && ! empty($r['purchases']['cols']['amount'])
                    && ! empty($r['purchases']['cols']['date'])
                    && ! isset($r['sales']),  // only if no sales — avoid duplicate trend
                'build' => static function (array $r, array $dr): array {
                    $t = $r['purchases']['table']['pg_table'];
                    $a = $r['purchases']['cols']['amount']['pg_name'];
                    $d = $r['purchases']['cols']['date']['pg_name'];

                    return [
                        'sql_main' => "
                            SELECT DATE($d) AS day, COALESCE(SUM($a+0), 0) AS v
                            FROM $t ".self::whereDate($d, $dr)."
                            GROUP BY day ORDER BY day",
                        'format'    => 'inr',
                        'transform' => static fn (array $rows): array => [
                            'labels' => array_map(static fn ($row) => $row->day ?? null, $rows),
                            'data'   => array_map(static fn ($row) => (float) ($row->v ?? 0), $rows),
                        ],
                    ];
                },
            ],

            [
                'id'        => 'chart.top_parties',
                'kind'      => 'chart',
                'chartKind' => 'donut',
                'title'     => 'Top Customers',
                'priority'  => 90,
                'requires'  => static fn (array $r): bool => isset($r['sales'])
                    && ! empty($r['sales']['cols']['party'])
                    && ! empty($r['sales']['cols']['amount'])
                    && ! empty($r['sales']['cols']['date']),
                'build' => static function (array $r, array $dr): array {
                    $t = $r['sales']['table']['pg_table'];
                    $p = $r['sales']['cols']['party']['pg_name'];
                    $a = $r['sales']['cols']['amount']['pg_name'];
                    $d = $r['sales']['cols']['date']['pg_name'];

                    return [
                        'sql_main' => "
                            SELECT $p AS label, COALESCE(SUM($a+0), 0) AS v
                            FROM $t ".self::whereDate($d, $dr)." AND $p IS NOT NULL
                            GROUP BY $p ORDER BY v DESC LIMIT 6",
                        'format'    => 'inr',
                        'transform' => static fn (array $rows): array => [
                            'labels' => array_map(static fn ($row) => $row->label ?? 'Unknown', $rows),
                            'data'   => array_map(static fn ($row) => (float) ($row->v ?? 0), $rows),
                        ],
                    ];
                },
            ],

            [
                'id'        => 'chart.top_items',
                'kind'      => 'chart',
                'chartKind' => 'bar',
                'title'     => 'Top Items',
                'priority'  => 85,
                'requires'  => static fn (array $r): bool => isset($r['sales'])
                    && ! empty($r['sales']['cols']['item'])
                    && ! empty($r['sales']['cols']['amount'])
                    && ! empty($r['sales']['cols']['date']),
                'build' => static function (array $r, array $dr): array {
                    $t = $r['sales']['table']['pg_table'];
                    $i = $r['sales']['cols']['item']['pg_name'];
                    $a = $r['sales']['cols']['amount']['pg_name'];
                    $d = $r['sales']['cols']['date']['pg_name'];

                    return [
                        'sql_main' => "
                            SELECT $i AS label, COALESCE(SUM($a+0), 0) AS v
                            FROM $t ".self::whereDate($d, $dr)." AND $i IS NOT NULL
                            GROUP BY $i ORDER BY v DESC LIMIT 8",
                        'format'    => 'inr',
                        'transform' => static fn (array $rows): array => [
                            'labels' => array_map(
                                static fn ($row) => self::truncate((string) ($row->label ?? 'Unknown'), 24),
                                $rows
                            ),
                            'data' => array_map(static fn ($row) => (float) ($row->v ?? 0), $rows),
                        ],
                    ];
                },
            ],

            // ─────────────── TABLES ─────────────────────────────────────
            [
                'id'       => 'table.recent_invoices',
                'kind'     => 'table',
                'title'    => 'Recent Invoices',
                'priority' => 90,
                'requires' => static fn (array $r): bool => isset($r['sales'])
                    && ! empty($r['sales']['cols']['date'])
                    && ! empty($r['sales']['cols']['amount']),
                'build' => static function (array $r): array {
                    $t   = $r['sales']['table']['pg_table'];
                    $d   = $r['sales']['cols']['date']['pg_name'];
                    $a   = $r['sales']['cols']['amount']['pg_name'];
                    $p   = $r['sales']['cols']['party']['pg_name'] ?? null;
                    $id  = $r['sales']['cols']['id']['pg_name']    ?? null;

                    $cols = ["DATE($d) AS day", "($a+0) AS amount"];
                    if ($p)  $cols[] = "$p AS party";
                    if ($id) $cols[] = "$id AS voucher";

                    return [
                        'sql_main' => 'SELECT '.implode(', ', $cols)
                            ." FROM $t WHERE $d IS NOT NULL ORDER BY $d DESC LIMIT 10",
                        'format' => 'inr',
                        'meta'   => ['has_party' => (bool) $p, 'has_voucher' => (bool) $id],
                    ];
                },
            ],

            [
                'id'       => 'table.top_customers',
                'kind'     => 'table',
                'title'    => 'Top Customers',
                'priority' => 80,
                'requires' => static fn (array $r): bool => isset($r['sales'])
                    && ! empty($r['sales']['cols']['party'])
                    && ! empty($r['sales']['cols']['amount'])
                    && ! empty($r['sales']['cols']['date']),
                'build' => static function (array $r, array $dr): array {
                    $t = $r['sales']['table']['pg_table'];
                    $p = $r['sales']['cols']['party']['pg_name'];
                    $a = $r['sales']['cols']['amount']['pg_name'];
                    $d = $r['sales']['cols']['date']['pg_name'];

                    return [
                        'sql_main' => "
                            SELECT $p AS party, COALESCE(SUM($a+0), 0) AS total, COUNT(*) AS invoices
                            FROM $t ".self::whereDate($d, $dr)." AND $p IS NOT NULL
                            GROUP BY $p ORDER BY total DESC LIMIT 8",
                        'format' => 'inr',
                    ];
                },
            ],

            [
                'id'       => 'table.top_items',
                'kind'     => 'table',
                'title'    => 'Top Items',
                'priority' => 70,
                'requires' => static fn (array $r): bool => isset($r['sales'])
                    && ! empty($r['sales']['cols']['item'])
                    && ! empty($r['sales']['cols']['amount'])
                    && ! empty($r['sales']['cols']['date']),
                'build' => static function (array $r, array $dr): array {
                    $t = $r['sales']['table']['pg_table'];
                    $i = $r['sales']['cols']['item']['pg_name'];
                    $a = $r['sales']['cols']['amount']['pg_name'];
                    $d = $r['sales']['cols']['date']['pg_name'];
                    $q = $r['sales']['cols']['qty']['pg_name'] ?? null;
                    $sumQ = $q ? ", COALESCE(SUM($q+0), 0) AS qty" : '';

                    return [
                        'sql_main' => "
                            SELECT $i AS item, COALESCE(SUM($a+0), 0) AS total{$sumQ}
                            FROM $t ".self::whereDate($d, $dr)." AND $i IS NOT NULL
                            GROUP BY $i ORDER BY total DESC LIMIT 8",
                        'format' => 'inr',
                        'meta'   => ['has_qty' => (bool) $q],
                    ];
                },
            ],
        ];
    }

    // ─────────────── Helpers ───────────────

    /**
     * Build a generic Total-X KPI widget for a {role} table with amount + date columns.
     *
     * @param  array<int, string>  $requireExtra  list of required column keys in $r[$role]['cols']
     */
    private static function kpi(
        string $id,
        string $title,
        string $accent,
        string $icon,
        int $priority,
        string $role,
        array $requireExtra,
        string $amountKey,
        string $dateKey,
    ): array {
        return [
            'id'       => $id,
            'kind'     => 'kpi',
            'title'    => $title,
            'accent'   => $accent,
            'icon'     => $icon,
            'priority' => $priority,
            'requires' => static function (array $r) use ($role, $requireExtra): bool {
                if (! isset($r[$role])) return false;
                foreach ($requireExtra as $k) {
                    if (empty($r[$role]['cols'][$k])) return false;
                }
                return true;
            },
            'build' => static function (array $r, array $dr, array $prevDr) use ($role, $amountKey, $dateKey): array {
                $t = $r[$role]['table']['pg_table'];
                $a = $r[$role]['cols'][$amountKey]['pg_name'];
                $d = $r[$role]['cols'][$dateKey]['pg_name'];

                return [
                    'sql_main' => "SELECT COALESCE(SUM($a+0), 0) AS v FROM $t ".self::whereDate($d, $dr),
                    'sql_prev' => $prevDr['from'] !== null
                        ? "SELECT COALESCE(SUM($a+0), 0) AS v FROM $t ".self::whereDate($d, $prevDr)
                        : null,
                    'sql_spark' => "SELECT DATE($d) AS day, COALESCE(SUM($a+0), 0) AS v
                                    FROM $t ".self::whereDate($d, $dr).' GROUP BY day ORDER BY day',
                    'format' => 'inr',
                ];
            },
        ];
    }

    /**
     * Build a `WHERE col BETWEEN 'from' AND 'to'` clause, or `WHERE 1=1` for the
     * 'all' range. The `1=1` allows downstream `AND col IS NOT NULL` patterns
     * to compose without conditional string concatenation.
     *
     * @param  array{from: ?string, to: ?string}  $dr
     */
    private static function whereDate(string $col, array $dr): string
    {
        if (empty($dr['from'])) {
            return 'WHERE 1=1';
        }

        return "WHERE $col BETWEEN '{$dr['from']}' AND '{$dr['to']}'";
    }

    private static function truncate(string $s, int $n): string
    {
        if (mb_strlen($s) > $n) {
            return mb_substr($s, 0, $n - 1).'…';
        }

        return $s;
    }
}
