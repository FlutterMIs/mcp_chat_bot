<?php

declare(strict_types=1);

namespace App\Services\WhatsApp;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * WhisperTranscriber — wraps OpenAI's `/v1/audio/transcriptions` endpoint.
 *
 * Used by the WhatsApp webhook to convert voice messages into text before
 * routing through TenantRouter. Default language is Hindi ('hi') because most
 * tenant users send Hinglish/Hindi voice notes — explicitly setting language
 * gives Whisper better accuracy than auto-detect for short clips.
 *
 * Public surface:
 *   transcribe(string $audioBytes, ?string $language = 'hi', string $mime = 'audio/ogg'): ?string
 *
 * Returns the transcript text, or null on failure (logs the reason).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~line 2340 — Whisper FormData call)
 */
final class WhisperTranscriber
{
    private const ENDPOINT = 'https://api.openai.com/v1/audio/transcriptions';

    private const MODEL = 'whisper-1';

    /**
     * Send raw audio bytes to Whisper for transcription.
     *
     * @param  string  $audioBytes  raw binary content (e.g. .ogg from WhatsApp voice notes)
     * @param  string|null  $language  ISO-639-1 ('hi', 'en'), or null for auto-detect
     * @param  string  $mime  content-type to declare for the multipart upload
     */
    public static function transcribe(
        string $audioBytes,
        ?string $language = 'hi',
        string $mime = 'audio/ogg'
    ): ?string {
        $apiKey = (string) config('mis.openai_api_key', '');
        if ($apiKey === '') {
            Log::warning('[WHISPER] OPENAI_API_KEY missing');

            return null;
        }
        if ($audioBytes === '') {
            Log::warning('[WHISPER] empty audio buffer');

            return null;
        }

        // Pick the right extension for the mime so Whisper accepts the upload
        $ext = match ($mime) {
            'audio/mpeg', 'audio/mp3' => 'mp3',
            'audio/wav', 'audio/x-wav' => 'wav',
            'audio/mp4', 'audio/m4a' => 'm4a',
            'audio/webm' => 'webm',
            'audio/flac' => 'flac',
            default => 'ogg',
        };

        try {
            // Laravel's Http::attach + asMultipart sends the file as a multipart part;
            // additional fields go through post()'s second arg as `[['name' => ..., 'contents' => ...]]`.
            $extraParts = [
                ['name' => 'model', 'contents' => self::MODEL],
            ];
            if ($language !== null && $language !== '') {
                $extraParts[] = ['name' => 'language', 'contents' => $language];
            }

            $resp = Http::withToken($apiKey)
                ->timeout(60)
                ->asMultipart()
                ->attach('file', $audioBytes, "audio.{$ext}", ['Content-Type' => $mime])
                ->post(self::ENDPOINT, $extraParts);

            if (! $resp->ok()) {
                Log::warning('[WHISPER] non-200 '.$resp->status().' body='.substr($resp->body(), 0, 200));

                return null;
            }

            $json = $resp->json();
            $text = (string) ($json['text'] ?? '');
            $text = trim($text);
            if ($text === '') {
                Log::info('[WHISPER] empty transcript');

                return null;
            }

            Log::info('[WHISPER] transcribed '.strlen($audioBytes).'B → '.mb_substr($text, 0, 80));

            return $text;
        } catch (Throwable $e) {
            Log::error('[WHISPER] '.$e->getMessage());

            return null;
        }
    }
}
