<?php

declare(strict_types=1);

namespace App\Services\WhatsApp;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;
use App\Models\Tenant;
use App\Models\TenantApiKey;

/**
 * WhatsApp client — text + audio download.
 *
 * Uses the wa.apimis.in API gateway (which proxies to Meta WhatsApp Cloud API)
 * because that's what production already uses. Auth is two headers:
 *   x-api-key:  WA_ACCESS_TOKEN  (Meta access token)
 *   x-phone-id: WA_PHONE_ID      (Meta phone number ID)
 *
 * Public surface:
 *   sendText(string $to, string $msg): bool                            — outbound text
 *   sendImage(string $to, string $filePath, string $caption=''): bool  — upload + send image (chart PNG etc.)
 *   sendDocument(string $to, string $filePath, string $caption='', ?string $filename=null): bool — upload + send PDF/CSV/XLSX
 *   sendImageByUrl(string $to, string $url, string $caption=''): bool  — direct send by URL (no upload — for product images)
 *   uploadMedia(string $filePath, ?string $mime=null): ?string         — POST file → returns metaMediaId
 *   downloadAudioFromUrl(string $url): ?string                         — for wa.apimis.in `filePath` flow
 *   downloadMetaMedia(string $mediaId): ?string                        — for Meta nested-shape media id
 *   formatPhone(string $to): string                                    — E.164 normaliser
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/whatsapp.js
 */
final class Client
{
    private const BASE_URL = 'https://wa.apimis.in/api/v1';

    /** Text-send endpoint tied to the connected channel (auth: x-api-key only, no phone-id). */
    private const SEND_URL = 'http://app.mis.work/api/v1/message/create';

    /** Professional API endpoint (official WhatsApp Business API via wa.apimis.in). */
    private const PROFESSIONAL_SEND_URL = 'https://wa.apimis.in/api/v1/whatsapp/sendMessage';

    /**
     * Resolve the WA API key for a given tenant.
     * If tenant uses 'own' mode and has a key set, return that; else fall back to shared MIS key.
     */
    public static function resolveApiKey(?string $tenantId = null): string
    {
        $config = self::resolveChannelConfig($tenantId);
        return $config['api_key'];
    }

    /**
     * Resolve full channel config for a tenant: api_key, channel_mode, device_id.
     *
     * @return array{api_key: string, channel_mode: string, device_id: string|null}
     */
    public static function resolveChannelConfig(?string $tenantId = null): array
    {
        $channelMode = 'unprofessional';
        $apiKey = (string) config('mis.wa_unpro_api_key', '');
        $deviceId = (string) config('mis.wa_pro_phone_id', '');

        if ($tenantId) {
            $tenant = Tenant::query()
                ->select(['wa_key_mode', 'wa_channel_mode'])
                ->where('id', $tenantId)
                ->first();
                
            if ($tenant) {
                if ($tenant->wa_channel_mode) {
                    $channelMode = $tenant->wa_channel_mode;
                }

                if ($tenant->wa_key_mode === 'own') {
                    $keyType = $channelMode === 'professional' ? 1 : 2;
                    $customKey = TenantApiKey::query()
                        ->where('tenant_id', $tenantId)
                        ->where('type', $keyType)
                        ->where('status', 'active')
                        ->first();

                    if ($customKey && $customKey->api_key) {
                        $apiKey = $customKey->api_key;
                        if ($keyType === 1 && $customKey->device_id) {
                            $deviceId = $customKey->device_id;
                        }
                    } else {
                        // Fallback to global env keys if the custom key wasn't found or was empty, 
                        // but ensure we pick the global config for the *active channel mode*.
                        if ($channelMode === 'professional') {
                            $apiKey = (string) config('mis.wa_pro_api_key', '');
                        }
                    }
                } else if ($channelMode === 'professional') {
                    // Shared mode, but professional channel active
                    $apiKey = (string) config('mis.wa_pro_api_key', '');
                }
            }
        }

        return [
            'api_key'      => $apiKey,
            'channel_mode' => $channelMode,
            'device_id'    => $deviceId,
        ];
    }

    /** Send a plain text message. Returns true on success, false on failure. */
    public static function sendText(string $to, string $message, ?string $tenantId = null): bool
    {
        $config = self::resolveChannelConfig($tenantId);
        $apiKey = $config['api_key'];
        if ($apiKey === '') {
            Log::warning('[WA SEND] missing WA_ACCESS_TOKEN');

            return false;
        }

        $phone = self::formatPhone($to);
        $text = mb_substr($message, 0, 4096);

        // TESTING_MODE — short-circuit the actual HTTP call so webhook live tests don't deliver
        // real WhatsApp messages to phones that may unexpectedly be valid.
        if (filter_var(config('mis.testing_mode', false), FILTER_VALIDATE_BOOLEAN)) {
            Log::info("[WA SEND TESTING_MODE] suppressed → to={$phone} mode={$config['channel_mode']} msg=".mb_substr($text, 0, 80));

            return true;
        }

        // ── Professional API path ──
        if ($config['channel_mode'] === 'professional') {
            return self::sendViaProfessional($phone, [
                'to'   => $phone,
                'text' => $text,
            ], $apiKey, $config['device_id']);
        }

        // ── Unprofessional API path (default) ──
        Log::info("[WA SEND] to={$phone}  apiKey=…".substr($apiKey, -4)."  endpoint=".self::SEND_URL);

        try {
            $resp = Http::withHeaders(['x-api-key' => $apiKey])
                ->timeout(20)
                ->post(self::SEND_URL, [
                    'receiverMobileNo' => $phone,
                    'message'          => [$text],
                ]);

            $body = $resp->json();
            Log::info('[WA SEND RESP] status='.$resp->status().' body='.json_encode($body));

            if (! $resp->ok() || ($body['status'] ?? null) !== 200 || ($body['message'] ?? null) !== 'success') {
                Log::warning('[WA SEND FAIL] status='.$resp->status().' body='.json_encode($body));

                return false;
            }
            Log::info('[WA SEND OK] '.json_encode($body['result'] ?? $body));

            return true;
        } catch (Throwable $e) {
            Log::error('[WA SEND ERROR] '.$e->getMessage());

            return false;
        }
    }

    /**
     * Send a message via the Professional WhatsApp API (wa.apimis.in).
     * Accepts a pre-built message body in Meta Cloud API format.
     */
    private static function sendViaProfessional(string $phone, array $messageBody, string $apiKey, ?string $deviceId): bool
    {
        $headers = ['Content-Type' => 'application/json'];
        if ($apiKey) {
            $headers['x-api-key'] = $apiKey;
        }
        if ($deviceId) {
            $headers['x-phone-id'] = $deviceId;
        }

        Log::info("[WA SEND PRO] to={$phone}  apiKey=…".substr($apiKey, -4)."  endpoint=".self::PROFESSIONAL_SEND_URL);

        try {
            $resp = Http::withHeaders($headers)
                ->timeout(20)
                ->post(self::PROFESSIONAL_SEND_URL, $messageBody);

            $body = $resp->json();
            Log::info('[WA SEND PRO RESP] status='.$resp->status().' body='.json_encode($body));

            if (! $resp->ok()) {
                Log::warning('[WA SEND PRO FAIL] status='.$resp->status().' body='.json_encode($body));

                return false;
            }
            Log::info('[WA SEND PRO OK] '.json_encode($body));

            return true;
        } catch (Throwable $e) {
            Log::error('[WA SEND PRO ERROR] '.$e->getMessage());

            return false;
        }
    }

    /**
     * Normalise a phone number to E.164 (without `+`) — same logic as Node helpers/whatsapp.js
     * formatPhone. Drops non-digits, prepends "91" if 10-digit Indian, leaves alone otherwise.
     */
    public static function formatPhone(string $to): string
    {
        $phone = preg_replace('/[^0-9]/', '', $to) ?? '';
        if (str_starts_with($phone, '91') && strlen($phone) === 12) {
            return $phone;
        }
        if (strlen($phone) === 10) {
            return '91'.$phone;
        }

        return $phone;
    }

    /**
     * Fetch an audio buffer from a direct URL (used when wa.apimis.in payload carries `filePath`).
     * No auth headers — wa.apimis.in's filePath is typically a pre-signed S3 URL.
     *
     * @return string|null  raw bytes, or null on failure
     */
    public static function downloadAudioFromUrl(string $url): ?string
    {
        try {
            $resp = Http::timeout(30)->get($url);
            if (! $resp->ok()) {
                Log::warning("[WA AUDIO DL] {$url} returned ".$resp->status());

                return null;
            }

            return $resp->body();
        } catch (Throwable $e) {
            Log::error('[WA AUDIO DL] '.$e->getMessage());

            return null;
        }
    }

    /**
     * Fetch audio for a Meta media ID. Two-step:
     *   1. GET /whatsapp/media/mediaDetail/{id} with x-api-key + x-phone-id → returns JSON with the actual media URL
     *   2. GET that URL with Bearer auth → returns the raw bytes
     *
     * Mirrors Node helpers/whatsapp.js downloadMetaMedia exactly.
     *
     * @return string|null  raw bytes, or null on failure
     */
    public static function downloadMetaMedia(string $mediaId): ?string
    {
        $apiKey = (string) config('mis.wa_access_token', '');
        $phoneId = (string) config('mis.wa_phone_id', '');
        if ($apiKey === '' || $phoneId === '') {
            Log::warning('[WA MEDIA DL] missing WA_ACCESS_TOKEN or WA_PHONE_ID');

            return null;
        }

        try {
            $detailResp = Http::withHeaders([
                'x-api-key'  => $apiKey,
                'x-phone-id' => $phoneId,
            ])->timeout(15)->get(self::BASE_URL."/whatsapp/media/mediaDetail/{$mediaId}");

            if (! $detailResp->ok()) {
                Log::warning('[WA MEDIA DL] mediaDetail returned '.$detailResp->status());

                return null;
            }

            $detail = $detailResp->json();
            $url = $detail['mediaDetail']['url'] ?? $detail['url'] ?? null;
            if (! is_string($url) || $url === '') {
                Log::warning('[WA MEDIA DL] no URL for id '.$mediaId);

                return null;
            }

            $bytesResp = Http::withHeaders([
                'Authorization' => 'Bearer '.$apiKey,
            ])->timeout(30)->get($url);

            if (! $bytesResp->ok()) {
                Log::warning('[WA MEDIA DL] media URL returned '.$bytesResp->status());

                return null;
            }

            return $bytesResp->body();
        } catch (Throwable $e) {
            Log::error('[WA MEDIA DL] '.$e->getMessage());

            return null;
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // OUTBOUND MEDIA — upload + send (image / PDF / CSV / XLSX / chart PNG)
    // ════════════════════════════════════════════════════════════════════

    /**
     * Upload + send an image (chart PNG, screenshot, etc.).
     *
     *   1. uploadMedia($filePath) → metaMediaId
     *   2. POST /whatsapp/meta/sendMessage with {type:'image', image:{id, caption}}
     *
     * Caption is capped at 1024 chars (Meta limit).
     */
    public static function sendImage(string $to, string $filePath, string $caption = '', ?string $tenantId = null): bool
    {
        return self::sendFile($to, $filePath, $caption, null, $tenantId);
    }

    /**
     * Upload + send a document (PDF, CSV, XLSX, etc.).
     *
     *   1. uploadMedia($filePath) → metaMediaId
     *   2. POST /whatsapp/meta/sendMessage with {type:'document', document:{id, caption, filename}}
     *
     * `filename` defaults to basename($filePath) and shows as the file name on
     * the recipient's WhatsApp client. Caption is capped at 1024 chars.
     */
    public static function sendDocument(string $to, string $filePath, string $caption = '', ?string $filename = null, ?string $tenantId = null): bool
    {
        return self::sendFile($to, $filePath, $caption, $filename, $tenantId);
    }

    /**
     * Send an image directly by URL — no upload step. Used for product-image lists
     * where each item already has a public URL (sheet column with .jpg/.png link).
     *
     * Mirrors Node server.js line 2438-2447 — the product-images dispatch path
     * uses `image.link` instead of `image.id`.
     */
    public static function sendImageByUrl(string $to, string $url, string $caption = '', ?string $tenantId = null): bool
    {
        $phone = self::formatPhone($to);

        if (filter_var(config('mis.testing_mode', false), FILTER_VALIDATE_BOOLEAN)) {
            Log::info("[WA SEND IMAGE-URL TESTING_MODE] suppressed → to={$phone} url={$url}");

            return true;
        }

        return self::postCreate([
            'receiverMobileNo' => $phone,
            'message'          => [],
            'filePathUrl'      => [$url],
            'caption'          => [mb_substr($caption, 0, 1024)],
        ], $tenantId);
    }

    /**
     * Common Meta /sendMessage helper — POSTs the JSON body and validates the response.
     * Used by both sendImage / sendDocument (id-based) and sendImageByUrl (link-based).
     *
     * @param  array<string, mixed>  $mediaObj  the inner object — either {id, caption[, filename]} or {link, caption}
     */
    /** Send a local file (image / PDF / CSV / chart PNG) via /message/create with base64File. */
    private static function sendFile(string $to, string $filePath, string $caption, ?string $filename, ?string $tenantId = null): bool
    {
        if (! is_file($filePath) || ! is_readable($filePath)) {
            Log::warning("[WA SEND FILE] not readable: {$filePath}");

            return false;
        }

        $phone = self::formatPhone($to);
        $name = $filename ?? basename($filePath);

        if (filter_var(config('mis.testing_mode', false), FILTER_VALIDATE_BOOLEAN)) {
            Log::info("[WA SEND FILE TESTING_MODE] suppressed → to={$phone} name={$name}");

            return true;
        }

        $bytes = @file_get_contents($filePath);
        if ($bytes === false || $bytes === '') {
            Log::warning("[WA SEND FILE] empty/unreadable: {$filePath}");

            return false;
        }

        $capText = mb_substr($caption, 0, 1024);

        return self::postCreate([
            'receiverMobileNo' => $phone,
            'message'          => [$capText !== '' ? $capText : '📄'],
            'base64File'       => [['name' => $name, 'body' => base64_encode($bytes)]],
        ], $tenantId);
    }

    /** POST a body to /message/create with x-api-key auth; success = status 200 + message "success". */
    private static function postCreate(array $payload, ?string $tenantId = null): bool
    {
        $config = self::resolveChannelConfig($tenantId);
        $apiKey = $config['api_key'];
        if ($apiKey === '') {
            Log::warning('[WA SEND MEDIA] missing WA_ACCESS_TOKEN');

            return false;
        }

        // ── Professional API path for media ──
        if ($config['channel_mode'] === 'professional') {
            $phone = $payload['receiverMobileNo'] ?? '';
            // Build a document message for professional API if base64File is present
            if (!empty($payload['base64File'])) {
                $file = $payload['base64File'][0] ?? [];
                $proBody = [
                    'to'       => $phone,
                    'type'     => 'document',
                    'document' => [
                        'filename' => $file['name'] ?? 'file',
                        'caption'  => $payload['message'][0] ?? '',
                        'body'     => $file['body'] ?? '',
                    ],
                ];
                return self::sendViaProfessional($phone, $proBody, $apiKey, $config['device_id']);
            }
            // Image by URL
            if (!empty($payload['filePathUrl'])) {
                $proBody = [
                    'to'    => $phone,
                    'type'  => 'image',
                    'image' => [
                        'link'    => $payload['filePathUrl'][0] ?? '',
                        'caption' => $payload['caption'][0] ?? $payload['message'][0] ?? '',
                    ],
                ];
                return self::sendViaProfessional($phone, $proBody, $apiKey, $config['device_id']);
            }
        }

        // ── Unprofessional API path (default) ──
        try {
            $resp = Http::withHeaders(['x-api-key' => $apiKey])
                ->timeout(60)
                ->post(self::SEND_URL, $payload);

            $body = $resp->json();
            if (! $resp->ok() || ($body['status'] ?? null) !== 200 || ($body['message'] ?? null) !== 'success') {
                Log::warning('[WA SEND MEDIA FAIL] status='.$resp->status().' body='.json_encode($body));

                return false;
            }

            Log::info('[WA SEND MEDIA OK] '.json_encode($body['result'] ?? $body));

            return true;
        } catch (Throwable $e) {
            Log::error('[WA SEND MEDIA] '.$e->getMessage());

            return false;
        }
    }

    /**
     * Infer Content-Type from a file path's extension. Same map as Node helpers/whatsapp.js
     * sendWhatsAppMedia → covers .pdf / .csv / .xlsx / .xls / .png / .jpg / .jpeg / .gif / .webp /
     * .txt. Falls back to application/octet-stream for unknown extensions (Meta will accept
     * but the recipient may see a generic "file" icon).
     */
    public static function mimeFromExt(string $filePath): string
    {
        $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

        return match ($ext) {
            'pdf'             => 'application/pdf',
            'csv'             => 'text/csv',
            'txt'             => 'text/plain',
            'xlsx'            => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'xls'             => 'application/vnd.ms-excel',
            'png'             => 'image/png',
            'jpg', 'jpeg'     => 'image/jpeg',
            'gif'             => 'image/gif',
            'webp'            => 'image/webp',
            default           => 'application/octet-stream',
        };
    }
}
