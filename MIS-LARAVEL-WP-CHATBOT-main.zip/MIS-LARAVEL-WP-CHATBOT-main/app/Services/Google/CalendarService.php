<?php

declare(strict_types=1);

namespace App\Services\Google;

use Google\Client as GoogleClient;
use Google\Service\Calendar as GoogleCalendar;
use Google\Service\Calendar\Event;
use Google\Service\Calendar\EventAttendee;
use Google\Service\Calendar\EventDateTime;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

/**
 * CalendarService — OAuth2 flow + per-tenant Google Calendar operations.
 *
 * Port of Node helpers/tenant-calendar.js. Uses google/apiclient v2.19 (already
 * installed in Phase 23A). Single shared OAuth client config (CLIENT_ID + SECRET
 * from .env); per-tenant credentials supplied at request time as the stored
 * `refresh_token`.
 *
 * Public surface:
 *   getAuthURL(string $tenantId): string                                — Step 1: redirect URL
 *   exchangeCode(string $code): array                                   — Step 2: code → tokens
 *   createEvent(string $refreshToken, string $calId, array $event): array — book a meeting
 *   getEvents(string $refreshToken, string $calId, string $from, string $to): array
 *   getTodayEvents(string $refreshToken, string $calId): array          — today's events
 *   deleteEvent(string $refreshToken, string $calId, string $eventId): bool
 *   updateEvent(string $refreshToken, string $calId, string $eventId, array $updates): array
 *   generateMeetLink(string $title): string                             — Jitsi link
 *
 * `state` parameter on the auth URL carries `tenantId` so the callback can
 * resolve which tenant the OAuth flow is for.
 *
 * Times are sent/received in IST (Asia/Kolkata). Server.js uses the same TZ.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-calendar.js
 */
final class CalendarService
{
    public const TIMEZONE = 'Asia/Kolkata';

    private const SCOPES = ['https://www.googleapis.com/auth/calendar'];

    /** Build a Google_Client for OAuth (no per-tenant creds yet). */
    private static function getOAuth2Client(): GoogleClient
    {
        $clientId = (string) config('mis.google_client_id', '');
        $clientSecret = (string) config('mis.google_client_secret', '');

        if ($clientId === '' || $clientSecret === '') {
            throw new RuntimeException('GOOGLE_CLIENT_ID / GOOGLE_CLIENT_SECRET not configured in .env');
        }

        $client = new GoogleClient();
        $client->setClientId($clientId);
        $client->setClientSecret($clientSecret);
        $client->setRedirectUri(config('mis.google_redirect_uri'));
        $client->setAccessType('offline');
        $client->setPrompt('consent');
        $client->addScope(self::SCOPES);

        return $client;
    }

    /**
     * Step 1: build the Google consent URL. Pass `tenantId` in `state` so the
     * callback can resolve which tenant the OAuth flow is for.
     */
    public static function getAuthURL(string $tenantId): string
    {
        $client = self::getOAuth2Client();
        $client->setState($tenantId);

        return $client->createAuthUrl();
    }

    /**
     * Step 2: exchange the OAuth code for {access_token, refresh_token, ...}.
     *
     * @return array{access_token?: string, refresh_token?: string, expires_in?: int, scope?: string, token_type?: string}
     *
     * @throws RuntimeException  on any failure (Google error, missing refresh_token)
     */
    public static function exchangeCode(string $code): array
    {
        $client = self::getOAuth2Client();
        try {
            $tokens = $client->fetchAccessTokenWithAuthCode($code);
        } catch (Throwable $e) {
            throw new RuntimeException('OAuth code exchange failed: '.$e->getMessage(), 0, $e);
        }

        if (isset($tokens['error'])) {
            $err = (string) ($tokens['error_description'] ?? $tokens['error']);
            throw new RuntimeException("OAuth code exchange returned error: {$err}");
        }

        return $tokens;
    }

    /** Build a Calendar API client primed with the tenant's refresh_token. */
    private static function getCalendarClient(string $refreshToken): GoogleCalendar
    {
        $client = self::getOAuth2Client();
        $client->refreshToken($refreshToken);

        return new GoogleCalendar($client);
    }

    // ════════════════════════════════════════════════════════════════════
    // CALENDAR OPERATIONS (per-tenant)
    // ════════════════════════════════════════════════════════════════════

    /**
     * Generate a Jitsi Meet link for a meeting (no Google Workspace needed).
     * Format: https://meet.jit.si/SB-{slug}-{6-char-id}.
     */
    public static function generateMeetLink(?string $title = null): string
    {
        $slug = mb_substr(preg_replace('/[^a-zA-Z0-9]/', '', $title ?? 'meeting') ?? 'meeting', 0, 20);
        if ($slug === '') $slug = 'meeting';
        $id = substr(bin2hex(random_bytes(4)), 0, 6);

        return "https://meet.jit.si/SB-{$slug}-{$id}";
    }

    /**
     * Create a calendar event. Auto-injects a Jitsi Meet link into the description.
     *
     * @param  array{title:string, startTime:string, endTime?:string, description?:string, guests?:list<string>}  $event
     * @return array  ['eventId'=>..., 'htmlLink'=>..., 'meetLink'=>..., 'summary'=>..., 'startTime'=>..., 'endTime'=>...]
     *
     * @throws RuntimeException  on Google API error
     */
    public static function createEvent(string $refreshToken, string $calendarId, array $event): array
    {
        $title = (string) ($event['title'] ?? 'Meeting');
        $startTime = (string) $event['startTime'];   // ISO 8601 with offset
        $endTime = (string) ($event['endTime']
            ?? (new \DateTimeImmutable($startTime))->modify('+1 hour')->format('c'));
        $description = (string) ($event['description'] ?? '');
        $guests = $event['guests'] ?? [];

        $meetLink = self::generateMeetLink($title);
        $desc = trim(($description !== '' ? $description : '')."\n🔗 Video Call: {$meetLink}");

        $gEvent = new Event([
            'summary'     => $title,
            'description' => $desc,
            'start'       => new EventDateTime([
                'dateTime' => $startTime,
                'timeZone' => self::TIMEZONE,
            ]),
            'end'         => new EventDateTime([
                'dateTime' => $endTime,
                'timeZone' => self::TIMEZONE,
            ]),
        ]);

        if (is_array($guests) && count($guests) > 0) {
            $attendees = [];
            foreach ($guests as $email) {
                if (is_string($email) && $email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $a = new EventAttendee();
                    $a->setEmail($email);
                    $attendees[] = $a;
                }
            }
            if (count($attendees) > 0) {
                $gEvent->setAttendees($attendees);
            }
        }

        try {
            $cal = self::getCalendarClient($refreshToken);
            $created = $cal->events->insert($calendarId !== '' ? $calendarId : 'primary', $gEvent);
        } catch (Throwable $e) {
            throw new RuntimeException('Calendar createEvent failed: '.$e->getMessage(), 0, $e);
        }

        return [
            'eventId'   => $created->getId(),
            'htmlLink'  => $created->getHtmlLink(),
            'meetLink'  => $meetLink,
            'summary'   => $created->getSummary(),
            'startTime' => $created->getStart()?->getDateTime(),
            'endTime'   => $created->getEnd()?->getDateTime(),
        ];
    }

    /**
     * List events between $from and $to (ISO 8601 strings).
     *
     * @return list<array{id:string, summary:?string, start:?string, end:?string, htmlLink:?string}>
     *
     * @throws RuntimeException
     */
    public static function getEvents(string $refreshToken, string $calendarId, string $from, string $to): array
    {
        try {
            $cal = self::getCalendarClient($refreshToken);
            $items = $cal->events->listEvents($calendarId !== '' ? $calendarId : 'primary', [
                'timeMin'      => $from,
                'timeMax'      => $to,
                'singleEvents' => true,
                'orderBy'      => 'startTime',
                'timeZone'     => self::TIMEZONE,
            ]);
        } catch (Throwable $e) {
            throw new RuntimeException('Calendar getEvents failed: '.$e->getMessage(), 0, $e);
        }

        $out = [];
        foreach ($items->getItems() as $e) {
            $out[] = [
                'id'          => $e->getId(),
                'summary'     => $e->getSummary(),
                'description' => $e->getDescription() ?? '',
                'start'       => $e->getStart()?->getDateTime() ?: $e->getStart()?->getDate(),
                'end'         => $e->getEnd()?->getDateTime() ?: $e->getEnd()?->getDate(),
                'all_day'     => $e->getStart()?->getDateTime() === null,
                'location'    => $e->getLocation() ?? '',
                'attendees'   => array_values(array_filter(array_map(
                    static fn ($a) => $a->getEmail(),
                    $e->getAttendees() ?? []
                ))),
                'htmlLink'    => $e->getHtmlLink(),
            ];
        }

        return $out;
    }

    /** Convenience: list events between today's 00:00 and 24:00 IST. */
    public static function getTodayEvents(string $refreshToken, string $calendarId): array
    {
        $tz = new \DateTimeZone(self::TIMEZONE);
        $start = new \DateTimeImmutable('today', $tz);
        $end = $start->modify('+1 day');

        return self::getEvents(
            $refreshToken,
            $calendarId,
            $start->format('c'),
            $end->format('c')
        );
    }

    /** Delete an event. Returns true on success. Throws RuntimeException on any error. */
    public static function deleteEvent(string $refreshToken, string $calendarId, string $eventId): bool
    {
        try {
            $cal = self::getCalendarClient($refreshToken);
            $cal->events->delete($calendarId !== '' ? $calendarId : 'primary', $eventId);

            return true;
        } catch (Throwable $e) {
            throw new RuntimeException('Calendar deleteEvent failed: '.$e->getMessage(), 0, $e);
        }
    }

    /**
     * Patch an existing event. `$updates` can include any subset of {summary, description,
     * start.dateTime, end.dateTime, attendees}.
     *
     * @param  array<string, mixed>  $updates
     */
    public static function updateEvent(string $refreshToken, string $calendarId, string $eventId, array $updates): array
    {
        try {
            $cal = self::getCalendarClient($refreshToken);
            $existing = $cal->events->get($calendarId !== '' ? $calendarId : 'primary', $eventId);

            if (isset($updates['summary'])) $existing->setSummary((string) $updates['summary']);
            if (isset($updates['description'])) $existing->setDescription((string) $updates['description']);
            if (isset($updates['startTime'])) {
                $existing->setStart(new EventDateTime([
                    'dateTime' => (string) $updates['startTime'],
                    'timeZone' => self::TIMEZONE,
                ]));
            }
            if (isset($updates['endTime'])) {
                $existing->setEnd(new EventDateTime([
                    'dateTime' => (string) $updates['endTime'],
                    'timeZone' => self::TIMEZONE,
                ]));
            }

            $patched = $cal->events->update($calendarId !== '' ? $calendarId : 'primary', $eventId, $existing);

            return [
                'eventId'   => $patched->getId(),
                'summary'   => $patched->getSummary(),
                'startTime' => $patched->getStart()?->getDateTime(),
                'endTime'   => $patched->getEnd()?->getDateTime(),
                'htmlLink'  => $patched->getHtmlLink(),
            ];
        } catch (Throwable $e) {
            throw new RuntimeException('Calendar updateEvent failed: '.$e->getMessage(), 0, $e);
        }
    }
}
