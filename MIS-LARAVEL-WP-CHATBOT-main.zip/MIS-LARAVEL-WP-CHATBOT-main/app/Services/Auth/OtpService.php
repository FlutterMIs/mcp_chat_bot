<?php

declare(strict_types=1);

namespace App\Services\Auth;

use App\Services\WhatsApp\Client;
use Illuminate\Support\Facades\Cache;

/**
 * OTP service — sends 6-digit code via WhatsApp, verifies on login.
 * No SMS cost — uses existing WhatsApp gateway.
 */
final class OtpService
{
    private const TTL = 300; // 5 minutes
    private const MAX_ATTEMPTS = 5;
    private const RESEND_COOLDOWN = 60; // seconds between sends — enforced server-side so the
    // frontend countdown can't be bypassed by refreshing the page or calling the API directly.

    /**
     * Seconds remaining before this phone may request another OTP. 0 = may send now.
     * Frontend uses this to sync its visible countdown to ground truth.
     */
    public static function secondsUntilResend(string $phone): int
    {
        $sentAt = Cache::get("otp_sent_at:{$phone}");
        if ($sentAt === null) return 0;

        $remaining = self::RESEND_COOLDOWN - (time() - (int) $sentAt);

        return max(0, $remaining);
    }

    /** Generate and send OTP via WhatsApp. Returns true if sent. */
    public static function send(string $phone, ?string $tenantId = null): bool
    {
        $code = str_pad((string) random_int(100000, 999999), 6, '0', STR_PAD_LEFT);
        Cache::put("otp:{$phone}", $code, self::TTL);
        Cache::put("otp_attempts:{$phone}", 0, self::TTL);
        Cache::put("otp_sent_at:{$phone}", time(), self::RESEND_COOLDOWN);

        return Client::sendText($phone, "🔐 Your MIS login OTP: *{$code}*\n\nValid for 5 minutes. Do not share.", $tenantId);
    }

    /** Verify OTP. Returns true if correct, false if wrong/expired. */
    public static function verify(string $phone, string $code): bool
    {
        $attempts = (int) Cache::get("otp_attempts:{$phone}", 0);
        if ($attempts >= self::MAX_ATTEMPTS) return false;

        Cache::put("otp_attempts:{$phone}", $attempts + 1, self::TTL);

        $stored = Cache::get("otp:{$phone}");
        if ($stored === null) return false;

        if ($stored === $code) {
            Cache::forget("otp:{$phone}");
            Cache::forget("otp_attempts:{$phone}");
            return true;
        }

        return false;
    }
}
