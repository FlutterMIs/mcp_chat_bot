<?php

declare(strict_types=1);

namespace App\Services\Auth;

/**
 * ChatTokenService — HMAC-SHA256 phone-token sign + verify.
 *
 * Token format: `{phoneB64}.{iat}.{exp}.{hexHmac}`
 *   - phoneB64: base64url-encoded phone (digits only, 10-15 chars)
 *   - iat:      issued-at unix timestamp (seconds)
 *   - exp:      expiry unix timestamp (24h after iat by default)
 *   - hexHmac:  HMAC-SHA256 over `{phoneB64}.{iat}.{exp}` using CHAT_TOKEN_SECRET
 *
 * Issued by AuthController::issueToken (after phone resolves to a tenant).
 * Verified by ChatAuthGate middleware on /api/chat.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~lines 4300-4400 — issueChatToken/verifyChatToken)
 */
final class ChatTokenService
{
    /** Token TTL in seconds — 24 hours. Matches Node parity. */
    public const TTL_SECONDS = 86_400;

    /**
     * Issue a fresh token for the given phone.
     *
     * @throws \RuntimeException  if CHAT_TOKEN_SECRET unset or phone invalid
     */
    public static function issueToken(string $phone): string
    {
        $secret = (string) config('mis.chat_token_secret', '');
        if ($secret === '') {
            throw new \RuntimeException('CHAT_TOKEN_SECRET not configured');
        }

        $phoneClean = preg_replace('/[^0-9]/', '', $phone) ?? '';
        if ($phoneClean === '' || strlen($phoneClean) < 10 || strlen($phoneClean) > 15) {
            throw new \RuntimeException('Invalid phone for token issue');
        }

        $phoneB64 = self::b64urlEncode($phoneClean);
        $iat = time();
        $exp = $iat + self::TTL_SECONDS;
        $payload = "{$phoneB64}.{$iat}.{$exp}";
        $sig = hash_hmac('sha256', $payload, $secret);

        return "{$payload}.{$sig}";
    }

    /**
     * Verify a token. Returns ok=true with phone+exp on success, or ok=false with an error
     * code on any failure (missing, malformed, bad-signature, expired, bad-payload, etc.).
     *
     * Uses hash_equals for timing-safe signature comparison (defense against timing attacks
     * on the HMAC, even though our throughput is too low for them to matter in practice).
     *
     * @return array{ok: bool, error?: string, phone?: string, exp?: int}
     */
    public static function verifyToken(?string $token): array
    {
        $secret = (string) config('mis.chat_token_secret', '');
        if ($secret === '') {
            return ['ok' => false, 'error' => 'no-secret'];
        }
        if ($token === null || $token === '') {
            return ['ok' => false, 'error' => 'missing'];
        }

        $parts = explode('.', $token);
        if (count($parts) !== 4) {
            return ['ok' => false, 'error' => 'malformed'];
        }

        [$phoneB64, $iatStr, $expStr, $sig] = $parts;
        $payload = "{$phoneB64}.{$iatStr}.{$expStr}";
        $expected = hash_hmac('sha256', $payload, $secret);

        if (! hash_equals($expected, $sig)) {
            return ['ok' => false, 'error' => 'bad-signature'];
        }

        $exp = is_numeric($expStr) ? (int) $expStr : 0;
        if ($exp <= 0 || $exp < time()) {
            return ['ok' => false, 'error' => 'expired'];
        }

        $phone = self::b64urlDecode($phoneB64);
        if ($phone === null || ! preg_match('/^[0-9]{10,15}$/', $phone)) {
            return ['ok' => false, 'error' => 'bad-payload'];
        }

        return ['ok' => true, 'phone' => $phone, 'exp' => $exp];
    }

    /**
     * base64url encode (RFC 4648 Section 5) — same encoding the Node `_b64urlEncode` uses.
     */
    private static function b64urlEncode(string $raw): string
    {
        return rtrim(strtr(base64_encode($raw), '+/', '-_'), '=');
    }

    /**
     * base64url decode. Returns null on invalid input.
     */
    private static function b64urlDecode(string $encoded): ?string
    {
        $padded = strtr($encoded, '-_', '+/');
        $remainder = strlen($padded) % 4;
        if ($remainder !== 0) {
            $padded .= str_repeat('=', 4 - $remainder);
        }
        $raw = base64_decode($padded, true);

        return $raw === false ? null : $raw;
    }
}
