<?php

declare(strict_types=1);

namespace App\Services\Chat;

/**
 * ImageColumnDetector — find image-URL columns in tenant metadata and extract
 * image+caption pairs from SQL result rows.
 *
 * Used by the 'images' query mode:
 *   1. detectImageColumns(tablesMetadata) — pre-flight: which columns hold image URLs?
 *      If empty → TenantRouter returns a "no photo columns" reply without an AI call.
 *      Otherwise the column list goes into the prompt so AI knows to SELECT from them.
 *   2. extractImageItems(rows) — post-SQL: walk result rows, pick the first URL-shaped
 *      cell as the image, the first non-URL string as the caption.
 *
 * Detection strategy (high-confidence first):
 *   3 — column samples include an explicit image URL ending in .jpg/.png/.webp/etc.
 *   2 — column literally named image|photo|pic|thumbnail|tasveer|img
 *   1 — column named url|link|src AND every sample is a URL (best-effort)
 *
 * Public API (all static — pure functions, no I/O):
 *   detectImageColumns(list $tablesMetadata): list<array>
 *   extractImageItems(list $rows, int $maxItems = 20): list<array{url:string, caption:string}>
 *   isImageUrl(mixed $v): bool        — public so callers can probe single values
 *   isGenericUrl(mixed $v): bool
 *   isImageColumnName(string $n): bool
 *   isUrlColumnName(string $n): bool
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-router.js (~lines 263-348)
 */
final class ImageColumnDetector
{
    /** Direct image URL: https URL ending in image extension (optional query string). */
    private const IMG_URL_RE = '/^https?:\/\/[^\s]+\.(?:jpg|jpeg|png|gif|webp|bmp|svg)(?:\?[^\s]*)?$/i';

    /** Any https URL (image columns may serve from CDNs without extensions, e.g. Shopify). */
    private const GENERIC_URL_RE = '/^https?:\/\/[^\s]+$/i';

    /** Column names that suggest the value is an image URL. `pic(?!kup)` excludes "pickup". */
    private const IMG_NAME_RE = '/image|photo|pic(?!kup)|picture|thumbnail|tasveer|img/i';

    /** Column names that suggest a URL-bearing column (less specific than image-named). */
    private const URL_NAME_RE = '/url|link|src/i';

    /** Default cap for items (matches WhatsApp send-loop limit in WebhookController::dispatchMedia). */
    private const DEFAULT_MAX_ITEMS = 20;

    /** Caption length cap in characters (matches Node parity). */
    private const MAX_CAPTION_CHARS = 200;

    /**
     * Find all columns across tenant tables that look like they hold image URLs.
     *
     * @param  list<array<string, mixed>>  $tablesMetadata  tenant.tables_metadata
     * @return list<array{pgTable:string, pgColumn:string, original:string, sourceName:string, confidence:int}>
     *         sorted highest-confidence first
     */
    public static function detectImageColumns(array $tablesMetadata): array
    {
        $cols = [];
        foreach ($tablesMetadata as $t) {
            $pgTable = (string) ($t['pg_table'] ?? '');
            $sourceName = (string) ($t['source_name'] ?? '');
            $columns = $t['columns'] ?? [];

            foreach ($columns as $c) {
                $samples = array_values(array_filter(
                    $c['samples'] ?? [],
                    static fn ($s) => is_string($s) && $s !== ''
                ));
                $name = (string) ($c['original'] ?? $c['pg_name'] ?? '');

                $hasImgUrlSample = false;
                foreach ($samples as $s) {
                    if (self::isImageUrl($s)) { $hasImgUrlSample = true; break; }
                }
                $isImgNamed = self::isImageColumnName($name);
                $isUrlNamed = self::isUrlColumnName($name);
                $allSamplesAreUrls = count($samples) > 0
                    && array_reduce($samples, static fn ($acc, $s) => $acc && self::isGenericUrl($s), true);

                $confidence = 0;
                if ($hasImgUrlSample)                        $confidence = 3;
                elseif ($isImgNamed)                         $confidence = 2;
                elseif ($isUrlNamed && $allSamplesAreUrls)   $confidence = 1;

                if ($confidence === 0) continue;

                $cols[] = [
                    'pgTable'    => $pgTable,
                    'pgColumn'   => (string) ($c['pg_name'] ?? ''),
                    'original'   => $name,
                    'sourceName' => $sourceName,
                    'confidence' => $confidence,
                ];
            }
        }

        // Highest confidence first
        usort($cols, static fn ($a, $b) => $b['confidence'] <=> $a['confidence']);

        return $cols;
    }

    /**
     * Walk SQL result rows and emit `{url, caption}` pairs.
     *
     * Per-row strategy: the first cell with an explicit image-URL extension is preferred.
     * If none found, fall back to the first cell with any URL. The first NON-URL string
     * cell becomes the caption (typically an entity name). Rows with no URL at all are
     * skipped.
     *
     * @param  list<array<string, mixed>|object>  $rows  DB::select results (stdClass or array)
     * @return list<array{url:string, caption:string}>
     */
    public static function extractImageItems(array $rows, int $maxItems = self::DEFAULT_MAX_ITEMS): array
    {
        $items = [];
        foreach ($rows as $row) {
            if (count($items) >= $maxItems) break;
            $assoc = is_object($row) ? get_object_vars($row) : (array) $row;

            // Prefer image-extension URLs, then any URL
            $imageUrl = null;
            foreach ($assoc as $v) {
                if (is_string($v) && self::isImageUrl($v)) { $imageUrl = $v; break; }
            }
            if ($imageUrl === null) {
                foreach ($assoc as $v) {
                    if (is_string($v) && self::isGenericUrl($v)) { $imageUrl = $v; break; }
                }
            }
            if ($imageUrl === null) continue;

            // Caption = first non-URL string in the row
            $caption = '';
            foreach ($assoc as $v) {
                if (is_string($v) && $v !== '' && ! self::isGenericUrl($v)) {
                    $caption = $v; break;
                }
                if (is_numeric($v)) {
                    $caption = (string) $v; break;
                }
            }

            $items[] = [
                'url'     => $imageUrl,
                'caption' => mb_substr($caption, 0, self::MAX_CAPTION_CHARS),
            ];
        }

        return $items;
    }

    /** True if value is a non-empty string matching a typical image-extension URL. */
    public static function isImageUrl(mixed $v): bool
    {
        return is_string($v) && $v !== '' && (bool) preg_match(self::IMG_URL_RE, $v);
    }

    /** True if value is any https URL. */
    public static function isGenericUrl(mixed $v): bool
    {
        return is_string($v) && $v !== '' && (bool) preg_match(self::GENERIC_URL_RE, $v);
    }

    /** True if column name suggests image content (image|photo|pic|thumbnail|img|tasveer). */
    public static function isImageColumnName(string $name): bool
    {
        return $name !== '' && (bool) preg_match(self::IMG_NAME_RE, $name);
    }

    /** True if column name suggests a URL-bearing field (url|link|src). */
    public static function isUrlColumnName(string $name): bool
    {
        return $name !== '' && (bool) preg_match(self::URL_NAME_RE, $name);
    }
}
