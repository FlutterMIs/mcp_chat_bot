<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\Log;
use RuntimeException;

/**
 * ChartQueryHandler — high-level chart orchestration.
 *
 *   1. inferChartType(query)        — pick bar/pie/doughnut/line from user wording
 *   2. inferLabelValueCols(row, …)  — pick label column (entity/category/date) + value column (numeric)
 *      using SmartFormatter::buildRoleMap. Falls back to type-probing if role map misses.
 *   3. ChartBuilder::renderChartPng — POST to QuickChart, save PNG to /tmp
 *
 * Returns `{path, type, title, labelCol, valueCol}` so the caller (TenantRouter) can
 * compose the reply + media payload.
 *
 * Caps at 30 rows (charts unreadable beyond ~30 bars/slices).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-chart.js
 */
final class ChartQueryHandler
{
    private const MAX_ROWS = 30;

    /** Roles that can serve as the LABEL axis (text/categorical). */
    private const LABEL_ROLES = ['entity', 'location', 'category', 'date', 'id', 'text'];

    /** Roles that can serve as the VALUE axis (numeric). */
    private const NUMERIC_ROLES = ['currency', 'quantity', 'count', 'number', 'rate'];

    /**
     * Render a chart PNG from result rows.
     *
     * @param  list<array<string, mixed>>  $rows         result rows from the AI-generated SQL
     * @param  string                      $query        original user question — used for chart-type inference + title
     * @param  list<array<string, mixed>>  $tableColumns column metadata from tenants.tables_metadata for role lookup
     * @param  array{title?:string, dbName?:string}  $opts
     * @return array{path:string, type:string, title:string, labelCol:string, valueCol:string}
     *
     * @throws RuntimeException  on empty rows / no usable columns / QuickChart failure
     */
    public static function generate(array $rows, string $query, array $tableColumns = [], array $opts = []): array
    {
        if (count($rows) === 0) {
            throw new RuntimeException('No rows to chart');
        }
        if (count($rows) > self::MAX_ROWS) {
            $rows = array_slice($rows, 0, self::MAX_ROWS);
        }

        // Normalise first row to associative array (DB::select returns stdClass)
        $firstRow = is_object($rows[0]) ? get_object_vars($rows[0]) : (array) $rows[0];

        $roleMap = SmartFormatter::buildRoleMap($firstRow, $tableColumns);
        $cols = self::inferLabelValueCols($firstRow, $roleMap);
        if ($cols === null) {
            throw new RuntimeException('Could not pick label/value column from result');
        }

        $type = self::inferChartType($query);
        $title = (string) ($opts['title']
            ?? (mb_strlen($query) > 0
                ? mb_substr($query, 0, 60)
                : SmartFormatter::humanizeLabel($cols['valueCol']).' by '.SmartFormatter::humanizeLabel($cols['labelCol'])));

        $chartConfig = [
            'type'      => $type,
            'title'     => $title,
            'label_col' => $cols['labelCol'],
            'value_col' => $cols['valueCol'],
        ];

        $path = ChartBuilder::renderChartPng($chartConfig, $rows);

        return [
            'path'     => $path,
            'type'     => $type,
            'title'    => $title,
            'labelCol' => $cols['labelCol'],
            'valueCol' => $cols['valueCol'],
        ];
    }

    /**
     * Detect chart type from user-query keywords. Defaults to 'bar'.
     */
    public static function inferChartType(string $query): string
    {
        $q = mb_strtolower($query);

        if (preg_match('/\bpie\b/', $q)) return 'pie';
        if (preg_match('/\bdoughnut\b|\bdonut\b/', $q)) return 'doughnut';
        if (preg_match('/\bline\b|\btrend\b|\bover\s+time\b|\btime\s*series\b|month[- ]?wise|date[- ]?wise/', $q)) return 'line';
        if (preg_match('/\bbar\b|\bcolumn\b|\bgrouped\b/', $q)) return 'bar';

        return 'bar';
    }

    /**
     * Pick label + value columns from a result row using the role map.
     *
     * Strategy (mirrors Node helpers/tenant-chart.js inferLabelValueCols):
     *   1. First pass — explicit role match (label=entity/location/category/date/id/text, value=currency/quantity/count/number/rate)
     *   2. Fallback — probe by raw type:
     *        labelCol = first non-numeric value
     *        valueCol = first numeric-parseable value (other than labelCol)
     *
     * @param  array<string, mixed>  $row      first result row (associative)
     * @param  array<string, array{role:string, format:string, unit?:string}>  $roleMap
     * @return array{labelCol:string, valueCol:string}|null
     */
    public static function inferLabelValueCols(array $row, array $roleMap): ?array
    {
        $keys = array_keys($row);
        $labelCol = null;
        $valueCol = null;

        // Pass 1 — role-based
        foreach ($keys as $k) {
            $meta = $roleMap[$k] ?? $roleMap[strtolower($k)] ?? null;
            $role = $meta['role'] ?? null;
            if ($labelCol === null && $role !== null && in_array($role, self::LABEL_ROLES, true)) {
                $labelCol = $k;
            }
            if ($valueCol === null && $role !== null && in_array($role, self::NUMERIC_ROLES, true)) {
                $valueCol = $k;
            }
        }

        // Pass 2 — fallback: label = first string, value = first numeric
        if ($labelCol === null) {
            foreach ($keys as $k) {
                $v = $row[$k];
                // Treat as label if it's a non-numeric string (or any non-numeric value)
                if (is_string($v) && ! is_numeric($v)) {
                    $labelCol = $k;
                    break;
                }
                if ($v !== null && ! is_numeric($v) && ! is_bool($v)) {
                    $labelCol = $k;
                    break;
                }
            }
        }
        if ($valueCol === null) {
            foreach ($keys as $k) {
                if ($k === $labelCol) continue;
                $v = $row[$k];
                if (is_numeric($v)) {
                    $valueCol = $k;
                    break;
                }
            }
        }

        if ($labelCol === null || $valueCol === null || $labelCol === $valueCol) {
            Log::info('[CHART INFER] failed pick — labelCol='.($labelCol ?? 'null').' valueCol='.($valueCol ?? 'null'));

            return null;
        }

        return ['labelCol' => $labelCol, 'valueCol' => $valueCol];
    }
}
