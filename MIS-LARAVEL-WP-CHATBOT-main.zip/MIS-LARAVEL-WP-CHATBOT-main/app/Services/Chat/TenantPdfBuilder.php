<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

/**
 * TenantPdfBuilder — generic A4-landscape PDF for any tenant query result.
 *
 * Triggered by TenantRouter when a query returns 51-100 rows (CSV takes over above 100).
 * Type-aware via SmartFormatter::buildRoleMap — currency cols get ₹+L/Cr suffix, dates
 * get trimmed to YYYY-MM-DD, numbers get Indian-locale separators.
 *
 * Visual style cloned from Node helpers/tenant-pdf.js for parity:
 *   - Dark navy header (#1a1a2e) with db name + title + optional query line
 *   - Dark slate column headers (#333355)
 *   - Zebra-striped data rows
 *   - Footer with total row count + aggregate sums across numeric columns
 *
 * Public API:
 *   render(list $rows, list $tableColumns, array $opts): string  → tmp PDF path
 *   buildSummary(list $rows, list $tableColumns): ?string         → WhatsApp text summary
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-pdf.js
 * @see /Users/saranshrajput/Desktop/mis-chatbot-php/resources/views/pdf/tenant-results.blade.php
 */
final class TenantPdfBuilder
{
    /** Hard cap on columns shown in PDF — landscape A4 fits ~10 cleanly. */
    private const MAX_COLUMNS = 10;

    /** Roles that should be right-aligned in the table cells. */
    private const NUMERIC_ROLES = ['currency', 'quantity', 'count', 'number', 'rate', 'percent'];

    /**
     * Render the PDF and return the absolute temp file path.
     *
     * @param  list<array<string, mixed>>  $rows  raw query result rows (will be normalized to assoc arrays)
     * @param  list<array<string, mixed>>  $tableColumns  columnsMeta from tenants.tables_metadata for the queried table (used for role inference; pass [] for fallback)
     * @param  array{title?:string, query?:string, dbName?:string}  $opts
     * @return string  absolute path to the saved PDF in sys_get_temp_dir()
     *
     * @throws RuntimeException
     */
    public static function render(array $rows, array $tableColumns = [], array $opts = []): string
    {
        if (count($rows) === 0) {
            throw new RuntimeException('No rows to render');
        }

        $title = (string) ($opts['title'] ?? 'Query Results');
        $query = mb_substr((string) ($opts['query'] ?? ''), 0, 200);
        $dbName = (string) ($opts['dbName'] ?? 'Database');

        // Normalize stdClass → array (DB::select returns stdClass)
        $rowsAssoc = array_map(
            static fn ($r) => is_object($r) ? get_object_vars($r) : (array) $r,
            $rows
        );

        // Role map driven by first row's keys + tenant column metadata
        $roleMap = SmartFormatter::buildRoleMap($rowsAssoc[0], $tableColumns);
        $allKeys = array_keys($rowsAssoc[0]);

        // Cap displayed columns at 10 (landscape-fit). Narrow data shows all keys.
        $displayKeys = count($allKeys) > self::MAX_COLUMNS
            ? array_slice($allKeys, 0, self::MAX_COLUMNS)
            : $allKeys;

        // Pre-format every cell + collect column roles for alignment
        $headers = [];
        $columnRoles = [];
        foreach ($displayKeys as $col) {
            $meta = $roleMap[$col] ?? $roleMap[strtolower($col)] ?? null;
            $headers[] = mb_substr(SmartFormatter::humanizeLabel((string) ($meta['original'] ?? $col)), 0, 18);
            $columnRoles[] = $meta['role'] ?? 'text';
        }

        $cells = [];
        foreach ($rowsAssoc as $r) {
            $rowCells = [];
            foreach ($displayKeys as $col) {
                $meta = $roleMap[$col] ?? $roleMap[strtolower($col)] ?? null;
                $rowCells[] = self::pdfFormatCell($r[$col] ?? null, $meta['role'] ?? 'text');
            }
            $cells[] = $rowCells;
        }

        // Aggregate footer totals (currency / quantity / count / number cols only)
        $footerLines = self::buildFooterTotals($rowsAssoc, $allKeys, $roleMap);

        // Font size shrinks slightly when many columns (matches Node parity)
        $fontSize = count($displayKeys) > 8 ? 6 : 7;

        $viewData = [
            'title'       => $title,
            'query'       => $query,
            'dbName'      => $dbName,
            'headers'     => $headers,
            'columnRoles' => $columnRoles,
            'cells'       => $cells,
            'footerLines' => $footerLines,
            'rowCount'    => count($rowsAssoc),
            'fontSize'    => $fontSize,
        ];

        try {
            $pdf = Pdf::loadView('pdf.tenant-results', $viewData)
                ->setPaper('a4', 'landscape');

            $tmpPath = sys_get_temp_dir().DIRECTORY_SEPARATOR.'tenant_data_'.((int) (microtime(true) * 1000)).'.pdf';
            file_put_contents($tmpPath, $pdf->output());

            $size = filesize($tmpPath);
            Log::info("[TENANT PDF] {$dbName} \"{$title}\": ".count($rowsAssoc)." rows, ".count($displayKeys)." cols → {$tmpPath} ({$size}B)");

            return $tmpPath;
        } catch (Throwable $e) {
            throw new RuntimeException('PDF render failed: '.$e->getMessage(), 0, $e);
        }
    }

    /**
     * Build a short WhatsApp summary for the PDF dispatch reply.
     * Includes total row count + aggregate sums across numeric columns.
     *
     * @param  list<array<string, mixed>>  $rows
     * @param  list<array<string, mixed>>  $tableColumns
     */
    public static function buildSummary(array $rows, array $tableColumns = []): ?string
    {
        if (count($rows) === 0) return null;

        $rowsAssoc = array_map(
            static fn ($r) => is_object($r) ? get_object_vars($r) : (array) $r,
            $rows
        );
        $roleMap = SmartFormatter::buildRoleMap($rowsAssoc[0], $tableColumns);
        $keys = array_keys($rowsAssoc[0]);

        $parts = self::buildAggregateParts($rowsAssoc, $keys, $roleMap);

        $msg = '📄 Sending PDF with *'.count($rowsAssoc).' results*...';
        if (count($parts) > 0) {
            $msg .= "\n\n📊 *Totals:* ".implode(' | ', $parts);
        }

        return $msg;
    }

    // ════════════════════════════════════════════════════════════════════
    // INTERNAL HELPERS
    // ════════════════════════════════════════════════════════════════════

    /**
     * Type-aware cell formatter (PDF cell — shorter than WhatsApp text).
     */
    private static function pdfFormatCell(mixed $value, string $role): string
    {
        if ($value === null || $value === '' || $value === '-') return '-';

        return match ($role) {
            'currency', 'rate' => self::formatCurrencyShort($value),
            'quantity'         => self::formatNumberShort($value),
            'percent'          => is_numeric($value) ? number_format((float) $value, 2).'%' : (string) $value,
            'count', 'number'  => self::formatNumberShort($value),
            'date'             => mb_substr(explode('T', (string) $value)[0], 0, 12),
            default            => mb_substr((string) $value, 0, 40),
        };
    }

    /** ₹ + Indian-format with Cr/L suffix for big numbers. */
    private static function formatCurrencyShort(mixed $n): string
    {
        if (! is_numeric($n)) return (string) $n;
        $num = (float) $n;
        $abs = abs($num);
        $sign = $num < 0 ? '-' : '';
        if ($abs >= 1e7) return $sign.'₹'.number_format($abs / 1e7, 2).'Cr';
        if ($abs >= 1e5) return $sign.'₹'.number_format($abs / 1e5, 2).'L';

        return $sign.'₹'.number_format($abs, 2, '.', ',');
    }

    /** Plain number with Indian comma grouping. */
    private static function formatNumberShort(mixed $n): string
    {
        if (! is_numeric($n)) return (string) $n;
        $num = (float) $n;
        if (floor($num) == $num) {
            return number_format($num, 0, '.', ',');
        }

        return number_format($num, 2, '.', ',');
    }

    /**
     * Build "Label: Total" lines for each numeric column. Used inline in the PDF footer.
     *
     * @param  list<array<string, mixed>>  $rows
     * @param  list<string>  $keys
     * @param  array<string, array<string, mixed>>  $roleMap
     * @return list<string>
     */
    private static function buildFooterTotals(array $rows, array $keys, array $roleMap): array
    {
        $lines = [];
        foreach ($keys as $k) {
            $meta = $roleMap[$k] ?? $roleMap[strtolower($k)] ?? null;
            if (! $meta || ! in_array($meta['role'] ?? 'text', ['currency', 'quantity', 'count', 'number'], true)) {
                continue;
            }

            $total = 0.0;
            $count = 0;
            foreach ($rows as $r) {
                $n = $r[$k] ?? null;
                if (is_numeric($n)) {
                    $total += (float) $n;
                    $count++;
                }
            }
            if ($count === 0) continue;

            $label = SmartFormatter::humanizeLabel((string) ($meta['original'] ?? $k));
            $value = self::pdfFormatCell($total, (string) ($meta['role'] ?? 'number'));
            $lines[] = "{$label}: {$value}";
        }

        return $lines;
    }

    /**
     * Build "*Label:* Total" parts for the WhatsApp dispatch summary text.
     * Skips rate role (averaging rates is misleading).
     *
     * @return list<string>
     */
    private static function buildAggregateParts(array $rows, array $keys, array $roleMap): array
    {
        $parts = [];
        foreach ($keys as $k) {
            $meta = $roleMap[$k] ?? $roleMap[strtolower($k)] ?? null;
            if (! $meta) continue;
            $role = (string) ($meta['role'] ?? 'text');
            if (! in_array($role, ['currency', 'quantity', 'count', 'number'], true)) continue;
            if ($role === 'rate') continue;

            $total = 0.0;
            $count = 0;
            foreach ($rows as $r) {
                $n = $r[$k] ?? null;
                if (is_numeric($n)) {
                    $total += (float) $n;
                    $count++;
                }
            }
            if ($count === 0) continue;

            $label = SmartFormatter::humanizeLabel((string) ($meta['original'] ?? $k));
            $formatted = SmartFormatter::formatValue($total, $role);
            if ($formatted !== '') {
                $parts[] = "*{$label}:* {$formatted}";
            }
        }

        return $parts;
    }
}
