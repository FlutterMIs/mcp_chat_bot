<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Fuzzy entity-name fallback — third self-heal layer alongside SelfHeal::resolveColumnError
 * (column-fix) and SelfHeal::relaxSQL (filter-relax).
 *
 * When an AI-generated SQL has an ILIKE filter on an entity-role column (party_name, supplier,
 * sales_person, city, etc.) and the query returns 0 rows, this service uses pg_trgm via the
 * `tenant_fuzzy_search` Postgres RPC to suggest close matches. Catches typos like:
 *   - "Pansaree" → "Pansari Industries"  (similarity 0.27, beats >0.15 threshold)
 *   - "Mital Electronicss" → "MITTAL ELECTRONICS"
 *   - "Insulator" → "Insulators & Electricals Company"
 *
 * Pipeline order in TenantRouter::handle() (matches Node helpers/tenant-router.js):
 *   1. AI generates SQL → execute → 0 rows
 *   2. **FuzzyFallback::search()**  ← THIS  — fast (single RPC, ~50ms), returns suggestions
 *   3. If no fuzzy match → SelfHeal::relaxSQL variants (drop-date / loosen-ILIKE)
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-router.js (fuzzyFallback ~line 610)
 * @see /Users/saranshrajput/Desktop/mis-chatbot/migrations/006_tenant_proper_tables.sql (tenant_fuzzy_search RPC)
 */
final class FuzzyFallback
{
    /** Minimum trigram similarity score to be considered a "real" suggestion. */
    private const MIN_SCORE = 0.15;

    /** Top-K suggestions to fetch from the RPC. */
    private const LIMIT = 5;

    /**
     * If the SQL has an ILIKE on an entity/location column and returned 0 rows,
     * search for fuzzy matches.
     *
     * @param  list<array<string, mixed>>  $tablesMetadata
     * @return array{searchTerm: string, matches: list<string>, column: string, table: string}|null
     */
    public static function search(string $sql, array $tablesMetadata, array $mandatoryWheres = []): ?array
    {
        $filters = self::extractEntityFilters($sql, $tablesMetadata);
        if (count($filters) === 0) {
            return null;
        }

        $f = $filters[0];

        try {
            // MySQL LIKE-based fuzzy: split search term into words and match any
            $words = preg_split('/\s+/', $f['value']);
            $bindings = [];
            $conditions = [];
            foreach ($words as $w) {
                if (strlen($w) >= 2) {
                    $escaped = addcslashes($w, '%_');
                    $conditions[] = "`{$f['pgColumn']}` LIKE ?";
                    $bindings[] = "%{$escaped}%";
                }
            }
            if (count($conditions) === 0) {
                $escaped = addcslashes($f['value'], '%_');
                $conditions[] = "`{$f['pgColumn']}` LIKE ?";
                $bindings[] = "%{$escaped}%";
            }

            $whereClause = implode(' OR ', $conditions);
            // Access control (Z43) — a restricted CLIENT/TEAM user's fuzzy suggestions must
            // stay inside their own rows too, same constraint as the main query.
            $accessWhere = $mandatoryWheres[$f['pgTable']] ?? null;
            if ($accessWhere) {
                $whereClause = "({$whereClause}) AND ({$accessWhere})";
            }
            $rows = DB::select(
                "SELECT DISTINCT `{$f['pgColumn']}` AS value FROM `{$f['pgTable']}` WHERE {$whereClause} LIMIT " . self::LIMIT,
                $bindings
            );
        } catch (Throwable $e) {
            Log::warning('[FUZZY] search failed: '.substr($e->getMessage(), 0, 200));

            return null;
        }

        $matches = [];
        foreach ($rows as $row) {
            $value = (string) ($row->value ?? '');
            if ($value !== '') {
                $matches[] = $value;
            }
        }

        if (count($matches) === 0) {
            return null;
        }

        Log::info("[FUZZY] {$f['pgColumn']}=\"{$f['value']}\" → ".count($matches).' suggestion(s): '.implode(', ', $matches));

        return [
            'searchTerm' => $f['value'],
            'matches'    => $matches,
            'column'     => $f['pgColumn'],
            'table'      => $f['pgTable'],
        ];
    }

    /**
     * Walk through SQL `<col> ILIKE '%<value>%'` clauses and return only those where
     * <col> is an entity- or location-role column in the tenant's schema. Skips ILIKE
     * filters on item names, IDs, etc. (those wouldn't benefit from fuzzy entity matching).
     *
     * @param  list<array<string, mixed>>  $tablesMetadata
     * @return list<array{pgTable: string, pgColumn: string, value: string}>
     */
    public static function extractEntityFilters(string $sql, array $tablesMetadata): array
    {
        $filters = [];
        if (! preg_match_all('/(\w+)\s+(?:I?LIKE)\s+\'%([^%\']+)%\'/i', $sql, $matches, PREG_SET_ORDER)) {
            return $filters;
        }

        foreach ($matches as $m) {
            $colName = strtolower($m[1]);
            $value = $m[2];

            foreach ($tablesMetadata as $t) {
                $pgTable = (string) ($t['pg_table'] ?? '');
                if ($pgTable === '') continue;

                foreach (($t['columns'] ?? []) as $c) {
                    if (strtolower((string) ($c['pg_name'] ?? '')) !== $colName) continue;
                    if (! in_array($c['role'] ?? null, ['entity', 'location'], true)) continue;

                    $filters[] = [
                        'pgTable'  => $pgTable,
                        'pgColumn' => $c['pg_name'],
                        'value'    => $value,
                    ];
                    continue 3; // matched this ILIKE — move to next regex match
                }
            }
        }

        return $filters;
    }
}
