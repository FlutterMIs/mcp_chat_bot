<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

/**
 * LedgerPdfBuilder — render a ledger PDF for a resolved entity.
 *
 * Uses barryvdh/laravel-dompdf to render the resources/views/pdf/ledger.blade.php
 * template in A4 landscape orientation. Visual style cloned from Node
 * helpers/tenant-ledger-pdf.js (PDFKit) for parity:
 *   - Dark navy header with tenant name + entity + date range
 *   - 7-col table: Date | Type (To/By) | Particulars | Vch Type | Vch No | Debit | Credit
 *   - Opening + closing balance rows highlighted
 *   - Zebra-striped transactions
 *   - Grand total row at bottom
 *
 * Public API:
 *   render(list $rows, array $mapping, array $opts): string  → tmp PDF path
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-ledger-pdf.js
 * @see /Users/saranshrajput/Desktop/mis-chatbot-php/resources/views/pdf/ledger.blade.php
 */
final class LedgerPdfBuilder
{
    /** Particulars values that mark balance rows from Tally exports — excluded from txns table. */
    private const BALANCE_MARKERS = ['Opening Balance', 'Closing Balance', ''];

    /**
     * Render the ledger PDF and return absolute file path.
     *
     * @param  list<array<string, mixed>>  $rows  raw ledger rows for the entity (from LedgerEntityResolver::fetchLedgerForName)
     * @param  array{nameCol:string, debitCol:?string, creditCol:?string, openingBalanceCol:?string, closingBalanceCol:?string, particularCol:?string, dateCol:?string, vchTypeCol:?string, vchNoCol:?string}  $mapping
     * @param  array{entityName:string, dbName?:string, tabName?:string}  $opts
     * @return string  absolute path to the saved PDF in sys_get_temp_dir()
     *
     * @throws RuntimeException
     */
    public static function render(array $rows, array $mapping, array $opts): string
    {
        if (count($rows) === 0) {
            throw new RuntimeException('No ledger rows to render');
        }

        $entityName = (string) ($opts['entityName'] ?? 'Account');
        $dbName     = (string) ($opts['dbName']     ?? 'Database');
        $tabName    = (string) ($opts['tabName']    ?? 'LEDGER');

        // Pull opening / closing balance from first / last row (Tally-style: same value across rows)
        $first = $rows[0];
        $last = $rows[count($rows) - 1];
        $openBal = 0.0;
        $closeBal = 0.0;

        if ($mapping['openingBalanceCol'] ?? null) {
            // Check if we also have opening_debit/opening_credit for proper sign
            $openDebitCol = null;
            $openCreditCol = null;
            foreach ($rows[0] as $k => $v) {
                if (preg_match('/opening.*debit|open.*debit/i', $k)) $openDebitCol = $k;
                if (preg_match('/opening.*credit|open.*credit/i', $k)) $openCreditCol = $k;
            }
            if ($openDebitCol && $openCreditCol) {
                $od = (float) ($first[$openDebitCol] ?? 0);
                $oc = (float) ($first[$openCreditCol] ?? 0);
                $openBal = $od - $oc; // Dr positive, Cr negative
            } else {
                $openBal = (float) ($first[$mapping['openingBalanceCol']] ?? 0);
            }
        } else {
            // No dedicated opening balance column — look for a row with particulars = "Opening Balance"
            // and extract its debit/credit value (Tally-style export)
            if ($mapping['particularCol'] ?? null) {
                foreach ($rows as $r) {
                    $p = trim((string) ($r[$mapping['particularCol']] ?? ''));
                    if (stripos($p, 'opening balance') !== false || stripos($p, 'opening bal') !== false) {
                        $dr = (float) ($r[$mapping['debitCol'] ?? ''] ?? 0);
                        $cr = (float) ($r[$mapping['creditCol'] ?? ''] ?? 0);
                        $openBal = $dr > 0 ? $dr : -$cr; // Dr = positive, Cr = negative
                        break;
                    }
                }
            }
        }

        if ($mapping['closingBalanceCol'] ?? null) {
            // Check if we also have closing_debit/closing_credit for proper sign
            $closeDebitCol = null;
            $closeCreditCol = null;
            foreach ($rows[0] as $k => $v) {
                if (preg_match('/closing.*debit|close.*debit/i', $k)) $closeDebitCol = $k;
                if (preg_match('/closing.*credit|close.*credit/i', $k)) $closeCreditCol = $k;
            }
            if ($closeDebitCol && $closeCreditCol) {
                $cd = (float) ($last[$closeDebitCol] ?? 0);
                $cc = (float) ($last[$closeCreditCol] ?? 0);
                $closeBal = $cd - $cc;
            } else {
                $closeBal = (float) ($last[$mapping['closingBalanceCol']] ?? $first[$mapping['closingBalanceCol']] ?? 0);
            }
        } else {
            // No dedicated closing balance column — look for a "Closing Balance" row
            if ($mapping['particularCol'] ?? null) {
                for ($i = count($rows) - 1; $i >= 0; $i--) {
                    $p = trim((string) ($rows[$i][$mapping['particularCol']] ?? ''));
                    if (stripos($p, 'closing balance') !== false || stripos($p, 'closing bal') !== false) {
                        $dr = (float) ($rows[$i][$mapping['debitCol'] ?? ''] ?? 0);
                        $cr = (float) ($rows[$i][$mapping['creditCol'] ?? ''] ?? 0);
                        $closeBal = $dr > 0 ? $dr : -$cr;
                        break;
                    }
                }
            }
            // Fallback: compute from openBal + totalDr - totalCr
            if ($closeBal === 0.0 && ($mapping['debitCol'] ?? null) && ($mapping['creditCol'] ?? null)) {
                $txnDr = 0.0;
                $txnCr = 0.0;
                foreach ($rows as $r) {
                    $p = trim((string) ($r[$mapping['particularCol'] ?? ''] ?? ''));
                    if ($p !== '' && stripos($p, 'opening balance') === false && stripos($p, 'closing balance') === false) {
                        $txnDr += (float) ($r[$mapping['debitCol']] ?? 0);
                        $txnCr += (float) ($r[$mapping['creditCol']] ?? 0);
                    }
                }
                $closeBal = $openBal + $txnDr - $txnCr;
            }
        }

        // Filter out balance marker rows from the transactions table
        $txns = $rows;
        if ($mapping['particularCol'] ?? null) {
            $txns = array_values(array_filter($rows, static function ($r) use ($mapping) {
                $p = trim((string) ($r[$mapping['particularCol']] ?? ''));

                return $p !== '' && ! in_array($p, self::BALANCE_MARKERS, true);
            }));
        }

        // Date range for header
        $firstDate = '';
        $lastDate = '';
        if ($mapping['dateCol'] ?? null) {
            $dates = array_values(array_filter(array_map(
                static fn ($r) => (string) ($r[$mapping['dateCol']] ?? ''),
                $txns
            ), static fn ($d) => $d !== ''));
            sort($dates);
            $firstDate = self::fmtDate($dates[0] ?? '');
            $lastDate = self::fmtDate(end($dates) ?: ($dates[0] ?? ''));
        }

        // Compute totals (used in grand-total row).
        // Tally double-entry convention: closing balance is a BALANCING entry on the
        // OPPOSITE side from where the actual balance sits. So:
        //   - Dr-side total  = opening-Dr + period-Dr-txns + closing-as-Dr-balancing (when close is Cr)
        //   - Cr-side total  = opening-Cr + period-Cr-txns + closing-as-Cr-balancing (when close is Dr)
        // This guarantees grandDr === grandCr, which is what double-entry requires.
        $totalDr = 0.0;
        $totalCr = 0.0;
        if ($mapping['debitCol'] ?? null) {
            foreach ($txns as $r) $totalDr += (float) ($r[$mapping['debitCol']] ?? 0);
        }
        if ($mapping['creditCol'] ?? null) {
            foreach ($txns as $r) $totalCr += (float) ($r[$mapping['creditCol']] ?? 0);
        }
        $openDr = max(0.0, $openBal);                   // opening on Dr side if balance is positive
        $openCr = max(0.0, -$openBal);                  // opening on Cr side if balance is negative
        $closeBalancingDr = max(0.0, -$closeBal);       // close-Cr-balance shown as Dr-side balancing entry
        $closeBalancingCr = max(0.0, $closeBal);        // close-Dr-balance shown as Cr-side balancing entry
        $grandDr = $openDr + $totalDr + $closeBalancingDr;
        $grandCr = $openCr + $totalCr + $closeBalancingCr;

        // Closures the Blade template can use directly. dompdf evaluates the Blade
        // in the request context so closures pass through fine.
        $fmtAmt = static function (float|int|string|null $n): string {
            $num = is_numeric($n) ? (float) $n : 0.0;
            if ($num === 0.0) return '';

            return number_format(abs($num), 2, '.', ',');
        };
        $fmtDate = static fn (mixed $d): string => self::fmtDate($d);

        $viewData = [
            'entityName' => $entityName,
            'dbName'     => $dbName,
            'tabName'    => $tabName,
            'firstDate'  => $firstDate,
            'lastDate'   => $lastDate,
            'openBal'    => $openBal,
            'closeBal'   => $closeBal,
            'grandDr'    => $grandDr,
            'grandCr'    => $grandCr,
            'mapping'    => $mapping,
            'txns'       => $txns,
            'fmtAmt'     => $fmtAmt,
            'fmtDate'    => $fmtDate,
        ];

        try {
            $pdf = Pdf::loadView('pdf.ledger', $viewData)
                ->setPaper('a4', 'landscape');

            $tmpPath = sys_get_temp_dir().DIRECTORY_SEPARATOR.'tenant_ledger_'.((int) (microtime(true) * 1000)).'.pdf';
            file_put_contents($tmpPath, $pdf->output());

            $size = filesize($tmpPath);
            Log::info("[LEDGER PDF] {$entityName} ({$dbName}): ".count($txns)." txns, ".count($rows)." raw rows → {$tmpPath} ({$size}B)");

            return $tmpPath;
        } catch (Throwable $e) {
            throw new RuntimeException('PDF render failed: '.$e->getMessage(), 0, $e);
        }
    }

    /**
     * Format a date string for display in the PDF.
     *   ISO ("2026-04-15...") → "15-Apr-26"
     *   "1-Apr-26" or other short → unchanged (capped 12 chars)
     *   empty/null → ''
     */
    public static function fmtDate(mixed $d): string
    {
        if ($d === null || $d === '') return '';
        $s = trim((string) $d);
        if ($s === '') return '';

        // ISO date — strip time, format as "DD-Mon-YY"
        if (preg_match('/^\d{4}-\d{2}-\d{2}/', $s)) {
            try {
                $dt = new \DateTimeImmutable($s);

                return $dt->format('j-M-y');
            } catch (Throwable) {
                // fall through
            }
        }

        return mb_substr($s, 0, 12);
    }
}
