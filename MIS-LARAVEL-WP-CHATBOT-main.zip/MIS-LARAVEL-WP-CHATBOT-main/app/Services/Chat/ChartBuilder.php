<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

/**
 * ChartBuilder — QuickChart.io renderer.
 *
 * Port of Node `helpers/chart-builder.js`. The trick: QuickChart's POST endpoint accepts
 * the chart definition as a JS literal STRING (not JSON). This preserves inline
 * functions like `datalabels.formatter` which `JSON.stringify` would drop. We assemble
 * the literal manually here.
 *
 * Pre-scaling strategy: instead of trying to inject custom y-axis tick callbacks
 * (which break under JSON.stringify), we DIVIDE the values up front by an appropriate
 * unit (Cr / L / K / "") and append the unit to the title and datalabel suffix. The
 * y-axis then naturally formats clean numbers (0.5, 1.0, 1.5, ...) without any callback.
 *
 * Public API:
 *   renderChartPng(array $chartConfig, list<array> $rows, array $opts = []): string
 *     → returns absolute path to a saved PNG in sys_get_temp_dir()
 *
 *   buildChartLiteral(array $chartConfig, list<array> $rows, array $opts = []): array
 *     → {jsLiteral, unit, scaledValues, labels}  — exposed for tests / debugging
 *
 *   pickUnit(list<float> $values): array{unit:string, divisor:int}
 *     → ('Cr',1e7) / ('L',1e5) / ('K',1e3) / ('',1)
 *
 *   truncateLabel(?string $s, int $max = 25): string
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/chart-builder.js
 */
final class ChartBuilder
{
    private const QUICKCHART_URL = 'https://quickchart.io/chart';

    /** 12-color palette — repeats if more bars than colors. Same as Node. */
    private const COLORS = [
        '#4361ee', '#e63946', '#2ec4b6', '#ff9f1c',
        '#7209b7', '#06d6a0', '#f72585', '#118ab2',
        '#ffd166', '#073b4c', '#06aed5', '#f15bb5',
    ];

    /**
     * Render a chart and save the PNG to a temp file.
     *
     * @param  array{type?:string, title?:string, label_col:string, value_col:string}  $chartConfig
     * @param  list<array<string, mixed>>  $rows
     * @param  array{width?:int, height?:int, maxLabelChars?:int, bgColor?:string, timeoutMs?:int, prefix?:string}  $opts
     * @return string  absolute path to the saved PNG (in sys_get_temp_dir())
     *
     * @throws RuntimeException  on empty rows, non-2xx response, or suspiciously small file
     */
    public static function renderChartPng(array $chartConfig, array $rows, array $opts = []): string
    {
        if (count($rows) === 0) {
            throw new RuntimeException('No rows to chart');
        }

        $built = self::buildChartLiteral($chartConfig, $rows, [
            'maxLabelChars' => $opts['maxLabelChars'] ?? 25,
        ]);

        $body = [
            'chart'           => $built['jsLiteral'],
            'width'           => $opts['width'] ?? 1400,
            'height'          => $opts['height'] ?? 700,
            'format'          => 'png',
            'backgroundColor' => $opts['bgColor'] ?? 'white',
            // QuickChart defaults to Chart.js v2.9.4 (legacy), which uses `options.title`
            // and `options.legend` paths. Our config uses the v3+ paths under
            // `options.plugins.{title,legend}`. Without this version param, our title +
            // legend.position blocks are silently dropped — title doesn't render and
            // legend lands at the default top position.
            'version'         => '4',
        ];

        $timeoutSecs = (int) ceil(($opts['timeoutMs'] ?? 25000) / 1000);

        try {
            $resp = Http::timeout($timeoutSecs)
                ->withHeaders(['Content-Type' => 'application/json'])
                ->post(self::QUICKCHART_URL, $body);
        } catch (Throwable $e) {
            throw new RuntimeException('QuickChart HTTP failed: '.$e->getMessage(), 0, $e);
        }

        if (! $resp->ok()) {
            $errSnippet = substr($resp->body(), 0, 200);
            throw new RuntimeException("QuickChart returned HTTP {$resp->status()}".($errSnippet !== '' ? ': '.$errSnippet : ''));
        }

        $bytes = $resp->body();
        if (strlen($bytes) < 200) {
            throw new RuntimeException('QuickChart returned suspiciously small file ('.strlen($bytes).' bytes)');
        }

        $prefix = $opts['prefix'] ?? 'chart';
        $tmpPath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$prefix.'_'.((int) (microtime(true) * 1000)).'.png';
        if (file_put_contents($tmpPath, $bytes) === false) {
            throw new RuntimeException("Could not write chart PNG to {$tmpPath}");
        }

        Log::info("[CHART RENDER] {$built['unit']} unit, ".count($rows)." rows → {$tmpPath} (".strlen($bytes)."B)");

        return $tmpPath;
    }

    /**
     * Build the chart definition as a JavaScript literal STRING (NOT JSON).
     *
     * @param  array{type?:string, title?:string, label_col:string, value_col:string}  $chartConfig
     * @param  list<array<string, mixed>>  $rows
     * @param  array{maxLabelChars?:int}  $opts
     * @return array{jsLiteral:string, unit:string, scaledValues:list<float>, labels:list<string>}
     */
    public static function buildChartLiteral(array $chartConfig, array $rows, array $opts = []): array
    {
        $maxChars = (int) ($opts['maxLabelChars'] ?? 25);
        $labelCol = $chartConfig['label_col'];
        $valueCol = $chartConfig['value_col'];
        $chartType = $chartConfig['type'] ?? 'bar';
        $isPieish = $chartType === 'pie' || $chartType === 'doughnut';

        // Extract labels + raw numeric values, handling both array and stdClass rows
        $rawLabels = [];
        $rawValues = [];
        foreach ($rows as $r) {
            $row = is_object($r) ? get_object_vars($r) : (array) $r;
            $rawLabels[] = self::truncateLabel($row[$labelCol] ?? null, $maxChars);
            $v = $row[$valueCol] ?? 0;
            $rawValues[] = is_numeric($v) ? (float) $v : 0.0;
        }

        $picked = self::pickUnit($rawValues);
        $unit = $picked['unit'];
        $divisor = $picked['divisor'];
        $scaled = array_map(static fn (float $v) => round($v / $divisor, 2), $rawValues);

        // Color assignment
        if ($isPieish) {
            $bgColor = array_map(static fn (int $i) => self::COLORS[$i % count(self::COLORS)], array_keys($scaled));
        } elseif ($chartType === 'bar') {
            // ~80% alpha (cc suffix on hex) — gives bars a softer look than fully opaque
            $bgColor = array_map(static fn (int $i) => self::COLORS[$i % count(self::COLORS)].'cc', array_keys($scaled));
        } else {
            $bgColor = '#4361ee33'; // light fill under line chart
        }

        $baseTitle = $chartConfig['title'] ?? 'Chart';
        $fullTitle = $unit !== '' ? "{$baseTitle} (in {$unit})" : $baseTitle;

        // JSON-encode the arrays for safe interpolation; then assemble the rest as JS.
        $labelsJson = json_encode($rawLabels, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $dataJson = json_encode($scaled, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        $colorsJson = is_array($bgColor)
            ? json_encode($bgColor, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            : "'".$bgColor."'";

        $titleSafe = str_replace("'", "\\'", $fullTitle);
        $yTitleSafe = $unit !== '' ? "'₹ in {$unit}'" : "'Value'";
        $fmtSuffix = $unit !== '' ? " ' {$unit}'" : "''";

        // datalabels — annotations on top of bars / inside pie slices
        $datalabelsBlock = "
        datalabels: {
          display: true,
          anchor: ".($isPieish ? "'center'" : "'end'").",
          align:  ".($isPieish ? "'center'" : "'top'").",
          color:  ".($isPieish ? "'#ffffff'" : "'#1a1a2e'").",
          font:   { size: 12, weight: 'bold' },
          formatter: function(v) { return v.toFixed(2) +{$fmtSuffix}; }
        }";

        $scalesBlock = $isPieish ? '{}' : '{
        y: {
          beginAtZero: true,
          title: { display: '.($unit !== '' ? 'true' : 'false').", text: {$yTitleSafe}, font: { size: 12, weight: 'bold' }, color: '#555' },
          ticks: { font: { size: 11 }, color: '#555' },
          grid:  { color: 'rgba(0,0,0,0.06)' }
        },
        x: {
          ticks: { font: { size: 11 }, color: '#333', maxRotation: 50, minRotation: 30, autoSkip: false },
          grid:  { display: false }
        }
      }";

        $datasetExtras = match (true) {
            $chartType === 'line' => ", borderColor: '#4361ee', borderWidth: 3, fill: true, tension: 0.4, pointRadius: 5, pointBackgroundColor: '#4361ee'",
            $isPieish             => ", borderColor: '#ffffff', borderWidth: 2",
            default               => ", borderColor: 'rgba(0,0,0,0.12)', borderWidth: 1",
        };

        $jsLiteral = "{
    type: '{$chartType}',
    data: {
      labels: {$labelsJson},
      datasets: [{
        label: '{$titleSafe}',
        data: {$dataJson},
        backgroundColor: {$colorsJson}{$datasetExtras}
      }]
    },
    options: {
      layout: { padding: { top: 30, right: 24, bottom: 24, left: 12 } },
      plugins: {
        title:  { display: true, position: 'top', align: 'center', text: '{$titleSafe}', font: { size: 20, weight: 'bold' }, color: '#1a1a2e', padding: { top: 6, bottom: 22 } },
        legend: { display: ".($isPieish ? 'true' : 'false').", position: '".($isPieish ? 'bottom' : 'right')."', labels: { font: { size: 12 }, color: '#1a1a2e', padding: 14, boxWidth: 14 } },{$datalabelsBlock}
      },
      scales: {$scalesBlock}
    }
  }";

        return [
            'jsLiteral'    => $jsLiteral,
            'unit'         => $unit,
            'scaledValues' => $scaled,
            'labels'       => $rawLabels,
        ];
    }

    /**
     * Choose a friendly unit + divisor based on the max absolute value.
     *  ≥ 1 Cr (1e7) → "Cr"   ≥ 1 L (1e5) → "L"   ≥ 1k → "K"   else ""
     *
     * @param  list<float|int|string>  $values
     * @return array{unit: string, divisor: int}
     */
    public static function pickUnit(array $values): array
    {
        $max = 0.0;
        foreach ($values as $v) {
            $n = is_numeric($v) ? (float) $v : 0.0;
            $abs = abs($n);
            if ($abs > $max) $max = $abs;
        }
        if ($max >= 1e7) return ['unit' => 'Cr', 'divisor' => 10_000_000];
        if ($max >= 1e5) return ['unit' => 'L',  'divisor' => 100_000];
        if ($max >= 1e3) return ['unit' => 'K',  'divisor' => 1_000];

        return ['unit' => '', 'divisor' => 1];
    }

    /** Trim long axis labels so they don't overlap on the chart. */
    public static function truncateLabel(mixed $s, int $max = 25): string
    {
        if ($s === null) return '';
        $str = (string) $s;
        if (mb_strlen($str) > $max) {
            return mb_substr($str, 0, $max - 1).'…';
        }

        return $str;
    }
}
