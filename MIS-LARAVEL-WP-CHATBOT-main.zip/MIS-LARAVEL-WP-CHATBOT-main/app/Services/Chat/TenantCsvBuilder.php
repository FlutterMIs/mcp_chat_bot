<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\Log;
use RuntimeException;

/**
 * TenantCsvBuilder — RFC 4180 CSV export for tenant query results.
 *
 * Triggered by TenantRouter when a query returns more than 100 rows (PDF takes over for
 * 51-100 rows). CSV is preferred for large results because Excel/Sheets can sort/filter/
 * pivot freely — a 200-row PDF is unwieldy.
 *
 * Design choices (Node parity):
 *   - **Raw numeric values** — no ₹, no thousands separator, no L/Cr suffix. Excel-friendly:
 *     formulas can reference the cells directly. PDF does the formatting; CSV stays raw.
 *   - **All columns included** — PDF caps at 10 (landscape fit), CSV has no such constraint.
 *   - **RFC 4180 escaping** — fields containing comma, double-quote, CR, or LF wrapped in
 *     double-quotes; embedded double-quotes doubled to two double-quotes.
 *   - **UTF-8 BOM prefix** — `\xEF\xBB\xBF` so Excel correctly displays ₹ + Hindi characters.
 *   - **Filename pattern**: `{db_safe}_{title_safe}_{timestamp}.csv`.
 *
 * Public API:
 *   render(list $rows, list $tableColumns, array $opts): string  → tmp CSV path
 *   buildSummary(list $rows, list $tableColumns): ?string         → WhatsApp text summary
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-csv.js
 */
final class TenantCsvBuilder
{
    /** UTF-8 BOM — Excel needs this to render non-ASCII chars correctly. */
    private const UTF8_BOM = "\xEF\xBB\xBF";

    /**
     * Render the CSV file and return its absolute temp path.
     *
     * @param  list<array<string, mixed>>  $rows
     * @param  list<array<string, mixed>>  $tableColumns
     * @param  array{title?:string, dbName?:string}  $opts
     * @return string  absolute path to the saved CSV in sys_get_temp_dir()
     *
     * @throws RuntimeException
     */
    public static function render(array $rows, array $tableColumns = [], array $opts = []): string
    {
        if (count($rows) === 0) {
            throw new RuntimeException('No rows to render');
        }

        $title = (string) ($opts['title'] ?? 'results');
        $dbName = (string) ($opts['dbName'] ?? 'database');

        // Normalize stdClass → array
        $rowsAssoc = array_map(
            static fn ($r) => is_object($r) ? get_object_vars($r) : (array) $r,
            $rows
        );

        $roleMap = SmartFormatter::buildRoleMap($rowsAssoc[0], $tableColumns);
        $keys = array_keys($rowsAssoc[0]);

        // Build header line (humanized labels via SmartFormatter)
        $headerCells = array_map(
            static function (string $k) use ($roleMap) {
                $meta = $roleMap[$k] ?? $roleMap[strtolower($k)] ?? null;
                $original = (string) ($meta['original'] ?? $k);

                return self::escapeCell(SmartFormatter::humanizeLabel($original));
            },
            $keys
        );

        // Build body lines — raw values, no formatting (Excel-friendly)
        $lines = [implode(',', $headerCells)];
        foreach ($rowsAssoc as $r) {
            $rowCells = array_map(
                static fn (string $k) => self::escapeCell($r[$k] ?? null),
                $keys
            );
            $lines[] = implode(',', $rowCells);
        }

        // Grand Total row — sum numeric/currency columns
        $totalCells = [];
        foreach ($keys as $idx => $k) {
            $meta = $roleMap[$k] ?? $roleMap[strtolower($k)] ?? null;
            $role = (string) ($meta['role'] ?? 'text');
            if (in_array($role, ['currency', 'quantity', 'count', 'number'], true) && $role !== 'rate') {
                $sum = 0.0;
                foreach ($rowsAssoc as $r) {
                    if (is_numeric($r[$k] ?? null)) $sum += (float) $r[$k];
                }
                $totalCells[] = self::escapeCell($sum);
            } elseif ($idx === 0) {
                $totalCells[] = '"Grand Total"';
            } else {
                $totalCells[] = '';
            }
        }
        $lines[] = implode(',', $totalCells);

        // RFC 4180 line ending = CRLF
        $content = self::UTF8_BOM.implode("\r\n", $lines)."\r\n";

        $fileName = self::safeName($dbName).'_'.self::safeName($title).'_'.((int) (microtime(true) * 1000)).'.csv';
        $tmpPath = sys_get_temp_dir().DIRECTORY_SEPARATOR.$fileName;

        if (file_put_contents($tmpPath, $content) === false) {
            throw new RuntimeException("Could not write CSV to {$tmpPath}");
        }

        Log::info("[TENANT CSV] {$dbName} \"{$title}\": ".count($rowsAssoc).' rows, '.count($keys)." cols → {$tmpPath} (".strlen($content).'B)');

        return $tmpPath;
    }

    /**
     * Build a short WhatsApp summary message for the CSV dispatch reply.
     * Includes total row count + aggregate totals across numeric columns.
     *
     * @param  list<array<string, mixed>>  $rows
     * @param  list<array<string, mixed>>  $tableColumns
     */
    public static function buildSummary(array $rows, array $tableColumns = []): ?string
    {
        if (count($rows) === 0) return null;

        $rowsAssoc = array_map(
            static fn ($r) => is_object($r) ? get_object_vars($r) : (array) $r,
            $rows
        );
        $roleMap = SmartFormatter::buildRoleMap($rowsAssoc[0], $tableColumns);
        $keys = array_keys($rowsAssoc[0]);

        $parts = [];
        foreach ($keys as $k) {
            $meta = $roleMap[$k] ?? $roleMap[strtolower($k)] ?? null;
            if (! $meta) continue;
            $role = (string) ($meta['role'] ?? 'text');
            if (! in_array($role, ['currency', 'quantity', 'count', 'number'], true)) continue;
            if ($role === 'rate') continue;

            $total = 0.0;
            $count = 0;
            foreach ($rowsAssoc as $r) {
                $n = $r[$k] ?? null;
                if (is_numeric($n)) {
                    $total += (float) $n;
                    $count++;
                }
            }
            if ($count === 0) continue;

            $label = SmartFormatter::humanizeLabel((string) ($meta['original'] ?? $k));
            $formatted = SmartFormatter::formatValue($total, $role);
            if ($formatted !== '') {
                $parts[] = "*{$label}:* {$formatted}";
            }
        }

        $msg = '📊 Sending CSV with *'.count($rowsAssoc).' rows* (open in Excel/Sheets).';
        if (count($parts) > 0) {
            $msg .= "\n\n📈 *Totals:* ".implode(' | ', $parts);
        }

        return $msg;
    }

    // ════════════════════════════════════════════════════════════════════
    // INTERNAL HELPERS
    // ════════════════════════════════════════════════════════════════════

    /**
     * Escape a single CSV cell per RFC 4180.
     *   - null/empty → empty string
     *   - non-finite numeric → empty string
     *   - numeric → as-is, no thousands separator
     *   - any field with comma/quote/CR/LF → wrapped in quotes, internal quotes doubled
     */
    private static function escapeCell(mixed $v): string
    {
        if ($v === null || $v === '') return '';

        if (is_int($v) || is_float($v)) {
            if (! is_finite($v)) return '';

            return (string) $v;
        }

        $s = (string) $v;
        if ($s === '') return '';

        if (preg_match('/[",\r\n]/', $s)) {
            $s = '"'.str_replace('"', '""', $s).'"';
        }

        return $s;
    }

    /**
     * Sanitize a string for safe filesystem use.
     */
    private static function safeName(string $s, int $maxLen = 40): string
    {
        $clean = preg_replace('/[^\w\d\-]+/', '_', $s) ?? '';
        $clean = preg_replace('/_+/', '_', $clean) ?? '';
        $clean = trim($clean, '_');
        $clean = mb_substr($clean, 0, $maxLen);

        return $clean !== '' ? $clean : 'data';
    }
}
