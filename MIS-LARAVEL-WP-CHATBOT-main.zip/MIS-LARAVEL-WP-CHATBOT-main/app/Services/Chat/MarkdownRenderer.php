<?php

declare(strict_types=1);

namespace App\Services\Chat;

/**
 * MarkdownRenderer — converts the subset of Markdown the AI actually
 * produces (bold, bullet/numbered lists, links, paragraphs) into safe HTML
 * for the web chat panel.
 *
 * Not a full CommonMark implementation — deliberately small and
 * dependency-free. Input is HTML-escaped first, so all conversions below
 * operate on already-safe text (no XSS risk from AI-generated content).
 *
 * Replaces the old ChatController::whatsappTextToHtml(), which only handled
 * bold text and nl2br, and left stray `- ` bullets and `[text](url)` links
 * as literal text once the AI drifted into standard Markdown despite
 * WhatsApp-style prompt instructions.
 */
final class MarkdownRenderer
{
    public static function toHtml(string $text): string
    {
        $safe = e($text);
        $lines = preg_split('/\r\n|\r|\n/', $safe) ?: [];

        $htmlBlocks = [];
        $paragraphBuffer = [];
        $listBuffer = [];
        $listType = null; // 'ul' | 'ol'

        $flushParagraph = function () use (&$paragraphBuffer, &$htmlBlocks) {
            if (empty($paragraphBuffer)) return;
            $htmlBlocks[] = '<p style="margin:0 0 8px">'.implode('<br>', $paragraphBuffer).'</p>';
            $paragraphBuffer = [];
        };

        $flushList = function () use (&$listBuffer, &$listType, &$htmlBlocks) {
            if (empty($listBuffer)) return;
            $items = implode('', array_map(static fn ($i) => "<li>{$i}</li>", $listBuffer));
            $tag = $listType === 'ol' ? 'ol' : 'ul';
            $htmlBlocks[] = "<{$tag} style=\"margin:4px 0 8px 22px;padding:0\">{$items}</{$tag}>";
            $listBuffer = [];
            $listType = null;
        };

        foreach ($lines as $line) {
            $trimmed = trim($line);

            if ($trimmed === '') {
                $flushParagraph();
                $flushList();
                continue;
            }

            // Header lines (# / ## / ###) → bold paragraph line, not a real <h> tag
            // (keeps visual weight consistent with the rest of the chat bubble).
            if (preg_match('/^#{1,6}\s+(.*)$/', $trimmed, $m)) {
                $flushParagraph();
                $flushList();
                $htmlBlocks[] = '<p style="margin:0 0 8px"><b>'.self::inline($m[1]).'</b></p>';
                continue;
            }

            // Unordered list item: "- text" or "* text" (space required after the
            // marker, so it never collides with "*bold*" which has no space).
            if (preg_match('/^[-*]\s+(.*)$/', $trimmed, $m)) {
                if ($listType === 'ol') $flushList();
                $flushParagraph();
                $listType = 'ul';
                $listBuffer[] = self::inline($m[1]);
                continue;
            }

            // Ordered list item: "1. text" or "1) text"
            if (preg_match('/^\d+[.)]\s+(.*)$/', $trimmed, $m)) {
                if ($listType === 'ul') $flushList();
                $flushParagraph();
                $listType = 'ol';
                $listBuffer[] = self::inline($m[1]);
                continue;
            }

            // Plain paragraph line
            $flushList();
            $paragraphBuffer[] = self::inline($trimmed);
        }

        $flushParagraph();
        $flushList();

        if (empty($htmlBlocks)) {
            return '';
        }

        return '<div style="margin-bottom:12px;line-height:1.5">'.implode('', $htmlBlocks).'</div>';
    }

    /**
     * Inline-level conversions applied within a single line/list-item: bold
     * and links. Operates on already HTML-escaped text.
     */
    private static function inline(string $text): string
    {
        // Links: [label](https://...) — must run before bold so "**[x](y)**" still works.
        $text = preg_replace(
            '/\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/',
            '<a href="$2" target="_blank" rel="noopener" style="color:#1a73e8;text-decoration:none;font-weight:500">$1</a>',
            $text
        ) ?? $text;

        // Bold: **text** then *text* (double first so single-asterisk pass doesn't
        // eat one side of a double-asterisk pair).
        $text = preg_replace('/\*\*([^*\n]+)\*\*/', '<b>$1</b>', $text) ?? $text;
        $text = preg_replace('/\*([^*\n]+)\*/', '<b>$1</b>', $text) ?? $text;

        return $text;
    }
}
