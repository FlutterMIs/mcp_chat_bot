<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * MultiStepAgent — handles complex queries that need multiple SQL steps.
 *
 * Flow:
 *   1. AI receives schema + query → decides SIMPLE or COMPLEX
 *   2. If COMPLEX: AI outputs a plan (up to 5 SQL steps)
 *   3. Each step is executed, results fed back to AI
 *   4. AI produces final natural-language answer combining all results
 *
 * Triggers only when the planning AI explicitly says "COMPLEX".
 * Simple queries fall through to the normal single-SQL pipeline.
 */
final class MultiStepAgent
{
    private const MAX_STEPS = 5;
    private const STEP_ROW_LIMIT = 50;

    /**
     * Determine if the query needs multi-step processing.
     * Returns null if SIMPLE (caller should use normal pipeline).
     * Returns the final formatted answer if COMPLEX.
     */
    public static function handle(object $tenant, string $query, array $tablesMeta, bool $webMode = false): ?array
    {
        $schema = PromptBuilder::buildSchemaBlock($tablesMeta);

        // Step 1: Ask AI if this is complex and get a plan
        $plan = self::generatePlan($tenant->id, $tenant->name, $schema, $query);
        if ($plan === null) return null; // SIMPLE → let normal pipeline handle

        Log::info("[MULTI-STEP] {$tenant->name}: complex query detected, " . count($plan) . " steps planned");

        // Step 2: Execute each step, collecting results
        $stepResults = [];
        $lastStepRows = [];
        $lastStepSql = '';
        foreach ($plan as $i => $step) {
            $sql = $step['sql'] ?? '';
            if ($sql === '' || !self::isSafeSelect($sql)) {
                Log::warning("[MULTI-STEP] step " . ($i + 1) . " invalid SQL, skipping");
                continue;
            }

            try {
                $rows = DB::select($sql);
                $rows = array_slice($rows, 0, self::STEP_ROW_LIMIT);
                $stepResults[] = [
                    'step' => $i + 1,
                    'purpose' => $step['purpose'] ?? '',
                    'sql' => $sql,
                    'rows' => count($rows),
                    'data' => self::summarizeRows($rows),
                ];
                // Track the last step that actually returned rows — for most report-style
                // queries (the common case here) this is the final "put it all together"
                // query, so it's the row shape worth rendering as a web table. Earlier
                // steps are typically discovery/lookup queries with unrelated shapes.
                if (count($rows) > 0) {
                    $lastStepRows = $rows;
                    $lastStepSql = $sql;
                }
                Log::info("[MULTI-STEP] step " . ($i + 1) . ": " . count($rows) . " rows — " . ($step['purpose'] ?? ''));
            } catch (Throwable $e) {
                Log::warning("[MULTI-STEP] step " . ($i + 1) . " failed: " . $e->getMessage());
                $stepResults[] = [
                    'step' => $i + 1,
                    'purpose' => $step['purpose'] ?? '',
                    'sql' => $sql,
                    'rows' => 0,
                    'data' => 'ERROR: ' . substr($e->getMessage(), 0, 100),
                ];
            }
        }

        if (empty($stepResults)) return null;

        // Step 3: AI combines all step results into final answer
        $answer = self::synthesize($tenant->id, $query, $stepResults, $webMode, count($lastStepRows) > 1);

        return [
            'reply' => $answer,
            'intent' => 'MULTI_STEP_QUERY',
            'steps' => count($stepResults),
            'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
            // Populated so the web panel can render a table alongside the AI narrative,
            // same as the single-query DATA_QUERY path — see ChatController::toWebResponse.
            'sql' => $lastStepSql,
            'raw_rows' => $lastStepRows,
        ];
    }

    /**
     * Ask AI to decide SIMPLE vs COMPLEX and produce a step plan if complex.
     * Returns null for SIMPLE, array of steps for COMPLEX.
     */
    private static function generatePlan(string $tenantId, string $tenantName, string $schema, string $query): ?array
    {
        $prompt = <<<PROMPT
You are a query planner for a business database assistant ("{$tenantName}").

SCHEMA:
{$schema}

USER QUESTION: {$query}

TASK: Decide if this question can be answered with ONE simple SQL query or needs MULTIPLE steps.

SIMPLE = one SELECT with basic JOIN/GROUP BY/WHERE can answer it fully.
COMPLEX = needs multiple queries (cross-referencing tables, calculations from multiple sources, hierarchical grouping, data not directly in one table).

If SIMPLE, respond with exactly: SIMPLE
If COMPLEX, respond with a JSON array of steps (max 5). Each step has:
- "purpose": what this step finds (1 sentence)
- "sql": a valid MySQL SELECT query

Example COMPLEX response:
[
  {"purpose": "Get all team members from expenses table", "sql": "SELECT DISTINCT team_member FROM tenant_xxx_expenses WHERE team_member IS NOT NULL"},
  {"purpose": "Get monthly totals per team member", "sql": "SELECT team_member, DATE_FORMAT(date_actual, '%b-%y') AS month, SUM(amount+0) AS total FROM tenant_xxx_expenses GROUP BY 1, 2 ORDER BY 1, 2"}
]

RULES:
- Only output SIMPLE or a valid JSON array. Nothing else.
- Each SQL must be a SELECT (no INSERT/UPDATE/DELETE).
- Use real table and column names from the schema above.
- Limit each query to 50 rows max.
- If the question is ambiguous but answerable with one query, say SIMPLE.
- If the user mentions concepts like "team member", "salary", "joining date", "employee" etc. that don't directly appear as column names in the schema, say COMPLEX and use Step 1 to explore which columns contain that data (e.g. SELECT DISTINCT column_name FROM table LIMIT 10).
- When column names are misleading (e.g. "DESIGN NUMBER" might actually contain person names), use a discovery step first.
PROMPT;

        try {
            $aiResult = \App\Services\AI\AiGateway::chat($tenantId, [['role' => 'user', 'content' => $prompt]], ['temperature' => 0, 'max_tokens' => 1000, 'timeout' => 15]);
        } catch (Throwable $e) {
            Log::warning("[MULTI-STEP] plan generation failed: " . $e->getMessage());
            return null;
        }

        if (!$aiResult['ok']) return null;

        $content = trim($aiResult['content']);

        if (strtoupper($content) === 'SIMPLE') return null;

        // Try to parse JSON plan
        $content = preg_replace('/^```json?\s*/i', '', $content);
        $content = preg_replace('/\s*```$/', '', $content);
        $plan = json_decode($content, true);

        if (!is_array($plan) || empty($plan)) return null;

        return array_slice($plan, 0, self::MAX_STEPS);
    }

    /**
     * AI synthesizes all step results into a final answer.
     *
     * @param  bool  $webMode  true for the web chat panel — produces a short intro
     *                         sentence (no per-record breakdown) in clean Markdown,
     *                         since ChatController renders a real HTML table right
     *                         alongside it from raw_rows. WhatsApp has no table, so
     *                         it always gets the full narrative.
     * @param  bool  $hasTabularResult  true when the last step returned >1 rows that
     *                                  the web panel will render as a table.
     */
    private static function synthesize(string $tenantId, string $query, array $stepResults, bool $webMode = false, bool $hasTabularResult = false): string
    {
        $stepsText = '';
        foreach ($stepResults as $s) {
            $stepsText .= "Step {$s['step']} ({$s['purpose']}): {$s['rows']} rows\n{$s['data']}\n\n";
        }

        if ($webMode && $hasTabularResult) {
            $prompt = <<<PROMPT
You are a business data assistant. The user asked: "{$query}"

I executed multiple queries to gather the data. Here are the results:

{$stepsText}

A table with the full row-level detail will be shown to the user right below your reply — do NOT repeat the rows.
Produce ONLY one short introductory sentence (max ~20 words) that answers the user's question at a high level, e.g. "Here are the 5 most recent invoices, totalling ₹1.2 L." Use **bold** for the key number if any. No lists, no per-record breakdown, no sign-off line.
PROMPT;
        } elseif ($webMode) {
            $prompt = <<<PROMPT
You are a business data assistant. The user asked: "{$query}"

I executed multiple queries to gather the data. Here are the results:

{$stepsText}

Produce a clear, well-formatted reply answering the user's question, using standard Markdown (**bold**, `-`/`1.` lists, `[label](url)` links — no emojis as bullets).
Rules:
- Format Indian currency as ₹X.XX Cr / L / K
- Be concise but complete
- If some data is missing or errored, mention it briefly
PROMPT;
        } else {
            $prompt = <<<PROMPT
You are a business data assistant. The user asked: "{$query}"

I executed multiple queries to gather the data. Here are the results:

{$stepsText}

Now produce a clear, well-formatted WhatsApp reply answering the user's question.
Rules:
- Do NOT use * or _ for formatting
- Use emoji bullets (1️⃣ 2️⃣ etc.) for lists
- Format Indian currency as ₹X.XX Cr / L / K
- Be concise but complete
- If some data is missing or errored, mention it briefly
- End with: "Need more details? Just ask 👇"
PROMPT;
        }

        try {
            $aiResult = \App\Services\AI\AiGateway::chat($tenantId, [['role' => 'user', 'content' => $prompt]], ['temperature' => 0.3, 'max_tokens' => $webMode && $hasTabularResult ? 200 : 1500, 'timeout' => 15]);
        } catch (Throwable $e) {
            return "⚠️ Could not compile final answer: " . $e->getMessage();
        }

        if (!$aiResult['ok']) return "⚠️ Could not compile final answer.";

        $reply = trim($aiResult['content']);
        if (!$webMode) {
            $reply = preg_replace('/\*\*/', '*', $reply) ?? $reply;
        }
        return $reply ?: "⚠️ No answer generated.";
    }

    private static function isSafeSelect(string $sql): bool
    {
        $upper = strtoupper(trim($sql));
        return str_starts_with($upper, 'SELECT') && !preg_match('/\b(INSERT|UPDATE|DELETE|DROP|ALTER|TRUNCATE|CREATE)\b/i', $sql);
    }

    private static function summarizeRows(array $rows): string
    {
        if (empty($rows)) return '(no data)';
        $rows = array_map(fn($r) => (array) $r, $rows);
        // Show first 10 rows as compact text
        $lines = [];
        foreach (array_slice($rows, 0, 10) as $r) {
            $parts = [];
            foreach ($r as $k => $v) {
                if ($v !== null && $v !== '') $parts[] = "$k=$v";
            }
            $lines[] = implode(' | ', $parts);
        }
        $out = implode("\n", $lines);
        if (count($rows) > 10) $out .= "\n... (" . count($rows) . " total rows)";
        return $out;
    }
}
