<?php

declare(strict_types=1);

namespace App\Services\Chat;

use App\Services\WhatsApp\Client;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * DriveFileHandler — detects Google Drive PDF links in bot replies and downloads+sends
 * the actual file as a WhatsApp document (instead of just a text link).
 *
 * Supports:
 *   - https://drive.google.com/file/d/{fileId}/view...
 *   - https://drive.google.com/open?id={fileId}
 *   - https://docs.google.com/document/d/{fileId}/...
 *   - https://docs.google.com/spreadsheets/d/{fileId}/...
 */
final class DriveFileHandler
{
    private const DRIVE_LINK_RE = '#https?://(?:drive\.google\.com/(?:file/d/|open\?id=)|docs\.google\.com/(?:document|spreadsheets|presentation)/d/)([a-zA-Z0-9_-]+)#';

    /**
     * Extract Google Drive file IDs from a text string.
     * @return list<array{url: string, fileId: string}>
     */
    public static function extractDriveLinks(string $text): array
    {
        if (!preg_match_all(self::DRIVE_LINK_RE, $text, $matches, PREG_SET_ORDER)) {
            return [];
        }
        $seen = [];
        $links = [];
        foreach ($matches as $m) {
            $fileId = $m[1];
            if (isset($seen[$fileId])) continue;
            $seen[$fileId] = true;
            $links[] = ['url' => $m[0], 'fileId' => $fileId];
        }
        return $links;
    }

    /**
     * Download a file from Google Drive by fileId.
     * Uses the public download URL (works for files shared as "Anyone with link").
     * Returns the temp file path or null on failure.
     */
    public static function downloadDriveFile(string $fileId): ?string
    {
        $downloadUrl = "https://drive.google.com/uc?export=download&id={$fileId}";

        try {
            $resp = Http::withOptions(['allow_redirects' => true])
                ->timeout(30)
                ->get($downloadUrl);

            if (!$resp->ok() || strlen($resp->body()) < 100) {
                // Try confirm page bypass for large files
                if ($resp->ok() && str_contains($resp->body(), 'confirm=')) {
                    preg_match('/confirm=([^&"]+)/', $resp->body(), $cm);
                    if (!empty($cm[1])) {
                        $resp = Http::withOptions(['allow_redirects' => true])
                            ->timeout(30)
                            ->get("{$downloadUrl}&confirm={$cm[1]}");
                    }
                }
                if (!$resp->ok() || strlen($resp->body()) < 100) {
                    Log::warning("[DRIVE DL] failed for fileId={$fileId} status={$resp->status()}");
                    return null;
                }
            }

            // Detect file type from content-type header
            $contentType = $resp->header('Content-Type') ?? 'application/octet-stream';
            $ext = match (true) {
                str_contains($contentType, 'pdf') => 'pdf',
                str_contains($contentType, 'spreadsheet') || str_contains($contentType, 'excel') => 'xlsx',
                str_contains($contentType, 'document') || str_contains($contentType, 'msword') => 'docx',
                str_contains($contentType, 'image/png') => 'png',
                str_contains($contentType, 'image/jpeg') => 'jpg',
                default => 'pdf', // assume PDF if unknown
            };

            $tmpPath = sys_get_temp_dir() . '/drive_' . $fileId . '_' . time() . '.' . $ext;
            file_put_contents($tmpPath, $resp->body());
            Log::info("[DRIVE DL] downloaded {$fileId} → {$tmpPath} (" . strlen($resp->body()) . " bytes, {$contentType})");

            return $tmpPath;
        } catch (Throwable $e) {
            Log::warning("[DRIVE DL] error: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Derive a human-friendly filename from the reply text context.
     * Looks for company/party name and invoice number patterns.
     */
    private static function deriveFilename(string $replyText, string $fileId, string $ext): string
    {
        $company = '';
        $invoice = '';

        // Strip WhatsApp bold markers (*text*) so regexes match cleanly
        $clean = str_replace('*', '', $replyText);

        // Extract company/party name from common patterns in reply
        if (preg_match('/(?:Invoice\s*To|Party|Customer|Client)\s*[:：]\s*(.+)/i', $clean, $m)) {
            $company = trim(preg_replace('/[^\w\s&.-]/u', '', $m[1]));
            $company = mb_substr($company, 0, 40);
        }

        // Extract invoice number
        if (preg_match('/(?:Invoice\s*No\.?|Inv\s*No\.?|Bill\s*No\.?|Voucher\s*No\.?)\s*[:：]?\s*([A-Za-z0-9\/_-]+)/i', $clean, $m)) {
            $invoice = trim($m[1]);
        }

        if ($company && $invoice) {
            return trim("{$company} - Invoice {$invoice}") . ".{$ext}";
        }
        if ($company) {
            return trim("{$company} - Invoice") . ".{$ext}";
        }
        if ($invoice) {
            return "Invoice {$invoice}.{$ext}";
        }

        return "document_{$fileId}.{$ext}";
    }

    /**
     * Scan reply text for Drive links, download each file, and send as WhatsApp documents.
     * Returns the number of files successfully sent.
     */
    public static function sendDriveFiles(string $phone, string $replyText, ?string $tenantId = null): int
    {
        $links = self::extractDriveLinks($replyText);
        // Only auto-send when exactly 1 link (specific invoice request).
        // Multiple links = it's a list, don't spam PDFs.
        if (count($links) !== 1) return 0;

        $sent = 0;
        foreach (array_slice($links, 0, 3) as $link) { // cap at 3 files
            $filePath = self::downloadDriveFile($link['fileId']);
            if ($filePath === null) continue;

            try {
                $ext = pathinfo($filePath, PATHINFO_EXTENSION);
                $filename = self::deriveFilename($replyText, $link['fileId'], $ext);
                $caption = '📄 File from Google Drive';

                if ($ext === 'pdf') {
                    Client::sendDocument($phone, $filePath, $caption, $filename, $tenantId);
                } elseif (in_array($ext, ['png', 'jpg', 'jpeg'], true)) {
                    Client::sendImage($phone, $filePath, $caption, $tenantId);
                } else {
                    Client::sendDocument($phone, $filePath, $caption, $filename, $tenantId);
                }
                $sent++;
            } finally {
                if (is_file($filePath) && str_starts_with($filePath, sys_get_temp_dir())) {
                    @unlink($filePath);
                }
            }
        }

        Log::info("[DRIVE SEND] sent {$sent}/" . count($links) . " Drive files to {$phone}");
        return $sent;
    }
}
