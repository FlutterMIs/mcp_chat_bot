<?php

declare(strict_types=1);

namespace App\Services\Chat;

use App\Models\SheetTabAccess;
use App\Models\Tenant;
use App\Models\TenantLink;
use App\Models\TenantPhone;
use App\Models\TenantPrompt;
use App\Models\TenantQueryLog;
use App\Models\UserDatabase;
use App\Services\AI\AiGateway;
use App\Services\AI\AiOrchestrator;
use App\Services\AI\DisambiguationService;
use App\Services\AI\QueryMemory;
use App\Services\AI\ResultValidator;
use App\Services\Google\CalendarService;
use App\Services\Notifications\TenantNotificationService;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * TenantRouter — core /api/chat handler for tenant data queries.
 *
 * Flow:
 *   1. Resolve tenant from phone (3-step lookup)
 *   2. Detect intent (GREETING / IGNORE / CLARIFY_NEEDED / DATA_QUERY)
 *   3. For DATA_QUERY: build SQL prompt, call gpt-4o to generate SQL
 *   4. Validate SQL is SELECT-only, single statement
 *   5-7. Multi-step self-healing pipeline (up to 3 attempts):
 *        - SelfHeal::withRetry handles TRANSIENT (network) errors per attempt
 *        - SCHEMA_COLUMN errors → SelfHeal::resolveColumnError (Levenshtein) tries cheap rewrite
 *          before paying for an AI re-prompt
 *        - PERMISSION / SCHEMA_RELATION → fail fast (not retryable)
 *        - On retries, AI sees its previous SQL + error message so it can self-correct
 *        - Single-row all-NULL aggregate is rerouted as 0-row (false success)
 *        - 0 rows → FuzzyFallback::search (pg_trgm trigram on entity columns) for suggestions
 *        - Still 0 rows → SelfHeal::relaxSQL emits drop-date / loosen-ILIKE / both variants
 *   8. Format result via SmartFormatter (inline list <= 15 rows, AI summary > 15)
 *      OR — when mode === 'chart' and rows >= 2 — render via ChartQueryHandler/ChartBuilder
 *      and return a `{reply, media:{type:image, path, caption}}` payload (Z16). Falls through
 *      to text formatter on any chart-rendering failure.
 *      OR — when mode === 'images' — extract URL+caption pairs from rows via
 *      ImageColumnDetector::extractImageItems and return `{reply, media:{type:'images', items}}`
 *      (Z17). Pre-flight check (Step 4a) bails out fast with a friendly message if the tenant
 *      has no image-URL columns.
 *      OR — when mode === 'ledger' — route to LedgerQueryHandler::handle BEFORE the AI/SQL
 *      pipeline (Z18). Handler does entity-extraction + ILIKE/fuzzy name search + PDF render
 *      via barryvdh/laravel-dompdf, returns `{reply, media:{type:document, path, filename}}`
 *      for single matches; numbered disambiguation list for multi-matches. Multi-turn
 *      pending-state machinery deferred (user re-asks with full name).
 *      OR — when mode === 'calendar' — pre-flight checks calendar_connected (returns OAuth
 *      init URL if not), then routes to CalendarQueryHandler::handle for retrieve/cancel/book
 *      (Z19). BOOK uses gpt-4o-mini to parse {title, date, time, duration, guest, recurring,
 *      count, interval_days}, then loops CalendarService::createEvent for recurring (cap 365).
 *      Multi-turn pending state DEFERRED.
 *   9. Log to tenant_query_logs
 *
 * NOT implemented in this initial port (deferred to follow-up sessions):
 *   - Multi-DB switching ("switch db" command)
 *   - PDF/CSV auto-export for >50 / >100 row results
 *   - Email confirmations + reminders + daily schedule (Phase 23D notifications)
 *
 * Multi-turn pending state (Z20):
 *   - Step 2a checks PendingStateStore::get($phone) right after greeting/ignore filter.
 *   - Calendar pending → merge original_query + connector + new_query, route to handler.
 *   - Ledger pending → numeric/name pick, route to handler with `preselected` opt to skip
 *     entity extraction. Unmatched replies clear state and fall through to normal flow.
 *
 * Port of Node helpers/tenant-router.js (~lines 224-1400 — detectIntent + detectQueryMode +
 * aiPlanAndSQL + validateSQL + runSQL + processQueryProperTables retry loop + chart + image + ledger + calendar branches).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-router.js
 */
final class TenantRouter
{
    private const CACHE_TTL_SECONDS = 300;

    private const WA_TEXT_LIMIT = 4096;

    private const RESPONSE_LOG_LIMIT = 5000;

    private const IMAGE_ITEMS_CAP = 20;

    private const INLINE_FORMAT_ROWS = 0;

    private const CSV_THRESHOLD = 100;

    private const PDF_THRESHOLD = 50;

    private const MAX_SQL_ATTEMPTS = 3;

    private const RECENT_TURNS_COUNT = 3;

    /**
     * Public entry point — handle a single chat message from a phone.
     *
     * @return array{
     *     reply: string,
     *     intent?: string,
     *     tenant?: array{id: string, name: string},
     *     sql?: string,
     *     elapsed_ms?: int,
     * }
     */
    public static function handle(string $phone, string $query, bool $waMode = false, bool $isAudio = false, ?string $preResolvedTenantId = null): array
    {
        $t0 = microtime(true);
        $cleanPhone = preg_replace('/[^0-9]/', '', $phone);

        // Channel flag threaded into response-formatting prompts (SQL-generation
        // prompts stay channel-agnostic). Web gets clean Markdown output; WhatsApp
        // keeps its existing *bold*/emoji-bullet formatting untouched.
        $webMode = ! $waMode;

        // 1. Resolve tenant
        $tenantId = $preResolvedTenantId ?? self::resolveTenantId($cleanPhone);
        if (! $tenantId) {
            // WhatsApp ($waMode): stay completely silent for unregistered numbers.
            return [
                'reply' => $waMode ? '' : "🙏 I couldn't find a database linked to your number. Please register first via the onboarding page.",
                'intent' => 'NO_TENANT',
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        $tenant = Tenant::query()
            ->select(['id', 'name', 'phone', 'email', 'tables_metadata', 'system_prompt', 'business_description', 'schema_json', 'proper_tables_created', 'calendar_id', 'calendar_refresh_token', 'calendar_connected'])
            ->where('id', $tenantId)
            ->first();
        if (! $tenant) {
            return [
                'reply' => 'Tenant not found.',
                'intent' => 'ERROR',
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // Phase 6: Silent Correction — if current query contains negation words,
        // invalidate the previous query's cached SQL in query_memory.
        self::detectAndCorrect($tenant->id, $cleanPhone, $query);

        // 2. Detect intent — short-circuit greetings / ignored chatter
        $intent = self::detectIntent($query);
        if ($intent['intent'] === 'GREETING') {
            $greetReply = $waMode ? '' : $intent['greeting_reply'];
            if (! $waMode) {
                $personality = TenantPrompt::get($tenant->id, 'bot_personality');
                if ($personality) {
                    $greetReply = $personality;
                }
            }

            return [
                'reply' => $greetReply,
                'intent' => 'GREETING',
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }
        if ($intent['intent'] === 'IGNORE') {
            return [
                'reply' => '', // silent — same as Node behaviour
                'intent' => 'IGNORE',
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // 2-pre. SWITCH_DB intent (Z22) — handle BEFORE pending-state check so an explicit
        // "switch db" while a stale calendar/ledger pending exists clears that and starts fresh.
        // Lists the user's accessible databases and saves a {kind:'db_select'} state so the
        // next turn's numeric/name pick at the Z20 pending-check resolves it.
        if ($intent['intent'] === 'SWITCH_DB') {
            // Defensive — clear any other pending state so user gets a clean switch flow
            PendingStateStore::clear($cleanPhone);

            $dbs = self::listUserDatabases($cleanPhone);
            if (count($dbs) === 0) {
                // Should not happen — NO_TENANT path catches this earlier — but be defensive
                return [
                    'reply' => '🙏 No databases linked to your number yet. Please register first.',
                    'intent' => 'SWITCH_DB_NO_DBS',
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }
            if (count($dbs) === 1) {
                $only = $dbs[0];
                $shown = $only['alias'] ?? $only['name'];

                return [
                    'reply' => "📋 You only have 1 database: *{$shown}*",
                    'intent' => 'SWITCH_DB_SINGLE',
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }

            // Multiple DBs — save state, return numbered list
            $options = array_map(static fn (array $d) => [
                'id' => $d['id'],
                'name' => $d['alias'] ?? $d['name'],
            ], $dbs);

            PendingStateStore::set($cleanPhone, [
                'kind' => 'db_select',
                'options' => $options,
            ]);

            $listLines = [];
            foreach ($options as $i => $opt) {
                $star = ($dbs[$i]['is_default'] ?? false) ? ' (current)' : '';
                $listLines[] = ($i + 1).". *{$opt['name']}*{$star}";
            }

            return [
                'reply' => "📋 Your databases:\n\n".implode("\n", $listLines)."\n\n_Reply with the number (e.g. \"2\") or the name to switch._",
                'intent' => 'SWITCH_DB_LIST',
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'options' => $options,
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // 2a. Multi-turn pending-state check (Z20).
        //
        // If the previous turn left us waiting on the user (calendar booking missing
        // date/time, OR ledger disambiguation choice), route this turn straight to the
        // matching handler with the merged context. State is keyed by phone with 5-min TTL.
        //
        // - Calendar pending: any non-greeting reply is treated as continuation. We rebuild
        //   the query as `original_query + connector + new_query` (connector = " on " for date,
        //   " at " for time). Handler re-parses the merged query and either succeeds or asks
        //   for the next missing piece.
        //
        // - Ledger pending: try numeric pick (1-N) or name substring match against the saved
        //   options. If matched, render the PDF directly (skip entity extraction + search). If
        //   the new query doesn't look like a valid pick, clear pending state and fall through
        //   to the normal flow (so "NPL ka ledger" → list → "what's my total sales" works).
        //
        // GREETING and IGNORE are intentionally checked BEFORE pending state so a "thanks" reply
        // doesn't accidentally consume the pending context.
        $pending = PendingStateStore::get($cleanPhone);
        if ($pending !== null) {
            if (($pending['kind'] ?? '') === 'calendar') {
                Log::info('[TENANT PENDING CALENDAR] expecting='.($pending['expecting'] ?? '?').' reply="'.substr($query, 0, 80).'"');

                $result = CalendarQueryHandler::continueBooking($tenant, $pending, $query, $cleanPhone);
                self::logQuery($tenant->id, $cleanPhone, $query, null, $result['reply'] ?? '');

                return array_merge($result, [
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ]);
            }

            if (($pending['kind'] ?? '') === 'disambiguation') {
                $result = self::resolveDisambiguation($tenant, $pending, $query, $cleanPhone);
                if ($result !== null) {
                    self::logQuery($tenant->id, $cleanPhone, $query, null, $result['reply'] ?? '');

                    return array_merge($result, [
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'elapsed_ms' => self::elapsed($t0),
                    ]);
                }

                // Unmatched — user typed something unrelated. Clear and fall through.
                PendingStateStore::clear($cleanPhone);
                Log::info('[TENANT PENDING DISAMBIGUATION] unmatched reply → cleared pending state');
            }

            if (($pending['kind'] ?? '') === 'ledger') {
                $options = (array) ($pending['options'] ?? []);
                $resolved = self::resolveLedgerChoice($query, $options);

                if ($resolved !== null) {
                    Log::info("[TENANT PENDING LEDGER] resolved \"{$query}\" → \"{$resolved}\"");
                    PendingStateStore::clear($cleanPhone);

                    $result = LedgerQueryHandler::handle($tenant, $resolved, $cleanPhone, ['preselected' => $resolved, 'accessFilter' => self::computeAccessFilter($tenant->id, $cleanPhone)]);
                    self::logQuery($tenant->id, $cleanPhone, $query, null, $result['reply'] ?? '');

                    return array_merge($result, [
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'elapsed_ms' => self::elapsed($t0),
                    ]);
                }

                // Unmatched — user typed something unrelated. Clear and fall through.
                PendingStateStore::clear($cleanPhone);
                Log::info('[TENANT PENDING LEDGER] unmatched reply → cleared pending state');
            }

            if (($pending['kind'] ?? '') === 'db_select') {
                // options: list<{id:string, name:string}>. Resolve via the same numeric/name
                // matcher used for ledger picks — works for "1"/"2"/"option 2"/"#3" or any
                // case-insensitive substring match on the displayed name.
                $options = (array) ($pending['options'] ?? []);
                $names = array_map(static fn ($o) => (string) ($o['name'] ?? ''), $options);
                $resolvedName = self::resolveLedgerChoice($query, $names);

                if ($resolvedName !== null) {
                    // Find the matching option to get its id
                    $resolvedId = null;
                    foreach ($options as $opt) {
                        if (($opt['name'] ?? '') === $resolvedName) {
                            $resolvedId = (string) ($opt['id'] ?? '');
                            break;
                        }
                    }

                    if ($resolvedId !== null && $resolvedId !== '') {
                        Log::info("[TENANT PENDING DB_SELECT] resolved \"{$query}\" → \"{$resolvedName}\" (id={$resolvedId})");
                        try {
                            self::applyDbSwitch($cleanPhone, $resolvedId);
                            PendingStateStore::clear($cleanPhone);

                            // Re-fetch the new active tenant for response context
                            $newTenant = Tenant::query()->select(['id', 'name'])->where('id', $resolvedId)->first();
                            $newName = $newTenant?->name ?? $resolvedName;
                            $reply = "✅ Switched to *{$newName}*. Ask anything about this database now!";
                            self::logQuery($resolvedId, $cleanPhone, $query, null, $reply);

                            return [
                                'reply' => $reply,
                                'intent' => 'SWITCH_DB_DONE',
                                'tenant' => ['id' => $resolvedId, 'name' => $newName],
                                'elapsed_ms' => self::elapsed($t0),
                            ];
                        } catch (Throwable $e) {
                            Log::error('[TENANT PENDING DB_SELECT] applyDbSwitch failed: '.$e->getMessage());
                            PendingStateStore::clear($cleanPhone);

                            return [
                                'reply' => '⚠️ Could not switch the database. Please try again.',
                                'intent' => 'SWITCH_DB_ERROR',
                                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                                'elapsed_ms' => self::elapsed($t0),
                            ];
                        }
                    }
                }

                // Unmatched — user typed something unrelated. Clear and fall through.
                PendingStateStore::clear($cleanPhone);
                Log::info('[TENANT PENDING DB_SELECT] unmatched reply → cleared pending state');
            }

            if (($pending['kind'] ?? '') === 'cancel_select') {
                // options: list<{id:string, summary:string}>. Resolve to an index via number
                // pick ("1") or a unique name match, then delete that calendar event.
                $options = array_values((array) ($pending['options'] ?? []));
                $idx = self::resolveCancelChoice($query, $options);

                if ($idx !== null && isset($options[$idx])) {
                    $opt = $options[$idx];
                    PendingStateStore::clear($cleanPhone);
                    try {
                        CalendarService::deleteEvent(
                            (string) $tenant->calendar_refresh_token,
                            (string) ($tenant->calendar_id ?: 'primary'),
                            (string) $opt['id']
                        );
                        TenantNotificationService::notifyCancellation($tenant, (string) ($opt['summary'] ?? 'Meeting'));
                        $reply = '✅ Meeting cancelled: *'.($opt['summary'] ?? 'No title').'*';
                        $reply .= CalendarQueryHandler::upcomingScheduleText($tenant);
                        self::logQuery($tenant->id, $cleanPhone, $query, null, $reply);

                        return [
                            'reply' => $reply,
                            'intent' => 'CALENDAR_CANCELLED',
                            'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                            'elapsed_ms' => self::elapsed($t0),
                        ];
                    } catch (Throwable $e) {
                        Log::error('[TENANT PENDING CANCEL_SELECT] '.$e->getMessage());

                        return [
                            'reply' => '⚠️ Could not cancel the meeting. Please try again.',
                            'intent' => 'CALENDAR_ERROR',
                            'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                            'elapsed_ms' => self::elapsed($t0),
                        ];
                    }
                }

                // Unmatched — user typed something unrelated. Clear and fall through.
                PendingStateStore::clear($cleanPhone);
                Log::info('[TENANT PENDING CANCEL_SELECT] unmatched reply → cleared pending state');
            }

            if (($pending['kind'] ?? '') === 'contact_select') {
                $options = array_values((array) ($pending['options'] ?? []));
                $plan = (array) ($pending['plan'] ?? []);
                // Resolve numeric pick
                if (preg_match('/^\s*(?:option\s+|#)?(\d{1,2})\s*$/', $query, $m)) {
                    $idx = (int) $m[1] - 1;
                    if (isset($options[$idx])) {
                        $plan['guest'] = $options[$idx]['name'];
                        $plan['guest_email'] = $options[$idx]['email'];
                        Log::info("[TENANT PENDING CONTACT_SELECT] picked #{$m[1]} → {$options[$idx]['name']}");
                        // Save as calendar pending with date expecting — processPlan will show pre-booking confirm
                        // since date+time are already in plan
                        PendingStateStore::set($cleanPhone, ['kind' => 'calendar', 'expecting' => 'date', 'plan' => $plan]);
                        $result = CalendarQueryHandler::continueBooking($tenant, ['expecting' => 'date', 'plan' => $plan], $plan['date'] ?? 'today', $cleanPhone);
                        self::logQuery($tenant->id, $cleanPhone, $query, null, $result['reply'] ?? '');

                        return array_merge($result, ['tenant' => ['id' => $tenant->id, 'name' => $tenant->name], 'elapsed_ms' => self::elapsed($t0)]);
                    }
                }
                PendingStateStore::clear($cleanPhone);
                Log::info('[TENANT PENDING CONTACT_SELECT] unmatched → cleared');
            }
        }

        // 2b. WhatsApp-only relevance gate. For a registered user we only reply when the
        // message is about their business data / records / scheduling. Personal chatter
        // ("kaise ho", "kal office me kya hua") → stay silent. Placed AFTER pending-state so
        // multi-turn continuations ("6 PM", "2") are never blocked. Fails OPEN on AI error.
        //
        // BUT: check PDF knowledge FIRST — if user is asking about indexed PDFs, answer that
        // regardless of whether it passes the keyword gate.
        if ($waMode && ! $isAudio && ! self::isBusinessRelated($query)) {
            // Before rejecting, check if PDF knowledge can answer this
            $pdfAnswer = PdfKnowledgeService::search($tenant->id, $query, $cleanPhone, $webMode);
            if ($pdfAnswer) {
                self::logQuery($tenant->id, $cleanPhone, $query, null, $pdfAnswer);

                return [
                    'reply' => $pdfAnswer,
                    'intent' => 'PDF_KNOWLEDGE',
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }

            return [
                'reply' => '',
                'intent' => 'IGNORE_OFFTOPIC',
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        if ($intent['intent'] === 'CLARIFY_NEEDED') {
            return [
                'reply' => 'Please share a bit more detail — what would you like to know?',
                'intent' => 'CLARIFY_NEEDED',
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // 3. Query mode — AI Orchestrator decides dynamically what tool to use.
        // Falls back to regex-based detectQueryMode if orchestrator fails.
        $formatInstruction = null;
        $orchestratorDecision = null;
        $originalQuery = $query; // preserve original for disambiguation

        // Fetch once, reused below by both the orchestrator call and aiPlanAndSQL —
        // avoids querying tenant_query_logs twice per request for the same turns.
        $recentTurns = self::fetchRecentTurns($tenant->id, $cleanPhone);

        // Performance: keyword regex already resolves ledger/calendar/chart/images/pivot
        // with high confidence (see detectQueryMode) — for those, skip the orchestrator's
        // OpenAI round-trip entirely (~1-2s saved per message) since those handlers don't
        // use format_instruction/direct_answer/external_api routing anyway. The orchestrator
        // AI call is reserved for the ambiguous default ('data') case, where its judgement
        // between query_database / query_external_api / search_knowledge / direct_answer
        // actually matters.
        $deterministicMode = self::detectQueryMode($query);
        $skipOrchestrator = $deterministicMode !== 'data';

        if (! $skipOrchestrator) {
            try {
                $orchestratorDecision = AiOrchestrator::decide(
                    $tenant->id,
                    $query,
                    $tablesMeta ?? $tenant->tables_metadata ?? [],
                    $recentTurns
                );
            } catch (Throwable $e) {
                Log::warning('[ORCHESTRATOR] failed, falling back to regex: '.$e->getMessage());
            }
        }

        // Map orchestrator decision to existing mode system
        if ($skipOrchestrator) {
            $mode = $deterministicMode;
        } elseif ($orchestratorDecision !== null) {
            $tool = $orchestratorDecision['tool'] ?? '';
            $params = $orchestratorDecision['params'] ?? [];
            $formatInstruction = $orchestratorDecision['format_instruction'] ?? $params['format_instruction'] ?? null;

            // Direct answer (greeting, clarification) — GPT answered without needing data.
            // Guard: if the "direct" answer looks like fabricated tabular/business data
            // (markdown table, or dummy/sample/placeholder wording), it's a hallucination —
            // never trust it; fall through to the real query_database pipeline instead.
            if ($tool === 'direct_answer') {
                $reply = $params['answer'] ?? '';
                if (self::looksLikeFabricatedData($reply)) {
                    Log::warning('[ORCHESTRATOR] direct_answer looked fabricated, forcing data mode: '.substr($reply, 0, 150));
                    $tool = 'query_database';
                } else {
                    self::logQuery($tenant->id, $cleanPhone, $query, null, $reply);

                    return [
                        'reply' => $reply,
                        'intent' => 'AI_DIRECT',
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'elapsed_ms' => self::elapsed($t0),
                    ];
                }
            }

            // External API — delegation, checklist, leads, etc.
            if ($tool === 'query_external_api') {
                $userRole = self::detectUserRole($tenant->id, $cleanPhone);
                $extAnswer = ExternalApiService::query($tenant->id, $userRole, $query, $webMode);
                if ($extAnswer) {
                    self::logQuery($tenant->id, $cleanPhone, $query, null, $extAnswer);

                    return [
                        'reply' => $extAnswer,
                        'intent' => 'EXTERNAL_API',
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'elapsed_ms' => self::elapsed($t0),
                    ];
                }
            }

            // Calendar
            if ($tool === 'manage_calendar') {
                $mode = 'calendar';
            }
            // Ledger — GPT already extracted the clean party name; use it directly instead
            // of handing the full sentence ("What is the closing balance of X?") to the
            // entity-extraction regexes, which don't know how to strip question phrasing.
            elseif ($tool === 'get_ledger') {
                $mode = 'ledger';
                if (! empty($params['party_name'])) {
                    $query = (string) $params['party_name'];
                }
            }
            // Database query — check if chart requested
            elseif ($tool === 'query_database') {
                $chartType = $params['chart_type'] ?? 'none';
                if ($chartType !== 'none') {
                    $mode = 'chart';
                } else {
                    $mode = 'data';
                }
                // Use rephrased query only if it's longer/richer than original (avoids losing multi-table intent)
                if (! empty($params['natural_query']) && strlen($params['natural_query']) >= strlen($query)) {
                    $query = $params['natural_query'];
                }
            }
            // Knowledge base
            elseif ($tool === 'search_knowledge') {
                $pdfAnswer = PdfKnowledgeService::search($tenant->id, $params['search_query'] ?? $query, $cleanPhone, $webMode);
                if ($pdfAnswer) {
                    self::logQuery($tenant->id, $cleanPhone, $query, null, $pdfAnswer);

                    return [
                        'reply' => $pdfAnswer,
                        'intent' => 'PDF_KNOWLEDGE',
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'elapsed_ms' => self::elapsed($t0),
                    ];
                }
                $mode = 'data'; // fallback to SQL if PDF has no answer
            } else {
                $mode = self::detectQueryMode($query);
            }
        } else {
            $mode = self::detectQueryMode($query);
        }

        // Calendar mode dispatches to its own handler. Has its own pre-flight: if the tenant
        // hasn't connected Google Calendar yet, return a friendly OAuth init URL instead of
        // trying to call the API. Same as Node helpers/tenant-router.js calendar branch.
        if ($mode === 'calendar') {
            if (! $tenant->calendar_connected || empty($tenant->calendar_refresh_token)) {
                $baseUrl = rtrim((string) config('mis.public_base_url', 'http://localhost:8000'), '/');
                $authUrl = "{$baseUrl}/api/tenant/calendar/auth?tenant_id={$tenant->id}";

                return [
                    'reply' => "📅 Calendar is not connected yet.\n\n🔗 Connect here: {$authUrl}\n\nOpen the link → sign in with Google → done!",
                    'intent' => 'CALENDAR_NOT_CONNECTED',
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }

            $result = CalendarQueryHandler::handle($tenant, $query, $cleanPhone);
            self::logQuery($tenant->id, $cleanPhone, $query, null, $result['reply'] ?? '');

            return array_merge($result, [
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ]);
        }

        // Ledger mode dispatches to its own handler — entity extraction + fuzzy match + PDF render.
        // No AI SQL pipeline; no retry loop. The handler has its own returns for all branches.
        if ($mode === 'ledger') {
            $tablesMeta = $tenant->tables_metadata ?? [];
            if (! is_array($tablesMeta) || count($tablesMeta) === 0) {
                return [
                    'reply' => '📭 Your data isn\'t synced yet. Please connect your sheet via the onboarding page.',
                    'intent' => 'NO_DATA',
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }

            // Same table-name-ambiguity check the SQL/data pipeline runs (Phase 8) — a term
            // like "balance" can match several tenant tables (opening_balances,
            // balance_summary, ...). Ask which one instead of LedgerQueryHandler silently
            // picking its single highest-scored ledger table. Uses $originalQuery (pre
            // party_name rewrite) since that still carries the ambiguous keyword.
            $ledgerDisambig = self::checkDisambiguationWithPending($cleanPhone, $originalQuery, $tablesMeta);
            if ($ledgerDisambig !== null) {
                return [
                    'reply' => '🤔 '.$ledgerDisambig,
                    'intent' => 'CLARIFY_NEEDED',
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }

            $result = LedgerQueryHandler::handle($tenant, $query, $cleanPhone, ['accessFilter' => self::computeAccessFilter($tenant->id, $cleanPhone)]);
            self::logQuery($tenant->id, $cleanPhone, $query, null, $result['reply'] ?? '');

            return array_merge($result, [
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ]);
        }

        // 4. DATA_QUERY — needs proper-tables sync
        $tablesMeta = $tenant->tables_metadata ?? [];
        if (! is_array($tablesMeta) || count($tablesMeta) === 0) {
            return [
                'reply' => '📭 Your data isn\'t synced yet. Please connect your sheet via the onboarding page.',
                'intent' => 'NO_DATA',
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // 4-access. Tab-level access control (Z43) — filter tables_metadata based on
        // user's role (ALL/TEAM/CLIENT) and compute mandatory WHERE constraints.
        $accessFilter = self::computeAccessFilter($tenant->id, $cleanPhone);
        $noTableAccess = false;
        if ($accessFilter !== null) {
            // Filter tablesMeta to only include permitted tables. Always run this —
            // NOT only `if (!empty($allowedTables))` — because an empty allowed_tables
            // is now a real, meaningful outcome (e.g. a CLIENT phone that matched
            // nothing) and must collapse tablesMeta to empty so the deny check fires.
            $allowedTables = $accessFilter['allowed_tables']; // pg_table names
            $tabs = $tablesMeta['tabs'] ?? $tablesMeta;
            $filtered = [];
            foreach ($tabs as $tab) {
                $pgTable = $tab['pg_table'] ?? '';
                if (in_array($pgTable, $allowedTables, true)) {
                    $filtered[] = $tab;
                }
            }
            if (isset($tablesMeta['tabs'])) {
                $tablesMeta['tabs'] = $filtered;
            } else {
                $tablesMeta = $filtered;
            }
            // No SQL tables accessible — don't give up yet. PDF knowledge base,
            // external APIs, and shared links each enforce their own independent
            // access-level check (all/team/owner), so a restricted client can still
            // get a valid answer from one of those sources. Only deny at the very
            // end if nothing else answers either.
            $tabs = $tablesMeta['tabs'] ?? $tablesMeta;
            $noTableAccess = empty($tabs);
        }
        // $accessFilter['where_constraints'] will be passed to PromptBuilder later
        $mandatoryWheres = $accessFilter['where_constraints'] ?? [];

        // 4-pdf. Check PDF knowledge base BEFORE SQL pipeline — if the query matches
        // indexed PDF content well, answer from there instead of generating SQL.
        // SKIP when: data list query, external API query, OR orchestrator explicitly chose database/ledger/chart
        $isDataListQuery = (bool) preg_match('/\b(first|last|top|bottom|recent|latest)\s+\d+\b|\b\d+\s+(invoice|bill|sale|purchase|receipt|expense|payment|entry|record|row|transaction|order)/i', $query);
        $isExternalApiQuery = ExternalApiService::matches($query);
        $orchestratorChoseData = ($orchestratorDecision !== null && in_array($orchestratorDecision['tool'] ?? '', ['query_database', 'get_ledger', 'manage_calendar']));
        $pdfAnswer = ($isDataListQuery || $isExternalApiQuery || $orchestratorChoseData) ? null : PdfKnowledgeService::search($tenant->id, $query, $cleanPhone, $webMode);
        if ($pdfAnswer) {
            self::logQuery($tenant->id, $cleanPhone, $query, null, $pdfAnswer);

            return [
                'reply' => $pdfAnswer,
                'intent' => 'PDF_KNOWLEDGE',
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // 4b. External API check — query connected external APIs if keywords match
        $userRole = self::detectUserRole($tenant->id, $cleanPhone);
        $extAnswer = ExternalApiService::query($tenant->id, $userRole, $query, $webMode);
        if ($extAnswer) {
            self::logQuery($tenant->id, $cleanPhone, $query, null, $extAnswer);

            return [
                'reply' => $extAnswer,
                'intent' => 'EXTERNAL_API',
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // 4c. Shared links — same role-gated check the 0-row SQL fallback normally
        // uses (Z43). Try it here too so a restricted client with zero SQL access
        // still gets a real answer if the question matches a link they can see.
        if ($noTableAccess) {
            $linkResult = self::searchTenantLinks($tenant->id, $query, $cleanPhone);
            if ($linkResult) {
                self::logQuery($tenant->id, $cleanPhone, $query, null, $linkResult);

                return [
                    'reply' => $linkResult,
                    'intent' => 'LINK_QUERY',
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }

            // No SQL access AND none of the other sources answered — now it's a
            // genuine denial, not just "the SQL table list happened to be empty".
            return [
                'reply' => '🔒 You don\'t have access to any data. Please contact the admin.',
                'intent' => 'ACCESS_DENIED',
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // 4a. Image-mode pre-flight (Z17) — bail out fast with a friendly message if the
        // tenant has no image-URL columns. Skips an AI call when we know the SQL can't
        // possibly return useful image data. The detected $imageCols list is also passed
        // into the AI prompt so it knows which columns to SELECT.
        $imageCols = [];
        if ($mode === 'images') {
            $imageCols = ImageColumnDetector::detectImageColumns($tablesMeta);
            if (count($imageCols) === 0) {
                return [
                    'reply' => "🖼️ No photo/image columns available in this database.\n\nIf your sheet has product image URLs (like image_link or photo_url), please re-sync the sheet — or try a text query (e.g. \"Send the quantity of Foundation Bolt\").",
                    'intent' => 'NO_IMAGE_COLUMNS',
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }
            Log::info('[TENANT IMAGE MODE] detected '.count($imageCols).' image col(s): '.implode(', ', array_map(
                static fn (array $c) => "{$c['pgTable']}.{$c['pgColumn']}",
                $imageCols
            )));
        }

        // Phase 8: Disambiguation check — detect ambiguous terms BEFORE anything else
        // (cache, QueryMemory, MultiStepAgent) can short-circuit with a stale answer.
        // A term like "balance" matching multiple tables must ask every time it's asked —
        // not just the first time — otherwise a cached/logged SQL from an earlier turn
        // silently answers from the wrong (or only one of several) table forever after.
        $disambig = self::checkDisambiguationWithPending($cleanPhone, $originalQuery, $tablesMeta);
        if ($disambig !== null) {
            return [
                'reply' => '🤔 '.$disambig,
                'intent' => 'CLARIFY_NEEDED',
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // 5-7. Multi-step self-healing AI + SQL pipeline (3 attempts)
        // Chat response cache: same phone + tenant + normalized query within 5 min = instant
        // cached response. tenant->id MUST be in the key — one phone can have multiple tenants
        // (SWITCH_DB / UserDatabase.is_default), so phone+query alone would serve a stale
        // answer from the previously-active tenant right after switching databases.
        $chatCacheKey = 'chat:'.md5($cleanPhone.':'.$tenant->id.':'.$mode.':'.mb_strtolower(trim($query)));
        $cachedResult = Cache::get($chatCacheKey);
        if ($cachedResult !== null) {
            Log::info("[TENANT CACHE HIT] {$tenant->name}: ".mb_substr($query, 0, 60));
            $cachedResult['cached'] = true;

            return $cachedResult;
        }

        $knownColumns = SelfHeal::flattenColumnNames($tablesMeta);
        $lastSql = '';
        $lastError = '';
        $rows = null;
        $wasRelaxed = false;
        $fuzzyNote = null;

        // Phase 5 fast-path (promoted ahead of MultiStepAgent): an exact-query high-confidence
        // memory hit means we already know working SQL for this question — reuse it directly and
        // skip BOTH MultiStepAgent's SIMPLE/COMPLEX classify call and the aiPlanAndSQL generation
        // call below (saves up to two full OpenAI round-trips on a warm/repeated query).
        // SKIP memory when user has access filters — cached SQL from other users won't have the mandatory WHERE.
        if (empty($mandatoryWheres)) {
            $memoryHit = QueryMemory::lookup($tenant->id, $query);
            if ($memoryHit && $memoryHit['confidence'] >= 0.7) {
                Log::info('[MEMORY HIT] confidence='.$memoryHit['confidence'].' times_used='.$memoryHit['times_used']);
                $sql = $memoryHit['sql'];
                $lastSql = $sql;
                $valid = self::validateSQL($sql);
                if ($valid['ok']) {
                    try {
                        $rows = DB::select($sql);
                    } catch (Throwable $e) {
                        Log::warning('[MEMORY HIT FAILED] '.substr($e->getMessage(), 0, 200));
                        QueryMemory::invalidate($tenant->id, $query);
                        $lastError = $e->getMessage();
                    }
                }
            }
        }

        // Mirrors Node helpers/tenant-router.js processQueryProperTables flow:
        //   - First try MultiStepAgent for complex queries (cross-table, multi-step logic).
        //   - If SIMPLE, falls through to the single-SQL retry loop below.
        // SKIP MultiStepAgent when user has access filters — it plans + runs its own SQL
        // steps with no knowledge of mandatoryWheres, so a restricted CLIENT/TEAM user could
        // see other people's rows. The single-SQL retry loop below enforces mandatoryWheres
        // on every query it runs, so restricted users always go through that path.
        if ($rows === null && $mode === 'data' && empty($mandatoryWheres)) {
            $multiResult = MultiStepAgent::handle($tenant, $query, $tablesMeta, $webMode);
            if ($multiResult !== null) {
                $multiResult['elapsed_ms'] = self::elapsed($t0);
                self::logQuery($tenant->id, $cleanPhone, $query, null, $multiResult['reply']);
                Cache::put($chatCacheKey, $multiResult, self::CACHE_TTL_SECONDS);

                return $multiResult;
            }
        }

        //   - Each attempt asks the AI for SQL (attempts 2-3 include previous SQL+error so AI can self-correct).
        //   - On SCHEMA_COLUMN error → SelfHeal::resolveColumnError (Levenshtein) tries a cheap rewrite first to skip an AI round-trip.
        //   - PERMISSION / SCHEMA_RELATION → fail fast (not retryable per SelfHeal::classifyError).
        //   - On 0-row success → SelfHeal::relaxSQL emits drop-date / loosen-ILIKE / both variants and we try them in turn.
        //   - SelfHeal::validateResult catches "single row all NULL" aggregates and reroutes them through 0-row recovery.
        for ($attempt = 1; $attempt <= self::MAX_SQL_ATTEMPTS && $rows === null; $attempt++) {
            $retryCtx = $attempt > 1 ? ['sql' => $lastSql, 'error' => $lastError] : null;
            $aiOut = self::aiPlanAndSQL($tenant, $query, $tablesMeta, $retryCtx, $mode, $imageCols, $recentTurns, $mandatoryWheres);

            if (isset($aiOut['clarify'])) {
                return [
                    'reply' => '🤔 '.$aiOut['clarify'],
                    'intent' => 'CLARIFY_NEEDED',
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'attempts' => $attempt,
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }
            if (isset($aiOut['not_relevant'])) {
                return [
                    'reply' => '🤖 That doesn\'t look like a question about your data — try asking about sales, customers, items, or invoices.',
                    'intent' => 'NOT_RELEVANT',
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'attempts' => $attempt,
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }
            if (empty($aiOut['sql'])) {
                $lastError = 'AI returned no SQL';
                Log::warning("[TENANT AI {$attempt}] no SQL produced");
                if ($attempt === 3) {
                    break;
                }

                continue;
            }

            $sql = self::enforceMandatoryWheres($aiOut['sql'], $mandatoryWheres);
            $lastSql = $sql;

            $valid = self::validateSQL($sql);
            if (! $valid['ok']) {
                $lastError = "Validation failed: {$valid['error']}";
                Log::warning('[TENANT VALIDATE] '.$valid['error'].' | '.substr($sql, 0, 150));
                if ($attempt === 3) {
                    self::logQuery($tenant->id, $cleanPhone, $query, $sql, "ERROR: {$lastError}");

                    return [
                        'reply' => "Generated query failed safety check: {$valid['error']}",
                        'intent' => 'UNSAFE_SQL',
                        'sql' => $sql,
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'attempts' => $attempt,
                        'elapsed_ms' => self::elapsed($t0),
                    ];
                }

                continue;
            }

            Log::info("[TENANT SQL {$attempt}] ".substr($sql, 0, 300));

            try {
                $rows = SelfHeal::withRetry(
                    static fn () => DB::select($sql),
                    ['label' => "tenant-query-attempt-{$attempt}", 'maxAttempts' => 2]
                );
                break; // success
            } catch (Throwable $e) {
                $lastError = $e->getMessage();
                $cls = SelfHeal::classifyError($e);
                Log::warning("[TENANT SQL ERROR {$attempt}] [{$cls['kind']}] ".substr($lastError, 0, 200));

                // SCHEMA_COLUMN → try a Levenshtein-based rewrite before paying for an AI re-prompt
                if ($cls['kind'] === 'SCHEMA_COLUMN') {
                    $fix = SelfHeal::resolveColumnError($lastError, $sql, $knownColumns);
                    if ($fix !== null) {
                        Log::info("[TENANT COL-FIX] '{$fix['badCol']}' → '{$fix['goodCol']}' (score=".number_format($fix['score'], 2).')');
                        try {
                            $rows = DB::select($fix['rewrittenSQL']);
                            $lastSql = $fix['rewrittenSQL'];
                            break; // try/catch isn't a loop level — this exits the for loop
                        } catch (Throwable $e2) {
                            Log::warning('[TENANT COL-FIX FAILED] '.substr($e2->getMessage(), 0, 200));
                            $lastError = $e2->getMessage();
                            // fall through to AI re-prompt
                        }
                    }
                }

                // Terminal errors — no point retrying
                if (in_array($cls['kind'], ['PERMISSION', 'SCHEMA_RELATION'], true)) {
                    self::logQuery($tenant->id, $cleanPhone, $query, $sql, "ERROR: {$cls['friendly']}");

                    return [
                        'reply' => '⚠️ '.$cls['friendly'],
                        'intent' => 'SQL_FATAL',
                        'sql' => $sql,
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'attempts' => $attempt,
                        'elapsed_ms' => self::elapsed($t0),
                    ];
                }

                if ($attempt === 3) {
                    self::logQuery($tenant->id, $cleanPhone, $query, $sql, "ERROR after 3 attempts: {$lastError}");

                    return [
                        'reply' => '❌ Could not run the query after 3 attempts. Please try with simpler or clearer words — e.g. "What is the total sales for April?"',
                        'intent' => 'SQL_ERROR',
                        'sql' => $sql,
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'attempts' => $attempt,
                        'elapsed_ms' => self::elapsed($t0),
                    ];
                }
            }
        }

        if ($rows === null) {
            self::logQuery($tenant->id, $cleanPhone, $query, $lastSql, "ERROR: rows null after retry loop ({$lastError})");

            return [
                'reply' => '❌ Something went wrong. Please try again or rephrase the question.',
                'intent' => 'SQL_ERROR',
                'sql' => $lastSql,
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // Phase 3: Result Validation — silently retry with alternative if result looks wrong
        if ($rows !== null && count($rows) > 0) {
            $validation = ResultValidator::validate($rows, $query, $lastSql, $tablesMeta);
            if (! $validation['valid'] && $validation['issue']) {
                $altSql = ResultValidator::retryWithAlternative($lastSql, $tablesMeta, $validation['issue']);
                if ($altSql) {
                    try {
                        $altRows = DB::select($altSql);
                        if (count($altRows) > 0) {
                            $rows = $altRows;
                            $lastSql = $altSql;
                            Log::info("[RESULT VALIDATOR] Rewrote SQL for issue={$validation['issue']}");
                        }
                    } catch (Throwable $e) {
                        Log::warning('[RESULT VALIDATOR] Alternative SQL failed: '.substr($e->getMessage(), 0, 150));
                    }
                }
            }
        }

        // Phase 10.4 — single-row all-NULL aggregate is a "false success".
        // Reroute through the same 0-row recovery (relaxSQL).
        if (count($rows) === 1) {
            $first = is_object($rows[0]) ? get_object_vars($rows[0]) : (array) $rows[0];
            $allNull = count($first) > 0;
            foreach ($first as $v) {
                if ($v !== null) {
                    $allNull = false;
                    break;
                }
            }
            if ($allNull) {
                Log::info('[TENANT VALIDATE] single-row all-NULL aggregate → rerouting to relax');
                $rows = [];
            }
        }

        // 0 rows → first try fuzzy entity-name fallback (cheap, single RPC call).
        // Exactly one candidate → just re-run with that name, no confirmation needed
        // (same "closest match, act directly" behaviour as the ledger flow).
        // 2+ candidates → genuinely ambiguous, ask which one.
        if (count($rows) === 0) {
            $fuzzy = FuzzyFallback::search($lastSql, $tablesMeta, $mandatoryWheres);
            if ($fuzzy !== null && count($fuzzy['matches']) === 1) {
                $closest = $fuzzy['matches'][0];
                $retrySql = str_replace(
                    "%{$fuzzy['searchTerm']}%",
                    '%'.$closest.'%',
                    $lastSql
                );
                try {
                    $candidate = DB::select($retrySql);
                    if (count($candidate) > 0) {
                        $rows = $candidate;
                        $lastSql = $retrySql;
                        $fuzzyNote = "_(Couldn't find an exact match for \"{$fuzzy['searchTerm']}\" — using the closest one: {$closest})_";
                    }
                } catch (Throwable $e) {
                    Log::warning('[TENANT FUZZY AUTO] retry with "'.$closest.'" failed: '.substr($e->getMessage(), 0, 150));
                }
            } elseif ($fuzzy !== null && count($fuzzy['matches']) > 1) {
                $list = '';
                foreach ($fuzzy['matches'] as $i => $name) {
                    $list .= ($i + 1).'. '.$name."\n";
                }
                $reply = "📭 No exact match for \"{$fuzzy['searchTerm']}\". Did you mean one of these?\n\n".rtrim($list)."\n\nAsk about any of them — or try the correct spelling.";
                self::logQuery($tenant->id, $cleanPhone, $query, $lastSql, $reply);

                return [
                    'reply' => $reply,
                    'intent' => 'FUZZY_SUGGESTIONS',
                    'sql' => $lastSql,
                    'suggestions' => $fuzzy['matches'],
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }
        }

        // 0 rows → try SelfHeal::relaxSQL variants (drop date / loosen ILIKE / both)
        if (count($rows) === 0) {
            $variants = SelfHeal::relaxSQL($lastSql);
            foreach ($variants as $i => $variant) {
                try {
                    Log::info('[TENANT RELAX '.($i + 1).'/'.count($variants).'] '.substr($variant, 0, 200));
                    $candidate = DB::select($variant);
                    if (count($candidate) > 0) {
                        $rows = $candidate;
                        $lastSql = $variant;
                        $wasRelaxed = true;
                        Log::info('[TENANT RELAX] succeeded with '.count($candidate).' rows');
                        break;
                    }
                } catch (Throwable $e) {
                    // best-effort, skip failed variants
                }
            }

            if (count($rows) === 0) {
                // Check tenant_links before giving up
                $linkResult = self::searchTenantLinks($tenant->id, $query, $cleanPhone);
                if ($linkResult) {
                    self::logQuery($tenant->id, $cleanPhone, $query, null, $linkResult);

                    return [
                        'reply' => $linkResult,
                        'intent' => 'LINK_QUERY',
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'elapsed_ms' => self::elapsed($t0),
                    ];
                }

                // Try PDF knowledge base search
                $pdfAnswer = PdfKnowledgeService::search($tenant->id, $query, $cleanPhone, $webMode);
                if ($pdfAnswer) {
                    self::logQuery($tenant->id, $cleanPhone, $query, null, $pdfAnswer);

                    return [
                        'reply' => $pdfAnswer,
                        'intent' => 'PDF_KNOWLEDGE',
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'elapsed_ms' => self::elapsed($t0),
                    ];
                }

                $reply = '📊 0 records match your criteria. Try broadening the filter — remove the date range or use a less specific name.';
                self::logQuery($tenant->id, $cleanPhone, $query, $lastSql, $reply);

                return [
                    'reply' => $reply,
                    'intent' => 'NO_DATA',
                    'sql' => $lastSql,
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }
        }

        // Informational result-shape validation (logs only — final reply unchanged)
        $validation = SelfHeal::validateResult($rows, $query);
        if (! $validation['ok'] && $validation['hint']) {
            Log::info('[TENANT VALIDATE] '.$validation['hint']);
        }

        $tableColumns = self::columnsForSql($lastSql, $tablesMeta);

        // 8a. Image mode (Z17) — extract image-URL + caption pairs from rows and ship as
        // a {type:'images', items:[...]} media payload. WebhookController::dispatchMedia
        // (Z15) loops items at 700ms throttle and sends each via Client::sendImageByUrl.
        if ($mode === 'images') {
            $items = ImageColumnDetector::extractImageItems($rows, 20);
            if (count($items) === 0) {
                $reply = "📭 No photos found for \"{$query}\". Please check the spelling or try a simpler filter.";
                self::logQuery($tenant->id, $cleanPhone, $query, $lastSql, $reply);

                return [
                    'reply' => $reply,
                    'intent' => 'NO_IMAGES_FOUND',
                    'sql' => $lastSql,
                    'rows' => count($rows),
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            }

            $totalText = count($items) < count($rows) ? ' (top '.count($items).' of '.count($rows).')' : '';
            $reply = '📸 Sending *'.count($items).' photo'.(count($items) === 1 ? '' : 's')."*{$totalText}...";
            Log::info('[TENANT IMAGE MODE] dispatching '.count($items).' items');
            self::logQuery($tenant->id, $cleanPhone, $query, $lastSql, $reply);

            return [
                'reply' => $reply,
                'intent' => 'IMAGE_QUERY',
                'sql' => $lastSql,
                'rows' => count($rows),
                'media' => [
                    'type' => 'images',
                    'items' => $items,
                ],
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'elapsed_ms' => self::elapsed($t0),
            ];
        }

        // 8b. Chart mode (Z16) — render via QuickChart and return as image media payload.
        // The AI prompt forced 2-column aggregating SQL. We need >= 2 rows for a chart to be
        // meaningful (a 1-row chart is just a single bar — text reply is more useful).
        // On any chart-rendering failure (network, bad SQL shape, etc.) fall through to the
        // text formatter so the user still gets the data.
        if ($mode === 'chart' && count($rows) >= 2) {
            try {
                $rowsAssoc = array_map(
                    static fn ($r) => is_object($r) ? get_object_vars($r) : (array) $r,
                    $rows
                );
                $chart = ChartQueryHandler::generate($rowsAssoc, $query, $tableColumns, [
                    'dbName' => $tenant->name,
                ]);
                Log::info("[TENANT CHART] type={$chart['type']} label={$chart['labelCol']} value={$chart['valueCol']} → {$chart['path']}");

                $reply = "📊 *{$chart['title']}*\nSending ".count($rows)." {$chart['type']} chart...";
                self::logQuery($tenant->id, $cleanPhone, $query, $lastSql, $reply);

                return [
                    'reply' => $reply,
                    'intent' => 'CHART_QUERY',
                    'sql' => $lastSql,
                    'rows' => count($rows),
                    'media' => [
                        'type' => 'image',
                        'path' => $chart['path'],
                        'caption' => "📊 {$chart['title']}",
                    ],
                    'chart' => [
                        'type' => $chart['type'],
                        'label_col' => $chart['labelCol'],
                        'value_col' => $chart['valueCol'],
                    ],
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            } catch (Throwable $e) {
                Log::warning('[TENANT CHART ERROR] '.$e->getMessage().' → falling through to text formatter');
                // intentional fall-through
            }
        }

        // 8b-pivot. Pivot mode (Z26) — render rows as a 2D cross-tab with row/col/grand
        // totals. Small grids (cells <= 80) ship as a markdown-aligned text table; larger
        // grids ship as CSV via TenantCsvBuilder. The PIVOTNOTE block in PromptBuilder
        // steered the AI toward 3-column SQL. On any handler exception OR shape mismatch
        // (handler returns null), fall through to the regular text formatter so the user
        // still gets the data.
        if ($mode === 'pivot') {
            try {
                $pivotResult = PivotQueryHandler::buildResult(
                    rows: $rows,
                    query: $query,
                    tableColumns: $tableColumns,
                    sql: $lastSql,
                    opts: ['dbName' => (string) ($tenant->name ?? 'Database')]
                );
                if ($pivotResult !== null) {
                    if ($wasRelaxed) {
                        $pivotResult['reply'] = "ℹ️ _(Showing relaxed-filter results — your exact filters returned 0 rows.)_\n\n".$pivotResult['reply'];
                    }
                    Log::info('[TENANT PIVOT] '.json_encode($pivotResult['pivot'] ?? []));
                    self::logQuery($tenant->id, $cleanPhone, $query, $lastSql, $pivotResult['reply']);

                    return array_merge($pivotResult, [
                        'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                        'elapsed_ms' => self::elapsed($t0),
                    ]);
                }
                Log::info('[TENANT PIVOT] handler returned null (shape mismatch) → falling through');
            } catch (Throwable $e) {
                Log::warning('[TENANT PIVOT ERROR] '.$e->getMessage().' → falling through to text formatter');
                // intentional fall-through
            }
        }

        // 8c-pre. Auto-export when result is large (Z24).
        //   >100 rows → CSV (Excel-friendly, all cols, raw numeric)
        //   >50 rows  → PDF (styled, top 10 cols, formatted ₹/Cr)
        // Either path returns a {reply, media:{type:document, path}} payload that
        // WebhookController::dispatchMedia (Z15) ships to WhatsApp via Client::sendDocument.
        // Falls through to text formatter on any builder exception.
        if (count($rows) > self::CSV_THRESHOLD) {
            try {
                // Best-effort: derive a friendly title from the queried table name
                $sourceTable = self::sourceTableForSql($lastSql, $tablesMeta);
                $title = $sourceTable !== null
                    ? (string) ($sourceTable['source_name'] ?? $sourceTable['pg_table'] ?? 'Query Results')
                    : 'Query Results';
                $dbName = (string) ($tenant->name ?? 'Database');

                $csvPath = TenantCsvBuilder::render($rows, $tableColumns, ['title' => $title, 'dbName' => $dbName]);
                $reply = TenantCsvBuilder::buildSummary($rows, $tableColumns)
                    ?? '📊 Sending CSV with *'.count($rows).' rows*...';
                if ($wasRelaxed) {
                    $reply = "ℹ️ _(Showing relaxed-filter results — your exact filters returned 0 rows.)_\n\n".$reply;
                }
                Log::info("[TENANT CSV] {$dbName} \"{$title}\": ".count($rows)." rows → {$csvPath}");
                self::logQuery($tenant->id, $cleanPhone, $query, $lastSql, $reply);

                return [
                    'reply' => $reply,
                    'intent' => 'DATA_QUERY',
                    'sql' => $lastSql,
                    'rows' => count($rows),
                    'relaxed' => $wasRelaxed,
                    'media' => [
                        'type' => 'document',
                        'path' => $csvPath,
                        'filename' => basename($csvPath),
                        'caption' => "📊 {$title}",
                    ],
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            } catch (Throwable $e) {
                Log::warning('[TENANT CSV ERROR] '.$e->getMessage().' → falling through to PDF/text');
                // intentional fall-through
            }
        }

        if (count($rows) > self::PDF_THRESHOLD) {
            try {
                $sourceTable = self::sourceTableForSql($lastSql, $tablesMeta);
                $title = $sourceTable !== null
                    ? (string) ($sourceTable['source_name'] ?? $sourceTable['pg_table'] ?? 'Query Results')
                    : 'Query Results';
                $dbName = (string) ($tenant->name ?? 'Database');

                $pdfPath = TenantPdfBuilder::render($rows, $tableColumns, [
                    'title' => $title,
                    'query' => $query,
                    'dbName' => $dbName,
                ]);
                $reply = TenantPdfBuilder::buildSummary($rows, $tableColumns)
                    ?? '📄 Sending PDF with *'.count($rows).' results*...';
                if ($wasRelaxed) {
                    $reply = "ℹ️ _(Showing relaxed-filter results — your exact filters returned 0 rows.)_\n\n".$reply;
                }
                Log::info("[TENANT PDF] {$dbName} \"{$title}\": ".count($rows)." rows → {$pdfPath}");
                self::logQuery($tenant->id, $cleanPhone, $query, $lastSql, $reply);

                return [
                    'reply' => $reply,
                    'intent' => 'DATA_QUERY',
                    'sql' => $lastSql,
                    'rows' => count($rows),
                    'relaxed' => $wasRelaxed,
                    'media' => [
                        'type' => 'document',
                        'path' => $pdfPath,
                        'filename' => basename($pdfPath),
                        'caption' => "📄 {$title}",
                    ],
                    'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                    'elapsed_ms' => self::elapsed($t0),
                ];
            } catch (Throwable $e) {
                Log::warning('[TENANT PDF ERROR] '.$e->getMessage().' → falling through to text');
                // intentional fall-through
            }
        }

        // 8c. Default: format result — use AI Orchestrator's format instruction if available
        $reply = null;
        $tenantFormatInst = TenantPrompt::getFormatInstruction($tenant->id, $webMode);
        if ($formatInstruction) {
            // Merge tenant's custom data_format with orchestrator's format_instruction
            $mergedFormat = $formatInstruction;
            if ($tenantFormatInst) {
                $mergedFormat = $tenantFormatInst."\n\nAdditional hint: {$formatInstruction}";
            }
            $reply = AiOrchestrator::formatResponse($tenant->id, $query, $rows, $mergedFormat, $webMode);
        }
        if ($reply === null && count($rows) > self::INLINE_FORMAT_ROWS) {
            $reply = SmartFormatter::aiPrettyFormat($query, $rows, $tableColumns, $tenant->id, $webMode);
        }
        if ($reply === null) {
            $reply = SmartFormatter::formatResults($query, $rows, $tableColumns);
            if ($reply === null) {
                $reply = SmartFormatter::aiFormat($query, $rows, $tableColumns);
            }
        }
        if ($reply === '' || $reply === null) {
            $reply = '📭 No matching data found for that query.';
        }
        if ($wasRelaxed) {
            $reply = "ℹ️ _(Showing relaxed-filter results — your exact filters returned 0 rows.)_\n\n".$reply;
        }
        if ($fuzzyNote !== null) {
            $reply = $fuzzyNote."\n\n".$reply;
        }

        self::logQuery($tenant->id, $cleanPhone, $query, $lastSql, $reply);

        $result = [
            'reply' => $reply,
            'intent' => 'DATA_QUERY',
            'sql' => $lastSql,
            'rows' => count($rows),
            'raw_rows' => $rows,
            'relaxed' => $wasRelaxed,
            'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
            'elapsed_ms' => self::elapsed($t0),
        ];

        // Cache successful data query response for 5 minutes
        Cache::put($chatCacheKey, $result, self::CACHE_TTL_SECONDS);

        // Phase 5: Save successful query→SQL mapping to memory
        if (count($rows) > 0 && $lastSql !== '') {
            QueryMemory::save($tenant->id, $query, $lastSql, mb_substr($reply, 0, 200));
        }

        return $result;
    }

    // ════════════════════════════════════════════════════════════════════
    // INTENT + MODE DETECTION
    // ════════════════════════════════════════════════════════════════════

    /** @return array{intent: string, greeting_reply?: string, choice?: int} */
    public static function detectIntent(string $query): array
    {
        $q = strtolower(trim($query));

        if (preg_match('/^(hi+|hello|hey|hii+|namaste|namaskar|good\s*(morning|evening|night|afternoon)|shubh\s*(prabhat|sandhya))[\s?!.]*$/', $q)) {
            return ['intent' => 'GREETING', 'greeting_reply' => '🙏 Hello! I am your data assistant. Ask me anything about your data!'];
        }
        if (preg_match('/^(thanks|thank\s*you|dhanyavaad|shukriya|bye|alvida|ok\s*bye|tata)[\s?!.]*$/', $q)) {
            return ['intent' => 'GREETING', 'greeting_reply' => '🙏 You are welcome — ask anytime. Happy to help!'];
        }
        if (preg_match('/^(kaise\s*h[oa]|how\s*are\s*you|khana\s*khay?a|kya\s*h(al|aal)|what(\'?s)?\s*up|sup|hmm+|accha|theek|sahi)[\s?!.]*$/', $q)) {
            return ['intent' => 'IGNORE'];
        }
        if (mb_strlen($q) < 3 && ! preg_match('/^\d+$/', $q)) {
            return ['intent' => 'CLARIFY_NEEDED'];
        }
        if (preg_match('/^[1-9]$/', $q)) {
            return ['intent' => 'DB_SELECT', 'choice' => (int) $q];
        }
        if (preg_match('/^(switch|change|badlo|dusra)\s*(db|database|sheet)?/', $q)) {
            return ['intent' => 'SWITCH_DB'];
        }

        return ['intent' => 'DATA_QUERY'];
    }

    /**
     * WhatsApp relevance gate — true if the message is a request about the tenant's
     * business data (sales, purchases, inventory/stock, accounts, ledger/khata,
     * outstanding/payments, reports) OR scheduling (calendar/meetings/reminders).
     * False for greetings, small talk and personal chatter.
     *
     * Fails OPEN (returns true) when the key is missing or the API errors, so a real
     * data question is never silently dropped during an outage.
     */
    private static function isBusinessRelated(string $query): bool
    {
        $q = mb_strtolower(trim($query));

        // Numeric replies for multi-turn selections (e.g. "2", "5")
        if (preg_match('/^\d{1,3}$/', $q)) {
            return true;
        }

        // Domain-specific keywords — MUST match at least one of these
        // These are words that ONLY appear in business data contexts
        $domainKeywords = [
            'sale', 'sales', 'purchase', 'expense', 'invoice', 'bill', 'stock', 'inventory',
            'ledger', 'khata', 'khaata', 'bahi', 'outstanding', 'payment', 'receipt', 'pending',
            'customer', 'party', 'supplier', 'vendor', 'amount', 'total', 'profit', 'loss',
            'revenue', 'report', 'chart', 'graph', 'pivot', 'export', 'pdf', 'csv',
            'meeting', 'calendar', 'book', 'schedule', 'reminder', 'cancel',
            'sync', 'database', 'switch', 'balance',
            'gst', 'tax', 'cgst', 'sgst', 'igst', 'hsn',
            'qty', 'quantity', 'rate', 'price', 'discount',
            'crore', 'lakh', 'rupee',
            'kitni', 'kitna', 'kitne', 'dikhao', 'btao', 'batao', 'bhejo',
        ];

        foreach ($domainKeywords as $kw) {
            if (str_contains($q, $kw)) {
                return true;
            }
        }

        // Dynamic: also pass if query matches external API keywords
        if (ExternalApiService::matches($query)) {
            return true;
        }

        return false;
    }

    /**
     * Run the table-name-ambiguity check and, when it fires, persist a pending
     * disambiguation state (kind='disambiguation') so the user's next reply — a
     * table name, or "both"/"all" — resolves to a real query against the actual
     * candidate table(s) instead of the AI/ledger pipeline re-guessing from scratch
     * with no memory of what was being disambiguated (see Z20 pending-state block).
     * Falls back to the plain amount/date ambiguity check (no pending state — those
     * aren't "pick a table" questions) when no table ambiguity is found.
     */
    private static function checkDisambiguationWithPending(string $cleanPhone, string $query, array $tablesMeta): ?string
    {
        $tabs = $tablesMeta['tabs'] ?? $tablesMeta;
        $ambig = DisambiguationService::checkTables($query, $tabs);
        if ($ambig !== null) {
            $candidates = array_map(static fn (array $t) => [
                'pg_table' => (string) ($t['pg_table'] ?? ''),
                'source_name' => (string) ($t['source_name'] ?? ($t['pg_table'] ?? '')),
                'columns' => $t['columns'] ?? [],
            ], $ambig['tables']);

            PendingStateStore::set($cleanPhone, [
                'kind' => 'disambiguation',
                'term' => $ambig['term'],
                'tables' => $candidates,
                'query' => $query,
            ]);

            $opts = implode(', ', array_map(static fn (array $t) => $t['source_name'], $candidates));

            return "'{$ambig['term']}' multiple tables me hai: {$opts} — kaunsi table se data chahiye? (ya \"both\" bolo dono se)";
        }

        return DisambiguationService::check($query, $tablesMeta);
    }

    /**
     * Heuristic guard against AiOrchestrator's direct_answer hallucinating a fake
     * data table instead of calling query_database. Catches markdown tables and
     * common "this is example/sample data" hedging language a model uses when it
     * invents rows rather than admitting it doesn't have real data.
     */
    private static function looksLikeFabricatedData(string $reply): bool
    {
        if ($reply === '') {
            return false;
        }

        // Markdown table: header row + a separator row of dashes/pipes.
        if (preg_match('/\|.+\|[\r\n]+\s*\|?[\s:|-]{3,}\|/', $reply)) {
            return true;
        }

        // >= 3 pipe-delimited lines also reads as a fabricated table.
        if (preg_match_all('/^\s*\|.*\|\s*$/m', $reply) >= 3) {
            return true;
        }

        if (preg_match('/\b(dummy|sample|placeholder|example)\s+(data|dataset|finance|table|record)/i', $reply)) {
            return true;
        }

        return false;
    }

    /** Classify a query into a mode. Only 'data' is fully implemented. */
    public static function detectQueryMode(string $query): string
    {
        $q = strtolower($query);

        if (preg_match('/chart|graph|visual|trend\s*chart|bar\s*chart|pie\s*chart|line\s*chart|doughnut/', $q)) {
            return 'chart';
        }

        if (preg_match('/(send|bhej|dikhao|share|de\s*do|do\s+do).*(image|photo|tasveer|pic|tasvir)/', $q)
            || preg_match('/(image|photo|tasveer|pic|tasvir).*(send|bhej|dikhao|share|de\s*do)/', $q)
            || preg_match('/(ka|ki|ke)\s+(photo|image|tasveer|pic|tasvir)\b/', $q)) {
            return 'images';
        }

        if (preg_match('/pivot/', $q)) {
            return 'pivot';
        }

        if (preg_match('/ledger|khata|khaata|khaat[ae]|bahi/', $q)) {
            // A single ledger PDF is for ONE named party. Route to the SQL data pipeline
            // (a multi-row report) when the query is:
            //   • an aggregation (total/sum/count/compare/vs/avg/max/min), OR
            //   • a list / "all" / pending / outstanding style ask — e.g.
            //     "provide all pending ledger", "sabhi ledgers", "outstanding ledger list".
            //   These have no single party name, so ledger-entity extraction would wrongly
            //   treat the command words ("provide all pending") as an account name.
            if (preg_match('/\b(total|sum|count|kitna|kitne|kitni|compare|vs|average|maximum|minimum|highest|lowest)\b/', $q)
                || preg_match('/\b(all|sab|sabhi|saare|saari|sare|pending|outstanding|overdue|unpaid|due|list|everyone|har|sabka|sabki)\b/', $q)) {
                return 'data';
            }

            return 'ledger';
        }

        if (preg_match('/\b(meet\w*|book\w*|schedul\w*|calendar|appoint\w*|reminder)\b/', $q)
            || preg_match('/\b(buk|bukk|meeing|meeking|meting|booka|bookd|booed)\b/', $q)
            || preg_match('/\bcancel\b.*\bmeet/', $q)
            || preg_match('/^\s*(cancel|delete|hatao|remove)\b/', $q)
            || preg_match('/aaj\s*ki\s*meet|kal\s*ki\s*meet|aaj\s*ki\s*meeting|kal\s*ki\s*meeting/', $q)) {
            return 'calendar';
        }

        return 'data';
    }

    // ════════════════════════════════════════════════════════════════════
    // AI SQL GENERATION
    // ════════════════════════════════════════════════════════════════════

    /**
     * Single-call AI: PLAN + SQL together.
     *
     * @param  list<array<string, mixed>>  $tablesMetadata
     * @param  array{sql: string, error: string}|null  $retryContext  pass on attempts >= 2 to show AI its previous failed SQL + error
     * @param  string  $mode  'data' (default), 'chart', or 'images' — drives PromptBuilder mode-specific instructions
     * @param  list<array{pgTable:string, pgColumn:string}>  $imageCols  detected image-URL columns (only used when $mode='images')
     * @return array{sql?: string, clarify?: string, not_relevant?: bool}
     */
    public static function aiPlanAndSQL(
        Tenant $tenant,
        string $query,
        array $tablesMetadata,
        ?array $retryContext = null,
        string $mode = 'data',
        array $imageCols = [],
        array $history = [],
        array $mandatoryWheres = []
    ): array {
        $apiKey = (string) config('mis.openai_api_key', '');
        if ($apiKey === '' && empty(config('mis.openai_api_keys', []))) {
            // Check if tenant has own key via AiGateway
            $testResolve = AiGateway::chat($tenant->id, [['role' => 'user', 'content' => '']], ['max_tokens' => 1, 'timeout' => 10]);
            if (! $testResolve['ok'] && str_contains($testResolve['error'] ?? '', 'AI not configured')) {
                return ['clarify' => $testResolve['error']];
            }
        }

        $messages = PromptBuilder::buildSqlMessages($tenant, $query, $tablesMetadata, $mode, $imageCols, $mandatoryWheres);

        // NOTE (token optimization): we intentionally do NOT inject SchemaIntelligence's
        // "COLUMN DICTIONARY" here. buildSqlMessages() already embeds the full schema
        // (every table, column, type, role, original header and sample values) via
        // PromptBuilder::buildSchemaBlock(). Injecting the dictionary again duplicated
        // that same information on every SQL attempt (and every retry), burning tokens
        // with zero added grounding. The schema block is the single source of truth.

        // Phase 5: Learned Patterns — inject recent successful query→SQL pairs
        $recentMemory = QueryMemory::getRecentSuccessful($tenant->id, 5);
        if (! empty($recentMemory)) {
            $examples = array_map(fn ($r) => "{$r->query_text} → {$r->sql_used}", $recentMemory);
            $memMsg = "Here are examples of queries that worked successfully for this database:\n".implode("\n", $examples);
            array_splice($messages, 1, 0, [['role' => 'system', 'content' => $memMsg]]);
        }

        // Conversation memory — insert recent turns as a reference-ONLY context block right before
        // the current question, so the AI can resolve "their / those / last month too / same".
        if (! empty($history)) {
            $lines = [];
            foreach ($history as $h) {
                $c = trim((string) ($h['content'] ?? ''));
                if ($c === '') {
                    continue;
                }
                $who = ($h['role'] ?? '') === 'assistant' ? 'Assistant' : 'User';
                $lines[] = $who.': '.mb_substr($c, 0, 400);
            }
            if ($lines) {
                $ctx = "Recent conversation (use ONLY to resolve references such as \"their\", \"those\", \"last month too\", \"same\" — then answer the CURRENT question):\n".implode("\n", $lines);
                array_splice($messages, max(1, count($messages) - 1), 0, [['role' => 'user', 'content' => $ctx]]);
            }
        }

        // On retries, append the previous attempt + error so the AI can self-correct.
        // Mirrors Node helpers/tenant-router.js aiPlanAndSQL retry-context contract.
        if ($retryContext !== null) {
            $prevSql = trim((string) ($retryContext['sql'] ?? ''));
            $prevErr = trim((string) ($retryContext['error'] ?? ''));
            if ($prevSql !== '' || $prevErr !== '') {
                if ($prevSql !== '') {
                    $messages[] = ['role' => 'assistant', 'content' => $prevSql];
                }
                $messages[] = [
                    'role' => 'user',
                    'content' => "Your previous SQL failed with this error:\n```\n".substr($prevErr, 0, 500)."\n```\nPlease fix the issue and return ONLY the corrected SQL — same rules apply (single SELECT, no DDL/DML, no comments).",
                ];
            }
        }

        try {
            $aiResult = AiGateway::chat($tenant->id, $messages, [
                'temperature' => 0,
                'max_tokens' => 800,
                'timeout' => 15,
            ]);
        } catch (Throwable $e) {
            Log::warning('TenantRouter aiPlanAndSQL HTTP failed', ['error' => $e->getMessage()]);

            return ['clarify' => 'AI is temporarily unavailable. Please try again in a moment.'];
        }

        if (! $aiResult['ok']) {
            return ['clarify' => $aiResult['error'] ?? 'AI returned an error. Please try again.'];
        }

        $raw = trim($aiResult['content']);
        $raw = (string) preg_replace('/```sql?\s*/', '', $raw);
        $raw = str_replace('```', '', $raw);
        $raw = rtrim($raw, "; \t\n");

        if (preg_match('/^CLARIFY:\s*(.+)$/i', $raw, $m)) {
            return ['clarify' => trim($m[1])];
        }
        if (stripos($raw, 'NOT_RELEVANT') === 0) {
            return ['not_relevant' => true];
        }

        // Phase 7: Parse confidence prefix (HIGH/MEDIUM/LOW)
        $confidence = 'MEDIUM'; // default if GPT doesn't include prefix
        if (preg_match('/^(HIGH|MEDIUM|LOW):\s*(.+)$/is', $raw, $cm)) {
            $confidence = strtoupper($cm[1]);
            $raw = trim($cm[2]);
        }

        // Fallback: if raw still doesn't start with SELECT, extract it
        if (! preg_match('/^\s*SELECT/i', $raw) && preg_match('/(SELECT\s.+)/is', $raw, $selMatch)) {
            $raw = trim($selMatch[1]);
        }

        if ($confidence === 'LOW') {
            return ['clarify' => 'I\'m not confident about this query. Could you please clarify what exactly you want? Specify the column names, date range, or filters more clearly.'];
        }

        return ['sql' => $raw, 'confidence' => $confidence];
    }

    /**
     * Z43 — Server-side enforcement of access-control WHERE constraints.
     *
     * PromptBuilder tells the AI it MUST include these WHERE clauses, but an LLM can
     * still drop them (bad prompt-following, a retry re-write, etc.). Since that would
     * leak other clients'/team members' rows, we don't just trust the prompt — we check
     * the AI's SQL here and inject any missing constraint for a table it actually queries.
     *
     * @param  array<string, string>  $mandatoryWheres  pg_table => raw WHERE fragment (from computeAccessFilter)
     */
    public static function enforceMandatoryWheres(string $sql, array $mandatoryWheres): string
    {
        if ($sql === '' || empty($mandatoryWheres)) {
            return $sql;
        }

        foreach ($mandatoryWheres as $pgTable => $where) {
            if ($pgTable === '' || $where === '') {
                continue;
            }

            // Only touch tables the query actually references (FROM/JOIN `table`).
            $refPattern = '/\b(?:FROM|JOIN)\s+`?'.preg_quote($pgTable, '/').'`?/i';
            if (! preg_match($refPattern, $sql)) {
                continue;
            }

            // Already present (AI followed instructions)? Compare loosely — collapse
            // whitespace/backticks so trivial formatting differences don't cause a
            // duplicate condition to be appended.
            $normalizedSql = strtolower(preg_replace('/[`\s]+/', '', $sql) ?? $sql);
            $normalizedWhere = strtolower(preg_replace('/[`\s]+/', '', $where) ?? $where);
            if ($normalizedWhere !== '' && str_contains($normalizedSql, $normalizedWhere)) {
                continue;
            }

            $sql = self::injectWhereClause($sql, $where);
        }

        return $sql;
    }

    /**
     * Inject `AND (where)` into an existing WHERE clause, or add a new `WHERE (where)`
     * right before GROUP BY / ORDER BY / LIMIT / HAVING if there's no WHERE yet.
     */
    private static function injectWhereClause(string $sql, string $where): string
    {
        if (preg_match('/\bWHERE\b/i', $sql)) {
            // Insert immediately after the first WHERE keyword so it applies to the
            // base query rather than a later subquery's WHERE.
            return (string) preg_replace('/\bWHERE\b/i', 'WHERE ('.$where.') AND', $sql, 1);
        }

        // No WHERE yet — insert before the first GROUP BY / ORDER BY / LIMIT / HAVING,
        // or at the end if none of those clauses are present.
        if (preg_match('/\b(GROUP\s+BY|ORDER\s+BY|LIMIT|HAVING)\b/i', $sql, $m, PREG_OFFSET_CAPTURE)) {
            $pos = $m[0][1];

            return substr($sql, 0, $pos)." WHERE ({$where}) ".substr($sql, $pos);
        }

        return rtrim($sql)." WHERE ({$where})";
    }

    /**
     * SQL safety check: must be SELECT, single statement, no DDL/DML.
     *
     * @return array{ok: bool, error?: string}
     */
    public static function validateSQL(string $sql): array
    {
        $trimmed = trim($sql);
        if ($trimmed === '') {
            return ['ok' => false, 'error' => 'Empty SQL'];
        }
        if (! preg_match('/^\s*SELECT\b/i', $trimmed)) {
            return ['ok' => false, 'error' => 'Not a SELECT statement'];
        }
        if (preg_match('/;.*\S/', $trimmed)) {
            return ['ok' => false, 'error' => 'Multiple statements not allowed'];
        }
        if (preg_match('/\b(INSERT|UPDATE|DELETE|DROP|TRUNCATE|ALTER|CREATE|GRANT|REVOKE)\b/i', $trimmed)) {
            return ['ok' => false, 'error' => 'Only SELECT allowed'];
        }

        return ['ok' => true];
    }

    // ════════════════════════════════════════════════════════════════════
    // UTILITIES
    // ════════════════════════════════════════════════════════════════════

    /** 3-step phone resolution + CLIENT access fallback (Z43). */
    public static function resolveTenantId(string $phone): ?string
    {
        $defaultDb = UserDatabase::query()->select('tenant_id')
            ->where('phone', $phone)->where('is_default', true)->first();
        if ($defaultDb?->tenant_id) {
            return $defaultDb->tenant_id;
        }
        $owner = Tenant::query()->select('id')->where('phone', $phone)->first();
        if ($owner?->id) {
            return $owner->id;
        }
        $mapping = TenantPhone::query()->select('tenant_id')->where('phone', $phone)->first();
        if ($mapping?->tenant_id) {
            return $mapping->tenant_id;
        }

        // Z43 — CLIENT/TEAM fallback: check if any tenant has access configured with a
        // match column. If so, allow this phone to query that tenant.
        // We check the actual data to see if the phone exists in any accessible tab.
        $matchPhone = strlen($phone) > 10 ? substr($phone, -10) : $phone;
        $allConfigs = SheetTabAccess::query()
            ->where(function ($q) {
                $q->where(function ($q2) {
                    $q2->where('access_client', true)->whereNotNull('client_match_column');
                })->orWhere(function ($q2) {
                    $q2->where('access_team', true)->whereNotNull('team_match_column');
                });
            })
            ->whereNotNull('pg_table')
            ->get(['tenant_id', 'pg_table', 'client_match_column', 'team_match_column']);

        foreach ($allConfigs as $cfg) {
            $colsToCheck = array_filter([$cfg->client_match_column, $cfg->team_match_column]);
            foreach ($colsToCheck as $col) {
                try {
                    $exists = DB::selectOne(
                        "SELECT 1 FROM `{$cfg->pg_table}` WHERE `{$col}` LIKE ? LIMIT 1",
                        ["%{$matchPhone}%"]
                    );
                    if ($exists) {
                        return $cfg->tenant_id;
                    }
                } catch (Throwable $e) {
                    // Table/column might not exist — skip
                }
            }
        }

        return null;
    }

    /**
     * Resolve a user reply against a ledger disambiguation options list.
     *
     * Accepts either:
     *   - "1" / "2" / "option 3" → numeric index (1-based) into options
     *   - "NPL Industries" or partial name → substring match against options[]
     *
     * Returns the matched option string, or null if no confident match.
     *
     * @param  list<string>  $options
     */
    private static function resolveLedgerChoice(string $query, array $options): ?string
    {
        $q = trim(mb_strtolower($query));
        if ($q === '' || count($options) === 0) {
            return null;
        }

        // Numeric pick — "2", "option 2", "#2"
        if (preg_match('/^(?:option\s+|#)?(\d{1,2})\s*$/', $q, $m)) {
            $idx = (int) $m[1] - 1;
            if ($idx >= 0 && $idx < count($options)) {
                return $options[$idx];
            }

            return null;
        }

        // Substring match against options (both directions)
        foreach ($options as $opt) {
            $ol = trim(mb_strtolower($opt));
            if ($ol === '') {
                continue;
            }
            if ($ol === $q || str_contains($ol, $q) || str_contains($q, $ol)) {
                return $opt;
            }
        }

        return null;
    }

    /**
     * Resolve a pending table-disambiguation ("'balance' multiple tables me hai:
     * opening_balances, balance_summary — kaunsi table?"). The reply is either one
     * specific table name/keyword, or "both"/"all"/"sabhi"/"donon" meaning every
     * candidate. For each chosen table we re-derive the entity the ORIGINAL question
     * was about (via LedgerEntityResolver — it already knows "balance of X" /
     * "X ka balance" phrasing) and run a real, access-filtered lookup against that
     * table, formatting each with SmartFormatter so the numbers shown are exactly
     * what's stored — not a re-guess through an unrelated table.
     *
     * Returns null (→ pending state cleared, falls through to normal flow) when the
     * reply doesn't resolve to any candidate.
     */
    private static function resolveDisambiguation(Tenant $tenant, array $pending, string $query, string $phone): ?array
    {
        $candidates = (array) ($pending['tables'] ?? []);
        if (count($candidates) === 0) {
            return null;
        }

        $q = trim(mb_strtolower($query));
        // "dono se"/"donon se" ("from both") gets typed/heard as "done se", "don se",
        // etc. — match the word BEFORE "se" loosely (don[oe]... ) rather than requiring
        // an exact spelling, since "se" already disambiguates the intent unambiguously.
        $wantsAll = (bool) preg_match('/\b(both|all|everything|sabhi|sab|har\s*ek|dono|donon|donou)\b/i', $q)
            || (bool) preg_match('/\bdon[oe]\w*\s+se\b/i', $q);

        $chosen = [];
        if ($wantsAll) {
            $chosen = $candidates;
        } else {
            foreach ($candidates as $t) {
                $name = mb_strtolower((string) ($t['source_name'] ?? $t['pg_table'] ?? ''));
                $pg = mb_strtolower((string) ($t['pg_table'] ?? ''));
                if ($name !== '' && (str_contains($name, $q) || str_contains($q, $name))) {
                    $chosen[] = $t;
                } elseif ($pg !== '' && (str_contains($pg, $q) || str_contains($q, $pg))) {
                    $chosen[] = $t;
                }
            }
        }

        if (count($chosen) === 0) {
            return null; // unmatched — caller clears pending state and falls through
        }

        $originalQuery = (string) ($pending['query'] ?? $query);
        $entity = LedgerEntityResolver::extractEntityFromQuery($originalQuery);

        $accessFilter = self::computeAccessFilter($tenant->id, $phone);
        $allowedTables = $accessFilter['allowed_tables'] ?? null;
        $whereConstraints = $accessFilter['where_constraints'] ?? [];

        $sections = [];
        foreach ($chosen as $t) {
            $pgTable = (string) ($t['pg_table'] ?? '');
            $sourceName = (string) ($t['source_name'] ?? $pgTable);
            $cols = (array) ($t['columns'] ?? []);
            if ($pgTable === '') {
                continue;
            }

            if (is_array($allowedTables) && ! in_array($pgTable, $allowedTables, true)) {
                continue; // no access to this table — silently skip rather than leak data
            }

            $nameCol = self::detectNameColumn($cols);
            $whereConstraint = $whereConstraints[$pgTable] ?? null;

            try {
                if ($nameCol !== null && $entity !== null) {
                    // Reuse LedgerEntityResolver's proven ILIKE → word-split-fuzzy search
                    // instead of a single hand-rolled LIKE — a slightly-off name (typo,
                    // "Pvt Ltd" suffix, etc.) still resolves instead of coming back empty.
                    $ledgerShape = ['pgTable' => $pgTable, 'mapping' => ['nameCol' => $nameCol]];
                    $search = LedgerEntityResolver::searchLedgerNames($ledgerShape, $entity, $whereConstraint);
                    $matchedNames = $search['matches'];

                    if (count($matchedNames) === 0) {
                        $sections[] = "📭 *{$sourceName}*\nNo record found for \"{$entity}\". Please check the spelling or try the full name.";

                        continue;
                    }

                    $pickName = $matchedNames[0];
                    $where = '`'.str_replace('`', '``', $nameCol)."` = '".str_replace("'", "''", $pickName)."'";
                    if ($whereConstraint) {
                        $where .= ' AND '.$whereConstraint;
                    }
                    $sql = "SELECT * FROM `{$pgTable}` WHERE {$where} LIMIT 3";
                    $rows = DB::select($sql);
                    $fuzzyNote = $search['fuzzy'] ? " _(closest match: {$pickName})_" : '';
                } else {
                    // No name column / no extractable entity for this table — best-effort
                    // unfiltered peek so the user still sees *something* from this source
                    // rather than a hard failure.
                    $where = $whereConstraint ?? '1=1';
                    $sql = "SELECT * FROM `{$pgTable}` WHERE {$where} LIMIT 3";
                    $rows = DB::select($sql);
                    $fuzzyNote = '';
                }
            } catch (Throwable $e) {
                Log::warning('[DISAMBIG RESOLVE] query failed for '.$pgTable.': '.$e->getMessage());
                $sections[] = "⚠️ *{$sourceName}*\nCouldn't read this table right now.";

                continue;
            }

            if (count($rows) === 0) {
                $sections[] = "📭 *{$sourceName}*\nNo matching record found.";

                continue;
            }

            $formatted = SmartFormatter::formatResults($originalQuery, $rows, $cols) ?? SmartFormatter::aiFormat($originalQuery, $rows, $cols);
            $sections[] = "📊 *{$sourceName}*{$fuzzyNote}\n".$formatted;
        }

        if (count($sections) === 0) {
            return ['reply' => '🔒 No accessible data found in the selected table(s).', 'intent' => 'ACCESS_DENIED'];
        }

        PendingStateStore::clear($phone);

        $intro = $entity !== null ? "Here's *{$entity}*'s data from ".count($chosen).' source'.(count($chosen) === 1 ? '' : 's').":\n\n" : '';

        return [
            'reply' => $intro.implode("\n\n", $sections),
            'intent' => 'DISAMBIGUATION_RESOLVED',
        ];
    }

    /**
     * Pick the best "this row's name/party" column from a table's columns metadata.
     * Priority matters: a naive `str_contains($col, 'party')` match would happily pick
     * `party_id` (values like "CUST-001") over `party_name` (values like "Nova Retail
     * Co") since `party_id` often sorts first — silently searching the wrong column
     * and always coming back with 0 matches. Prefer an explicit "name" column first.
     */
    private static function detectNameColumn(array $cols): ?string
    {
        foreach ($cols as $c) {
            if (($c['role'] ?? null) === 'entity') {
                $pgName = (string) ($c['pg_name'] ?? '');
                if ($pgName !== '') {
                    return $pgName;
                }
            }
        }
        foreach ($cols as $c) {
            $pgName = (string) ($c['pg_name'] ?? '');
            if ($pgName !== '' && preg_match('/name/i', $pgName)) {
                return $pgName;
            }
        }
        foreach ($cols as $c) {
            $pgName = (string) ($c['pg_name'] ?? '');
            if ($pgName !== '' && preg_match('/party|customer|account|vendor|client/i', $pgName) && ! preg_match('/id$/i', $pgName)) {
                return $pgName;
            }
        }

        return null;
    }

    /**
     * Resolve a cancel-disambiguation reply to an option index.
     *
     * Number pick ("1", "cancel 2", "#2") wins first — the only reliable way to tell apart
     * meetings that share a title. Else a name that uniquely matches one option's summary.
     *
     * @param  list<array{id:string, summary:string}>  $options
     */
    private static function resolveCancelChoice(string $query, array $options): ?int
    {
        $q = trim(mb_strtolower($query));
        if ($q === '' || count($options) === 0) {
            return null;
        }

        if (preg_match('/(?:^|\b)(?:cancel\s+|delete\s+|option\s+|#)?([1-9]\d?)\b/', $q, $m)) {
            $idx = (int) $m[1] - 1;
            if ($idx >= 0 && $idx < count($options)) {
                return $idx;
            }
        }

        $term = self::extractCancelTermLocal($q);
        if ($term !== '') {
            $matches = [];
            foreach ($options as $i => $opt) {
                if (stripos((string) ($opt['summary'] ?? ''), $term) !== false) {
                    $matches[] = $i;
                }
            }
            if (count($matches) === 1) {
                return $matches[0];
            }
        }

        return null;
    }

    /** Strip cancel verbs + filler, leaving the name (mirror of CalendarQueryHandler helper). */
    private static function extractCancelTermLocal(string $q): string
    {
        $q = (string) preg_replace('/\b(cancel|delete|hatao|remove|meeting|meet|with|the|my|it|please|plz|bro|wala|wali)\b/', ' ', mb_strtolower($q));

        return trim((string) preg_replace('/\s+/', ' ', $q));
    }

    /**
     * List all databases (tenants) accessible to a phone — owner + member access combined.
     *
     * Sources:
     *   1. Owner — `tenants.phone == $phone` (Tenant model)
     *   2. Member — `user_databases.phone == $phone` rows (UserDatabase model). When alias is
     *      present, it overrides the displayed name. is_default flag preserved.
     *
     * Tenants showing up in BOTH lists are de-duplicated by id, with the user_databases row
     * winning on alias + is_default (since it's the explicit per-phone customisation).
     *
     * @return list<array{id:string, name:string, alias:?string, is_default:bool, role:string}>
     */
    public static function listUserDatabases(string $phone): array
    {
        $rows = [];

        // Owners: tenants.phone == $phone
        $owners = Tenant::query()->select(['id', 'name'])->where('phone', $phone)->get();
        foreach ($owners as $t) {
            $rows[$t->id] = [
                'id' => $t->id,
                'name' => (string) ($t->name ?? 'Database'),
                'alias' => null,
                'is_default' => false,
                'role' => 'owner',
            ];
        }

        // Members: user_databases joins (also catches owners if they have an explicit row)
        $linked = UserDatabase::query()
            ->select(['tenant_id', 'alias', 'is_default'])
            ->where('phone', $phone)->get();
        foreach ($linked as $ud) {
            $tid = (string) $ud->tenant_id;
            if (isset($rows[$tid])) {
                // Owner already in list — overlay alias + is_default
                $rows[$tid]['alias'] = $ud->alias;
                $rows[$tid]['is_default'] = (bool) $ud->is_default;
            } else {
                // Member-only — fetch the tenant name via separate query
                $tenant = Tenant::query()->select(['id', 'name'])->where('id', $tid)->first();
                if ($tenant) {
                    $rows[$tid] = [
                        'id' => (string) $tenant->id,
                        'name' => (string) ($tenant->name ?? 'Database'),
                        'alias' => $ud->alias,
                        'is_default' => (bool) $ud->is_default,
                        'role' => 'member',
                    ];
                }
            }
        }

        return array_values($rows);
    }

    /**
     * Apply a "switch db" choice — reset all is_default=false for the phone, then
     * upsert the chosen tenant as is_default=true. Idempotent. Subsequent queries
     * via resolveTenantId() will pick this tenant first (Step 1 of the 3-step lookup).
     *
     * Note: This does NOT validate that $tenantId is actually accessible by $phone.
     * Caller is expected to have selected from listUserDatabases() output.
     */
    public static function applyDbSwitch(string $phone, string $tenantId): void
    {
        // Reset all rows for this phone to is_default = false
        UserDatabase::query()->where('phone', $phone)->update(['is_default' => false]);

        // Upsert the selected tenant as default. We need an alias so look up the name.
        $tenantName = Tenant::query()->select('name')->where('id', $tenantId)->value('name') ?? 'Database';

        // Try to update an existing user_databases row first (preserves the original alias if set)
        $existing = UserDatabase::query()
            ->where('phone', $phone)
            ->where('tenant_id', $tenantId)
            ->first();

        if ($existing) {
            $existing->is_default = true;
            $existing->save();
        } else {
            UserDatabase::query()->insert([
                'phone' => $phone,
                'tenant_id' => $tenantId,
                'alias' => $tenantName,
                'is_default' => true,
            ]);
        }
    }

    /**
     * Try to determine which table the SQL queries from, return that table's columns
     * for SmartFormatter role lookup. Falls back to flattening all tables' columns.
     *
     * @param  list<array<string, mixed>>  $tablesMetadata
     * @return list<array<string, mixed>>
     */
    private static function columnsForSql(string $sql, array $tablesMetadata): array
    {
        $sqlLower = strtolower($sql);
        foreach ($tablesMetadata as $t) {
            $tName = strtolower((string) ($t['pg_table'] ?? ''));
            if ($tName !== '' && str_contains($sqlLower, $tName)) {
                return $t['columns'] ?? [];
            }
        }
        // Fallback — flatten all columns
        $all = [];
        foreach ($tablesMetadata as $t) {
            foreach (($t['columns'] ?? []) as $c) {
                $all[] = $c;
            }
        }

        return $all;
    }

    /**
     * Same as columnsForSql, but returns the FULL table metadata entry (not just columns).
     * Used by Z24 auto-export to derive a friendly title from the queried table's source_name.
     * Returns null if no table matches.
     *
     * @param  list<array<string, mixed>>  $tablesMetadata
     * @return array<string, mixed>|null
     */
    private static function sourceTableForSql(string $sql, array $tablesMetadata): ?array
    {
        $sqlLower = strtolower($sql);
        foreach ($tablesMetadata as $t) {
            $tName = strtolower((string) ($t['pg_table'] ?? ''));
            if ($tName !== '' && str_contains($sqlLower, $tName)) {
                return $t;
            }
        }

        return null;
    }

    /**
     * Phase 6: Silent Correction — if current query contains negation words,
     * invalidate the previous query's cached SQL in query_memory.
     */
    private static function detectAndCorrect(string $tenantId, string $phone, string $query): void
    {
        try {
            $q = mb_strtolower(trim($query));
            $negations = ['nahi', 'galat', 'wrong', 'not this', 'ye nahi', 'incorrect', 'no ', 'nope'];
            $isNegation = false;
            foreach ($negations as $neg) {
                if (str_starts_with($q, $neg) || str_contains($q, $neg)) {
                    $isNegation = true;
                    break;
                }
            }
            if (! $isNegation) {
                return;
            }

            $prev = TenantQueryLog::query()
                ->where('tenant_id', $tenantId)
                ->where('phone', $phone)
                ->where('created_at', '>=', now()->subSeconds(60))
                ->orderByDesc('created_at')
                ->first(['query']);

            if ($prev && $prev->query) {
                QueryMemory::invalidate($tenantId, $prev->query);
                Log::info('[SILENT CORRECTION] invalidated previous query: '.mb_substr($prev->query, 0, 100));
            }
        } catch (Throwable $e) {
            Log::warning('[SILENT CORRECTION ERROR] '.$e->getMessage());
        }
    }

    private static function logQuery(string $tenantId, string $phone, string $query, ?string $sql, string $response): void
    {
        try {
            TenantQueryLog::create([
                'tenant_id' => $tenantId,
                'phone' => $phone,
                'query' => $query,
                'sql_generated' => $sql,
                'response' => mb_substr($response, 0, 5000),
            ]);
        } catch (Throwable $e) {
            Log::warning('TenantQueryLog write failed', ['error' => $e->getMessage()]);
        }
    }

    private static function elapsed(float $t0): int
    {
        return (int) ((microtime(true) - $t0) * 1000);
    }

    /**
     * Last few conversation turns for this phone+tenant (chronological), so the AI can resolve
     * cross-turn references. user(query)+assistant(response) per logged row; capped + tag-stripped.
     *
     * @return list<array{role:string, content:string}>
     */
    private static function fetchRecentTurns(string $tenantId, string $phone, int $rows = 3): array
    {
        try {
            $logs = TenantQueryLog::query()
                ->select(['query', 'response'])
                ->where('tenant_id', $tenantId)
                ->where('phone', $phone)
                ->orderByDesc('created_at')
                ->limit($rows)
                ->get()
                ->reverse();
        } catch (Throwable $e) {
            return [];
        }

        $turns = [];
        foreach ($logs as $log) {
            $q = trim((string) ($log->query ?? ''));
            $r = trim(strip_tags((string) ($log->response ?? '')));
            if ($q !== '') {
                $turns[] = ['role' => 'user', 'content' => $q];
            }
            if ($r !== '') {
                $turns[] = ['role' => 'assistant', 'content' => $r];
            }
        }

        return $turns;
    }

    /**
     * Z43 — Compute access filter for a phone number based on sheet_tab_access config.
     *
     * Returns null if no access control is configured (backwards compatible — full access).
     * Otherwise returns:
     *   ['allowed_tables' => [...pg_table names...], 'where_constraints' => ['pg_table' => 'WHERE col LIKE ...']]
     */
    /**
     * Search tenant_links by title/description matching words from the query.
     */
    private static function searchTenantLinks(string $tenantId, string $query, string $phone = ''): ?string
    {
        // Determine user's access level
        $allowedLevels = ['all'];
        if ($phone !== '') {
            $isOwner = Tenant::query()->where('id', $tenantId)->where('phone', $phone)->exists();
            $superAdmins = config('mis.super_admin_phones', []);
            if ($isOwner || in_array($phone, $superAdmins, true)) {
                $allowedLevels = ['all', 'team', 'owner'];
            } elseif (UserDatabase::query()->where('phone', $phone)->where('tenant_id', $tenantId)->exists()) {
                $allowedLevels = ['all', 'team'];
            }
        }

        $links = TenantLink::where('tenant_id', $tenantId)
            ->whereIn('access_level', $allowedLevels)
            ->get();
        if ($links->isEmpty()) {
            return null;
        }

        $q = mb_strtolower($query);
        $matches = [];
        foreach ($links as $link) {
            $title = mb_strtolower($link->title);
            $desc = mb_strtolower($link->description ?? '');
            // Check if any word from query matches title or description
            $words = preg_split('/\s+/', $q);
            $score = 0;
            foreach ($words as $w) {
                if (strlen($w) < 3) {
                    continue;
                }
                if (str_contains($title, $w)) {
                    $score += 2;
                }
                if (str_contains($desc, $w)) {
                    $score += 1;
                }
            }
            if ($score > 0) {
                $matches[] = ['link' => $link, 'score' => $score];
            }
        }

        if (empty($matches)) {
            return null;
        }

        usort($matches, fn ($a, $b) => $b['score'] - $a['score']);
        $top = array_slice($matches, 0, 5);

        $reply = "🔗 *Here are the relevant links:*\n\n";
        foreach ($top as $m) {
            $l = $m['link'];
            $reply .= "📎 *{$l->title}*\n";
            if ($l->description) {
                $reply .= "_{$l->description}_\n";
            }
            $reply .= "{$l->url}\n\n";
        }

        return $reply;
    }

    private static function computeAccessFilter(string $tenantId, string $phone): ?array
    {
        $configs = SheetTabAccess::query()->where('tenant_id', $tenantId)->get();
        if ($configs->isEmpty()) {
            return null; // No access control configured — full access (backwards compatible)
        }

        // Determine user's role relative to this tenant
        $isOwner = Tenant::query()->where('id', $tenantId)->where('phone', $phone)->exists();
        $isTeam = ! $isOwner && UserDatabase::query()->where('phone', $phone)->where('tenant_id', $tenantId)->exists();

        // Owners/super-admins bypass all access control
        $superAdmins = config('mis.super_admin_phones', []);
        if ($isOwner || in_array($phone, $superAdmins, true)) {
            return null; // Full access
        }

        // Use last 10 digits for matching (sheet may store without country code)
        $matchPhone = strlen($phone) > 10 ? substr($phone, -10) : $phone;

        // If not a registered team member, check if phone exists in any team_match_column data
        if (! $isTeam) {
            foreach ($configs as $c) {
                if ($c->access_team && $c->team_match_column && $c->pg_table) {
                    try {
                        $found = DB::selectOne(
                            "SELECT 1 FROM `{$c->pg_table}` WHERE `{$c->team_match_column}` LIKE ? LIMIT 1",
                            ["%{$matchPhone}%"]
                        );
                        if ($found) {
                            $isTeam = true;
                            break;
                        }
                    } catch (Throwable $e) {
                    }
                }
            }
        }
        $isClient = ! $isOwner && ! $isTeam;

        $allowedTables = [];
        $whereConstraints = [];

        foreach ($configs as $c) {
            $pgTable = $c->pg_table;
            if (! $pgTable) {
                continue;
            }

            // ALL — everyone gets full access to this tab
            if ($c->access_all) {
                $allowedTables[] = $pgTable;

                continue;
            }

            // TEAM — registered member. If a match column is set, filter rows to that
            // member's own (e.g. a salesperson only sees their own deals). If left
            // blank, the admin's intent is "team gets the whole tab" — grant it with
            // no row filter, same as ALL but scoped to the TEAM role only.
            if ($isTeam && $c->access_team) {
                $allowedTables[] = $pgTable;
                if ($c->team_match_column) {
                    $whereConstraints[$pgTable] = "`{$c->team_match_column}` LIKE '%{$matchPhone}%'";
                }

                continue;
            }

            // CLIENT — external user, row-filtered by client_match_column. Unlike TEAM
            // (whose membership is already verified via UserDatabase registration),
            // a CLIENT's only proof of identity is this row match — so require at
            // least one matching row before granting the table at all. Without this,
            // a client whose number matches nothing still got the table added with a
            // WHERE constraint that silently returned 0 rows, instead of an explicit
            // "you don't have access" reply.
            if ($isClient && $c->access_client && $c->client_match_column) {
                if (self::phoneHasMatchInColumn($pgTable, $c->client_match_column, $matchPhone)) {
                    $allowedTables[] = $pgTable;
                    $whereConstraints[$pgTable] = "`{$c->client_match_column}` LIKE '%{$matchPhone}%'";
                }

                continue;
            }
        }

        return [
            'allowed_tables' => $allowedTables,
            'where_constraints' => $whereConstraints,
        ];
    }

    /**
     * Does at least one row in $pgTable.$column match $matchPhone? Used to gate CLIENT
     * table access — fails closed (returns false / denies) on any query error, since
     * this backs an access-control decision.
     */
    private static function phoneHasMatchInColumn(string $pgTable, string $column, string $matchPhone): bool
    {
        try {
            $found = DB::selectOne(
                "SELECT 1 FROM `{$pgTable}` WHERE `{$column}` LIKE ? LIMIT 1",
                ["%{$matchPhone}%"]
            );

            return $found !== null;
        } catch (Throwable $e) {
            Log::warning('[ACCESS FILTER] match check failed for '.$pgTable.'.'.$column.': '.$e->getMessage());

            return false;
        }
    }

    private static function detectUserRole(string $tenantId, string $phone): string
    {
        $superAdmins = config('mis.super_admin_phones', []);
        if (in_array($phone, $superAdmins, true)) {
            return 'super_admin';
        }
        if (Tenant::where('id', $tenantId)->where('phone', $phone)->exists()) {
            return 'owner';
        }
        if (UserDatabase::where('tenant_id', $tenantId)->where('phone', $phone)->exists()) {
            return 'member';
        }

        return 'guest';
    }
}
