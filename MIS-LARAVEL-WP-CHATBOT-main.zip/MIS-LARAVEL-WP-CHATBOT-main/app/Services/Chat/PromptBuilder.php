<?php

declare(strict_types=1);

namespace App\Services\Chat;

use App\Models\Tenant;

/**
 * PromptBuilder — system prompt + message payload generator for the tenant AI.
 *
 * Two flavours:
 *   - generateSystemPrompt(): legacy prompt for the JSONB-cache flow
 *     (tenants where proper_tables_created=false). Includes the 10-rule list.
 *   - buildSqlGenerationPrompt(): rich schema-aware prompt for the proper-
 *     tables flow (Phase 6+). Tells the model the real table names, typed
 *     columns, role hints, and the 13 critical SQL rules ported from
 *     tenant-router.js Sprint 4 work.
 *
 * Port of Node helpers/prompt.js + the inline SQL prompt from tenant-router.js.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/prompt.js
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-router.js
 */
final class PromptBuilder
{
    // ════════════════════════════════════════════════════════════════════
    // LEGACY (JSONB) PROMPT
    // ════════════════════════════════════════════════════════════════════

    /**
     * Build the legacy data-assistant system prompt for tenants still on the
     * JSONB cache (pre-Phase 6). Returns AI rules + business context.
     */
    public static function generateSystemPrompt(Tenant $tenant): string
    {
        $schema = $tenant->schema_json;
        if (! is_array($schema) || empty($schema['columns'])) {
            return self::fallbackPrompt($tenant);
        }

        $columnLines = [];
        foreach ($schema['columns'] as $c) {
            $line = '- '.($c['name'] ?? '').' ('.($c['type'] ?? 'text').')';
            if (! empty($c['samples']) && is_array($c['samples'])) {
                $samples = array_slice($c['samples'], 0, 2);
                $line .= ' — e.g. '.implode(', ', $samples);
            }
            $columnLines[] = $line;
        }
        $columnList = implode("\n", $columnLines);
        $rowCount = (int) ($schema['row_count'] ?? 0);
        $bizContext = $tenant->business_description
            ? "Business context: {$tenant->business_description}"
            : '';

        return <<<PROMPT
You are a data assistant for "{$tenant->name}".
{$bizContext}

The user's data has {$rowCount} rows with these columns:
{$columnList}

RULES:
1. Answer questions by analyzing the data provided in the context.
2. For aggregations (total, sum, average, count), compute from the data.
3. For numeric columns, treat comma-separated numbers as numbers (remove commas before math).
4. ALWAYS reply in English, regardless of the language the user writes in. Users may write in Hindi, English, or Hinglish — you understand all three but reply in clean English only.
5. Keep answers concise. Use bullet points for lists.
6. If data doesn't have the answer, say so honestly.
7. For date columns, understand relative dates (today, yesterday, last week, this month) — including their Hindi/Hinglish forms (aaj, kal, is hafte).
8. Format currency with ₹ symbol and commas (₹1,23,456).
9. CRITICAL — When multiple rows match a query:
   - ALWAYS give a summary first: total count of matching entries, total/sum of amount columns
   - Then show ALL unique entries (group by invoice/voucher number, show each with amount and date)
   - If more than 15 unique entries, show top 10 and say "There are X more entries — ask for a specific date/range to see them."
   - Ask: "Would you like details for a specific invoice/date/item?"
   - NEVER pick just one random value — always aggregate all matching rows
10. If user asks "what is X's amount/invoice" and X appears multiple times, give TOTAL of all entries + count of invoices.

IMPORTANT: You will receive the user's data as JSON rows in the context. Use ONLY that data to answer. Do not make up numbers.
PROMPT;
    }

    public static function fallbackPrompt(Tenant $tenant): string
    {
        $bizContext = $tenant->business_description ?? '';

        return <<<PROMPT
You are a helpful data assistant for "{$tenant->name}".
{$bizContext}
Answer questions about the user's data. ALWAYS reply in English (users may write in Hindi/English/Hinglish — understand all, reply in English only).
If you don't have enough data, say so honestly.
PROMPT;
    }

    /**
     * Legacy message-payload builder — used by the JSONB flow.
     *
     * @param  list<array<string, mixed>>  $relevantData
     * @return list<array{role: string, content: string}>
     */
    public static function buildQueryMessages(Tenant $tenant, string $userQuery, array $relevantData, int $totalRows = 0): array
    {
        $systemPrompt = $tenant->system_prompt ?: self::generateSystemPrompt($tenant);

        // Up to 120K chars of data context
        $dataStr = json_encode($relevantData, JSON_UNESCAPED_UNICODE);
        $maxLen = 120_000;
        $truncated = strlen($dataStr) > $maxLen
            ? substr($dataStr, 0, $maxLen).'...(truncated)'
            : $dataStr;

        $totalNote = ($totalRows > 0 && $totalRows > count($relevantData))
            ? "\n(Note: Total database has {$totalRows} rows. Showing ".count($relevantData).' most relevant rows matching the query. Compute answers from ALL provided rows.)'
            : '';

        $userBlock = 'DATA ('.count($relevantData)." rows):{$totalNote}\n{$truncated}\n\nQUESTION: {$userQuery}";

        return [
            ['role' => 'system', 'content' => $systemPrompt],
            ['role' => 'user',   'content' => $userBlock],
        ];
    }

    // ════════════════════════════════════════════════════════════════════
    // MODERN (PROPER TABLES) SQL-GEN PROMPT
    // ════════════════════════════════════════════════════════════════════

    /**
     * Build a schema-aware SQL-generation prompt for the proper-tables flow.
     * Tells gpt-4o-mini the exact table names + typed columns + role hints
     * + 13 critical SQL rules ported from tenant-router.js.
     *
     * The `$mode` param injects mode-specific guidance:
     *   'data'   (default) — normal data query, no extra instructions
     *   'chart'  — forces 2-column aggregating SQL (label + numeric value, GROUP BY,
     *              ORDER BY value DESC, LIMIT 12, NULL labels filtered)
     *   'images' — forces SELECT to include the detected image-URL column + a
     *              meaningful name/entity column for caption (uses $imageCols)
     *
     * @param  list<array<string, mixed>>  $tablesMetadata  tenant.tables_metadata
     * @param  string  $mode  'data' (default), 'chart', or 'images'
     * @param  list<array{pgTable:string, pgColumn:string}>  $imageCols  image-URL columns detected by ImageColumnDetector (only used when mode='images')
     * @return list<array{role: string, content: string}>
     */
    public static function buildSqlMessages(
        Tenant $tenant,
        string $userQuery,
        array $tablesMetadata,
        string $mode = 'data',
        array $imageCols = [],
        array $mandatoryWheres = []
    ): array {
        $schemaBlock = self::buildSchemaBlock($tablesMetadata);

        // Z43 — Mandatory WHERE constraints for access-controlled tabs
        $accessNote = '';
        if (!empty($mandatoryWheres)) {
            $lines = [];
            foreach ($mandatoryWheres as $table => $where) {
                $lines[] = "  - Table `{$table}`: MUST include WHERE {$where}";
            }
            $accessNote = "\n\nACCESS CONTROL — MANDATORY FILTERS (NEVER omit these):\n"
                . "The user has restricted access. Every query against these tables MUST include the specified WHERE clause:\n"
                . implode("\n", $lines)
                . "\nCombine with AND if you need additional filters. NEVER remove these conditions.";
        } else {
            $accessNote = "\n\nACCESS: This user is an OWNER/ADMIN with FULL access. Do NOT add any phone/number-based WHERE filters. Words like \"my\", \"mera\", \"meri\" mean \"from my business\" = ALL data. Never filter by phone or internal_numbers column unless the user explicitly provides a specific phone number.";
        }

        $modeNote = '';
        if ($mode === 'chart') {
            $modeNote = "\n\n".<<<'CHARTNOTE'
CHART QUERY MODE:
The result will be rendered as a chart image. Generate AGGREGATING SQL with EXACTLY 2 columns:
  1. The LABEL column (TEXT — entity name, city, month, category, etc.) — first in SELECT.
  2. The VALUE column (NUMERIC — SUM/COUNT/AVG of currency/qty/count) — second in SELECT.
Use GROUP BY on the label column.
Use ORDER BY value DESC.
Use LIMIT 12 (charts become unreadable beyond ~12 slices/bars).
Filter NULL labels: WHERE label_col IS NOT NULL AND label_col <> ''.
Examples:
  - "monthly sales chart" → SELECT DATE_FORMAT(c_date_actual, '%b-%y') AS month, SUM(amount+0) AS total FROM t WHERE c_date_actual IS NOT NULL GROUP BY 1 ORDER BY MIN(c_date_actual) LIMIT 12
  - "top 5 parties bar chart" → SELECT party_name, SUM(amount+0) AS total FROM t WHERE party_name IS NOT NULL GROUP BY party_name ORDER BY total DESC LIMIT 5
  - "city wise pie chart" → SELECT city, SUM(amount+0) AS total FROM t WHERE city IS NOT NULL AND city <> '' GROUP BY city ORDER BY total DESC LIMIT 8
NEVER select more than 2 columns in chart mode.
CHARTNOTE;
        } elseif ($mode === 'images' && count($imageCols) > 0) {
            $colList = implode(', ', array_map(
                static fn (array $c) => "{$c['pgColumn']} (in {$c['pgTable']})",
                $imageCols
            ));
            $primary = $imageCols[0];
            $modeNote = "\n\nIMAGE QUERY MODE:\n"
                ."The user wants product/entity images. The schema has these image-URL columns: {$colList}.\n"
                ."The SELECT statement MUST include the image column AND a meaningful name/entity column for caption.\n"
                ."Example pattern: SELECT entity_name, {$primary['pgColumn']} FROM {$primary['pgTable']} WHERE entity_name LIKE '%term%' AND {$primary['pgColumn']} IS NOT NULL LIMIT 20\n"
                ."Always filter out NULL image URLs. Limit to 20 rows max.";
        } elseif ($mode === 'pivot') {
            $modeNote = "\n\n".<<<'PIVOTNOTE'
PIVOT QUERY MODE:
The result will be rendered as a 2-dimensional cross-tab (rows × columns × value) or as a 1D summary if the user asks for a single dimension. Generate AGGREGATING SQL with EXACTLY 2 OR 3 columns:

For 2D pivot (preferred — user mentioned two dimensions like "month-wise sales by city"):
  SELECT <row_label_col>, <col_label_col>, SUM/COUNT/AVG(<numeric>) AS value
  FROM <table>
  WHERE <row_label_col> IS NOT NULL AND <col_label_col> IS NOT NULL
  GROUP BY 1, 2
  ORDER BY 1, 2

For 1D pivot (user mentioned only one dimension like "month-wise sales"):
  SELECT <label_col>, SUM/COUNT/AVG(<numeric>) AS value
  FROM <table>
  WHERE <label_col> IS NOT NULL
  GROUP BY 1
  ORDER BY 1

CRITICAL pivot rules:
  - The first column MUST be the row label, second column MUST be the column label (for 2D) OR the value (for 1D).
  - The LAST column MUST be a numeric aggregate (SUM/COUNT/AVG/etc.) with an alias.
  - Filter NULL labels with `IS NOT NULL AND <col> <> ''`.
  - For month-wise breakdown, prefer `DATE_FORMAT(date_actual, '%b-%y')` for human-readable labels — handler will sort calendar-aware.
  - Cap each axis at 30 distinct values (use `WHERE <col> IN (...)` if needed); the handler caps automatically but tighter SQL is faster.
  - DO NOT include extra columns like row_id, voucher_no, or invoice_no — they create unique-per-row pivots which are useless.

Examples:
  - "month-wise sales pivot by city" →
      SELECT DATE_FORMAT(c_date_actual, '%b-%y') AS month, city, SUM(amount+0) AS total
      FROM tenant_xxx_sales
      WHERE c_date_actual IS NOT NULL AND city IS NOT NULL AND city <> ''
      GROUP BY 1, 2 ORDER BY MIN(c_date_actual), 2
  - "sales person × month pivot" →
      SELECT sales_person, DATE_FORMAT(c_date_actual, '%b-%y') AS month, SUM(amount+0) AS total
      FROM tenant_xxx_sales
      WHERE sales_person IS NOT NULL AND sales_person <> 'NA' AND c_date_actual IS NOT NULL
      GROUP BY 1, 2 ORDER BY 1, MIN(c_date_actual)
  - "month-wise sales pivot" (1D) →
      SELECT DATE_FORMAT(c_date_actual, '%b-%y') AS month, SUM(amount+0) AS total
      FROM tenant_xxx_sales
      WHERE c_date_actual IS NOT NULL
      GROUP BY 1 ORDER BY MIN(c_date_actual)
PIVOTNOTE;
        }

        // Intelligence overlay: admin-provided business context (Settings → Chatbot
        // Prompts → Company context). When set, it helps the model interpret
        // business-specific terms and pick the right tables/columns. Opt-in + bounded,
        // so it costs zero tokens unless the admin actually configured it.
        $contextNote = '';
        $companyContext = trim((string) (\App\Models\TenantPrompt::get($tenant->id, 'company_context') ?? ''));
        if ($companyContext !== '') {
            $companyContext = mb_substr($companyContext, 0, 1200);
            $contextNote = "\n\nBUSINESS CONTEXT (use ONLY to interpret the user's wording and choose the right tables/columns — never invent data or ignore the schema):\n{$companyContext}";
        }

        // The primary/base prompt lives in ONE place — buildBaseSqlPrompt() — so it stays
        // identical for every tenant and every database that gets connected. The dynamic
        // pieces (schema, business context, mode, access filters) are slotted in; the core
        // rules never change per-tenant. This is the consistency anchor.
        $systemPrompt = self::buildBaseSqlPrompt($tenant->name, $schemaBlock, $contextNote, $modeNote, $accessNote);

        return [
            ['role' => 'system', 'content' => $systemPrompt],
            ['role' => 'user',   'content' => "QUESTION: {$userQuery}"],
        ];
    }

    /**
     * THE primary / base SQL-generation system prompt — the single source of truth.
     *
     * Deliberately kept in code (NOT admin-editable) so the chatbot behaves consistently
     * for every tenant and every new database/sheet that gets connected. Only the dynamic
     * arguments below are injected into fixed slots; the hard rules never vary per-tenant.
     * Admin customisations (business context, data-reply format, tone) are layered on as
     * ADDITIVE overlays elsewhere — they never rewrite these rules. This is what protects
     * working consistency when a new data system is plugged in.
     *
     * @param  string  $tenantName    business/tenant display name
     * @param  string  $schemaBlock   dynamically-built schema (tables/columns/roles/samples)
     * @param  string  $contextNote   optional admin business-context overlay (may be '')
     * @param  string  $modeNote      chart/images/pivot mode instructions (may be '')
     * @param  string  $accessNote    access-control mandatory-filter note (may be '')
     */
    private static function buildBaseSqlPrompt(
        string $tenantName,
        string $schemaBlock,
        string $contextNote = '',
        string $modeNote = '',
        string $accessNote = ''
    ): string {
        $systemPrompt = <<<PROMPT
You are a MySQL SQL generator for tenant "{$tenantName}".
Output ONE well-formed SELECT query that answers the user's question — nothing else, no markdown, no explanations.

SCHEMA:
{$schemaBlock}

CRITICAL RULES:
1. Output ONE single SQL SELECT statement. No semicolons, no comments, no DDL/DML.
2. Numeric columns stored as TEXT: use `col+0` or `CAST(col AS DECIMAL)` before SUM/AVG/MIN/MAX.
3. Use COUNT(DISTINCT voucher_id) for invoice counts when an id column exists.
4. Filter NULL party/sales_person/item: `WHERE col IS NOT NULL AND col <> 'NA'`.
5. Exclude tax/round/discount lines from item-level queries: `AND item_col NOT LIKE '%cgst%' AND item_col NOT LIKE '%sgst%' AND item_col NOT LIKE '%igst%' AND item_col NOT LIKE '%cess%' AND item_col NOT LIKE '%round%' AND item_col NOT LIKE '%discount%'`.
6. DATE FILTERING — text date columns (e.g. c_date "2-Apr-26") have a companion _actual DATE column. If a table has a "⚠️ PRIMARY DATE COLUMN" annotation, ALWAYS use THAT column for date filtering on that table. Otherwise use timestamp_actual. For RELATIVE dates, ALWAYS use the _actual column:
   "this month"      → timestamp_actual >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
   "last month"      → timestamp_actual >= DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 MONTH), '%Y-%m-01') AND timestamp_actual < DATE_FORMAT(CURDATE(), '%Y-%m-01')
   "last 30 days"    → timestamp_actual >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
   "this week"       → timestamp_actual >= DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY)
   "yesterday/kal"   → timestamp_actual = DATE_SUB(CURDATE(), INTERVAL 1 DAY)
   "today/aaj"       → timestamp_actual = CURDATE()
   "this year"       → timestamp_actual >= DATE_FORMAT(CURDATE(), '%Y-01-01')
   "last year"       → timestamp_actual >= DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 YEAR), '%Y-01-01') AND timestamp_actual < DATE_FORMAT(CURDATE(), '%Y-01-01')
   "last one year/last 1 year/past year" → timestamp_actual >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)
   Specific month:   → timestamp_actual >= '2026-05-01' AND timestamp_actual < '2026-06-01'
   Month-wise GROUP: → DATE_FORMAT(timestamp_actual, '%b-%y')
   "from April 2024 to June 2026" → timestamp_actual >= '2024-04-01' AND timestamp_actual <= '2026-06-30'
   FALLBACK: If _actual column might be NULL, add: COALESCE(timestamp_actual, STR_TO_DATE(SUBSTRING_INDEX(timestamp, ' ', 1), '%d-%b-%Y'))
   For LIKE on text date: "April 2026" → timestamp LIKE '%-Apr-26%'
7. LIKE for fuzzy entity match (MySQL is case-insensitive by default): `party_name LIKE '%term%'`. Use the SHORTEST unique part of the name.
8. When user asks about an entity but it could be in EITHER party OR sales_person column, search both: `(party_name LIKE '%X%' OR sales_person LIKE '%X%')`.
9. For "with GST" questions, prefer the with_gst_amount column if present; deduplicate per voucher first: SELECT SUM(amt) FROM (SELECT DISTINCT voucher_no, with_gst_amount AS amt FROM table) s.
10. Use CASE WHEN for IMMEDIATE-vs-others / category buckets.
11. ALWAYS provide column aliases: `SUM(col+0) AS total_amount`.
12. For lists / "top N" / "by category", end with `GROUP BY ... ORDER BY ... DESC LIMIT N`.
13. For "median" / "percentile", compute via: SELECT col FROM table ORDER BY col+0 LIMIT 1 OFFSET (COUNT(*)/2).
14. User may write in Hindi, English, or Hinglish (e.g. "kitni sales hui", "total bikri", "sabse zyada kisko becha"). Understand ALL — output SQL only.
15. No subqueries unless required. No CTE unless needed. LIMIT 200 for lists. Single statement only.
16. INCLUDE EVERY COLUMN the user asks for. If user says "top clients with phone, contact person, and total invoices" → SELECT party_name, phone, contact_person_name, SUM(total_price+0) AS total_sales, COUNT(DISTINCT invoice_no) AS total_invoices. NEVER reduce to just 2 columns when user asks for more. More detail = better.
17. Reply with the SQL only. No prose, no JSON, no code fences. If you cannot answer, reply: CLARIFY: <your question>.
18. When multiple tables have similar data (e.g. "SALES" 100 rows vs "SALE DATABASE" 1313 rows), ALWAYS use the table with MORE rows — it has the real/complete data. A table with 100 rows is likely test/fake data. NEVER prefer a smaller table over a larger one for the same type of data.
19. When listing invoices/bills/documents, ALWAYS include any column whose name contains "pdf", "link", "url", "file", or "drive" (e.g. invoice_pdf, file_link, pdf_url). These contain document links the user needs. Include them in SELECT even if the user didn't explicitly ask.
20. CROSS-TABLE COMPARISON (e.g. "sales vs expenses", "income vs expenditure"): Use LEFT JOIN on date/month between two subqueries. Each subquery uses ITS OWN table's PRIMARY DATE COLUMN. Example:
    SELECT s.month, s.total_sales, e.total_expenses FROM
      (SELECT DATE_FORMAT(timestamp_actual, '%b-%y') AS month, SUM(amount+0) AS total_sales FROM sales_table WHERE timestamp_actual >= '2025-01-01' AND timestamp_actual < '2026-01-01' GROUP BY month) s
    LEFT JOIN
      (SELECT DATE_FORMAT(c_date_actual, '%b-%y') AS month, SUM(amount+0) AS total_expenses FROM expense_table WHERE c_date_actual >= '2025-01-01' AND c_date_actual < '2026-01-01' GROUP BY month) e
    ON s.month = e.month
    ORDER BY MIN(s.timestamp_actual){$contextNote}{$modeNote}{$accessNote}
PROMPT;

        return $systemPrompt
            . "\n\nBefore your SQL, write exactly one word: HIGH, MEDIUM, or LOW indicating your confidence that this SQL correctly answers the question. HIGH = certain (clear columns, clear intent). MEDIUM = likely correct but some ambiguity. LOW = guessing (unclear which column/table/filter to use). Format: CONFIDENCE_WORD: SQL_HERE";
    }

    /**
     * Compact human-readable schema block for the SQL prompt.
     * Lists each tenant table with its real PG name + columns + role hints + sample values.
     *
     * @param  list<array<string, mixed>>  $tablesMetadata
     */
    public static function buildSchemaBlock(array $tablesMetadata): string
    {
        if (count($tablesMetadata) === 0) {
            return '(no tables synced yet)';
        }

        $blocks = [];
        foreach ($tablesMetadata as $t) {
            $tName = $t['pg_table'] ?? '?';
            $rowCount = $t['row_count'] ?? 0;
            $sourceName = $t['source_name'] ?? '';
            $cols = $t['columns'] ?? [];

            $colLines = [];
            $dateActualCols = [];
            foreach ($cols as $c) {
                $line = '  - '.($c['pg_name'] ?? '?').' '.($c['pg_type'] ?? 'TEXT');
                if (! empty($c['role'])) {
                    $line .= " [role: {$c['role']}]";
                }
                if (! empty($c['original'])) {
                    $line .= ' (orig "'.($c['original']).'")';
                }
                if (! empty($c['samples']) && is_array($c['samples'])) {
                    $samples = array_slice($c['samples'], 0, 2);
                    $line .= ' — e.g. '.implode(', ', array_map(static fn ($s) => (string) $s, $samples));
                }
                $colLines[] = $line;

                // Track date_actual columns and check if their source has diverse data
                if (($c['role'] ?? '') === 'date_actual') {
                    $dateActualCols[] = ['name' => $c['pg_name'], 'table' => $tName];
                }
            }

            // Pick best date column: prefer one with most distinct values in actual DB
            $dateHint = '';
            if (count($dateActualCols) > 1) {
                $scored = [];
                foreach ($dateActualCols as $dc) {
                    try {
                        $cnt = \Illuminate\Support\Facades\DB::selectOne(
                            "SELECT COUNT(DISTINCT `{$dc['name']}`) as cnt FROM `{$dc['table']}` WHERE `{$dc['name']}` IS NOT NULL LIMIT 1"
                        );
                        $scored[] = ['name' => $dc['name'], 'distinct' => $cnt->cnt ?? 0];
                    } catch (\Throwable $e) {
                        $scored[] = ['name' => $dc['name'], 'distinct' => 0];
                    }
                }
                usort($scored, fn ($a, $b) => $b['distinct'] <=> $a['distinct']);
                if ($scored[0]['distinct'] > $scored[1]['distinct']) {
                    $best = $scored[0]['name'];
                    $dateHint = "\n  ⚠️ PRIMARY DATE COLUMN for this table: `{$best}` (use this instead of other _actual columns for date filtering)";
                }
            }

            $sourceLabel = $sourceName !== '' ? ", source: \"{$sourceName}\"" : '';
            $sizeWarning = $rowCount <= 100 ? ' ⚠️ SMALL/TEST DATA' : '';
            $blocks[] = "TABLE {$tName} ({$rowCount} rows{$sourceLabel}){$sizeWarning}:\n".implode("\n", $colLines).$dateHint;
        }

        return implode("\n\n", $blocks);
    }
}
