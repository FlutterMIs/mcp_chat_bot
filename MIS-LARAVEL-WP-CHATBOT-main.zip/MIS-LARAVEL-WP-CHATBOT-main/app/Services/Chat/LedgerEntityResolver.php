<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * LedgerEntityResolver — three responsibilities for the ledger query mode:
 *
 *   1. detectLedgerTables(tablesMetadata)   — find tables that look like ledgers
 *      (debit/credit cols OR closing_balance + particulars OR tab named ledger/khata/bahi),
 *      resolve role columns into a {nameCol, debitCol, creditCol, balance cols, ...} mapping
 *
 *   2. extractEntityFromQuery(query)        — pull party name out of phrases like
 *      "Pansari ka ledger", "ledger of Acme", "X ka khata", etc.
 *
 *   3. searchLedgerNames(ledger, term)      — find unique party names matching the term:
 *      first ILIKE '%term%' (exact substring) then pg_trgm fuzzy fallback (threshold 0.15)
 *
 * Plus fetchLedgerForName(ledger, name) which loads all rows for a resolved party,
 * ordered by date (if available), capped at 5000 rows.
 *
 * Pure-ish — no Eloquent dependency; uses DB::select for raw queries against tenant tables.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-ledger.js
 */
final class LedgerEntityResolver
{
    /** Limit rows per ledger fetch (Tally exports can be very long). */
    private const FETCH_ROW_LIMIT = 5000;

    /** pg_trgm fuzzy-search similarity threshold — values below this are noise. */
    private const FUZZY_SCORE_THRESHOLD = 0.15;

    /** Search-result limit (display in disambiguation list). */
    private const SEARCH_NAME_LIMIT = 8;

    // ════════════════════════════════════════════════════════════════════
    // 1. LEDGER-TABLE DETECTION
    // ════════════════════════════════════════════════════════════════════

    /**
     * Find tables that look like ledgers and resolve their role columns.
     *
     * A table qualifies as a ledger if it has either:
     *   • A debit AND a credit column, OR
     *   • A closing_balance column AND (particulars OR voucher number) col, OR
     *   • Tab name explicitly contains "ledger" / "khata" / "khaata" / "bahi"
     * AND has a name column to search by (party_name / customer_name / account_name / etc.)
     *
     * @param  list<array<string, mixed>>  $tablesMetadata
     * @return list<array{pgTable:string, sourceName:string, columns:list, mapping:array}>
     */
    public static function detectLedgerTables(array $tablesMetadata): array
    {
        $out = [];
        foreach ($tablesMetadata as $t) {
            $tabName = strtolower((string) ($t['source_name'] ?? $t['pg_table'] ?? ''));
            $cols = $t['columns'] ?? [];

            $findCol = static function (string $regex) use ($cols) {
                foreach ($cols as $c) {
                    $name = strtolower((string) ($c['original'] ?? $c['pg_name'] ?? ''));
                    if (preg_match($regex, $name)) return $c['pg_name'] ?? null;
                }

                return null;
            };

            $debitCol           = $findCol('/^(?!.*credit)(?!.*opening)(?!.*closing).*debit/i') ?? $findCol('/^(?!.*credit).*debit/i') ?? $findCol('/^dr$/i');
            $creditCol          = $findCol('/^(?!.*debit)(?!.*period)(?!.*limit)(?!.*opening)(?!.*closing).*credit/i') ?? $findCol('/^(?!.*debit)(?!.*period)(?!.*limit).*credit/i') ?? $findCol('/^cr$/i');
            $openingBalanceCol  = $findCol('/opening.*balance|opening_bal|open_bal/i');
            $closingBalanceCol  = $findCol('/closing.*balance|closing_bal|close_bal|^balance$/i');
            $particularCol      = $findCol('/^(?!.*opening)(?!.*closing).*(?:particular|narration|description)/i') ?? $findCol('/particular|narration|description/i');
            $dateCol            = $findCol('/voucher.*date|^date$|txn.*date|trans.*date/i');
            $vchTypeCol         = $findCol('/voucher.*type|vch.*type/i');
            $vchNoCol           = $findCol('/voucher.*no|voucher.*num|vch.*no|voucher.*number/i');
            $nameCol            = $findCol('/^name$|party.*name|account.*name|customer.*name|ledger.*name/i');
            if ($nameCol === null) {
                // Fallback — first column with role 'entity'
                foreach ($cols as $c) {
                    if (($c['role'] ?? null) === 'entity') {
                        $nameCol = $c['pg_name'] ?? null;
                        break;
                    }
                }
            }

            $tabIsLedgerNamed = (bool) preg_match('/ledger|khata|khaata|bahi/i', $tabName);
            $looksLikeLedger = $tabIsLedgerNamed
                || ($debitCol !== null && $creditCol !== null)
                || ($closingBalanceCol !== null && ($particularCol !== null || $vchNoCol !== null));

            if (! $looksLikeLedger) continue;
            if ($nameCol === null) continue; // can't search without a name col

            $out[] = [
                'pgTable'    => (string) ($t['pg_table'] ?? ''),
                'sourceName' => (string) ($t['source_name'] ?? ''),
                'columns'    => $cols,
                'mapping'    => [
                    'nameCol'           => $nameCol,
                    'debitCol'          => $debitCol,
                    'creditCol'         => $creditCol,
                    'openingBalanceCol' => $openingBalanceCol,
                    'closingBalanceCol' => $closingBalanceCol,
                    'particularCol'     => $particularCol,
                    'dateCol'           => $dateCol,
                    'vchTypeCol'        => $vchTypeCol,
                    'vchNoCol'          => $vchNoCol,
                ],
            ];
        }

        // Prioritize transaction tables (with real debit+credit columns and a
        // particulars/vchType column) over summary/balance tables. A table named
        // "ledger" with debit+credit+particulars is almost certainly the transaction
        // ledger; "ledger_balance" with opening/closing is a master summary.
        usort($out, static function (array $a, array $b): int {
            $score = static function (array $t): int {
                $m = $t['mapping'];
                $s = 0;
                if ($m['debitCol'] && $m['creditCol']) $s += 4;
                if ($m['particularCol'] || $m['vchTypeCol']) $s += 2;
                if ($m['vchNoCol']) $s += 1;
                // Penalize tables that look like master/balance summaries
                if (preg_match('/balance|master|summary/i', $t['sourceName'] ?? '')) $s -= 3;
                return $s;
            };
            return $score($b) - $score($a);
        });

        return $out;
    }

    // ════════════════════════════════════════════════════════════════════
    // 2. ENTITY-NAME EXTRACTION
    // ════════════════════════════════════════════════════════════════════

    /**
     * Pull the entity name out of phrases like:
     *   "Pansari ka ledger"           → "Pansari"
     *   "Pansari k ledger bhejo"      → "Pansari"
     *   "Pansari industries ledger"   → "Pansari industries"
     *   "ledger of Acme Corp"         → "Acme Corp"
     *   "show me ABC khata"           → "ABC"
     *   "Acme bahi khata"             → "Acme"
     *   bare "ledger"                 → null (no entity given)
     */
    public static function extractEntityFromQuery(?string $query): ?string
    {
        if ($query === null) return null;
        $q = trim($query);
        if ($q === '') return null;

        // 1) "give me ledger for/of X" / "show me ledger for X" / "send ledger for X"
        if (preg_match('/(?:give|show|send|get|fetch|share)\s+(?:me\s+)?(?:the\s+)?(?:ledger|khata|khaata|bahi)\s+(?:for|of|ka|ke|ki|k)\s+(.+)$/i', $q, $m)) {
            return self::cleanEntity($m[1]);
        }

        // 2) "ledger of/for X" / "khata of X"
        if (preg_match('/(?:ledger|khata|khaata|bahi)\s+(?:for|of|ka|ke|ki|k)\s+(.+)$/i', $q, $m)) {
            return self::cleanEntity($m[1]);
        }

        // 2) "X ka/k/ke/ki ledger ..."
        if (preg_match('/^(.+?)\s+(?:ka|ke|ki|k)\s+(?:ledger|khata|khaata|bahi)\b/i', $q, $m)) {
            return self::cleanEntity($m[1]);
        }

        // 3) "X ledger" / "X khata" — strip trailing ledger word
        if (preg_match('/^(.+?)\s+(?:ledger|khata|khaata|bahi)\b/i', $q, $m)) {
            return self::cleanEntity($m[1]);
        }

        // 4) "ledger X" — strip leading word
        if (preg_match('/^(?:ledger|khata|khaata|bahi)\s+(.+)$/i', $q, $m)) {
            return self::cleanEntity($m[1]);
        }

        // 5) Bare "ledger" — no entity given
        if (preg_match('/^(?:ledger|khata|khaata|bahi)[\s?!.]*$/i', $q)) {
            return null;
        }

        // 5b) No "ledger" keyword at all — "what is the (closing/opening) balance of X",
        // "X ka balance/statement/account", "balance of X". These reach this resolver when
        // detectQueryMode/the AI orchestrator routes a balance-style question to ledger mode.
        if (preg_match('/(?:balance|statement|account)\s+(?:for|of|ka|ke|ki|k)\s+(.+)$/i', $q, $m)) {
            return self::cleanEntity($m[1]);
        }
        if (preg_match('/^(.+?)\s+(?:ka|ke|ki|k)\s+(?:balance|statement|account)\b/i', $q, $m)) {
            return self::cleanEntity($m[1]);
        }

        // 6) Fallback — strip the ledger word and common verbs from anywhere
        $stripped = preg_replace(
            '/\b(?:ledger|khata|khaata|bahi|bhejo|dikhao|send|share|please|plz|btao|batao|do|de\s*do)\b/i',
            ' ',
            $q
        ) ?? '';

        return self::cleanEntity($stripped);
    }

    private static function cleanEntity(string $s): ?string
    {
        // Strip command verbs, pronouns, ledger words AND list/quantifier words
        // (provide/all/pending/outstanding/list/...). The latter matter because a query
        // like "provide all pending ledger" would otherwise leave "provide all pending"
        // as the searched party name — the exact bug in the reported screenshot. After
        // stripping, such a query cleans to '' → null → handler asks "which party?"
        // instead of "no account named 'provide all pending' found".
        $t = preg_replace('/\b(?:give|show|get|fetch|send|share|provide|for|of|bhejo|dikhao|please|plz|pls|btao|batao|de\s*do|do|me|mujhe|mereko|merko|the|my|mera|mere|ledger|khata|khaata|bahi|what|whats|is|kya|hai|closing|opening|current|balance|statement|account|all|sab|sabhi|saare|saari|sare|sabka|sabki|pending|outstanding|overdue|unpaid|due|list|everyone|har)\b/i', ' ', $s) ?? '';
        $t = preg_replace('/[?!.,]+$/', '', $t) ?? '';
        $t = preg_replace('/\s+/', ' ', $t) ?? '';
        $t = trim($t);
        if (mb_strlen($t) < 2) return null;

        return $t;
    }

    // ════════════════════════════════════════════════════════════════════
    // 3. NAME SEARCH (ILIKE → fuzzy fallback)
    // ════════════════════════════════════════════════════════════════════

    /**
     * Find unique party names in the ledger table that match the search term.
     *
     * Step 1: ILIKE '%term%' (exact substring). If none found...
     * Step 2: pg_trgm fuzzy_search RPC, filtering by SCORE_THRESHOLD.
     *
     * @param  array{pgTable:string, mapping:array}  $ledger
     * @return array{matches:list<string>, fuzzy:bool}
     */
    public static function searchLedgerNames(array $ledger, string $term, ?string $whereConstraint = null): array
    {
        $pgTable = $ledger['pgTable'];
        $nameCol = $ledger['mapping']['nameCol'];

        // Step 1: ILIKE substring match
        try {
            $escapedTerm = addcslashes($term, '%_');
            $whereClause = self::quoteIdent($nameCol) . ' LIKE ' . self::quoteLit('%'.$escapedTerm.'%');
            if ($whereConstraint) {
                $whereClause .= ' AND ' . $whereConstraint;
            }
            $sql = sprintf(
                'SELECT DISTINCT %s AS name FROM %s WHERE %s ORDER BY name LIMIT %d',
                self::quoteIdent($nameCol),
                self::quoteIdent($pgTable),
                $whereClause,
                self::SEARCH_NAME_LIMIT
            );
            $rows = DB::select($sql);
            $exact = array_values(array_filter(
                array_map(static fn ($r) => is_object($r) ? ($r->name ?? null) : ($r['name'] ?? null), $rows),
                static fn ($n) => is_string($n) && $n !== ''
            ));
            if (count($exact) > 0) {
                return ['matches' => $exact, 'fuzzy' => false];
            }
        } catch (Throwable $e) {
            Log::warning('[LEDGER LIKE] '.$e->getMessage());
        }

        // Step 2: word-split fuzzy fallback — AND for significant words
        try {
            $words = preg_split('/\s+/', $term);
            $skip = ['pvt','ltd','llp','the','and','for','private','limited'];
            $sigWords = []; $shortWords = [];
            foreach ($words as $w) {
                if (strlen($w) < 2) continue;
                if (in_array(strtolower($w), $skip) || strlen($w) <= 3) { $shortWords[] = $w; }
                else { $sigWords[] = preg_replace('/s$/i', '', $w); }
            }
            $useWords = count($sigWords) > 0 ? $sigWords : $shortWords;
            $conditions = [];
            foreach ($useWords as $w) {
                $escaped = addcslashes($w, '%_');
                $conditions[] = self::quoteIdent($nameCol) . ' LIKE ' . self::quoteLit('%'.$escaped.'%');
            }
            if (count($conditions) === 0) {
                return ['matches' => [], 'fuzzy' => false];
            }
            $where = implode(' AND ', $conditions);
            if ($whereConstraint) {
                $where .= ' AND ' . $whereConstraint;
            }
            $sql = sprintf(
                'SELECT DISTINCT %s AS name FROM %s WHERE %s ORDER BY name LIMIT 5',
                self::quoteIdent($nameCol),
                self::quoteIdent($pgTable),
                $where
            );
            $rows = DB::select($sql);
            $fuzzyMatches = [];
            foreach ($rows as $r) {
                $value = is_object($r) ? ($r->name ?? null) : ($r['name'] ?? null);
                if (is_string($value) && $value !== '') {
                    $fuzzyMatches[] = $value;
                }
            }

            return ['matches' => $fuzzyMatches, 'fuzzy' => true];
        } catch (Throwable $e) {
            Log::warning('[LEDGER FUZZY] '.$e->getMessage());
            return ['matches' => [], 'fuzzy' => false];
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // 4. FETCH ROWS FOR A RESOLVED NAME
    // ════════════════════════════════════════════════════════════════════

    /**
     * Fetch all ledger rows for a specific name. Ordered by date if available,
     * capped at 5000 rows.
     *
     * @param  array{pgTable:string, mapping:array}  $ledger
     * @return list<array<string, mixed>>  result rows as associative arrays
     */
    public static function fetchLedgerForName(array $ledger, string $name, ?string $whereConstraint = null): array
    {
        $pgTable = $ledger['pgTable'];
        $nameCol = $ledger['mapping']['nameCol'];
        $dateCol = $ledger['mapping']['dateCol'] ?? null;

        $orderClause = $dateCol !== null
            ? 'ORDER BY '.self::quoteIdent($dateCol).' IS NULL, '.self::quoteIdent($dateCol).' ASC'
            : '';

        $whereClause = sprintf('%s = %s', self::quoteIdent($nameCol), self::quoteLit($name));
        if ($whereConstraint) {
            $whereClause .= ' AND ' . $whereConstraint;
        }

        $sql = sprintf(
            'SELECT * FROM %s WHERE %s %s LIMIT %d',
            self::quoteIdent($pgTable),
            $whereClause,
            $orderClause,
            self::FETCH_ROW_LIMIT
        );

        $rows = DB::select($sql);

        return array_map(
            static fn ($r) => is_object($r) ? get_object_vars($r) : (array) $r,
            $rows
        );
    }

    // ════════════════════════════════════════════════════════════════════
    // SQL ESCAPING (small + safe)
    // ════════════════════════════════════════════════════════════════════

    /** Quote a MySQL identifier (table or column name) with backticks. */
    private static function quoteIdent(string $name): string
    {
        return '`'.str_replace('`', '``', $name).'`';
    }

    /** Quote a string literal with single quotes (escape internal singles). */
    private static function quoteLit(string $value): string
    {
        return "'".str_replace("'", "''", $value)."'";
    }
}
