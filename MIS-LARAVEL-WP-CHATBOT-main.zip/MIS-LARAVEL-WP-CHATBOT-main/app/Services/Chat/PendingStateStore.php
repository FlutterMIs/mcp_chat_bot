<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * PendingStateStore — wp_sessions-backed multi-turn conversation state per phone.
 *
 * Used by TenantRouter to remember in-flight context between consecutive WhatsApp
 * (or web /chat) messages from the same phone. Examples:
 *
 *   - Calendar booking missing date or time:
 *       user: "book meeting with sharma tomorrow"  → bot: "what time?"  → state saved
 *       user: "3 PM"                                → state restored, query merged, booked
 *
 *   - Ledger disambiguation (multi-match):
 *       user: "NPL ka ledger"     → bot: "1. NPL Buildcon  2. NPL Industries  3. NPL Foundation"
 *       user: "2"                  → state restored, NPL Industries resolved, PDF sent
 *
 *   - Multi-DB switching (Z22):
 *       user: "switch db"          → bot: "1. kaizen (current)  2. MIS-2  3. retail"
 *       user: "2"                  → state restored, applyDbSwitch sets MIS-2 default, ack sent
 *
 * State shape (data JSONB on wp_sessions row):
 *
 *   calendar:
 *     {
 *       "kind": "calendar",
 *       "expecting": "date" | "time",
 *       "original_query": string,
 *       "partial": { "title": string, "date": "YYYY-MM-DD"?, "time": "HH:MM"?, "guest": string?, ... }
 *     }
 *
 *   ledger:
 *     {
 *       "kind": "ledger",
 *       "options": [ "NPL Buildcon LLP", "NPL Industries", ... ],
 *       "ledger_idx": 0,                     // which detected ledger table (rare to be > 0)
 *       "tenant_db_name": "kaizen"           // for the PDF header
 *     }
 *
 *   db_select (Z22):
 *     {
 *       "kind": "db_select",
 *       "options": [
 *         { "id": "uuid",  "name": "kaizen" },
 *         { "id": "uuid2", "name": "MIS-2"  }
 *       ]
 *     }
 *
 * TTL: 5 minutes (matches Node helpers/tenant-router.js pendingCalendar / pendingLedgers).
 *
 * Architecture note — TIMEZONE SAFETY:
 *   APP_TIMEZONE=Asia/Kolkata in .env causes Carbon::now() to return IST clock time.
 *   When that's serialized to a naive datetime string and sent to Postgres' timestamptz
 *   column, Postgres interprets it as UTC — silently storing a value 5.5h in the future.
 *   Our defense: do the WRITE and the TTL comparison server-side in Postgres using `now()`.
 *   No PHP-side timestamp arithmetic. Eliminates the entire class of TZ-mismatch bugs.
 *
 * Cleanup is lazy — expired rows are simply ignored on read. A Phase 23D scheduler job
 * can periodically `DELETE FROM wp_sessions WHERE updated_at < now() - interval '1 hour'`
 * to garbage-collect dead rows.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-router.js (pendingCalendar/pendingLedgers Maps)
 */
final class PendingStateStore
{
    /** TTL in seconds — 5 minutes. Matches Node parity. */
    public const TTL_SECONDS = 300;

    /**
     * Save (or replace) pending state for a phone. Idempotent — overwrites prior state.
     *
     * Uses Postgres' `now()` for updated_at to avoid the APP_TIMEZONE=IST mismatch.
     *
     * @param  array<string, mixed>  $state
     */
    public static function set(string $phone, array $state): void
    {
        try {
            $json = json_encode($state, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);

            DB::statement(
                'INSERT INTO wp_sessions (phone, data, updated_at)
                 VALUES (?, ?, NOW())
                 ON DUPLICATE KEY UPDATE data = VALUES(data), updated_at = NOW()',
                [$phone, $json]
            );
        } catch (Throwable $e) {
            Log::warning('[PENDING SET] '.$e->getMessage(), [
                'phone' => $phone,
                'kind'  => $state['kind'] ?? 'unknown',
            ]);
        }
    }

    /**
     * Get pending state for a phone if it exists AND has not expired (5-min TTL).
     * Returns null otherwise. Auto-clears the row when expired.
     *
     * The TTL comparison is server-side via `updated_at > now() - interval '300 seconds'`,
     * eliminating any PHP-side timezone math.
     *
     * @return array<string, mixed>|null
     */
    public static function get(string $phone): ?array
    {
        try {
            $ttl = (int) self::TTL_SECONDS;
            $row = DB::selectOne(
                "SELECT data
                 FROM wp_sessions
                 WHERE phone = ?
                   AND updated_at > NOW() - INTERVAL ? SECOND",
                [$phone, $ttl]
            );

            if (! $row) {
                self::clear($phone);

                return null;
            }

            $data = is_string($row->data) ? json_decode($row->data, true) : $row->data;

            return is_array($data) && isset($data['kind']) ? $data : null;
        } catch (Throwable $e) {
            Log::warning('[PENDING GET] '.$e->getMessage(), ['phone' => $phone]);

            return null;
        }
    }

    /**
     * Clear pending state for a phone. No-op if nothing pending.
     */
    public static function clear(string $phone): void
    {
        try {
            DB::table('wp_sessions')->where('phone', $phone)->delete();
        } catch (Throwable $e) {
            Log::warning('[PENDING CLEAR] '.$e->getMessage(), ['phone' => $phone]);
        }
    }
}
