<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * PivotQueryHandler — Z26.
 *
 * Cross-tab handler for queries containing "pivot" (or month-wise / breakdown
 * style intent — see TenantRouter::detectQueryMode). Receives ALREADY-EXECUTED
 * 3-column SQL rows from the main TenantRouter retry loop (the AI was steered
 * by the PIVOTNOTE block in PromptBuilder to emit `dim1, dim2, value` shape),
 * builds an in-memory pivot grid, and returns either:
 *
 *   - small grid (cells ≤ 80) → markdown-aligned text table reply
 *   - large grid (cells > 80) → CSV media payload via TenantCsvBuilder
 *   - 1D fallback (2-col input) → simple list with totals
 *   - shape mismatch (≠ 2/3 cols) → null sentinel so caller falls back to
 *     SmartFormatter (graceful degradation, never crashes the pipeline)
 *
 * Input contract (3-col happy path):
 *   $rows[i] = { '<row_label_col>' => string|number,
 *                '<col_label_col>' => string|number,
 *                '<value_col>'     => numeric }
 *
 * Output contract: same shape as TenantRouter Step 8 returns
 *   {reply, intent:'PIVOT_QUERY', sql, rows, [media:{type:document, path, ...}]}
 *
 * Why this is a "format-only" handler (no SQL of its own):
 *   The main TenantRouter retry loop (Step 5-7) already runs the AI + SQL
 *   pipeline with full self-heal coverage. By making PivotQueryHandler take
 *   pre-fetched rows, we get retry-on-error + relaxSQL + fuzzy fallback for
 *   FREE — same battle-tested machinery used for data/chart/images. No
 *   duplication.
 *
 * @see PromptBuilder::buildSqlMessages() $mode='pivot' branch — emits 3-col SQL
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-router.js:248 — Node has detection but no handler
 */
final class PivotQueryHandler
{
    /** Above this many cells (rows × cols) we ship a CSV instead of a text table. */
    public const MAX_TEXT_CELLS = 80;

    /** Hard cap on dimension axes — protects against `dim1=invoice_no` (3000+ unique). */
    public const MAX_AXIS_LABELS = 30;

    /**
     * Build a pivot reply from already-executed rows.
     *
     * @param  list<array<string, mixed>|object>  $rows           result rows from the AI-generated 3-col SQL
     * @param  string                              $query          original user query (for caption)
     * @param  list<array<string, mixed>>          $tableColumns   columns for the table the SQL queried (for SmartFormatter role lookup)
     * @param  string                              $sql            the SQL that produced $rows (for log + return payload)
     * @param  array{dbName?:string}               $opts
     * @return array<string, mixed>|null  null = caller should fall back to SmartFormatter (shape mismatch / no useful pivot)
     */
    public static function buildResult(
        array $rows,
        string $query,
        array $tableColumns,
        string $sql,
        array $opts = []
    ): ?array {
        if (count($rows) === 0) return null;

        // Normalise rows to assoc arrays
        $rowsAssoc = array_map(
            static fn ($r) => is_object($r) ? get_object_vars($r) : (array) $r,
            $rows
        );

        $first = $rowsAssoc[0];
        $keys = array_keys($first);
        $colCount = count($keys);

        // Need at least 2 columns. < 2 → degraded result, fall back.
        if ($colCount < 2) return null;

        // Build role map for value formatting
        $roleMap = SmartFormatter::buildRoleMap($first, $tableColumns);

        // ─────────────────────────────────────────────────────────────────
        // 1D PATH (2 columns) — simple list with grand total
        // ─────────────────────────────────────────────────────────────────
        if ($colCount === 2) {
            return self::buildOneDimensional($rowsAssoc, $keys, $roleMap, $query, $sql, $opts);
        }

        // ─────────────────────────────────────────────────────────────────
        // 2D PATH (3+ columns — use first 3)
        // ─────────────────────────────────────────────────────────────────
        $rowKey = $keys[0];
        $colKey = $keys[1];
        $valKey = $keys[2];
        $valueRole = $roleMap[$valKey]['role'] ?? 'number';

        // Collect distinct row + col labels (preserving first-seen order, then sorted)
        $rowLabels = [];
        $colLabels = [];
        $grid      = []; // grid[rowLabel][colLabel] = sum
        $rowTotals = [];
        $colTotals = [];
        $grandTotal = 0.0;

        foreach ($rowsAssoc as $r) {
            $rl = self::stringify($r[$rowKey] ?? '');
            $cl = self::stringify($r[$colKey] ?? '');
            $v  = self::numericOf($r[$valKey] ?? 0);

            if ($rl === '' || $cl === '') continue; // skip null axis cells

            if (! isset($grid[$rl])) {
                $grid[$rl] = [];
                $rowTotals[$rl] = 0.0;
                $rowLabels[$rl] = true;
            }
            if (! isset($colTotals[$cl])) {
                $colTotals[$cl] = 0.0;
                $colLabels[$cl] = true;
            }

            $grid[$rl][$cl] = ($grid[$rl][$cl] ?? 0.0) + $v;
            $rowTotals[$rl] += $v;
            $colTotals[$cl] += $v;
            $grandTotal     += $v;
        }

        $rowLabels = array_keys($rowLabels);
        $colLabels = array_keys($colLabels);

        // Sort axis labels — month-aware if values look like Mon-YY / YYYY-MM / Mon
        self::sortAxis($rowLabels);
        self::sortAxis($colLabels);

        // Cap axis size — protects against dim1=invoice_no with thousands of unique values
        if (count($rowLabels) > self::MAX_AXIS_LABELS || count($colLabels) > self::MAX_AXIS_LABELS) {
            Log::warning(sprintf(
                '[PIVOT] axis too wide: rows=%d cols=%d — degrading to CSV',
                count($rowLabels),
                count($colLabels)
            ));

            return self::buildCsvResult(
                rows: $rowsAssoc,
                tableColumns: $tableColumns,
                query: $query,
                sql: $sql,
                opts: $opts,
                rowKey: $rowKey,
                colKey: $colKey,
                valKey: $valKey
            );
        }

        // ─────────────────────────────────────────────────────────────────
        // Decide: text table OR CSV
        // ─────────────────────────────────────────────────────────────────
        $cellCount = count($rowLabels) * count($colLabels);
        $dbName = (string) ($opts['dbName'] ?? 'Database');

        if ($cellCount <= self::MAX_TEXT_CELLS) {
            $reply = self::renderTextTable(
                rowLabels: $rowLabels,
                colLabels: $colLabels,
                grid: $grid,
                rowTotals: $rowTotals,
                colTotals: $colTotals,
                grandTotal: $grandTotal,
                rowKeyDisplay: SmartFormatter::humanizeLabel($rowKey),
                valueRole: $valueRole,
                dbName: $dbName,
                query: $query
            );

            return [
                'reply'  => $reply,
                'intent' => 'PIVOT_QUERY',
                'sql'    => $sql,
                'rows'   => count($rowsAssoc),
                'pivot'  => [
                    'rows'        => count($rowLabels),
                    'cols'        => count($colLabels),
                    'cells'       => $cellCount,
                    'value_role'  => $valueRole,
                    'grand_total' => $grandTotal,
                ],
            ];
        }

        // > MAX_TEXT_CELLS → CSV via TenantCsvBuilder
        return self::buildCsvResult(
            rows: $rowsAssoc,
            tableColumns: $tableColumns,
            query: $query,
            sql: $sql,
            opts: $opts,
            rowKey: $rowKey,
            colKey: $colKey,
            valKey: $valKey
        );
    }

    // ════════════════════════════════════════════════════════════════════
    // 1D path
    // ════════════════════════════════════════════════════════════════════

    /**
     * @param  list<array<string, mixed>>  $rows
     * @param  list<string>                 $keys
     * @param  array<string, array{role:string}>  $roleMap
     * @return array<string, mixed>
     */
    private static function buildOneDimensional(
        array $rows,
        array $keys,
        array $roleMap,
        string $query,
        string $sql,
        array $opts
    ): array {
        $labelKey = $keys[0];
        $valueKey = $keys[1];
        $valueRole = $roleMap[$valueKey]['role'] ?? 'number';

        // Compute total for the footer
        $total = 0.0;
        $items = [];
        foreach ($rows as $r) {
            $label = self::stringify($r[$labelKey] ?? '');
            if ($label === '') continue;
            $val = self::numericOf($r[$valueKey] ?? 0);
            $items[$label] = ($items[$label] ?? 0.0) + $val;
            $total += $val;
        }

        // Sort by label (month-aware if applicable)
        $labels = array_keys($items);
        self::sortAxis($labels);

        $colWidth = max(array_merge(
            [self::displayWidth(SmartFormatter::humanizeLabel($labelKey))],
            array_map([self::class, 'displayWidth'], $labels)
        ));
        $valWidth = max(array_merge(
            [self::displayWidth(SmartFormatter::humanizeLabel($valueKey))],
            array_map(static fn ($l) => self::displayWidth(self::compactValue($items[$l], $valueRole)), $labels),
            [self::displayWidth(self::compactValue($total, $valueRole))]
        ));

        $header = self::padRight(SmartFormatter::humanizeLabel($labelKey), $colWidth)
                . '  '
                . self::padLeft(SmartFormatter::humanizeLabel($valueKey), $valWidth);
        $sep    = str_repeat('─', $colWidth) . '  ' . str_repeat('─', $valWidth);
        $body   = [];
        foreach ($labels as $l) {
            $body[] = self::padRight($l, $colWidth)
                    . '  '
                    . self::padLeft(self::compactValue($items[$l], $valueRole), $valWidth);
        }
        $totalLine = self::padRight('TOTAL', $colWidth)
                   . '  '
                   . self::padLeft(self::compactValue($total, $valueRole), $valWidth);

        $table = "```\n{$header}\n{$sep}\n" . implode("\n", $body) . "\n{$sep}\n{$totalLine}\n```";

        $reply = "📊 *Pivot — " . SmartFormatter::humanizeLabel($labelKey) . "*\n\n{$table}";

        return [
            'reply'  => $reply,
            'intent' => 'PIVOT_QUERY',
            'sql'    => $sql,
            'rows'   => count($rows),
            'pivot'  => [
                'mode'        => '1d',
                'rows'        => count($items),
                'cols'        => 1,
                'cells'       => count($items),
                'value_role'  => $valueRole,
                'grand_total' => $total,
            ],
        ];
    }

    // ════════════════════════════════════════════════════════════════════
    // 2D text table renderer
    // ════════════════════════════════════════════════════════════════════

    /**
     * @param  list<string>                              $rowLabels
     * @param  list<string>                              $colLabels
     * @param  array<string, array<string, float>>       $grid
     * @param  array<string, float>                      $rowTotals
     * @param  array<string, float>                      $colTotals
     */
    private static function renderTextTable(
        array $rowLabels,
        array $colLabels,
        array $grid,
        array $rowTotals,
        array $colTotals,
        float $grandTotal,
        string $rowKeyDisplay,
        string $valueRole,
        string $dbName,
        string $query
    ): string {
        // Compute column widths (each col-label width = max of its header + cell formatted values + col total)
        $rowLabelWidth = max(array_merge(
            [self::displayWidth($rowKeyDisplay)],
            array_map([self::class, 'displayWidth'], $rowLabels),
            [self::displayWidth('TOTAL')]
        ));

        $colWidths = [];
        foreach ($colLabels as $cl) {
            $w = self::displayWidth($cl);
            foreach ($rowLabels as $rl) {
                $cell = self::compactValue($grid[$rl][$cl] ?? 0.0, $valueRole);
                $w = max($w, self::displayWidth($cell));
            }
            $w = max($w, self::displayWidth(self::compactValue($colTotals[$cl] ?? 0.0, $valueRole)));
            $colWidths[$cl] = $w;
        }
        $totalColWidth = max(array_merge(
            [self::displayWidth('TOTAL')],
            array_map(static fn ($rl) => self::displayWidth(self::compactValue($rowTotals[$rl] ?? 0.0, $valueRole)), $rowLabels),
            [self::displayWidth(self::compactValue($grandTotal, $valueRole))]
        ));

        // Build header row
        $headerCells = [self::padRight($rowKeyDisplay, $rowLabelWidth)];
        foreach ($colLabels as $cl) {
            $headerCells[] = self::padLeft($cl, $colWidths[$cl]);
        }
        $headerCells[] = self::padLeft('TOTAL', $totalColWidth);

        // Separator
        $sepCells = [str_repeat('─', $rowLabelWidth)];
        foreach ($colLabels as $cl) {
            $sepCells[] = str_repeat('─', $colWidths[$cl]);
        }
        $sepCells[] = str_repeat('─', $totalColWidth);

        // Body rows
        $bodyRows = [];
        foreach ($rowLabels as $rl) {
            $cells = [self::padRight($rl, $rowLabelWidth)];
            foreach ($colLabels as $cl) {
                $cells[] = self::padLeft(self::compactValue($grid[$rl][$cl] ?? 0.0, $valueRole), $colWidths[$cl]);
            }
            $cells[] = self::padLeft(self::compactValue($rowTotals[$rl] ?? 0.0, $valueRole), $totalColWidth);
            $bodyRows[] = implode('  ', $cells);
        }

        // Totals row
        $totalCells = [self::padRight('TOTAL', $rowLabelWidth)];
        foreach ($colLabels as $cl) {
            $totalCells[] = self::padLeft(self::compactValue($colTotals[$cl] ?? 0.0, $valueRole), $colWidths[$cl]);
        }
        $totalCells[] = self::padLeft(self::compactValue($grandTotal, $valueRole), $totalColWidth);

        $table = '```'."\n"
               . implode('  ', $headerCells)."\n"
               . implode('  ', $sepCells)."\n"
               . implode("\n", $bodyRows)."\n"
               . implode('  ', $sepCells)."\n"
               . implode('  ', $totalCells)."\n"
               . '```';

        $title = ucfirst(trim($query));
        if (mb_strlen($title) > 80) $title = mb_substr($title, 0, 77).'...';

        return "📊 *Pivot — {$title}*\n\n{$table}";
    }

    // ════════════════════════════════════════════════════════════════════
    // CSV path (large pivots)
    // ════════════════════════════════════════════════════════════════════

    /**
     * @param  list<array<string, mixed>>  $rows
     * @return array<string, mixed>
     */
    private static function buildCsvResult(
        array $rows,
        array $tableColumns,
        string $query,
        string $sql,
        array $opts,
        string $rowKey,
        string $colKey,
        string $valKey
    ): array {
        $dbName = (string) ($opts['dbName'] ?? 'Database');
        $title = 'Pivot — '.SmartFormatter::humanizeLabel($rowKey).' × '.SmartFormatter::humanizeLabel($colKey);

        try {
            // Pivot the rows into a wide-format list-of-arrays for CSV writer
            $wideRows = self::pivotToWideRows($rows, $rowKey, $colKey, $valKey);
            // Synthetic columns: row label first, then each colLabel as its own column, then Total
            $wideColumns = self::buildWideColumnList($wideRows);

            $csvPath = TenantCsvBuilder::render($wideRows, $wideColumns, [
                'title'  => $title,
                'dbName' => $dbName,
            ]);

            $cellCount = (count($wideRows) - 1) * (count($wideColumns) - 2); // ignore TOTAL row + first/last cols
            $reply = "📊 *Pivot — too wide for chat*\n\n"
                   . 'Sending CSV: *'.count($wideRows).' rows × '.count($wideColumns).' cols* '
                   . '('.number_format($cellCount).' cells).';

            return [
                'reply'  => $reply,
                'intent' => 'PIVOT_QUERY',
                'sql'    => $sql,
                'rows'   => count($rows),
                'media'  => [
                    'type'     => 'document',
                    'path'     => $csvPath,
                    'filename' => basename($csvPath),
                    'caption'  => "📊 {$title}",
                ],
                'pivot'  => [
                    'mode'  => '2d-csv',
                    'rows'  => count($wideRows),
                    'cols'  => count($wideColumns),
                    'cells' => $cellCount,
                ],
            ];
        } catch (Throwable $e) {
            Log::warning('[PIVOT CSV] '.$e->getMessage());

            // Fallback: return null so caller falls back to SmartFormatter
            return [
                'reply'  => '⚠️ Pivot result was too large to render. Try narrowing the date range or using a smaller dimension.',
                'intent' => 'PIVOT_TOO_LARGE',
                'sql'    => $sql,
                'rows'   => count($rows),
            ];
        }
    }

    /**
     * Pivot original 3-col rows into wide format suitable for CSV.
     * Each output row = [rowLabelKey => label, ...colLabels => values, 'Total' => rowSum].
     *
     * @param  list<array<string, mixed>>  $rows
     * @return list<array<string, mixed>>
     */
    private static function pivotToWideRows(array $rows, string $rowKey, string $colKey, string $valKey): array
    {
        $grid       = [];
        $rowTotals  = [];
        $colTotals  = [];
        $grandTotal = 0.0;

        foreach ($rows as $r) {
            $rl = self::stringify($r[$rowKey] ?? '');
            $cl = self::stringify($r[$colKey] ?? '');
            if ($rl === '' || $cl === '') continue;
            $v = self::numericOf($r[$valKey] ?? 0);

            $grid[$rl][$cl] = ($grid[$rl][$cl] ?? 0.0) + $v;
            $rowTotals[$rl] = ($rowTotals[$rl] ?? 0.0) + $v;
            $colTotals[$cl] = ($colTotals[$cl] ?? 0.0) + $v;
            $grandTotal    += $v;
        }

        $rowLabels = array_keys($rowTotals);
        $colLabels = array_keys($colTotals);
        self::sortAxis($rowLabels);
        self::sortAxis($colLabels);

        $rowKeyDisplay = SmartFormatter::humanizeLabel($rowKey);
        $wideRows = [];
        foreach ($rowLabels as $rl) {
            $row = [$rowKeyDisplay => $rl];
            foreach ($colLabels as $cl) {
                $row[$cl] = $grid[$rl][$cl] ?? 0;
            }
            $row['Total'] = $rowTotals[$rl] ?? 0;
            $wideRows[] = $row;
        }
        // Footer total row
        $totalRow = [$rowKeyDisplay => 'TOTAL'];
        foreach ($colLabels as $cl) {
            $totalRow[$cl] = $colTotals[$cl] ?? 0;
        }
        $totalRow['Total'] = $grandTotal;
        $wideRows[] = $totalRow;

        return $wideRows;
    }

    /**
     * Build a column-metadata list for TenantCsvBuilder from the first wide row.
     * All synthetic columns are treated as TEXT (CSV doesn't need types — Excel infers).
     *
     * @param  list<array<string, mixed>>  $wideRows
     * @return list<array<string, mixed>>
     */
    private static function buildWideColumnList(array $wideRows): array
    {
        if (count($wideRows) === 0) return [];
        $cols = [];
        foreach (array_keys($wideRows[0]) as $name) {
            $cols[] = [
                'pg_name' => $name,
                'pg_type' => 'TEXT',
                'role'    => 'text',
            ];
        }

        return $cols;
    }

    // ════════════════════════════════════════════════════════════════════
    // Helpers
    // ════════════════════════════════════════════════════════════════════

    /**
     * Compact value formatter — short enough to fit in a pivot cell.
     *   currency: ₹1.23Cr / ₹45.6L / ₹1,234 / ₹0
     *   quantity: 1,234 / 45.6K (no ₹)
     *   count/number: 1,234
     *   else: stringified up to 12 chars
     */
    public static function compactValue(mixed $v, string $role): string
    {
        if ($v === null || $v === '') return '–';
        if (! is_numeric($v)) return (string) $v;
        $num = (float) $v;
        if ($num === 0.0) {
            return $role === 'currency' ? '₹0' : '0';
        }
        $abs = abs($num);
        $sign = $num < 0 ? '-' : '';

        if ($role === 'currency') {
            if ($abs >= 1e7) return $sign.'₹'.number_format($abs / 1e7, 2).'Cr';
            if ($abs >= 1e5) return $sign.'₹'.number_format($abs / 1e5, 2).'L';
            if ($abs >= 1e3) return $sign.'₹'.number_format($abs / 1e3, 2).'K';

            return $sign.'₹'.number_format($abs, 0);
        }

        // quantity / count / number / unknown
        if ($abs >= 1e6) return $sign.number_format($abs / 1e6, 2).'M';
        if ($abs >= 1e3) return $sign.number_format($abs, 0); // keep precision for thousands

        return $sign.number_format($abs, $abs < 100 && floor($abs) !== $abs ? 2 : 0);
    }

    private static function stringify(mixed $v): string
    {
        if ($v === null) return '';

        return trim((string) $v);
    }

    private static function numericOf(mixed $v): float
    {
        if (is_numeric($v)) return (float) $v;
        if (is_string($v)) {
            $clean = preg_replace('/[,₹\s]/', '', $v) ?? '';
            if (is_numeric($clean)) return (float) $clean;
        }

        return 0.0;
    }

    private static function displayWidth(string $s): int
    {
        return mb_strlen($s);
    }

    private static function padRight(string $s, int $w): string
    {
        $diff = $w - mb_strlen($s);

        return $diff > 0 ? $s.str_repeat(' ', $diff) : $s;
    }

    private static function padLeft(string $s, int $w): string
    {
        $diff = $w - mb_strlen($s);

        return $diff > 0 ? str_repeat(' ', $diff).$s : $s;
    }

    /**
     * Sort axis labels in-place. Month-aware:
     *   - "Jan-26" / "Feb-26" → calendar order
     *   - "2026-01" / "2026-02" → ISO date order
     *   - "Jan" / "Feb" → calendar order
     *   - else: natural string sort
     *
     * @param  list<string>  $labels
     */
    public static function sortAxis(array &$labels): void
    {
        if (count($labels) <= 1) return;

        $monthMap = [
            'jan' => 1, 'feb' => 2, 'mar' => 3, 'apr' => 4, 'may' => 5, 'jun' => 6,
            'jul' => 7, 'aug' => 8, 'sep' => 9, 'oct' => 10, 'nov' => 11, 'dec' => 12,
        ];

        $allMonthYY = true;
        $allIsoMonth = true;
        $allMonthOnly = true;

        foreach ($labels as $l) {
            if (! preg_match('/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[\-\s]\d{2,4}$/i', $l)) {
                $allMonthYY = false;
            }
            if (! preg_match('/^\d{4}-\d{2}(-\d{2})?$/', $l)) {
                $allIsoMonth = false;
            }
            if (! preg_match('/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)$/i', $l)) {
                $allMonthOnly = false;
            }
        }

        if ($allMonthYY) {
            usort($labels, static function ($a, $b) use ($monthMap) {
                preg_match('/^(\w+)[\-\s](\d+)/', $a, $ma);
                preg_match('/^(\w+)[\-\s](\d+)/', $b, $mb);
                $ya = (int) $ma[2];
                $yb = (int) $mb[2];
                if ($ya !== $yb) return $ya <=> $yb;

                return ($monthMap[strtolower($ma[1])] ?? 0) <=> ($monthMap[strtolower($mb[1])] ?? 0);
            });

            return;
        }

        if ($allIsoMonth) {
            sort($labels);

            return;
        }

        if ($allMonthOnly) {
            usort($labels, static fn ($a, $b) => ($monthMap[strtolower($a)] ?? 0) <=> ($monthMap[strtolower($b)] ?? 0));

            return;
        }

        // Natural sort — handles mixed alpha-numeric reasonably
        natcasesort($labels);
        $labels = array_values($labels);
    }
}
