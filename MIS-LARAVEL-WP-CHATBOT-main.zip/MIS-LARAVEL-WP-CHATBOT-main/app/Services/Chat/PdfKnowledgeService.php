<?php

declare(strict_types=1);

namespace App\Services\Chat;

use App\Models\TenantPdfChunk;
use App\Services\AI\AiGateway;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Smalot\PdfParser\Parser;
use Throwable;

/**
 * PdfKnowledgeService — indexes PDF text content into searchable chunks,
 * and searches them using keyword matching + GPT for answer synthesis.
 *
 * Flow:
 *   1. indexFromUrl(tenantId, url, title) — downloads PDF, extracts text, chunks, stores
 *   2. search(tenantId, query) — keyword-searches chunks, sends top matches to GPT for answer
 */
final class PdfKnowledgeService
{
    private const CHUNK_SIZE = 1500; // chars per chunk
    private const CHUNK_OVERLAP = 200;

    /**
     * Bounds worst-case embedding latency/cost for an unusually large document on
     * hosting with no queue (a request-time upload must still complete within the
     * server's execution limit). Chunks beyond this cap are still stored and
     * remain fully searchable by keyword — they just don't get a semantic embedding.
     */
    private const MAX_EMBEDDED_CHUNKS = 200;

    /**
     * Scrape a website URL, extract text content, split into chunks, store in DB.
     * Returns number of chunks created, or 0 on failure.
     */
    public static function indexFromWebUrl(string $tenantId, string $url, ?string $title = null): int
    {
        try {
            $resp = Http::withOptions(['allow_redirects' => true])->timeout(20)->get($url);
            if (!$resp->ok()) {
                Log::warning("[WEB INDEX] failed to fetch {$url} status={$resp->status()}");
                return 0;
            }

            $html = $resp->body();
            // Strip scripts, styles, then all tags
            $text = preg_replace('/<script[^>]*>.*?<\/script>/si', ' ', $html);
            $text = preg_replace('/<style[^>]*>.*?<\/style>/si', ' ', $text);
            $text = preg_replace('/<[^>]+>/', ' ', $text);
            $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8');
            $text = preg_replace('/\s+/', ' ', trim($text));

            if (strlen($text) < 100) {
                Log::warning("[WEB INDEX] extracted text too short for {$url}");
                return 0;
            }

            // Remove existing chunks for this URL (re-index)
            TenantPdfChunk::where('tenant_id', $tenantId)->where('source_url', $url)->delete();

            $chunks = self::splitIntoChunks($text);
            self::storeChunks($tenantId, $url, $title, $chunks);

            Log::info("[WEB INDEX] indexed {$url}: " . count($chunks) . " chunks, " . strlen($text) . " chars");
            \Illuminate\Support\Facades\Cache::forget("has_pdf_chunks:{$tenantId}");
            return count($chunks);
        } catch (Throwable $e) {
            Log::warning("[WEB INDEX] error: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Download a file from URL, extract text based on extension, split into chunks, store in DB.
     * Returns number of chunks created, or 0 on failure.
     */
    public static function indexFromUrl(string $tenantId, string $url, ?string $title = null): int
    {
        try {
            // Get file extension from URL path
            $pathInfo = parse_url($url, PHP_URL_PATH);
            $ext = $pathInfo ? strtolower(pathinfo($pathInfo, PATHINFO_EXTENSION)) : '';

            // If no extension, check if it's Google Drive, otherwise default to web scraping
            if (empty($ext)) {
                if (preg_match('/drive\.google\.com/i', $url)) {
                    $ext = 'pdf'; // Default to PDF if Google Drive link but no extension
                } else {
                    return self::indexFromWebUrl($tenantId, $url, $title);
                }
            }

            // If it's a web page, scrape it
            if (in_array($ext, ['html', 'htm', 'php', 'asp', 'aspx'])) {
                return self::indexFromWebUrl($tenantId, $url, $title);
            }

            // Download file bytes
            $fileBytes = self::downloadFile($url);
            if ($fileBytes === null) return 0;

            // Save to a temporary file for parsing
            $tmpPath = tempnam(sys_get_temp_dir(), 'idx_');
            if ($tmpPath === false) return 0;
            
            // Append correct extension to temp file path so ZipArchive / parser can work if needed
            $tmpFileWithExt = $tmpPath . '.' . $ext;
            file_put_contents($tmpFileWithExt, $fileBytes);

            try {
                // Extract text
                $text = self::extractText($tmpFileWithExt, $ext);
            } finally {
                @unlink($tmpPath);
                @unlink($tmpFileWithExt);
            }

            if (!$text || strlen(trim($text)) < 20) {
                Log::warning("[FILE INDEX] extracted text too short or empty for {$url}");
                return 0;
            }

            // Remove existing chunks for this URL (re-index)
            TenantPdfChunk::where('tenant_id', $tenantId)->where('source_url', $url)->delete();

            // Split into chunks
            $chunks = self::splitIntoChunks($text);
            self::storeChunks($tenantId, $url, $title, $chunks);

            Log::info("[FILE INDEX] indexed {$url}: " . count($chunks) . " chunks, " . strlen($text) . " chars total");
            \Illuminate\Support\Facades\Cache::forget("has_pdf_chunks:{$tenantId}");
            return count($chunks);
        } catch (Throwable $e) {
            Log::warning("[FILE INDEX] error: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Search indexed PDF chunks for a query and synthesize an answer via GPT.
     * Returns the answer string or null if no relevant content found.
     */
    public static function search(string $tenantId, string $query, string $phone = '', bool $webMode = false): ?string
    {
        // Fast check: skip entirely if this tenant has no indexed chunks (cached 5 min)
        $hasPdfKey = "has_pdf_chunks:{$tenantId}";
        $hasPdf = \Illuminate\Support\Facades\Cache::remember($hasPdfKey, 300, function () use ($tenantId) {
            return TenantPdfChunk::where('tenant_id', $tenantId)->exists();
        });
        if (!$hasPdf) return null;
        // Determine allowed access levels based on user role
        $allowedLevels = ['all'];
        if ($phone !== '') {
            $isOwner = \App\Models\Tenant::query()->where('id', $tenantId)->where('phone', $phone)->exists();
            $superAdmins = config('mis.super_admin_phones', []);
            if ($isOwner || in_array($phone, $superAdmins, true)) {
                $allowedLevels = ['all', 'team', 'owner'];
            } elseif (\App\Models\UserDatabase::query()->where('phone', $phone)->where('tenant_id', $tenantId)->exists()) {
                $allowedLevels = ['all', 'team'];
            }
        }

        // Get accessible source URLs from tenant_links
        $accessibleUrls = \App\Models\TenantLink::where('tenant_id', $tenantId)
            ->whereIn('access_level', $allowedLevels)
            ->pluck('url')->toArray();

        if (empty($accessibleUrls)) {
            return null;
        }

        // Quick check: does the query mention any indexed PDF title OR does a short keyword appear in content?
        $titleMatch = false;
        $chunkQuery = TenantPdfChunk::where('tenant_id', $tenantId)->whereIn('source_url', $accessibleUrls);
        $titles = (clone $chunkQuery)->select('title')->distinct()->pluck('title')->filter()->toArray();
        $qLower = mb_strtolower($query);
        foreach ($titles as $t) {
            $tLower = mb_strtolower($t);
            if (str_contains($qLower, $tLower) || str_contains($tLower, $qLower)) {
                $titleMatch = true;
                break;
            }
            foreach (preg_split('/\s+/', $tLower) as $tw) {
                if (strlen($tw) >= 2 && str_contains($qLower, $tw)) {
                    $titleMatch = true;
                    break 2;
                }
            }
        }
        // Also check: do any 3+ char words from query appear in chunk content? (handles brand names like "MIS")
        if (!$titleMatch) {
            $shortWords = array_filter(preg_split('/\s+/', $qLower), fn($w) => strlen($w) >= 3);
            if (!empty($shortWords)) {
                $testChunk = (clone $chunkQuery)->where(function($b) use ($shortWords) {
                    foreach ($shortWords as $w) { $b->orWhere('content', 'LIKE', "%{$w}%"); }
                })->first();
                if ($testChunk) $titleMatch = true;
            }
        }

        // Find relevant chunks via keyword matching
        $chunks = self::findRelevantChunks($tenantId, $query, 8, $accessibleUrls);

        // Hybrid fallback: keyword matching found nothing — try semantic (embedding)
        // search, which catches paraphrased questions with no literal word overlap
        // with the source text. This is the "advanced mode" gap keyword-only search had.
        $viaEmbedding = false;
        if (empty($chunks)) {
            $embeddingChunks = self::findRelevantChunksByEmbedding($tenantId, $query, 8, $accessibleUrls);
            if (!empty($embeddingChunks)) {
                $chunks = $embeddingChunks;
                $viaEmbedding = true;
            }
        }

        if (empty($chunks) && !$titleMatch) return null;

        // If title matched but no content chunks, get first few chunks of that document
        if (empty($chunks) && $titleMatch) {
            $q = TenantPdfChunk::where('tenant_id', $tenantId);
            if (!empty($accessibleUrls)) $q->whereIn('source_url', $accessibleUrls);
            $chunks = $q->orderBy('chunk_index')->limit(3)->get()->all();
            if (empty($chunks)) return null;
        }

        // Score check: need at least 1 meaningful keyword match (3+ chars) OR title match.
        // Skipped when chunks came from the embedding fallback — a genuine paraphrase
        // legitimately scores 0 on literal keyword overlap.
        if (!$titleMatch && !$viaEmbedding) {
            $words = array_filter(preg_split('/\s+/', mb_strtolower($query)), fn($w) => strlen($w) >= 3);
            if (empty($words)) return null;
            $bestScore = 0;
            foreach ($chunks as $chunk) {
                $lower = mb_strtolower($chunk->content);
                $score = 0;
                foreach ($words as $w) {
                    if (str_contains($lower, $w)) $score++;
                }
                $bestScore = max($bestScore, $score);
            }
            if ($bestScore < 1) return null;
        }

        // Also include adjacent chunks for continuity
        $chunks = self::expandWithAdjacentChunks($chunks, $tenantId, $accessibleUrls);

        // Synthesize answer using GPT
        $context = implode("\n---\n", array_map(fn($c) => $c->content, $chunks));
        $titles = array_unique(array_filter(array_map(fn($c) => $c->title, $chunks)));
        $sourceLabel = !empty($titles) ? implode(', ', $titles) : 'uploaded documents';

        $apiKey = (string) config('mis.openai_api_key', '');
        if ($apiKey === '' && !$tenantId) return null;

        // Inject admin-customizable prompts
        $customStyle = \App\Models\TenantPrompt::get($tenantId, 'response_style') ?? '';
        $companyCtx = \App\Models\TenantPrompt::get($tenantId, 'company_context') ?? '';
        $extraInstructions = '';
        if ($customStyle) $extraInstructions .= "\n\nADDITIONAL STYLE INSTRUCTIONS: {$customStyle}";
        if ($companyCtx) $extraInstructions .= "\n\nCOMPANY CONTEXT: {$companyCtx}";

        try {
            if ($webMode) {
                $system = "You are a helpful RAG business assistant answering inside a web dashboard chat panel. Answer questions based on the provided document contents, spreadsheets, webpage contents, or reference manuals. The context may contain structured text, CSV row formats, database-like records, or text catalogs. Format rules:\n- Use standard Markdown: **bold** for key values, `-` for bullet lists, `1.` for numbered lists, `[label](url)` for links\n- Do NOT use emojis as bullet points\n- Separate sections with a blank line\n- Keep it clear and concise\n- Include specific numbers and details from context\n- If the answer is NOT in the context at all, reply with exactly: NONE{$extraInstructions}";
                $userInstruction = 'Provide a detailed answer using clean Markdown formatting.';
            } else {
                $system = "You are a helpful RAG business assistant. Answer questions based on the provided document contents, spreadsheets, webpage contents, or reference manuals. The context may contain structured text, CSV row formats, database-like records, or text catalogs. Format rules for WhatsApp:\n- Use plain text only. NO markdown headers (no #, ##, ###)\n- Use *text* for bold (WhatsApp style)\n- Use emojis as bullet points (📌, ✅, 🔹, 💡) instead of - or *\n- Separate sections with a blank line\n- Keep it conversational and engaging\n- Include specific numbers and details from context\n- If the answer is NOT in the context at all, reply with exactly: NONE\n\nExample good format:\n📌 *Item/Title*\nDescription here with details\n\n✅ *Another Point*\nMore info here{$extraInstructions}";
                $userInstruction = 'Provide a detailed answer using WhatsApp-friendly formatting.';
            }
            $messages = [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => "Source documents: {$sourceLabel}\n\nContext:\n{$context}\n\nQuestion: {$query}\n\n{$userInstruction} If you cannot answer, reply with exactly: NONE"],
            ];
            $aiResult = \App\Services\AI\AiGateway::chat($tenantId, $messages, ['temperature' => 0.3, 'max_tokens' => 1500, 'timeout' => 15]);

            if (!$aiResult['ok']) return null;
            $answer = trim($aiResult['content']);
            // If GPT says it can't answer from context, return null so SQL pipeline runs
            if ($answer === '' || strlen($answer) < 10 || stripos($answer, 'NONE') === 0 || str_contains(mb_strtolower($answer), 'does not provide') || str_contains(mb_strtolower($answer), 'not available in')) {
                return null;
            }
            return $webMode
                ? "📄 **From: {$sourceLabel}**\n\n{$answer}"
                : "📄 *From: {$sourceLabel}*\n\n{$answer}";
        } catch (Throwable $e) {
            Log::warning("[PDF SEARCH] GPT error: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Store chunks for a tenant/source, computing best-effort embeddings so search()
     * can rank/retrieve semantically, not just by literal keyword match. Centralized
     * here so all three index* entry points behave identically.
     *
     * Embeddings are fetched via one batched AiGateway::embedBatch() call (chunked
     * internally into groups of 50) rather than one API round-trip per chunk — on
     * hosting with no queue, an upload request has to complete within the server's
     * execution limit, and N sequential embedding calls for a large document risked
     * timing that out. An embedding failure (or the MAX_EMBEDDED_CHUNKS cap) never
     * blocks indexing — the chunk is still stored and stays keyword-searchable.
     *
     * @param  list<string>  $chunks
     */
    private static function storeChunks(string $tenantId, string $sourceUrl, ?string $title, array $chunks): void
    {
        if (empty($chunks)) return;

        $toEmbed = array_slice($chunks, 0, self::MAX_EMBEDDED_CHUNKS, true);
        $embeddings = AiGateway::embedBatch($tenantId, array_values($toEmbed));
        $embeddingByChunkIndex = array_combine(array_keys($toEmbed), $embeddings);

        foreach ($chunks as $chunkIndex => $chunk) {
            TenantPdfChunk::create([
                'tenant_id'   => $tenantId,
                'source_url'  => $sourceUrl,
                'title'       => $title,
                'chunk_index' => $chunkIndex,
                'content'     => $chunk,
                'embedding'   => $embeddingByChunkIndex[$chunkIndex] ?? null,
            ]);
        }
    }

    /**
     * Semantic fallback: rank chunks by cosine similarity to the query's embedding.
     * Used when keyword matching finds nothing — catches paraphrased questions that
     * share no literal words with the source text. Returns [] if the tenant has no
     * embeddings (e.g. non-OpenAI vendor) or nothing clears the similarity floor.
     *
     * @return list<TenantPdfChunk>
     */
    private static function findRelevantChunksByEmbedding(string $tenantId, string $query, int $limit, array $accessibleUrls): array
    {
        $queryVector = AiGateway::embed($tenantId, $query);
        if ($queryVector === null) return [];

        $q = TenantPdfChunk::where('tenant_id', $tenantId)->whereNotNull('embedding');
        if (!empty($accessibleUrls)) $q->whereIn('source_url', $accessibleUrls);

        // Bounded scan — per-tenant document sets from manual upload are small in practice.
        $candidates = $q->limit(500)->get();
        if ($candidates->isEmpty()) return [];

        $scored = [];
        foreach ($candidates as $chunk) {
            $vector = $chunk->embedding;
            if (!is_array($vector) || empty($vector)) continue;
            $scored[] = ['chunk' => $chunk, 'score' => self::cosineSimilarity($queryVector, $vector)];
        }

        usort($scored, fn($a, $b) => $b['score'] <=> $a['score']);

        // Similarity floor is a tunable heuristic to avoid surfacing weakly-related chunks.
        $top = array_filter(array_slice($scored, 0, $limit), fn($s) => $s['score'] >= 0.35);

        return array_values(array_map(fn($s) => $s['chunk'], $top));
    }

    private static function cosineSimilarity(array $a, array $b): float
    {
        $n = min(count($a), count($b));
        if ($n === 0) return 0.0;

        $dot = 0.0; $magA = 0.0; $magB = 0.0;
        for ($i = 0; $i < $n; $i++) {
            $dot += $a[$i] * $b[$i];
            $magA += $a[$i] * $a[$i];
            $magB += $b[$i] * $b[$i];
        }

        if ($magA <= 0.0 || $magB <= 0.0) return 0.0;
        return $dot / (sqrt($magA) * sqrt($magB));
    }

    /**
     * Expand matched chunks by including their adjacent chunks for better context continuity.
     */
    private static function expandWithAdjacentChunks(array $chunks, string $tenantId, array $accessibleUrls): array
    {
        if (empty($chunks)) return $chunks;

        $existing = [];
        foreach ($chunks as $c) {
            $existing[$c->source_url . ':' . $c->chunk_index] = true;
        }

        $extra = [];
        foreach ($chunks as $chunk) {
            $nextIdx = $chunk->chunk_index + 1;
            $key = $chunk->source_url . ':' . $nextIdx;
            if (!isset($existing[$key])) {
                $q = TenantPdfChunk::where('tenant_id', $tenantId)
                    ->where('source_url', $chunk->source_url)
                    ->where('chunk_index', $nextIdx);
                if ($adj = $q->first()) {
                    $extra[] = $adj;
                    $existing[$key] = true;
                }
            }
        }

        return array_merge($chunks, array_slice($extra, 0, 4)); // cap extra at 4
    }

    /**
     * Find chunks matching query keywords via SQL LIKE.
     * @return list<TenantPdfChunk>
     */
    private static function findRelevantChunks(string $tenantId, string $query, int $limit = 5, array $accessibleUrls = []): array
    {
        $words = array_filter(preg_split('/\s+/', mb_strtolower($query)), fn($w) => strlen($w) >= 3);
        if (empty($words)) return [];

        $q = TenantPdfChunk::where('tenant_id', $tenantId);
        if (!empty($accessibleUrls)) $q->whereIn('source_url', $accessibleUrls);

        // Score by number of matching words
        $q->where(function ($builder) use ($words) {
            foreach ($words as $word) {
                $builder->orWhere('content', 'LIKE', "%{$word}%");
            }
        });

        $results = $q->limit($limit * 3)->get();

        // Rank by word-match count
        $scored = [];
        foreach ($results as $chunk) {
            $lower = mb_strtolower($chunk->content);
            $score = 0;
            foreach ($words as $w) {
                if (str_contains($lower, $w)) $score++;
            }
            $scored[] = ['chunk' => $chunk, 'score' => $score];
        }

        usort($scored, fn($a, $b) => $b['score'] - $a['score']);
        return array_map(fn($s) => $s['chunk'], array_slice($scored, 0, $limit));
    }

    public static function downloadFile(string $url): ?string
    {
        try {
            // Handle Google Drive links
            if (preg_match('#drive\.google\.com/file/d/([a-zA-Z0-9_-]+)#', $url, $m)) {
                $url = "https://drive.google.com/uc?export=download&id={$m[1]}";
            } elseif (preg_match('#drive\.google\.com/open\?id=([a-zA-Z0-9_-]+)#', $url, $m)) {
                $url = "https://drive.google.com/uc?export=download&id={$m[1]}";
            }

            $resp = Http::withOptions(['allow_redirects' => true])->timeout(45)->get($url);
            if (!$resp->ok() || strlen($resp->body()) < 10) {
                Log::warning("[FILE DL] failed: {$url} status={$resp->status()}");
                return null;
            }
            return $resp->body();
        } catch (Throwable $e) {
            Log::warning("[FILE DL] error: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Index a local file. Useful for direct file uploads.
     */
    public static function indexLocalFile(string $tenantId, string $localFilePath, string $sourceUrl, ?string $title = null): int
    {
        try {
            $ext = strtolower(pathinfo($localFilePath, PATHINFO_EXTENSION));
            $text = self::extractText($localFilePath, $ext);

            if (!$text || strlen(trim($text)) < 20) {
                Log::warning("[LOCAL FILE INDEX] extracted text too short or empty for {$localFilePath}");
                return 0;
            }

            // Remove existing chunks for this URL (re-index)
            TenantPdfChunk::where('tenant_id', $tenantId)->where('source_url', $sourceUrl)->delete();

            // Split into chunks
            $chunks = self::splitIntoChunks($text);
            self::storeChunks($tenantId, $sourceUrl, $title, $chunks);

            Log::info("[LOCAL FILE INDEX] indexed {$localFilePath}: " . count($chunks) . " chunks, " . strlen($text) . " chars total");
            \Illuminate\Support\Facades\Cache::forget("has_pdf_chunks:{$tenantId}");
            return count($chunks);
        } catch (Throwable $e) {
            Log::warning("[LOCAL FILE INDEX] error: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Extract text from file path based on extension.
     */
    public static function extractText(string $filePath, string $ext): ?string
    {
        $ext = strtolower($ext);

        try {
            switch ($ext) {
                case 'pdf':
                    $parser = new Parser();
                    $pdf = $parser->parseFile($filePath);
                    return $pdf->getText();

                case 'docx':
                    return self::extractDocxText($filePath);

                case 'xlsx':
                case 'xls':
                    // Treat .xls as .xlsx for unzipping in case it is actually an xlsx renamed or modern format.
                    // True legacy binary .xls is not ZIP, ZipArchive will return false and we will handle gracefully.
                    return self::extractXlsxText($filePath);

                case 'csv':
                    return self::extractCsvText($filePath);

                case 'txt':
                case 'md':
                    return file_get_contents($filePath);

                default:
                    Log::warning("[KNOWLEDGE EXTRACT] unsupported extension: {$ext}");
                    return null;
            }
        } catch (Throwable $e) {
            Log::warning("[KNOWLEDGE EXTRACT] error parsing {$filePath} ({$ext}): " . $e->getMessage());
            return null;
        }
    }

    /**
     * Extract plain text from docx file using native XML parsing.
     */
    private static function extractDocxText(string $filePath): ?string
    {
        try {
            $zip = new \ZipArchive();
            if ($zip->open($filePath) !== true) {
                Log::warning("[DOCX PARSE] failed to open zip archive: {$filePath}");
                return null;
            }
            $xml = $zip->getFromName('word/document.xml');
            $zip->close();
            if (!$xml) {
                Log::warning("[DOCX PARSE] word/document.xml not found in zip");
                return null;
            }

            // Match all w:t tags (text tags in DOCX XML)
            preg_match_all('/<w:t[^>]*>(.*?)<\/w:t>/s', $xml, $matches);
            if (!empty($matches[1])) {
                return implode(' ', array_map(function($t) {
                    return html_entity_decode(strip_tags($t), ENT_QUOTES, 'UTF-8');
                }, $matches[1]));
            }
            return strip_tags($xml);
        } catch (Throwable $e) {
            Log::warning("[DOCX PARSE] error: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Extract text from CSV file.
     */
    private static function extractCsvText(string $filePath): ?string
    {
        try {
            if (($handle = fopen($filePath, "r")) === FALSE) {
                Log::warning("[CSV PARSE] failed to open file: {$filePath}");
                return null;
            }
            $headers = fgetcsv($handle);
            $rows = [];
            $rowNum = 1;
            while (($data = fgetcsv($handle)) !== FALSE) {
                $rowText = "Row {$rowNum}: ";
                foreach ($data as $index => $val) {
                    $colName = $headers[$index] ?? "Column " . ($index + 1);
                    $rowText .= "{$colName} = {$val}; ";
                }
                $rows[] = trim($rowText);
                $rowNum++;
            }
            fclose($handle);
            return implode("\n", $rows);
        } catch (Throwable $e) {
            Log::warning("[CSV PARSE] error: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Extract text from XLSX file using native XML parsing.
     */
    private static function extractXlsxText(string $filePath): ?string
    {
        try {
            $zip = new \ZipArchive();
            if ($zip->open($filePath) !== true) {
                Log::warning("[XLSX PARSE] failed to open zip archive: {$filePath}");
                return null;
            }

            // Read shared strings
            $sharedStrings = [];
            $stringsXml = $zip->getFromName('xl/sharedStrings.xml');
            if ($stringsXml) {
                preg_match_all('/<t[^>]*>(.*?)<\/t>/s', $stringsXml, $matches);
                if (!empty($matches[1])) {
                    $sharedStrings = array_map(function($t) {
                        return html_entity_decode(strip_tags($t), ENT_QUOTES, 'UTF-8');
                    }, $matches[1]);
                }
            }

            // Find worksheet files
            $worksheets = [];
            for ($i = 0; $i < $zip->numFiles; $i++) {
                $name = $zip->getNameIndex($i);
                if (str_starts_with($name, 'xl/worksheets/sheet') && str_ends_with($name, '.xml')) {
                    $worksheets[] = $name;
                }
            }

            $allText = [];
            foreach ($worksheets as $sheetName) {
                $sheetXml = $zip->getFromName($sheetName);
                if (!$sheetXml) continue;

                // Parse rows and columns from sheet XML
                preg_match_all('/<row[^>]*>(.*?)<\/row>/s', $sheetXml, $rowMatches);
                $rowNum = 1;
                foreach ($rowMatches[1] as $rowContent) {
                    $rowCells = [];
                    // Matches cells of format: <c r="A1" t="s"><v>0</v></c> OR <c r="B1"><v>123</v></c>
                    preg_match_all('/<c[^>]*t="([^"]+)"[^>]*>.*?<v>([^<]+)<\/v>.*?<\/c>|<c[^>]*>.*?<v>([^<]+)<\/v>.*?<\/c>/s', $rowContent, $cellMatches, PREG_SET_ORDER);
                    foreach ($cellMatches as $cell) {
                        $type = $cell[1] ?? '';
                        $val = ($type !== '') ? $cell[2] : $cell[3];

                        if ($type === 's') {
                            $idx = (int)$val;
                            $val = $sharedStrings[$idx] ?? '';
                        }
                        $rowCells[] = html_entity_decode(strip_tags($val), ENT_QUOTES, 'UTF-8');
                    }
                    if (!empty($rowCells)) {
                        $allText[] = "Row {$rowNum}: " . implode(' | ', $rowCells);
                    }
                    $rowNum++;
                }
            }
            $zip->close();
            return implode("\n", $allText);
        } catch (Throwable $e) {
            Log::warning("[XLSX PARSE] error: " . $e->getMessage());
            return null;
        }
    }

    private static function splitIntoChunks(string $text): array
    {
        $text = preg_replace('/\s+/', ' ', trim($text));
        $chunks = [];
        $len = strlen($text);
        $pos = 0;

        while ($pos < $len) {
            $chunk = substr($text, $pos, self::CHUNK_SIZE);
            $chunks[] = trim($chunk);
            $pos += self::CHUNK_SIZE - self::CHUNK_OVERLAP;
        }

        return array_filter($chunks, fn($c) => strlen($c) > 50);
    }
}
