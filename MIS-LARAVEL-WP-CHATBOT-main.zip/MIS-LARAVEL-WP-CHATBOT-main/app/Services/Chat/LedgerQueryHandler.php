<?php

declare(strict_types=1);

namespace App\Services\Chat;

use App\Models\Tenant;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Throwable;

/**
 * LedgerQueryHandler — orchestrates the ledger query pipeline.
 *
 * Flow:
 *   1. detectLedgerTables(tenant.tables_metadata) — find ledger-shaped tables.
 *      None → friendly error "no ledger table here".
 *   1a. Multi-turn preselected (Z20) — when called via TenantRouter pending continuation
 *       with opts={preselected: <name>}, skips entity extraction + name search and renders
 *       the PDF directly.
 *   2. extractEntityFromQuery(query) — pull party name from "X ka ledger" patterns.
 *      No entity → ask "Kis party ka ledger?".
 *   3. searchLedgerNames(ledger, term) — ILIKE → fuzzy fallback.
 *      0 matches → "naam nahi mila" message.
 *      1 match  → fetch all rows + render PDF + return media payload.
 *      2-8 matches → numbered list reply + save options to PendingStateStore (Z20 multi-turn).
 *   4. buildPdfResult — runs fetchLedgerForName + LedgerPdfBuilder::render.
 *      Computes Dr/Cr totals + closing balance for the WhatsApp summary text.
 *
 * @return array  one of:
 *   - {reply, intent:'NO_LEDGER_TABLES'}
 *   - {reply, intent:'LEDGER_NEEDS_ENTITY'}
 *   - {reply, intent:'LEDGER_NOT_FOUND'}
 *   - {reply, intent:'LEDGER_DISAMBIGUATE', matches:[...]}
 *   - {reply, intent:'LEDGER_QUERY', media:{type:document, path, filename}, ledger:{...}}
 *   - {reply, intent:'LEDGER_ERROR'} on any unhandled exception
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-router.js (~lines 651-790)
 */
final class LedgerQueryHandler
{
    /**
     * Handle a ledger query end-to-end.
     *
     * @param  string|null  $phone  digits-only phone, used for multi-turn pending state (Z20).
     *                              When provided, multi-match disambiguation saves state so the
     *                              user's next reply ("2" or "NPL Industries") gets resolved
     *                              at TenantRouter pending-check entry.
     * @param  array{preselected?: string}|null  $opts  when {preselected: string} is set, skips
     *                                                  entity extraction + ILIKE/fuzzy search and
     *                                                  goes straight to PDF render. Used by
     *                                                  TenantRouter pending continuation.
     * @return array<string, mixed>
     */
    public static function handle(Tenant $tenant, string $query, ?string $phone = null, ?array $opts = null): array
    {
        $tablesMetadata = $tenant->tables_metadata ?? [];

        // 1. Detect ledger-shaped tables
        $ledgers = LedgerEntityResolver::detectLedgerTables(is_array($tablesMetadata) ? $tablesMetadata : []);
        $ledgersBeforeAccessFilter = count($ledgers);

        // Filter by access control — only keep tables the user is allowed to see.
        // Always filter when accessFilter is non-null (access control IS configured
        // for this tenant) — not only `!empty($accessFilter['allowed_tables'])`.
        // An empty allowed_tables is a real "this phone matched nothing" outcome
        // (see TenantRouter::computeAccessFilter's CLIENT match check); skipping the
        // filter in that case would silently hand the user every ledger table.
        $accessFilter = $opts['accessFilter'] ?? null;
        if ($accessFilter !== null) {
            $allowed = $accessFilter['allowed_tables'] ?? [];
            $ledgers = array_values(array_filter($ledgers, fn($l) => in_array($l['pgTable'], $allowed, true)));
        }

        if (count($ledgers) === 0) {
            if ($ledgersBeforeAccessFilter > 0) {
                // Ledger tables exist but access control filtered all of them out —
                // this is a permissions issue, not "no ledger tables configured".
                return [
                    'reply'  => "🔒 You don't have access to any ledger data. Please contact the admin.",
                    'intent' => 'ACCESS_DENIED',
                ];
            }

            return [
                'reply'  => "📒 No ledger-type table found in this database.\n\n"
                          ."For ledger queries, the sheet should have columns like \"Debit\", \"Credit\", \"Voucher No\", \"Particular\". "
                          ."Or try a regular text query (e.g. \"What is Pansari's total sales?\").",
                'intent' => 'NO_LEDGER_TABLES',
            ];
        }

        $whereConstraint = null;
        if (!empty($ledgers)) {
            $ledger = $ledgers[0];
            if ($accessFilter !== null && !empty($accessFilter['where_constraints'])) {
                $whereConstraint = $accessFilter['where_constraints'][$ledger['pgTable']] ?? null;
            }
        }

        // 1a. Multi-turn preselected path (Z20) — user picked from a prior disambiguation list.
        // Skip entity extraction + name search; render the PDF directly.
        if ($opts !== null && ! empty($opts['preselected'])) {
            $preselected = (string) $opts['preselected'];
            $ledger = $ledgers[0];
            Log::info("[TENANT LEDGER PRESELECTED] table={$ledger['pgTable']} entity=\"{$preselected}\"");
            try {
                if ($phone !== null) PendingStateStore::clear($phone);

                return self::buildPdfResult($ledger, $preselected, $tenant->name ?? 'Database', $whereConstraint, $tenant->id);
            } catch (Throwable $e) {
                Log::error('[TENANT LEDGER PRESELECTED PDF] '.$e->getMessage(), [
                    'trace' => substr($e->getTraceAsString(), 0, 500),
                ]);

                return [
                    'reply'  => '❌ Could not generate ledger PDF. Please try again.',
                    'intent' => 'LEDGER_ERROR',
                ];
            }
        }

        // 2. Entity extraction
        $entity = LedgerEntityResolver::extractEntityFromQuery($query);
        if ($entity === null) {
            return [
                'reply'  => '📒 Which party/company\'s ledger do you need? Please specify the name — for example: "Send Pansari Industries\' ledger".',
                'intent' => 'LEDGER_NEEDS_ENTITY',
            ];
        }

        // For now, search the first detected ledger table. (Multi-ledger-table tenants are rare.)
        $ledger = $ledgers[0];
        Log::info('[TENANT LEDGER] table='.$ledger['pgTable']." nameCol={$ledger['mapping']['nameCol']} entity=\"{$entity}\"");

        // 3. Name search (ILIKE → fuzzy)
        try {
            $search = LedgerEntityResolver::searchLedgerNames($ledger, $entity, $whereConstraint);
        } catch (Throwable $e) {
            Log::error('[TENANT LEDGER SEARCH] '.$e->getMessage());

            return [
                'reply'  => '❌ Ledger search failed. Please try again.',
                'intent' => 'LEDGER_ERROR',
            ];
        }

        $matches = $search['matches'];
        $fuzzy = $search['fuzzy'];

        // 0 matches
        if (count($matches) === 0) {
            return [
                'reply'  => "📭 No account named \"{$entity}\" found in the ledger. Please check the spelling or try a different name.",
                'intent' => 'LEDGER_NOT_FOUND',
            ];
        }

        // Single match → render PDF directly
        if (count($matches) === 1) {
            try {
                $result = self::buildPdfResult($ledger, $matches[0], $tenant->name ?? 'Database', $whereConstraint, $tenant->id);
                if ($fuzzy) {
                    $result['reply'] = "_(Couldn't find an exact match for \"{$entity}\" — using the closest one: {$matches[0]})_\n\n".$result['reply'];
                }
                if ($phone !== null) PendingStateStore::clear($phone);

                return $result;
            } catch (Throwable $e) {
                Log::error('[TENANT LEDGER PDF] '.$e->getMessage(), [
                    'trace' => substr($e->getTraceAsString(), 0, 500),
                ]);

                return [
                    'reply'  => '❌ Could not generate ledger PDF. Please try again.',
                    'intent' => 'LEDGER_ERROR',
                ];
            }
        }

        // Multi-match → numbered list (disambiguation).
        // Z20: save options to PendingStateStore so the user's next reply ("2" or a name)
        // gets resolved at TenantRouter pending-check entry and routed back here with
        // opts={preselected: <name>}. State has 5-min TTL.
        if ($phone !== null) {
            PendingStateStore::set($phone, [
                'kind'           => 'ledger',
                'options'        => $matches,
                'ledger_idx'     => 0,
                'tenant_db_name' => (string) ($tenant->name ?? 'Database'),
            ]);
        }

        $listLines = [];
        foreach ($matches as $i => $name) {
            $listLines[] = ($i + 1).'. '.$name;
        }
        $list = implode("\n", $listLines);
        $header = $fuzzy
            ? "📋 No exact match for *{$entity}*. Here are similar accounts:"
            : "🏢 Multiple accounts found for *{$entity}*:";

        return [
            'reply'   => "{$header}\n\n{$list}\n\n_Reply with the number (e.g. \"2\") or the full name to pick one._",
            'intent'  => 'LEDGER_DISAMBIGUATE',
            'matches' => $matches,
        ];
    }

    /**
     * Fetch rows for the resolved entity, render PDF, build the WhatsApp reply payload.
     *
     * @param  array{pgTable:string, sourceName:string, mapping:array}  $ledger
     * @return array{reply:string, intent:string, media:array, ledger:array, raw_rows:array, pdf_url:?string}
     *
     * @throws \RuntimeException
     */
    private static function buildPdfResult(array $ledger, string $entityName, string $tenantName, ?string $whereConstraint = null, ?string $tenantId = null): array
    {
        $rows = LedgerEntityResolver::fetchLedgerForName($ledger, $entityName, $whereConstraint);
        if (count($rows) === 0) {
            throw new \RuntimeException("No transactions found for \"{$entityName}\".");
        }

        $mapping = $ledger['mapping'];
        $tabName = $ledger['sourceName'] !== '' ? $ledger['sourceName'] : $ledger['pgTable'];

        // Render PDF
        $pdfPath = LedgerPdfBuilder::render($rows, $mapping, [
            'entityName' => $entityName,
            'dbName'     => $tenantName,
            'tabName'    => $tabName,
        ]);

        // Compute summary stats for the reply text
        $balanceMarkers = ['Opening Balance', 'Closing Balance', ''];
        $txns = $rows;
        if ($mapping['particularCol'] ?? null) {
            $txns = array_values(array_filter($rows, static function ($r) use ($mapping, $balanceMarkers) {
                $p = trim((string) ($r[$mapping['particularCol']] ?? ''));

                return $p !== '' && ! in_array($p, $balanceMarkers, true);
            }));
        }

        $totalDr = 0.0;
        $totalCr = 0.0;
        if ($mapping['debitCol'] ?? null) {
            foreach ($txns as $r) $totalDr += (float) ($r[$mapping['debitCol']] ?? 0);
        }
        if ($mapping['creditCol'] ?? null) {
            foreach ($txns as $r) $totalCr += (float) ($r[$mapping['creditCol']] ?? 0);
        }

        $closeBal = ($mapping['closingBalanceCol'] ?? null)
            ? (float) ($rows[count($rows) - 1][$mapping['closingBalanceCol']] ?? 0)
            : ($totalDr - $totalCr);

        $drCr = $closeBal >= 0 ? '(Dr)' : '(Cr)';
        $closeAmt = number_format(abs($closeBal), 2, '.', ',');

        // Compute opening balance for reply text
        $openBal = 0.0;
        if ($mapping['openingBalanceCol'] ?? null) {
            $openDebitCol = null; $openCreditCol = null;
            foreach ($rows[0] as $k => $v) {
                if (preg_match('/opening.*debit|open.*debit/i', $k)) $openDebitCol = $k;
                if (preg_match('/opening.*credit|open.*credit/i', $k)) $openCreditCol = $k;
            }
            if ($openDebitCol && $openCreditCol) {
                $openBal = (float) ($rows[0][$openDebitCol] ?? 0) - (float) ($rows[0][$openCreditCol] ?? 0);
            } else {
                $openBal = (float) ($rows[0][$mapping['openingBalanceCol']] ?? 0);
            }
        }
        $openDrCr = $openBal >= 0 ? '(Dr)' : '(Cr)';
        $openAmt = number_format(abs($openBal), 2, '.', ',');
        $openLine = "📖 Opening Balance: ₹{$openAmt} {$openDrCr}\n";

        // Sanitize entity name for PDF filename — strip non-ASCII / problematic chars
        $safeFilename = preg_replace('/[^A-Za-z0-9 \-_.]/', '', $entityName) ?? $entityName;
        $safeFilename = trim($safeFilename) ?: 'Ledger';

        // Persist a copy to public storage so the web panel can offer a real, stable
        // download link (not just a base64 blob) — keyed by tenant+entity so re-running
        // the same ledger query overwrites in place rather than accumulating files.
        $pdfUrl = null;
        if ($tenantId !== null) {
            try {
                $publicPath = "ledgers/{$tenantId}/".Str::slug($safeFilename ?: $entityName).'.pdf';
                Storage::disk('public')->put($publicPath, file_get_contents($pdfPath));
                $pdfUrl = asset('storage/'.$publicPath);
            } catch (Throwable $e) {
                Log::warning('[LEDGER PDF PERSIST] '.$e->getMessage());
            }
        }

        return [
            'reply'  => "📒 *Ledger: {$entityName}*\n"
                       ."{$openLine}"
                       ."📝 Transactions: ".count($txns)."\n"
                       ."💰 Closing Balance: ₹{$closeAmt} {$drCr}\n\n"
                       ."📄 Sending PDF...",
            'intent' => 'LEDGER_QUERY',
            'media'  => [
                'type'     => 'document',
                'path'     => $pdfPath,
                'filename' => $safeFilename.' — Ledger.pdf',
                'caption'  => "📒 {$entityName} — Ledger",
                'url'      => $pdfUrl,
            ],
            // Web panel builds an HTML table from these transaction rows — same rows
            // rendered in the PDF (balance-marker rows already excluded above).
            'raw_rows' => $txns,
            'pdf_url'  => $pdfUrl,
            'ledger' => [
                'entity'        => $entityName,
                'txn_count'     => count($txns),
                'closing_bal'   => $closeBal,
                'total_debit'   => $totalDr,
                'total_credit'  => $totalCr,
                'pdf_path'      => $pdfPath,
            ],
        ];
    }
}
