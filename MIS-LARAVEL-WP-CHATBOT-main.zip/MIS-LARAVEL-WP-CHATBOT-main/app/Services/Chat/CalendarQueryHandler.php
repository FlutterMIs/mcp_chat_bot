<?php

declare(strict_types=1);

namespace App\Services\Chat;

use App\Models\Tenant;
use App\Services\Google\CalendarService;
use App\Services\Notifications\TenantNotificationService;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * CalendarQueryHandler — calendar intent for both WhatsApp + web bots (via TenantRouter::handle).
 *
 *   RETRIEVE — "aaj ki meetings" → today's list.
 *   CANCEL   — searches the next 12 months (not just today). Supports name filter,
 *              date filter ("cancel meeting on 5 june"), "cancel all", and a number-pick
 *              disambiguation (cancel_select pending state, resolved in TenantRouter).
 *   BOOK     — AI parse → processPlan. Multi-turn is deterministic: the parsed plan is stored
 *              in pending state and on each reply we merge ONLY the missing piece (sticky
 *              fields → fixes the wrong-weekday bug). Recurring without a duration asks
 *              "kitne time tak?"; 10+ occurrences ask haan/na before booking.
 *
 * Every successful book/cancel appends the tenant's upcoming schedule, and fires
 * TenantNotificationService (WhatsApp + email).
 */
final class CalendarQueryHandler
{
    private const MAX_RECURRING = 365;
    private const BULK_CONFIRM_THRESHOLD = 10;
    private const SCHEDULE_LIST_LIMIT = 10;
    private const WINDOW_MONTHS = 12;

    /** @return array<string, mixed> */
    public static function handle(Tenant $tenant, string $query, ?string $phone = null): array
    {
        if (self::rt($tenant) === '') {
            return ['reply' => '📅 Calendar is not connected.', 'intent' => 'CALENDAR_NOT_CONNECTED'];
        }

        $q = mb_strtolower($query);

        // RETRIEVE — today's/tomorrow's meetings.
        if (
            preg_match('/\b(aaj|today)\b|meetings?\s*(batao|dikhao|list)|meeking\s*list|coming\s*week\s*meet|schedule|tomorrow|kal/i', $q)
            && ! preg_match('/\b(book|buk|cancel|delete|hatao|remove)\b/i', $q)
        ) {
            if ($phone !== null) PendingStateStore::clear($phone);

            return self::retrieveSchedule(self::rt($tenant), self::cal($tenant), $q);
        }

        // CANCEL.
        if (preg_match('/\b(cancel|delete|hatao|remove)\b/i', $q)) {
            if ($phone !== null) PendingStateStore::clear($phone);

            return self::cancelMeetings($tenant, $query, $phone);
        }

        // BOOK (fresh — no seed).
        return self::bookFromQuery($tenant, $query, $phone);
    }

    /**
     * Resume a multi-turn booking from pending state. Called by TenantRouter.
     *
     * @param  array<string, mixed>  $pending  {expecting, plan}
     * @return array<string, mixed>
     */
    public static function continueBooking(Tenant $tenant, array $pending, string $reply, ?string $phone): array
    {
        $expecting = (string) ($pending['expecting'] ?? '');
        $plan = (array) ($pending['plan'] ?? []);

        if ($expecting === 'date' || $expecting === 'time') {
            return self::bookFromQuery($tenant, $reply, $phone, $plan);
        }

        if ($expecting === 'duration') {
            $recurring = strtolower((string) ($plan['recurring'] ?? 'weekly'));
            $interval = (int) ($plan['interval_days'] ?? ($recurring === 'daily' ? 1 : ($recurring === 'monthly' ? 30 : 7)));
            $count = self::parseDurationToCount($reply, $interval);
            if ($count <= 0) {
                self::savePending($phone, 'duration', $plan);

                return ['reply' => "🤔 Samajh nahi aaya. Reply like \"3 weeks\", \"1 month\" or \"1 year\".", 'intent' => 'CALENDAR_NEEDS_DURATION'];
            }
            $plan['count'] = $count;

            return self::processPlan($tenant, $plan, $phone);
        }

        if ($expecting === 'confirm') {
            $r = mb_strtolower(trim($reply));
            if (preg_match('/\b(haan|han|haa|ha|yes|yeah|yep|ok|okay|sure|theek|thik|confirm|book)\b/', $r)) {
                return self::processPlan($tenant, $plan, $phone, true);
            }
            if (preg_match('/\b(na|nahi|nahin|no|nope|mat|rehne|rahne|cancel)\b/', $r)) {
                if ($phone !== null) PendingStateStore::clear($phone);

                return ['reply' => '👍 Theek hai, booking cancel kar di.', 'intent' => 'CALENDAR_BOOK_ABORTED'];
            }
            self::savePending($phone, 'confirm', $plan);

            return ['reply' => '❓ Pakka book karu? _(haan / na)_', 'intent' => 'CALENDAR_CONFIRM_BULK'];
        }

        // Unknown — treat reply as a fresh booking seeded with whatever we had.
        return self::bookFromQuery($tenant, $reply, $phone, $plan);
    }

    // ════════════════════════════════════════════════════════════ RETRIEVE

    /** @return array<string, mixed> */
    private static function retrieveSchedule(string $refreshToken, string $calendarId, string $query): array
    {
        $tz = new \DateTimeZone(CalendarService::TIMEZONE);

        // Detect target day
        $isTomorrow = (bool) preg_match('/\b(tomorrow|kal|tmrw|tmrow)\b/i', $query);
        $day = $isTomorrow
            ? new \DateTimeImmutable('tomorrow', $tz)
            : new \DateTimeImmutable('today', $tz);
        $label = $isTomorrow ? "Tomorrow's" : "Today's";

        try {
            $from = $day->setTime(0, 0)->format('c');
            $to = $day->setTime(23, 59, 59)->format('c');
            $events = CalendarService::getEvents($refreshToken, $calendarId, $from, $to);
        } catch (Throwable $e) {
            Log::error('[CALENDAR RETRIEVE] '.$e->getMessage());
            return ['reply' => '⚠️ Could not fetch meetings. Please try again.', 'intent' => 'CALENDAR_ERROR'];
        }

        if (count($events) === 0) {
            return ['reply' => "📅 No meetings scheduled for {$label} day.", 'intent' => 'CALENDAR_RETRIEVED', 'events' => []];
        }

        $lines = [];
        foreach ($events as $i => $e) {
            $lines[] = ($i + 1).'. '.self::eventLabel($e, $tz);
        }

        return [
            'reply'  => "📅 *{$label} meetings (".count($events)."):*\n\n".implode("\n", $lines),
            'intent' => 'CALENDAR_RETRIEVED',
            'events' => $events,
        ];
    }

    // ════════════════════════════════════════════════════════════ CANCEL

    /** @return array<string, mixed> */
    private static function cancelMeetings(Tenant $tenant, string $query, ?string $phone): array
    {
        $rt = self::rt($tenant);
        $cal = self::cal($tenant);

        try {
            [$from, $to] = self::window(true);
            $events = CalendarService::getEvents($rt, $cal, $from, $to);
        } catch (Throwable $e) {
            Log::error('[CALENDAR CANCEL FETCH] '.$e->getMessage());

            return ['reply' => '⚠️ Could not fetch your meetings to cancel. Please try again.', 'intent' => 'CALENDAR_ERROR'];
        }

        if (count($events) === 0) {
            return ['reply' => '📅 No upcoming meetings to cancel.', 'intent' => 'CALENDAR_NOTHING_TO_CANCEL'];
        }

        $wantsAll = (bool) preg_match('/\b(all|saari|saare|sare|sab|sabhi|everything)\b/', mb_strtolower($query));
        $date = self::extractCancelDate($query);
        $term = self::extractCancelTerm($query);

        // Each filter only NARROWS — if applying it would eliminate everything, it is ignored,
        // so leftover junk words or an over-specific date can never produce a false "no match".
        $candidates = $events;
        if ($date !== null) {
            $tz = new \DateTimeZone(CalendarService::TIMEZONE);
            $byDate = array_values(array_filter($candidates, static function ($e) use ($date, $tz) {
                $s = (string) ($e['start'] ?? '');
                if ($s === '') return false;
                try {
                    return (new \DateTimeImmutable($s))->setTimezone($tz)->format('Y-m-d') === $date;
                } catch (Throwable) {
                    return false;
                }
            }));
            if (count($byDate) > 0) $candidates = $byDate;
        }
        if ($term !== '') {
            $byName = array_values(array_filter(
                $candidates,
                static fn ($e) => stripos((string) ($e['summary'] ?? ''), $term) !== false
            ));
            if (count($byName) > 0) $candidates = $byName;
        }

        // Delete when explicitly "all", or a single unambiguous match.
        if ($wantsAll || count($candidates) === 1) {
            $cancelled = [];
            $skipped = 0;
            foreach ($candidates as $e) {
                // Skip birthday/non-deletable events
                $summary = mb_strtolower((string) ($e['summary'] ?? ''));
                if (($e['all_day'] ?? false) && str_contains($summary, 'birthday')) {
                    $skipped++;
                    continue;
                }
                try {
                    CalendarService::deleteEvent($rt, $cal, (string) $e['id']);
                    $cancelled[] = (string) ($e['summary'] ?? 'Meeting');
                } catch (Throwable $ex) {
                    Log::error('[CALENDAR CANCEL] '.$ex->getMessage());
                    $skipped++;
                }
            }
            if (count($cancelled) === 0) {
                $msg = $skipped > 0
                    ? '📅 No cancellable meetings found (birthdays and special events cannot be cancelled).'
                    : '⚠️ Could not cancel. Please try again.';
                return ['reply' => $msg, 'intent' => $skipped > 0 ? 'CALENDAR_NOTHING_TO_CANCEL' : 'CALENDAR_ERROR'];
            }
            if ($phone !== null) PendingStateStore::clear($phone);

            TenantNotificationService::notifyCancellation($tenant, count($cancelled) === 1 ? $cancelled[0] : count($cancelled).' meetings');

            $reply = count($cancelled) === 1
                ? "✅ Meeting cancelled: *{$cancelled[0]}*"
                : '✅ *'.count($cancelled).' meetings cancelled.*';

            return ['reply' => $reply.self::upcomingScheduleText($tenant), 'intent' => 'CALENDAR_CANCELLED'];
        }

        // Multiple — disambiguate with date+time labels via cancel_select pending state.
        $tz = new \DateTimeZone(CalendarService::TIMEZONE);
        $options = array_map(static fn ($e) => [
            'id'      => (string) ($e['id'] ?? ''),
            'summary' => (string) ($e['summary'] ?? 'No title'),
            'label'   => self::eventLabel($e, $tz),
        ], $candidates);

        if ($phone !== null) {
            PendingStateStore::set($phone, ['kind' => 'cancel_select', 'options' => $options]);
        }

        $lines = [];
        foreach ($options as $i => $o) {
            $lines[] = ($i + 1).'. '.$o['label'];
        }

        return [
            'reply'  => "📅 Which one would you like to cancel?\n\n".implode("\n", $lines)."\n\n_Reply with the number (e.g. \"1\")._",
            'intent' => 'CALENDAR_CANCEL_DISAMBIGUATE',
            'events' => $candidates,
        ];
    }

    /** Strip cancel verbs, filler, weekdays, months, am/pm, numbers — leaves the real name (or ''). */
    private static function extractCancelTerm(string $query): string
    {
        $q = mb_strtolower(trim($query));
        $q = (string) preg_replace('/\b(cancel|delete|hatao|hatado|remove|meetings?|meets?|with|the|my|mere|meri|mera|it|isse|is|ye|yeh|these|this|that|those|all|saari|saare|sare|sab|sabhi|please|plz|kardo|kar|kr|do|bro|wala|wali|on|ko|ki|ka|ke|want|wanna|to|i|an|krna|krni|book|schedule|appointment|every|har|each|at|am|pm|mon|tue|tues|wed|wednes|thu|thur|thurs|fri|sat|sun|monday|tuesday|wednesday|thursday|friday|saturday|sunday|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|january|february|march|april|june|july|august|september|october|november|december)\b/', ' ', $q);
        $q = (string) preg_replace('/[^a-z ]+/', ' ', $q);
        // Keep only meaningful tokens (≥3 chars) so leftover noise ("a", "wed", "pm") never becomes a filter.
        $tokens = array_filter(preg_split('/\s+/', trim($q)) ?: [], static fn ($t) => mb_strlen($t) >= 3);

        return trim(implode(' ', $tokens));
    }

    /** Detect a recurrence signal from free text — any weekday / English or Hindi. */
    private static function detectRecurrence(string $q): ?array
    {
        $q = mb_strtolower($q);
        if (preg_match('/\b(daily|every\s*day|har\s*din|roz|each\s*day)\b/', $q)) return ['recurring' => 'daily', 'interval_days' => 1];
        if (preg_match('/\b(monthly|every\s*month|har\s*mah(ina|ine)?|each\s*month)\b/', $q)) return ['recurring' => 'monthly', 'interval_days' => 30];
        if (preg_match('/\b(weekly|every\s*week|har\s*haft[ae]|each\s*week)\b/', $q)) return ['recurring' => 'weekly', 'interval_days' => 7];
        $wd = '(?:mon|tue|tues|wed|wednes|thu|thur|thurs|fri|sat|sun)[a-z]*|monday|tuesday|wednesday|thursday|friday|saturday|sunday';
        if (preg_match('/\b(?:every|har|each|prati)\s+(?:'.$wd.')\b/', $q)) return ['recurring' => 'weekly', 'interval_days' => 7];

        return null;
    }

    /** Pull a date out of a cancel query ("5 june 2026", "5june", "june 5", "5/6/26"). */
    private static function extractCancelDate(string $query): ?string
    {
        $q = mb_strtolower($query);
        $mm = ['jan' => 1, 'feb' => 2, 'mar' => 3, 'apr' => 4, 'may' => 5, 'jun' => 6, 'jul' => 7, 'aug' => 8, 'sep' => 9, 'oct' => 10, 'nov' => 11, 'dec' => 12];

        if (preg_match('/\b(\d{1,2})\s*(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*(\d{4})?/', $q, $m)) {
            return self::ymd((int) $m[1], $mm[$m[2]], isset($m[3]) && $m[3] !== '' ? (int) $m[3] : null);
        }
        if (preg_match('/\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s*(\d{1,2})\b\s*(\d{4})?/', $q, $m)) {
            return self::ymd((int) $m[2], $mm[$m[1]], isset($m[3]) && $m[3] !== '' ? (int) $m[3] : null);
        }
        if (preg_match('/\b(\d{1,2})[\/\-](\d{1,2})(?:[\/\-](\d{2,4}))?\b/', $q, $m)) {
            $mo = (int) $m[2];
            $d = (int) $m[1];
            if ($mo >= 1 && $mo <= 12 && $d >= 1 && $d <= 31) {
                return self::ymd($d, $mo, isset($m[3]) && $m[3] !== '' ? (int) $m[3] : null);
            }
        }

        return null;
    }

    private static function ymd(int $d, int $mo, ?int $y): ?string
    {
        $tz = new \DateTimeZone(CalendarService::TIMEZONE);
        $today = new \DateTimeImmutable('today', $tz);
        $year = $y ?? (int) $today->format('Y');
        if ($y !== null && $y < 100) $year = 2000 + $y;
        if (! checkdate($mo, $d, $year)) return null;
        $cand = \DateTimeImmutable::createFromFormat('!Y-n-j', "{$year}-{$mo}-{$d}", $tz);
        if ($cand === false) return null;
        if ($y === null && $cand < $today) $cand = $cand->modify('+1 year');

        return $cand->format('Y-m-d');
    }

    // ════════════════════════════════════════════════════════════ BOOK

    /**
     * Parse the query (seeded with $known for continuations) → plan → processPlan.
     *
     * @param  array<string, mixed>  $known
     * @return array<string, mixed>
     */
    private static function bookFromQuery(Tenant $tenant, string $query, ?string $phone, array $known = []): array
    {
        $today = (new \DateTimeImmutable('today', new \DateTimeZone(CalendarService::TIMEZONE)))->format('Y-m-d');
        $parsed = self::aiParse($tenant->id, $query, $today, $known);
        if ($parsed === null) {
            return ['reply' => '🤔 Could not understand the meeting details. Try: "Book a meeting with Sharma at 3 PM tomorrow".', 'intent' => 'CALENDAR_PARSE_FAILED'];
        }

        if (empty($parsed['guest_email']) && preg_match('/[\w.+-]+@[\w-]+\.[\w.-]+/', $query, $m)) {
            $parsed['guest_email'] = $m[0];
        }

        // Dynamic recurrence safety-net — the AI sometimes misses "every <weekday>" / "weekly".
        // Detect from the user's own words; if recurring with no stated duration → ask "kitne tak?".
        $recur = self::detectRecurrence($query);
        if ($recur !== null && ($parsed['recurring'] ?? 'none') === 'none') {
            $parsed['recurring'] = $recur['recurring'];
            $parsed['interval_days'] = $recur['interval_days'];
        }
        if (($parsed['recurring'] ?? 'none') !== 'none') {
            $lq = mb_strtolower($query);
            $hasDuration = (bool) preg_match('/\b\d+\s*(day|din|week|haft|month|mah|year|saal|varsh)/', $lq)
                || (bool) preg_match('/\b(till|until|upto|up\s*to|tak)\b/', $lq);
            $cnt = $parsed['count'] ?? null;
            if (! $hasDuration && (! is_numeric($cnt) || (int) $cnt <= 1)) {
                $parsed['count'] = 'ASK';
            }
        }

        return self::processPlan($tenant, self::mergePlan($known, $parsed), $phone);
    }

    /**
     * Drive a (possibly partial) plan to completion: ask for missing date/time/duration,
     * confirm bulk, then create the occurrences.
     *
     * @param  array<string, mixed>  $plan
     * @return array<string, mixed>
     */
    private static function processPlan(Tenant $tenant, array $plan, ?string $phone, bool $confirmed = false): array
    {
        $title = trim((string) ($plan['title'] ?? 'Meeting')) ?: 'Meeting';
        $date = (string) ($plan['date'] ?? 'ASK');
        $time = (string) ($plan['time'] ?? 'ASK');

        if ($date === 'ASK' || $date === '') {
            self::savePending($phone, 'date', $plan);

            return ['reply' => "📅 To book *{$title}*, please tell me the date.\n\n_Reply like \"27 May\" or \"tomorrow\"._", 'intent' => 'CALENDAR_NEEDS_DATE'];
        }
        if ($time === 'ASK' || $time === '') {
            self::savePending($phone, 'time', $plan);

            return ['reply' => "📅 To book *{$title}* on {$date}, please tell me the time.\n\n_Reply like \"3 PM\" or \"15:00\"._", 'intent' => 'CALENDAR_NEEDS_TIME'];
        }

        $recurring = strtolower((string) ($plan['recurring'] ?? 'none'));
        $intervalDays = (int) ($plan['interval_days'] ?? 0);
        if ($recurring === 'daily' && $intervalDays === 0)   $intervalDays = 1;
        if ($recurring === 'weekly' && $intervalDays === 0)  $intervalDays = 7;
        if ($recurring === 'monthly' && $intervalDays === 0) $intervalDays = 30;

        $countRaw = $plan['count'] ?? 1;
        if ($recurring === 'none') {
            $count = 1;
            $intervalDays = 0;
        } elseif ($countRaw === 'ASK' || $countRaw === null || $countRaw === '' || (is_numeric($countRaw) && (int) $countRaw < 1)) {
            $plan['recurring'] = $recurring;
            $plan['interval_days'] = $intervalDays;
            self::savePending($phone, 'duration', $plan);

            return ['reply' => "🔁 Kitne time tak ye {$recurring} meeting book karu?\n\n_Reply like \"3 weeks\", \"1 month\", \"6 months\" or \"1 year\"._", 'intent' => 'CALENDAR_NEEDS_DURATION'];
        } else {
            $count = max(1, min((int) $countRaw, self::MAX_RECURRING));
        }

        if ($count >= self::BULK_CONFIRM_THRESHOLD && ! $confirmed) {
            $plan['count'] = $count;
            $plan['recurring'] = $recurring;
            $plan['interval_days'] = $intervalDays;
            self::savePending($phone, 'confirm', $plan);

            return ['reply' => "⚠️ Ye *{$count} meetings* book hongi. Pakka book karu? _(haan / na)_", 'intent' => 'CALENDAR_CONFIRM_BULK'];
        }

        // --- CONTACT LOOKUP (if guest name given but no email) ---
        $guest = $plan['guest'] ?? null;
        $guestEmail = $plan['guest_email'] ?? null;

        if (! empty($guest) && empty($guestEmail) && $phone !== null) {
            $contacts = ContactLookupService::search((string) $guest, $phone);
            if (count($contacts) === 1) {
                $plan['guest_email'] = $contacts[0]['client_email'];
                $plan['guest'] = $contacts[0]['client_name'];
                $guest = $plan['guest'];
                $guestEmail = $plan['guest_email'];
            } elseif (count($contacts) > 1) {
                // Multiple matches — ask user to pick
                $options = array_map(fn($c) => [
                    'name'  => $c['client_name'],
                    'phone' => $c['client_number'],
                    'email' => $c['client_email'],
                ], $contacts);
                PendingStateStore::set($phone, ['kind' => 'contact_select', 'options' => $options, 'plan' => $plan]);
                $lines = [];
                foreach ($options as $i => $o) {
                    $lines[] = '*' . ($i + 1) . '.* ' . $o['name'] . ' (' . $o['phone'] . ' - ' . $o['email'] . ')';
                }
                return [
                    'reply'  => "🤔 *Multiple matches found!*\nWho is this meeting with?\n\n" . implode("\n", $lines) . "\n\n*Reply with the number (e.g., 1)*",
                    'intent' => 'CALENDAR_CONTACT_DISAMBIGUATE',
                ];
            }
            // 0 matches — proceed without email (or ask)
        }

        try {
            $baseStart = new \DateTimeImmutable("{$date}T{$time}:00", new \DateTimeZone(CalendarService::TIMEZONE));
        } catch (Throwable $e) {
            return ['reply' => "🤔 Could not parse the date/time (date=\"{$date}\", time=\"{$time}\").", 'intent' => 'CALENDAR_PARSE_FAILED'];
        }

        $durationMin = (int) ($plan['duration_min'] ?? 60);
        if ($durationMin <= 0) $durationMin = 60;

        // --- CONFLICT DETECTION (single meetings only) ---
        if ($count === 1 && ! $confirmed) {
            try {
                $tz = new \DateTimeZone(CalendarService::TIMEZONE);
                $dayStart = $baseStart->setTime(0, 0)->format('c');
                $dayEnd = $baseStart->setTime(23, 59, 59)->format('c');
                $existing = CalendarService::getEvents(self::rt($tenant), self::cal($tenant), $dayStart, $dayEnd);

                $baseEnd = $baseStart->modify('+' . $durationMin . ' minutes');
                $conflicts = [];
                foreach ($existing as $ev) {
                    $evStart = new \DateTimeImmutable((string) ($ev['start'] ?? ''));
                    $evEnd = new \DateTimeImmutable((string) ($ev['end'] ?? $evStart->modify('+1 hour')->format('c')));
                    // Overlap check: new meeting starts before existing ends AND new meeting ends after existing starts
                    if ($baseStart < $evEnd && $baseEnd > $evStart) {
                        $conflicts[] = $ev;
                    }
                }

                if (count($conflicts) > 0) {
                    $conflictName = (string) ($conflicts[0]['summary'] ?? 'Meeting');
                    $conflictTime = (new \DateTimeImmutable((string) $conflicts[0]['start']))->setTimezone($tz)->format('h:i A');
                    $plan['_conflict_warned'] = true;
                    // Fall through to pre-booking confirmation which will mention the conflict
                }
            } catch (Throwable $e) {
                Log::warning('[CALENDAR CONFLICT CHECK] ' . $e->getMessage());
            }
        }

        // --- PRE-BOOKING CONFIRMATION (single meetings, not yet confirmed) ---
        if ($count === 1 && ! $confirmed) {
            $guestEmails = ! empty($guestEmail) ? [(string) $guestEmail] : [];
            $titleBase = ! empty($guest) ? "{$title} with {$guest}" : $title;
            $tz = new \DateTimeZone(CalendarService::TIMEZONE);

            $summary = "🗓️ *Pre-Booking Summary*\n\n"
                . "📌 *Title:* {$titleBase}\n"
                . (! empty($guest) ? "👥 *Guest:* {$guest}" . (! empty($guestEmail) ? " ({$guestEmail})" : '') . "\n" : '')
                . "📅 *Time:* " . $baseStart->setTimezone($tz)->format('d-M-Y h:i A') . "\n"
                . "🏢 *Venue:* Jitsi Meet\n";

            // Add conflict warning if detected
            if (! empty($plan['_conflict_warned']) && ! empty($conflicts)) {
                $cName = (string) ($conflicts[0]['summary'] ?? 'Meeting');
                $cTime = (new \DateTimeImmutable((string) $conflicts[0]['start']))->setTimezone($tz)->format('h:i A');
                $summary .= "\n⚠️ *Conflict!* You already have:\n📌 \"{$cName}\" at {$cTime}\n";
            }

            $summary .= "\n*Confirm this booking?*\nReply *YES* to book or *NO* to abort.";

            $plan['count'] = $count;
            $plan['recurring'] = $recurring;
            $plan['interval_days'] = $intervalDays;
            unset($plan['_conflict_warned']);
            self::savePending($phone, 'confirm', $plan);

            return ['reply' => $summary, 'intent' => 'CALENDAR_CONFIRM_BOOKING'];
        }

        $guestEmails = ! empty($guestEmail) ? [(string) $guestEmail] : [];
        $titleBase = ! empty($guest) ? "{$title} with {$guest}" : $title;

        $rt = self::rt($tenant);
        $cal = self::cal($tenant);
        $created = [];
        $failed = [];
        for ($i = 0; $i < $count; $i++) {
            $start = $baseStart->modify('+'.($i * $intervalDays).' days');
            $end = $start->modify('+'.$durationMin.' minutes');
            try {
                $event = CalendarService::createEvent($rt, $cal, [
                    'title'       => $titleBase,
                    'startTime'   => $start->format('c'),
                    'endTime'     => $end->format('c'),
                    'description' => ! empty($guest) ? "Guest: {$guest}".(! empty($guestEmail) ? " <{$guestEmail}>" : '') : '',
                    'guests'      => $guestEmails,
                ]);
                $created[] = ['event' => $event, 'start' => $start, 'end' => $end];
            } catch (Throwable $e) {
                Log::error("[TENANT BOOK ERROR {$i}/{$count}] ".$e->getMessage());
                $failed[] = ['error' => $e->getMessage()];
            }
        }

        if (count($created) === 0) {
            return ['reply' => '❌ Could not create any meeting. Error: '.($failed[0]['error'] ?? 'unknown').'.', 'intent' => 'CALENDAR_ERROR'];
        }

        $first = $created[0];
        $last = $created[count($created) - 1];
        $tz = new \DateTimeZone(CalendarService::TIMEZONE);
        $fmtDate = fn (\DateTimeImmutable $d) => $d->setTimezone($tz)->format('D, j M Y');
        $fmtTime = fn (\DateTimeImmutable $d) => $d->setTimezone($tz)->format('h:i A');
        $meetLink = (string) ($first['event']['meetLink'] ?? '');
        $titleShown = (string) ($first['event']['summary'] ?? $titleBase);

        if (count($created) === 1) {
            $reply = "✅ *Meeting booked!*\n📌 {$titleShown}\n📅 ".$fmtDate($first['start'])
                    ."\n⏰ ".$fmtTime($first['start']).' to '.$fmtTime($first['end'])
                    .($meetLink !== '' ? "\n🔗 {$meetLink}" : '');
        } else {
            $reply = '✅ *'.count($created)." meetings booked!*\n📌 {$titleShown}\n⏰ ".$fmtTime($first['start'])
                    ."\n📅 First: ".$fmtDate($first['start'])
                    ."\n📅 Last:  ".$fmtDate($last['start'])
                    .' ('.$recurring.', every '.$intervalDays.' day'.($intervalDays === 1 ? '' : 's').')';
        }
        if (count($failed) > 0) {
            $reply .= "\n\n⚠️ ".count($failed).' occurrence'.(count($failed) === 1 ? '' : 's').' failed.';
        }

        if ($phone !== null) PendingStateStore::clear($phone);

        $reply .= self::upcomingScheduleText($tenant, $date);

        // Send email notification to guest
        if (! empty($guestEmail)) {
            TenantNotificationService::emailBookingConfirmation($tenant, [
                'summary'   => $titleShown,
                'startTime' => $first['start']->format('c'),
                'endTime'   => $first['end']->format('c'),
                'meetLink'  => $meetLink,
            ], $guestEmails);
        }

        TenantNotificationService::notifyBooking($tenant, [
            'summary'   => $titleShown,
            'startTime' => $first['start']->format('c'),
            'endTime'   => $first['end']->format('c'),
            'meetLink'  => $meetLink,
        ], $guestEmails, $reply);

        return [
            'reply'   => $reply,
            'intent'  => count($created) === 1 ? 'CALENDAR_BOOKED' : 'CALENDAR_BOOKED_RECURRING',
            'created' => array_map(static fn ($c) => [
                'eventId'   => $c['event']['eventId'] ?? null,
                'startTime' => $c['start']->format('c'),
                'meetLink'  => $c['event']['meetLink'] ?? null,
            ], $created),
            'failed'  => $failed,
        ];
    }

    // ════════════════════════════════════════════════════════════ HELPERS

    /** Upcoming schedule block — shows only same-day events after book/cancel. */
    public static function upcomingScheduleText(Tenant $tenant, ?string $targetDate = null): string
    {
        try {
            $tz = new \DateTimeZone(CalendarService::TIMEZONE);
            $day = $targetDate
                ? new \DateTimeImmutable($targetDate, $tz)
                : new \DateTimeImmutable('today', $tz);
            $from = $day->setTime(0, 0)->format('c');
            $to = $day->setTime(23, 59, 59)->format('c');
            $events = CalendarService::getEvents(self::rt($tenant), self::cal($tenant), $from, $to);
        } catch (Throwable $e) {
            return '';
        }

        if (count($events) === 0) {
            return "\n\n📋 _No other meetings on this day._";
        }

        $tz = new \DateTimeZone(CalendarService::TIMEZONE);
        $lines = [];
        foreach (array_slice($events, 0, self::SCHEDULE_LIST_LIMIT) as $i => $e) {
            $lines[] = ($i + 1).'. '.self::eventLabel($e, $tz);
        }
        $more = count($events) > self::SCHEDULE_LIST_LIMIT
            ? "\n…and ".(count($events) - self::SCHEDULE_LIST_LIMIT).' more'
            : '';

        return "\n\n📋 *Schedule for this day:*\n".implode("\n", $lines).$more;
    }

    /** Convert a duration reply ("3 weeks", "1 month", "1 year") into an occurrence count. */
    private static function parseDurationToCount(string $reply, int $intervalDays): int
    {
        $r = mb_strtolower($reply);
        $iv = $intervalDays > 0 ? $intervalDays : 7;

        if (preg_match('/(\d+)\s*(days?|din|weeks?|hafte|hafta|months?|mahine|mahina|maheene|years?|saal|varsh|yr)/', $r, $m)) {
            $n = max(1, (int) $m[1]);
            $u = $m[2];
            $days = match (true) {
                str_starts_with($u, 'day') || $u === 'din'           => $n,
                str_starts_with($u, 'week') || str_contains($u, 'haft') => $n * 7,
                str_contains($u, 'month') || str_contains($u, 'mah')  => $n * 30,
                default                                                => $n * 365,
            };

            return max(1, min((int) floor($days / $iv), self::MAX_RECURRING));
        }

        if (preg_match('/\b(\d{1,3})\b/', $r, $m2)) {
            return max(1, min((int) $m2[1], self::MAX_RECURRING));
        }

        return 0;
    }

    private static function savePending(?string $phone, string $expecting, array $plan): void
    {
        if ($phone === null) return;
        PendingStateStore::set($phone, ['kind' => 'calendar', 'expecting' => $expecting, 'plan' => $plan]);
    }

    /**
     * Merge a fresh AI parse onto known fields. Already-concrete known values are STICKY
     * (parse can't overwrite them) — this is what fixes the wrong-weekday bug on continuations.
     *
     * @param  array<string, mixed>  $known
     * @param  array<string, mixed>  $parsed
     * @return array<string, mixed>
     */
    private static function mergePlan(array $known, array $parsed): array
    {
        // First turn — take the parse as-is.
        if (empty($known)) return $parsed;

        // Continuation — turn-1 already decided recurring/count/title/guest. Only the asked-for
        // date/time get filled from the reply. This keeps the correct weekday (no recompute) and
        // stops the reply's default count=1 from clobbering a pending count='ASK'.
        $plan = $known;
        foreach (['date', 'time'] as $k) {
            $kn = $known[$k] ?? null;
            if ($kn !== null && $kn !== '' && $kn !== 'ASK') continue; // already concrete
            $pv = $parsed[$k] ?? null;
            if ($pv !== null && $pv !== '' && $pv !== 'ASK') $plan[$k] = $pv;
        }

        return $plan;
    }

    /** @param array<string, mixed> $known @return array<string,mixed>|null */
    private static function aiParse(string $tenantId, string $query, string $today, array $known): ?array
    {
        $messages = [['role' => 'user', 'content' => self::buildParsePrompt($query, $today, $known)]];
        $aiResult = \App\Services\AI\AiGateway::chat($tenantId, $messages, ['temperature' => 0, 'max_tokens' => 300, 'timeout' => 15]);

        if (!$aiResult['ok']) {
            Log::warning('[CALENDAR PARSE] ' . ($aiResult['error'] ?? 'unknown'));
            return null;
        }

        $raw = trim($aiResult['content']);
        $raw = trim(str_replace('```', '', (string) preg_replace('/```json?\s*/', '', $raw)));
        try {
            return json_decode($raw, true, 16, JSON_THROW_ON_ERROR);
        } catch (Throwable $e) {
            Log::warning('[CALENDAR PARSE JSON] '.$e->getMessage().' raw='.substr($raw, 0, 200));

            return null;
        }
    }

    private static function buildParsePrompt(string $query, string $today, array $known = []): string
    {
        $safeQuery = str_replace('"', '\\"', $query);
        $knownBlock = '';
        if (! empty($known)) {
            $knownJson = json_encode($known, JSON_UNESCAPED_SLASHES);
            $knownBlock = "\nThis is a CONTINUATION of an ongoing booking.\nAlready known (KEEP exactly, do NOT recompute the date): {$knownJson}\nThe new message only supplies the missing piece.\n";
        }

        return <<<PROMPT
Extract meeting details from this message. Return JSON only — no prose.
Message: "{$safeQuery}"
Today: {$today}{$knownBlock}

Return EXACTLY this shape:
{
  "title": "short title or 'Meeting'",
  "date": "YYYY-MM-DD or 'ASK' if cannot infer",
  "time": "HH:MM 24h or 'ASK' if cannot infer",
  "duration_min": 60,
  "guest": "name or null",
  "guest_email": "email or null",
  "recurring": "none | daily | weekly | monthly",
  "count": <number, or 'ASK' if recurring is set but the user did NOT say how long / how many times>,
  "interval_days": 0
}

Rules:
- "every Monday"/"weekly"/"har Monday"/"har wednesday" → recurring="weekly", interval_days=7
- "daily"/"har din" → recurring="daily", interval_days=1
- "monthly"/"har mahine" → recurring="monthly", interval_days=30
- Recurring set but NO duration/number given (e.g. "har wednesday meeting book krdo") → count="ASK"
- "for 3 weeks"/"next 3 weeks" weekly → count=3 ; "for 1 month" weekly → count=4 ; "for 1 year" weekly → count=52
- one-off meeting → recurring="none", count=1, interval_days=0
- For a recurring weekday, "date" MUST be the FIRST upcoming occurrence of THAT weekday (never past).
- "this wed"/"coming wed"/"next wed" → the upcoming Wednesday's date.
- "tomorrow"/"kal" → tomorrow ; "today"/"aaj" → today
- Cap count at 365.
PROMPT;
    }

    private static function eventLabel(array $e, \DateTimeZone $tz): string
    {
        $title = (string) ($e['summary'] ?? 'No title');
        $s = (string) ($e['start'] ?? '');
        if ($s === '') return $title;
        try {
            return $title.' — '.(new \DateTimeImmutable($s))->setTimezone($tz)->format('D, j M, h:i A');
        } catch (Throwable) {
            return $title;
        }
    }

    /** @return array{0:string,1:string} ISO from/to for the search window. */
    private static function window(bool $fromMidnight = false): array
    {
        $tz = new \DateTimeZone(CalendarService::TIMEZONE);
        $from = $fromMidnight ? new \DateTimeImmutable('today', $tz) : new \DateTimeImmutable('now', $tz);

        return [$from->format('c'), $from->modify('+'.self::WINDOW_MONTHS.' months')->format('c')];
    }

    private static function rt(Tenant $t): string
    {
        return (string) ($t->calendar_refresh_token ?? '');
    }

    private static function cal(Tenant $t): string
    {
        return (string) ($t->calendar_id ?: 'primary');
    }
}
