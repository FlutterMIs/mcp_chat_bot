<?php

declare(strict_types=1);

namespace App\Services\Chat;

use App\Models\TenantApiKey;
use App\Services\AI\AiGateway;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * ExternalApiService — queries external APIs (apps.apimis.co.in) using tenant's stored keys.
 *
 * ARCHITECTURE (v2 — PHP filters, GPT only formats):
 *   1. Detect endpoint from query keywords
 *   2. Call API with date range
 *   3. PHP filters records (by person, priority, status, expired, frequency)
 *   4. PHP computes exact stats (counts, breakdowns)
 *   5. GPT ONLY formats the pre-filtered/pre-computed data — NEVER counts or filters
 *
 * This eliminates the 70% inaccuracy caused by GPT miscounting/misfiltering raw JSON.
 */
final class ExternalApiService
{
    private const ENDPOINT_MAP = [
        'call'       => '/getAllCallRecords',
        'visiting'   => '/visitingGetDataSheet',
        'lead'       => '/leadDataSheet',
        'follow'     => '/leadFollowupSheet',
        'delegation' => '/googleSheetDelegation',
        'checklist'  => '/googleSheetchecklist',
        'scoring'    => '/scoringList',
        'leave'      => '/leaveSheet',
    ];

    public static function query(string $tenantId, string $userRole, string $query, bool $webMode = false): ?string
    {
        $keys = TenantApiKey::accessible($tenantId, $userRole);
        if (empty($keys)) return null;

        $qLower = mb_strtolower($query);
        $endpoint = self::detectEndpoint($qLower);
        if (!$endpoint) return null;

        if ($endpoint === 'AMBIGUOUS_TASK') {
            return "📋 *Kaunsi task list chahiye?*\n\n1️⃣ *Delegation Tasks* — assigned tasks (one-time, with deadlines)\n2️⃣ *Checklist Tasks* — recurring tasks (daily/weekly/monthly)\n\n_Reply with \"delegation list\" or \"checklist list\"_";
        }

        foreach ($keys as $key) {
            $url = $key['base_url'] . $endpoint;
            $result = self::callApi($url, $key['api_key'], $key['label'], $query, $tenantId, $webMode);
            if ($result !== null) return $result;
        }

        return null;
    }

    public static function matches(string $query): bool
    {
        return self::detectEndpoint(mb_strtolower($query)) !== null;
    }

    private static function detectEndpoint(string $query): ?string
    {
        $keywords = [
            'call'       => ['call log', 'call record', 'call summary', 'calls today', 'calls yesterday', 'phone log', 'call history', 'missed call', 'incoming call', 'outgoing call', 'total calls', 'calls this', 'calls last', 'calls made', 'how many call', 'kitne call', 'call report', 'rejected call'],
            'visiting'   => ['visiting card', 'visit card', 'business card'],
            'lead'       => ['lead', 'leads', 'prospect'],
            'follow'     => ['follow up', 'followup', 'follow-up'],
            'delegation' => ['delegation', 'delegate', 'task assign', 'assigned task', 'expired task', 'overdue task', 'delegated task', 'pending delegation', 'assigned to'],
            'checklist'  => ['checklist', 'check list', 'to do', 'todo', 'pending checklist', 'daily task', 'weekly task', 'monthly task', 'recurring task'],
            'scoring'    => ['scoring', 'score', 'performance', 'rating', 'scorecard', 'score card', 'employee score'],
            'leave'      => ['leave', 'absent', 'attendance', 'chutti', 'holiday'],
        ];

        foreach ($keywords as $key => $words) {
            foreach ($words as $w) {
                if (str_contains($query, $w)) {
                    return self::ENDPOINT_MAP[$key];
                }
            }
        }

        // Ambiguous: "pending task" / "task list" / "my tasks"
        if (preg_match('/\b(pending|expired|overdue)?\s*task/i', $query) || preg_match('/\btask\s*(list|lists)\b/i', $query)) {
            return 'AMBIGUOUS_TASK';
        }

        return null;
    }

    // ═══════════════════════════════════════════════════════════════════
    // CORE: Call API → PHP filter → PHP stats → GPT format only
    // ═══════════════════════════════════════════════════════════════════

    private static function callApi(string $url, string $apiKey, string $label, string $userQuery, string $tenantId, bool $webMode = false): ?string
    {
        try {
            // Always fetch ALL data — API's date filtering is unreliable. We filter in PHP.
            $resp = Http::withHeaders(['Content-Type' => 'application/json'])
                ->timeout(25)
                ->post($url, ['clientApiKey' => $apiKey, 'fromDate' => '2020-01-01', 'toDate' => date('Y-m-d')]);

            if (!$resp->ok()) {
                Log::warning("[EXT API] {$label} failed: status={$resp->status()}");
                return null;
            }

            $data = $resp->json();
            if (empty($data) || (isset($data['success']) && $data['success'] === false) || (isset($data['status']) && $data['status'] === 0)) {
                $apiMsg = $data['message'] ?? '';
                Log::info("[EXT API] {$label} returned error: {$apiMsg}");
                return "🔗 *From: {$label}*\n\n⚠️ This feature is currently unavailable via the API.\n\n_Please check directly on the apps.apimis.co.in website for now._";
            }

            $records = $data['data'] ?? $data['records'] ?? $data;
            if (!is_array($records) || empty($records)) {
                return "🔗 *From: {$label}*\n\n📭 No records found.\n\nThe external system has no data available.";
            }

            // ── PHP date filtering (since API date params are unreliable) ──
            [$from, $to] = self::extractDateRange($userQuery);
            if ($from !== '2020-01-01') {
                $records = self::filterByDate($records, $from, $to);
                if (empty($records)) {
                    return "🔗 *From: {$label}*\n\n📭 No records found for this period ({$from} to {$to}).\n\nTry a broader date range like \"this month\" or \"last 30 days\".";
                }
            }

            // ── Step 1: GPT extracts structured filters from natural language ──
            $filters = self::extractFilters($userQuery, $records[0], $tenantId);

            // ── Step 2: PHP applies filters deterministically ──
            $totalRaw = count($records);
            $filtered = self::applyUserFilters($records, $userQuery, $filters);
            $totalFiltered = count($filtered);

            if ($totalFiltered === 0) {
                return "🔗 *From: {$label}*\n\n📭 No records match your criteria.\n\n📋 Total in date range: {$totalRaw}, after filters: 0.";
            }

            // ── Step 3: PHP computes exact stats ──
            $stats = self::computeStats($filtered, $url);

            // ── Step 4: GPT formats (never counts) ──
            // If user asked for specific fields ("with their tasks", "show X only") → list mode
            // If user just wants numbers ("how many", "kitne", "total count") → summary mode
            $wantsList = !empty($filters['fields_to_show']) || preg_match('/\b(with their|show.*(name|detail|list)|dikhao|all.*task)\b/i', $userQuery);
            $wantsSummary = !$wantsList && ($filters['wants_summary'] ?? self::wantsSummary($userQuery));

            if ($wantsSummary) {
                $formatted = self::aiFormatSummary($stats, $userQuery, $tenantId, $label, $webMode);
            } else {
                $formatted = self::aiFormatList($filtered, $userQuery, $tenantId, $label, $stats, $webMode);
            }

            if (!$formatted) {
                $formatted = self::fallbackFormat($filtered, $stats);
            }

            $filterNote = ($totalFiltered < $totalRaw)
                ? "\n\n📋 Showing: *{$totalFiltered}* of {$totalRaw} total."
                : "\n\n📋 Total: *{$totalFiltered}* record(s).";

            return "🔗 *From: {$label}*\n\n{$formatted}{$filterNote}";
        } catch (Throwable $e) {
            Log::warning("[EXT API] {$label} error: " . $e->getMessage());
            return null;
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    // SMART FILTERING — GPT extracts filters as JSON, PHP applies them
    // ═══════════════════════════════════════════════════════════════════

    /**
     * Ask GPT to extract structured filters from natural language query.
     * Returns: {person, priority, frequency, status, direction, source, expired, fields_to_show, fields_to_hide}
     * PHP then applies these filters deterministically.
     */
    private static function extractFilters(string $query, array $sampleRecord, string $tenantId): array
    {
        $fields = array_keys($sampleRecord);
        $fieldList = implode(', ', $fields);

        $messages = [
            ['role' => 'system', 'content' => "Extract search filters from the user's question. Return ONLY valid JSON.\n\nAvailable fields in data: {$fieldList}\n\nReturn this JSON structure (omit keys that don't apply):\n{\n  \"person\": \"name to filter by (assignee/delegator)\",\n  \"priority\": \"High|Medium|Low\",\n  \"frequency\": \"Daily|Weekly|Monthly\",\n  \"call_status\": \"CONNECTED|MISSED|REJECTED\",\n  \"call_direction\": \"INCOMING|OUTGOING\",\n  \"lead_source\": \"source name\",\n  \"expired\": true,\n  \"city\": \"city name\",\n  \"product\": \"product name\",\n  \"fields_to_show\": [\"field1\", \"field2\"],\n  \"fields_to_hide\": [\"field1\", \"field2\"],\n  \"wants_summary\": true/false,\n  \"sort_by\": \"field_name\",\n  \"limit\": 5\n}\n\nRules:\n- Only include filters the user EXPLICITLY asked for\n- \"total\" / \"kitne\" / \"how many\" → wants_summary: true\n- \"without X\" → fields_to_hide: [\"X\"]\n- \"only X and Y\" → fields_to_show: [\"X\", \"Y\"]\n- If no filters, return {\"wants_summary\": false}\n- Return ONLY JSON, no explanation"],
            ['role' => 'user', 'content' => $query],
        ];

        try {
            $result = AiGateway::chat($tenantId, $messages, ['max_tokens' => 300, 'timeout' => 10]);
            if ($result['ok'] && !empty($result['content'])) {
                $json = trim($result['content']);
                // Strip markdown code fences if present
                $json = preg_replace('/^```(?:json)?\s*|\s*```$/s', '', $json);
                $parsed = json_decode($json, true);
                if (is_array($parsed)) {
                    // Only keep recognized filter keys
                    $allowed = ['person', 'priority', 'frequency', 'call_status', 'call_direction', 'lead_source', 'expired', 'city', 'product', 'fields_to_show', 'fields_to_hide', 'wants_summary', 'sort_by', 'limit'];
                    return array_intersect_key($parsed, array_flip($allowed));
                }
            }
        } catch (Throwable $e) {
            Log::warning("[EXT API] extractFilters failed: " . $e->getMessage());
        }

        // Fallback: basic regex extraction (still works if GPT fails)
        return self::regexFallbackFilters($query);
    }

    /**
     * Fallback regex filters when GPT is unavailable.
     */
    private static function regexFallbackFilters(string $query): array
    {
        $q = mb_strtolower($query);
        $filters = [];

        if (preg_match('/(?:assigned to|delegated to|from|by)\s+([a-z][a-z\s]{2,20})/i', $query, $m)) {
            $filters['person'] = trim($m[1]);
        }
        if (preg_match('/\b(high|medium|low|urgent)\b/i', $q, $m)) {
            $filters['priority'] = ucfirst(strtolower($m[1]));
        }
        if (preg_match('/\b(daily|weekly|monthly)\b/i', $q, $m)) {
            $filters['frequency'] = ucfirst(strtolower($m[1]));
        }
        if (preg_match('/\b(expired|overdue)\b/i', $q)) {
            $filters['expired'] = true;
        }
        if (preg_match('/\b(missed|connected|rejected)\b/i', $q, $m)) {
            $filters['call_status'] = strtoupper($m[1]);
        }
        if (preg_match('/\b(incoming|outgoing)\b/i', $q, $m)) {
            $filters['call_direction'] = strtoupper($m[1]);
        }
        $filters['wants_summary'] = self::wantsSummary($query);

        return $filters;
    }

    /**
     * Apply structured filters to records. 100% deterministic — no GPT involved.
     */
    private static function applyUserFilters(array $records, string $query, array $filters = []): array
    {
        $filtered = $records;

        // Person filter
        if (!empty($filters['person'])) {
            $pLower = mb_strtolower($filters['person']);
            $filtered = array_values(array_filter($filtered, fn($r) =>
                str_contains(mb_strtolower($r['delegatedTo'] ?? $r['DelegatedTo'] ?? $r['taskTo'] ?? $r['TaskTo'] ?? ''), $pLower) ||
                str_contains(mb_strtolower($r['delegateFrom'] ?? $r['DelegateFrom'] ?? $r['taskFrom'] ?? $r['assignBy'] ?? ''), $pLower) ||
                str_contains(mb_strtolower($r['queryName'] ?? $r['companyName'] ?? ''), $pLower)
            ));
        }

        // Priority filter
        if (!empty($filters['priority'])) {
            $prio = $filters['priority'];
            $filtered = array_values(array_filter($filtered, fn($r) => strcasecmp($r['priority'] ?? '', $prio) === 0));
        }

        // Frequency filter (checklist)
        if (!empty($filters['frequency'])) {
            $freq = $filters['frequency'];
            $filtered = array_values(array_filter($filtered, fn($r) => strcasecmp($r['frequency'] ?? '', $freq) === 0));
        }

        // Expired/overdue
        if (!empty($filters['expired'])) {
            $today = date('Y-m-d');
            $filtered = array_values(array_filter($filtered, function ($r) use ($today) {
                $parsed = self::parseApiDate($r['finalDate'] ?? $r['targetDate'] ?? '');
                return $parsed && $parsed < $today;
            }));
        }

        // Call status
        if (!empty($filters['call_status'])) {
            $status = strtoupper($filters['call_status']);
            $filtered = array_values(array_filter($filtered, fn($r) => strtoupper($r['callStatus'] ?? '') === $status));
        }

        // Call direction
        if (!empty($filters['call_direction'])) {
            $dir = strtoupper($filters['call_direction']);
            $filtered = array_values(array_filter($filtered, fn($r) => strtoupper($r['direction'] ?? '') === $dir));
        }

        // Lead source
        if (!empty($filters['lead_source'])) {
            $src = mb_strtolower($filters['lead_source']);
            $filtered = array_values(array_filter($filtered, fn($r) => str_contains(mb_strtolower($r['leadSource'] ?? $r['leadSourceAPI'] ?? ''), $src)));
        }

        // City
        if (!empty($filters['city'])) {
            $city = mb_strtolower($filters['city']);
            $filtered = array_values(array_filter($filtered, fn($r) => str_contains(mb_strtolower($r['city'] ?? ''), $city)));
        }

        // Product
        if (!empty($filters['product'])) {
            $prod = mb_strtolower($filters['product']);
            $filtered = array_values(array_filter($filtered, fn($r) => str_contains(mb_strtolower($r['productName'] ?? ''), $prod)));
        }

        // Sort
        if (!empty($filters['sort_by'])) {
            $sortField = $filters['sort_by'];
            usort($filtered, fn($a, $b) => ($a[$sortField] ?? '') <=> ($b[$sortField] ?? ''));
        }

        // Limit
        if (!empty($filters['limit']) && is_numeric($filters['limit'])) {
            $filtered = array_slice($filtered, 0, (int) $filters['limit']);
        }

        return $filtered;
    }

    private static function parseApiDate(string $dateStr): ?string
    {
        $dateStr = trim($dateStr);
        if (!$dateStr) return null;
        // DD-MM-YYYY HH:MM or DD-MM-YYYY (most common in call logs)
        if (preg_match('/^(\d{1,2})-(\d{2})-(\d{4})/', $dateStr, $m)) {
            return "{$m[3]}-{$m[2]}-{$m[1]}";
        }
        // DD/MM/YYYY
        if (preg_match('/^(\d{1,2})\/(\d{2})\/(\d{4})/', $dateStr, $m)) {
            return "{$m[3]}-{$m[2]}-{$m[1]}";
        }
        // DD Mon YYYY (e.g. "1 Jun 2026")
        if (preg_match('/^(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})/', $dateStr, $m)) {
            $t = strtotime("{$m[1]} {$m[2]} {$m[3]}");
            return $t ? date('Y-m-d', $t) : null;
        }
        $t = strtotime($dateStr);
        return ($t && $t > strtotime('2000-01-01')) ? date('Y-m-d', $t) : null;
    }

    private static function filterByDate(array $records, string $from, string $to): array
    {
        return array_values(array_filter($records, function ($r) use ($from, $to) {
            $dateStr = $r['callDate'] ?? $r['calldate'] ?? $r['date'] ?? $r['createdAt'] ?? $r['dataEntryDate'] ?? $r['created_at'] ?? '';
            $parsed = self::parseApiDate((string) $dateStr);
            if (!$parsed) return true; // Keep records with unparseable dates
            return $parsed >= $from && $parsed <= $to;
        }));
    }

    // ═══════════════════════════════════════════════════════════════════
    // PHP STATS — exact counts, never GPT-estimated
    // ═══════════════════════════════════════════════════════════════════

    private static function computeStats(array $records, string $url): array
    {
        $count = count($records);

        // Call logs
        if (str_contains($url, 'Call') && isset($records[0]['callStatus'])) {
            $s = ['type' => 'calls', 'total' => $count, 'incoming' => 0, 'outgoing' => 0, 'connected' => 0, 'missed' => 0, 'rejected' => 0, 'totalDurationSec' => 0];
            foreach ($records as $r) {
                $dir = strtoupper($r['direction'] ?? '');
                $st = strtoupper($r['callStatus'] ?? '');
                if ($dir === 'INCOMING') $s['incoming']++;
                if ($dir === 'OUTGOING') $s['outgoing']++;
                if ($st === 'CONNECTED') $s['connected']++;
                if ($st === 'MISSED') $s['missed']++;
                if ($st === 'REJECTED') $s['rejected']++;
                $s['totalDurationSec'] += (int)($r['callDuration'] ?? 0);
            }
            $avg = $count > 0 ? round($s['totalDurationSec'] / $count) : 0;
            $s['avgDuration'] = $avg >= 60 ? floor($avg / 60) . 'm ' . ($avg % 60) . 's' : $avg . 's';
            return $s;
        }

        // Delegation
        if (str_contains($url, 'Delegation') || str_contains($url, 'delegation')) {
            $s = ['type' => 'delegation', 'total' => $count, 'byPerson' => [], 'byPriority' => [], 'expired' => 0];
            $today = date('Y-m-d');
            foreach ($records as $r) {
                $to = $r['delegatedTo'] ?? $r['DelegatedTo'] ?? $r['taskTo'] ?? '?';
                $p = $r['priority'] ?? '';
                $s['byPerson'][$to] = ($s['byPerson'][$to] ?? 0) + 1;
                if ($p) $s['byPriority'][$p] = ($s['byPriority'][$p] ?? 0) + 1;
                $fd = self::parseApiDate($r['finalDate'] ?? '');
                if ($fd && $fd < $today) $s['expired']++;
            }
            arsort($s['byPerson']);
            return $s;
        }

        // Checklist
        if (str_contains($url, 'checklist')) {
            $s = ['type' => 'checklist', 'total' => $count, 'byPerson' => [], 'byFrequency' => [], 'byPriority' => []];
            foreach ($records as $r) {
                $to = $r['taskTo'] ?? $r['TaskTo'] ?? '?';
                $freq = $r['frequency'] ?? '?';
                $p = $r['priority'] ?? '';
                $s['byPerson'][$to] = ($s['byPerson'][$to] ?? 0) + 1;
                if ($freq !== '?') $s['byFrequency'][$freq] = ($s['byFrequency'][$freq] ?? 0) + 1;
                if ($p) $s['byPriority'][$p] = ($s['byPriority'][$p] ?? 0) + 1;
            }
            arsort($s['byPerson']);
            return $s;
        }

        // Leads
        if (str_contains($url, 'lead')) {
            $s = ['type' => 'leads', 'total' => $count, 'bySource' => [], 'byProduct' => [], 'byCity' => []];
            foreach ($records as $r) {
                $src = trim($r['leadSource'] ?? $r['leadSourceAPI'] ?? '');
                $prod = trim($r['productName'] ?? '');
                $city = trim($r['city'] ?? '');
                $s['bySource'][$src ?: 'Direct/Other'] = ($s['bySource'][$src ?: 'Direct/Other'] ?? 0) + 1;
                if ($prod) $s['byProduct'][$prod] = ($s['byProduct'][$prod] ?? 0) + 1;
                if ($city) $s['byCity'][$city] = ($s['byCity'][$city] ?? 0) + 1;
            }
            arsort($s['bySource']);
            return $s;
        }

        return ['type' => 'generic', 'total' => $count];
    }

    private static function wantsSummary(string $query): bool
    {
        return (bool) preg_match('/\b(kitne|kitni|how many|count|total|summary|summarize|overview|stats|report|number of)\b/i', $query);
    }

    // ═══════════════════════════════════════════════════════════════════
    // GPT FORMATTING — it NEVER filters or counts, only makes it pretty
    // ═══════════════════════════════════════════════════════════════════

    private static function aiFormatSummary(array $stats, string $query, string $tenantId, string $label, bool $webMode = false): ?string
    {
        try {
            $statsJson = json_encode($stats, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            $customFormat = \App\Models\TenantPrompt::getFormatInstruction($tenantId, $webMode);
            $customNote = $customFormat ? "\n\nADDITIONAL TENANT FORMAT INSTRUCTIONS (follow exactly): {$customFormat}" : '';

            $system = $webMode
                ? "You format pre-computed stats into a clean message for a web dashboard chat panel. RULES:\n- Use the EXACT numbers provided. NEVER recalculate.\n- Use standard Markdown: **bold** for values, `-` for bullet lists.\n- Respond in the same language as the user.\n- Be concise. No extra commentary.\n- Do NOT add greetings or footers like \"Dear User\" / \"Thank You\".{$customNote}"
                : "You format pre-computed stats into a clean WhatsApp message. RULES:\n- Use the EXACT numbers provided. NEVER recalculate.\n- Use *bold* for values, emojis as bullets.\n- Respond in the same language as the user.\n- Be concise. No extra commentary.\n- Do NOT add greetings or footers like \"Dear User\" / \"Thank You\".{$customNote}";

            $messages = [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => "User: \"{$query}\"\nSource: {$label}\n\nEXACT stats (use as-is):\n{$statsJson}"],
            ];

            $result = AiGateway::chat($tenantId, $messages, ['max_tokens' => 1500, 'timeout' => 30]);
            return ($result['ok'] && !empty($result['content'])) ? $result['content'] : null;
        } catch (Throwable $e) {
            return null;
        }
    }

    private static function aiFormatList(array $records, string $query, string $tenantId, string $label, array $stats, bool $webMode = false): ?string
    {
        try {
            $count = count($records);
            $display = $count > 30 ? array_slice($records, 0, 30) : $records;
            $json = json_encode($display, JSON_UNESCAPED_UNICODE);
            if (strlen($json) > 14000) {
                $display = array_slice($records, 0, 15);
                $json = json_encode($display, JSON_UNESCAPED_UNICODE);
            }

            $customFormat = \App\Models\TenantPrompt::getFormatInstruction($tenantId, $webMode);
            $customNote = $customFormat ? "\n- ADDITIONAL TENANT FORMAT INSTRUCTIONS (follow exactly): {$customFormat}" : '';
            $statsNote = json_encode($stats, JSON_UNESCAPED_UNICODE);

            $system = $webMode
                ? "You format pre-filtered records into a message for a web dashboard chat panel.\n\nCRITICAL RULES:\n- Show ACTUAL data from the records. Do NOT invent fields or text.\n- Do NOT add greetings like \"Dear User\" or footers like \"Thank You | MIS TEAM\".\n- If user said 'without X' — exclude that field.\n- If user said 'only X and Y' or 'with their X' — show ONLY those specific fields per record.\n- Use standard Markdown: **bold** for labels, numbered list (`1.`) per record.\n- Show ALL {$count} records. Do NOT skip or truncate. List EVERY single record.\n- NEVER recount. Total is exactly: {$count}.\n- Respond in same language as user.\n- Key fields: taskName=task description, delegatedTo=assignee, priority, timestamp, frequency.{$customNote}"
                : "You format pre-filtered records into a WhatsApp message.\n\nCRITICAL RULES:\n- Show ACTUAL data from the records. Do NOT invent fields or text.\n- Do NOT add greetings like \"Dear User\" or footers like \"Thank You | MIS TEAM\".\n- If user said 'without X' — exclude that field.\n- If user said 'only X and Y' or 'with their X' — show ONLY those specific fields per record.\n- Use *bold* for labels, number each record.\n- Show ALL {$count} records. Do NOT skip or truncate. List EVERY single record.\n- NEVER recount. Total is exactly: {$count}.\n- Respond in same language as user.\n- Key fields: taskName=task description, delegatedTo=assignee, priority, timestamp, frequency.{$customNote}";

            $messages = [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => "User: \"{$query}\"\nSource: {$label}\nTotal: {$count}" . ($count > count($display) ? " (showing first " . count($display) . ")" : "") . "\nStats: {$statsNote}\n\nRecords:\n{$json}"],
            ];

            $result = AiGateway::chat($tenantId, $messages, ['max_tokens' => 4000, 'timeout' => 60]);
            return ($result['ok'] && !empty($result['content'])) ? $result['content'] : null;
        } catch (Throwable $e) {
            return null;
        }
    }

    /**
     * Fallback: no GPT, just plain text format with stats.
     */
    private static function fallbackFormat(array $records, array $stats): string
    {
        $lines = [];

        // Stats summary first
        if ($stats['type'] === 'delegation' || $stats['type'] === 'checklist') {
            $lines[] = "📊 *Summary:* Total: {$stats['total']}";
            if (!empty($stats['byPerson'])) {
                $pList = array_map(fn($k, $v) => "{$k}: {$v}", array_keys($stats['byPerson']), $stats['byPerson']);
                $lines[] = "👤 " . implode(', ', array_slice($pList, 0, 5));
            }
            if (!empty($stats['byPriority'])) {
                $lines[] = "⚡ Priority: " . implode(', ', array_map(fn($k, $v) => "{$k}={$v}", array_keys($stats['byPriority']), $stats['byPriority']));
            }
            $lines[] = '';
        }

        foreach (array_slice($records, 0, 15) as $i => $r) {
            if (!is_array($r)) continue;
            $parts = [];
            foreach ($r as $key => $val) {
                if ($val === null || $val === '' || str_contains((string)$key, 'Id') || str_contains((string)$key, 'Adior')) continue;
                $parts[] = "*" . ucwords(str_replace(['_', '-'], ' ', (string)$key)) . ":* {$val}";
            }
            $lines[] = "📌 #" . ($i + 1) . "\n" . implode("\n", $parts);
        }

        return implode("\n━━━━━━\n", $lines);
    }

    private static function formatRecords(array $records, string $label): string
    {
        if (empty($records)) return 'No records found.';
        $lines = [];
        foreach (array_slice($records, 0, 15) as $i => $record) {
            if (!is_array($record)) continue;
            $parts = [];
            foreach ($record as $key => $val) {
                if ($val === null || $val === '') continue;
                $parts[] = "*" . ucwords(str_replace(['_', '-'], ' ', (string)$key)) . ":* {$val}";
            }
            $lines[] = "📌 #" . ($i + 1) . "\n" . implode("\n", $parts);
        }
        return implode("\n━━━━━━━━━━\n", $lines);
    }

    private static function extractDateRange(string $query): array
    {
        $q = mb_strtolower($query);
        $today = date('Y-m-d');
        $yesterday = date('Y-m-d', strtotime('-1 day'));

        if (preg_match('/\b(yesterday|yester\w*|kal)\b/', $q)) return [$yesterday, $yesterday];
        if (preg_match('/\b(today|aaj|todays)\b/', $q)) return [$today, $today];
        if (preg_match('/\b(this|current|is)\s*(week|weak|hafte|hafta)\b/', $q)) return [date('Y-m-d', strtotime('monday this week')), $today];
        if (preg_match('/\b(last|prev\w*|pich\w*)\s*(week|weak|hafte|hafta)\b/', $q)) return [date('Y-m-d', strtotime('monday last week')), date('Y-m-d', strtotime('sunday last week'))];
        if (preg_match('/\b(this|current|is)\s*(month|mahine|mahina)\b/', $q)) return [date('Y-m-01'), $today];
        if (preg_match('/\b(last|prev\w*|pich\w*)\s*(month|mahine|mahina)\b/', $q)) return [date('Y-m-01', strtotime('first day of last month')), date('Y-m-t', strtotime('last month'))];
        if (preg_match('/last (\d+) days/', $q, $m)) return [date('Y-m-d', strtotime("-{$m[1]} days")), $today];

        // No date mentioned → ALL TIME (user wants total/all data)
        return ['2020-01-01', $today];
    }
}
