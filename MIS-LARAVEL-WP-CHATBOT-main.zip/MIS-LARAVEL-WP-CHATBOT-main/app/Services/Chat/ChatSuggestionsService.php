<?php

declare(strict_types=1);

namespace App\Services\Chat;

use App\Services\Dashboard\TableClassifier;

/**
 * ChatSuggestionsService — schema-aware chip prompts for the chat composer.
 *
 * Reuses TableClassifier (extends with a 'tasks' role for delegation/checklist
 * tables that the dashboard ignores). Round-robin selects chips across kinds
 * so the visible top row shows variety even when the tenant has many sales
 * chips. Falls back to a generic chip set when classification yields nothing.
 *
 * Port of Node helpers/chat-suggestions.js (Phase 20 Sprint 3).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/chat-suggestions.js
 */
final class ChatSuggestionsService
{
    /** Stable role-priority ordering for chip pool building. */
    private const ROLE_ORDER = [
        'sales', 'purchases', 'outstanding', 'stock',
        'ledger', 'expenses', 'payments', 'leads', 'tasks',
    ];

    /**
     * Generic fallback when tenant has no classifiable tables.
     *
     * @var list<array{label: string, prompt: string, icon: string, kind: string}>
     */
    private const GENERIC_CHIPS = [
        ['label' => 'Show me a quick summary', 'prompt' => 'Give me a quick summary of my data',     'icon' => 'sparkles',    'kind' => 'generic'],
        ['label' => 'What can you do?',        'prompt' => 'What kinds of questions can I ask you?', 'icon' => 'help-circle', 'kind' => 'generic'],
        ['label' => 'Sync my latest data',     'prompt' => 'Sync my latest data',                    'icon' => 'refresh-cw',  'kind' => 'generic'],
    ];

    /**
     * Per-role chip catalog.
     *
     * @return array<string, list<array{label: string, prompt: string, icon: string, kind: string}>>
     */
    private static function catalog(): array
    {
        return [
            'sales' => [
                ['label' => 'Total sales this month',   'prompt' => 'Total sales this month',                            'icon' => 'trending-up',    'kind' => 'sales'],
                ['label' => 'Top 5 customers',          'prompt' => 'Show me top 5 customers by total sales',            'icon' => 'users',          'kind' => 'sales'],
                ['label' => 'Sales by item',            'prompt' => 'Show me sales by item, top 10',                     'icon' => 'package',        'kind' => 'sales'],
                ['label' => 'Sales trend last 30 days', 'prompt' => 'Show me a sales trend chart for the last 30 days',  'icon' => 'line-chart',     'kind' => 'sales'],
                ['label' => 'Sales by city',            'prompt' => 'Show me sales by city, top 8',                      'icon' => 'map-pin',        'kind' => 'sales'],
                ['label' => 'Today’s sales',            'prompt' => 'How much did we sell today?',                       'icon' => 'calendar-clock', 'kind' => 'sales'],
            ],
            'purchases' => [
                ['label' => 'Total purchases this month', 'prompt' => 'Total purchases this month',                          'icon' => 'shopping-cart', 'kind' => 'purchases'],
                ['label' => 'Top suppliers',              'prompt' => 'Show me top 5 suppliers by purchase value',           'icon' => 'truck',         'kind' => 'purchases'],
                ['label' => 'Purchases by item',          'prompt' => 'Show me purchases by item, top 10',                   'icon' => 'boxes',         'kind' => 'purchases'],
                ['label' => 'Purchase trend',             'prompt' => 'Show me a purchase trend chart for the last 30 days', 'icon' => 'activity',      'kind' => 'purchases'],
            ],
            'outstanding' => [
                ['label' => 'Outstanding aging', 'prompt' => 'Show me an outstanding aging report',                                          'icon' => 'hourglass',      'kind' => 'outstanding'],
                ['label' => 'Pending > 30 days', 'prompt' => 'Which customers are pending payment for more than 30 days?',                  'icon' => 'alert-triangle', 'kind' => 'outstanding'],
                ['label' => 'Top defaulters',    'prompt' => 'Show me the top 5 customers with the highest outstanding amount',            'icon' => 'user-x',         'kind' => 'outstanding'],
            ],
            'stock' => [
                ['label' => 'Low stock items',    'prompt' => 'Show me items that are low in stock',           'icon' => 'package-x', 'kind' => 'stock'],
                ['label' => 'Stock value',        'prompt' => 'What is the total value of current stock?',     'icon' => 'banknote',  'kind' => 'stock'],
                ['label' => 'Slow moving items',  'prompt' => 'Show me slow moving items by stock turnover',   'icon' => 'snowflake', 'kind' => 'stock'],
            ],
            'ledger' => [
                ['label' => 'Open ledger for…',       'prompt' => 'Open ledger for ',               'icon' => 'book-open', 'kind' => 'ledger'],
                ['label' => 'Ledger balance summary', 'prompt' => 'Show me a ledger balance summary', 'icon' => 'scale',     'kind' => 'ledger'],
            ],
            'expenses' => [
                ['label' => 'Total expenses this month', 'prompt' => 'Total expenses this month',           'icon' => 'receipt',   'kind' => 'expenses'],
                ['label' => 'Expense by category',       'prompt' => 'Show me expenses by category',        'icon' => 'pie-chart', 'kind' => 'expenses'],
            ],
            'payments' => [
                ['label' => 'Recent payments', 'prompt' => 'Show me the most recent payments received', 'icon' => 'wallet', 'kind' => 'payments'],
            ],
            'leads' => [
                ['label' => 'New leads this week', 'prompt' => 'Show me new leads added this week',  'icon' => 'user-plus',   'kind' => 'leads'],
                ['label' => 'Leads by status',     'prompt' => 'Show me leads grouped by status',    'icon' => 'list-checks', 'kind' => 'leads'],
            ],
            'tasks' => [
                ['label' => 'Pending tasks', 'prompt' => 'Show me my pending tasks', 'icon' => 'check-square', 'kind' => 'tasks'],
            ],
        ];
    }

    /**
     * Build the chip list for a tenant.
     *
     * @param  list<array<string, mixed>>|null  $tablesMetadata
     * @param  array{limit?: int}  $opts
     * @return array{
     *     roles: list<string>,
     *     chips: list<array{label: string, prompt: string, icon: string, kind: string}>,
     * }
     */
    public static function build(?array $tablesMetadata, array $opts = []): array
    {
        $limit = max(2, min(8, (int) ($opts['limit'] ?? 6)));

        if (! is_array($tablesMetadata) || count($tablesMetadata) === 0) {
            return ['roles' => [], 'chips' => array_slice(self::GENERIC_CHIPS, 0, $limit)];
        }

        // Detect roles. classify() handles 'tasks' too — we accept it here and
        // ignore from chips if the catalog has no entry for it.
        $detected = [];
        foreach ($tablesMetadata as $meta) {
            $kind = self::classify($meta);
            if ($kind !== 'other') {
                $detected[$kind] = true;
            }
        }

        // Build chip pool in priority order
        $catalog = self::catalog();
        $pool = [];
        foreach (self::ROLE_ORDER as $role) {
            if (! isset($detected[$role])) continue;
            foreach ($catalog[$role] ?? [] as $c) {
                $pool[] = $c;
            }
        }

        if (count($pool) === 0) {
            return ['roles' => [], 'chips' => array_slice(self::GENERIC_CHIPS, 0, $limit)];
        }

        // Round-robin selection so first row shows variety
        $buckets = [];
        foreach ($pool as $c) {
            $buckets[$c['kind']][] = $c;
        }
        $kinds = array_keys($buckets);
        $result = [];
        $idx = 0;
        while (count($result) < $limit) {
            $added = false;
            foreach ($kinds as $k) {
                if (isset($buckets[$k][$idx])) {
                    $result[] = $buckets[$k][$idx];
                    $added = true;
                    if (count($result) >= $limit) {
                        break 2;
                    }
                }
            }
            if (! $added) break;
            $idx++;
        }

        return [
            'roles' => array_keys($detected),
            'chips' => $result,
        ];
    }

    /**
     * Classify a single table — extends TableClassifier with a 'tasks' role
     * for delegation/checklist/task tables that the dashboard ignores.
     *
     * @param  array<string, mixed>  $meta
     */
    public static function classify(array $meta): string
    {
        $name = strtolower((string) ($meta['source_name'] ?? $meta['pg_table'] ?? ''));
        if (preg_match('/checklist|task|delegation/', $name)) {
            return 'tasks';
        }

        return TableClassifier::classify($meta);
    }
}
