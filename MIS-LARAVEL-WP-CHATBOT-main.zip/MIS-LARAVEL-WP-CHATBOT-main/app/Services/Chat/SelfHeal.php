<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * SelfHeal — six-layer auto-recovery for AI SQL execution.
 *
 *   classifyError      — TRANSIENT vs SCHEMA vs USER vs PERMANENT
 *   withRetry          — generic retry with exponential backoff (transient only)
 *   resolveColumnError — AI used wrong column → Levenshtein-suggest closest, rewrite SQL
 *   detectSchemaDrift  — diff sheet headers vs existing PG columns
 *   relaxSQL           — on 0 rows, drop date / loosen ILIKE — try simpler variants
 *   validateResult     — detect single-row-all-NULL aggregates, suspicious empties
 *   pingDb             — round-trip the DB; used by /health
 *
 * Port of Node helpers/self-heal.js (Phase 10).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/self-heal.js
 */
final class SelfHeal
{
    // ════════════════════════════════════════════════════════════════════
    // 10.6 — ERROR CLASSIFICATION
    // ════════════════════════════════════════════════════════════════════

    /**
     * @return array{kind: string, retryable: bool, friendly: string}
     */
    public static function classifyError(?Throwable $err): array
    {
        if ($err === null) {
            return ['kind' => 'UNKNOWN', 'retryable' => false, 'friendly' => 'Something went wrong.'];
        }

        $msg = strtolower($err->getMessage());
        $code = method_exists($err, 'getCode') ? strtolower((string) $err->getCode()) : '';

        // TRANSIENT (network) — auto-retry safely
        if (
            preg_match(
                '/econnreset|etimedout|enotfound|enetunreach|socket hang up|fetch failed|connection (terminated|refused|reset)|network (error|request failed)/',
                $msg
            )
            || in_array($code, ['econnreset', 'etimedout', 'enotfound', 'enetunreach', 'eai_again', 'epipe'], true)
        ) {
            return ['kind' => 'TRANSIENT', 'retryable' => true, 'friendly' => 'Minor network issue — retrying...'];
        }

        if (preg_match('/timeout|timed out|deadline exceeded/', $msg)) {
            return ['kind' => 'TIMEOUT', 'retryable' => true, 'friendly' => 'Server is slow — retrying...'];
        }

        if (preg_match('/rate limit|too many requests|429|quota/', $msg)) {
            return ['kind' => 'RATE_LIMIT', 'retryable' => true, 'friendly' => 'Hit a rate limit — retrying shortly...'];
        }

        // MySQL: "Unknown column 'x' in 'field list'/'where clause'/'group statement'/'order clause'".
        // (Postgres-style "column ... does not exist" kept too in case a tenant DB is ever swapped.)
        if (preg_match('/unknown column|column .* does not exist|column ".+" of relation/', $msg)) {
            return ['kind' => 'SCHEMA_COLUMN', 'retryable' => true, 'friendly' => 'Column name was wrong — fixing and retrying...'];
        }

        // MySQL: "Base table or view not found: ... Table 'db.name' doesn't exist".
        if (preg_match('/doesn.t exist|base table or view not found|relation .* does not exist|table .* does not exist/', $msg)) {
            return ['kind' => 'SCHEMA_RELATION', 'retryable' => false, 'friendly' => 'Table not found. Please re-sync the sheet.'];
        }

        if (preg_match('/permission denied|insufficient privilege|rls|access denied/', $msg)) {
            return ['kind' => 'PERMISSION', 'retryable' => false, 'friendly' => 'Permission issue — please contact admin.'];
        }

        // Checked AFTER the schema-specific patterns above so a genuine "unknown column"
        // error whose Laravel-appended raw-SQL text happens to contain "group by" doesn't
        // get misclassified as SQL_SYNTAX and skip the cheap column-name fix.
        if (preg_match('/syntax error|invalid input syntax|operator does not exist|aggregate.*invalid|group by/', $msg)) {
            return ['kind' => 'SQL_SYNTAX', 'retryable' => true, 'friendly' => 'Query was a bit off — retrying...'];
        }

        if (preg_match('/division by zero|out of range|numeric overflow|invalid input/', $msg)) {
            return ['kind' => 'PERMANENT', 'retryable' => false, 'friendly' => 'Calculation error.'];
        }

        return ['kind' => 'UNKNOWN', 'retryable' => false, 'friendly' => 'Something went wrong — please try again.'];
    }

    // ════════════════════════════════════════════════════════════════════
    // 10.5 — GENERIC RETRY WITH EXPONENTIAL BACKOFF
    // ════════════════════════════════════════════════════════════════════

    /**
     * Run callable with auto-retry on transient errors.
     *
     * @template T
     * @param  callable(int): T  $fn  receives attempt number (1-indexed)
     * @param  array{maxAttempts?: int, baseDelayMs?: int, label?: string, onRetry?: callable(Throwable, int): void}  $opts
     * @return T
     */
    public static function withRetry(callable $fn, array $opts = []): mixed
    {
        $max = $opts['maxAttempts'] ?? 3;
        $base = $opts['baseDelayMs'] ?? 250;
        $label = $opts['label'] ?? 'op';
        $lastErr = null;

        for ($attempt = 1; $attempt <= $max; $attempt++) {
            try {
                return $fn($attempt);
            } catch (Throwable $err) {
                $lastErr = $err;
                $cls = self::classifyError($err);
                if (! $cls['retryable'] || $attempt >= $max) {
                    throw $err;
                }

                $delay = (int) ($base * (2 ** ($attempt - 1)));
                Log::info("[SELF-HEAL] $label attempt $attempt/$max failed ({$cls['kind']}: ".substr($err->getMessage(), 0, 80).") — retrying in {$delay}ms");
                if (isset($opts['onRetry']) && is_callable($opts['onRetry'])) {
                    try { ($opts['onRetry'])($err, $attempt); } catch (Throwable) { /* ignore */ }
                }
                usleep($delay * 1000);
            }
        }

        throw $lastErr;
    }

    // ════════════════════════════════════════════════════════════════════
    // 10.1 — FUZZY COLUMN NAME RESOLUTION
    // ════════════════════════════════════════════════════════════════════

    /** Levenshtein distance, lowercased, iterative DP. PHP has built-in levenshtein() with same semantics. */
    public static function levenshtein(string $a, string $b): int
    {
        return levenshtein(strtolower($a), strtolower($b));
    }

    /**
     * Find closest match from a list of candidate column names, with substring + prefix boosts.
     *
     * @param  list<string>  $candidates
     * @return array{name: string, distance: int|float, score: float}|null
     */
    public static function findClosestColumn(string $bad, array $candidates): ?array
    {
        if ($bad === '' || count($candidates) === 0) {
            return null;
        }
        $badLower = strtolower($bad);
        $best = null;

        foreach ($candidates as $cand) {
            $candLower = strtolower($cand);
            $dist = levenshtein($badLower, $candLower);

            // Substring boost — "amount" inside "with_gst_amount" beats "amt"
            if (str_contains($candLower, $badLower) || str_contains($badLower, $candLower)) {
                $dist = max(0, $dist - min(strlen($badLower), strlen($candLower)) / 2);
            }
            // Prefix boost — "qty" matches "quantity"
            if (str_starts_with($candLower, $badLower) || str_starts_with($badLower, $candLower)) {
                $dist = max(0, $dist - 1);
            }

            $maxLen = max(strlen($badLower), strlen($candLower));
            $score = $maxLen > 0 ? 1 - ($dist / $maxLen) : 0;

            if ($best === null || $dist < $best['distance']) {
                $best = ['name' => $cand, 'distance' => $dist, 'score' => $score];
            }
        }

        return $best;
    }

    /**
     * Parse Postgres "column does not exist" error and rewrite SQL with closest match.
     *
     * @param  list<string>  $knownColumns
     * @return array{rewrittenSQL: string, badCol: string, goodCol: string, score: float}|null
     */
    public static function resolveColumnError(string $errorMsg, string $sql, array $knownColumns, float $minScore = 0.5): ?array
    {
        if ($errorMsg === '' || $sql === '' || count($knownColumns) === 0) {
            return null;
        }

        if (! preg_match('/column "?([a-zA-Z_][\w.]*)"? (?:does not exist|of relation)/i', $errorMsg, $m)) {
            return null;
        }

        $badCol = $m[1];
        if (str_contains($badCol, '.')) {
            $parts = explode('.', $badCol);
            $badCol = end($parts);
        }

        // Already valid? Then this isn't a typo
        $knownLower = array_map('strtolower', $knownColumns);
        if (in_array(strtolower($badCol), $knownLower, true)) {
            return null;
        }

        $match = self::findClosestColumn($badCol, $knownColumns);
        if ($match === null || $match['score'] < $minScore) {
            return null;
        }

        // Whole-word replacement, case-insensitive
        $escaped = preg_quote($badCol, '/');
        $rewritten = (string) preg_replace("/\b{$escaped}\b/i", $match['name'], $sql);
        if ($rewritten === $sql) {
            return null;
        }

        return [
            'rewrittenSQL' => $rewritten,
            'badCol'       => $badCol,
            'goodCol'      => $match['name'],
            'score'        => (float) $match['score'],
        ];
    }

    /**
     * Build flat list of all known PG column names from tables_metadata.
     *
     * @param  list<array<string, mixed>>  $tablesMetadata
     * @return list<string>
     */
    public static function flattenColumnNames(array $tablesMetadata): array
    {
        $set = [];
        foreach ($tablesMetadata as $t) {
            foreach (($t['columns'] ?? []) as $c) {
                if (! empty($c['pg_name'])) {
                    $set[$c['pg_name']] = true;
                }
            }
        }

        return array_keys($set);
    }

    // ════════════════════════════════════════════════════════════════════
    // 10.2 — SCHEMA DRIFT DETECTION
    // ════════════════════════════════════════════════════════════════════

    /**
     * Compare live PG columns vs newly-built sheetColumns.
     *
     * @param  list<string>  $pgColumns  lowercased real PG columns
     * @param  list<array{pg_name: string, pg_type: string, role?: string}>  $sheetColumns
     * @param  list<array{pg_name: string, pg_type?: string, role?: string}>|null  $previousMeta
     * @return array{
     *     added:       list<array{name: string, type: string, role: ?string}>,
     *     removed:     list<string>,
     *     typeChanged: list<array{name: string, from: string, to: string}>,
     *     total:       int,
     *     summary:     string,
     * }
     */
    public static function detectSchemaDrift(array $pgColumns, array $sheetColumns, ?array $previousMeta = null): array
    {
        $pgLower = array_map('strtolower', $pgColumns);
        $sheetLower = array_map(static fn ($c) => strtolower($c['pg_name']), $sheetColumns);
        $systemCols = ['id', 'created_at', 'updated_at', '_row_id'];

        $added = [];
        foreach ($sheetColumns as $c) {
            if (! in_array(strtolower($c['pg_name']), $pgLower, true)) {
                $added[] = ['name' => $c['pg_name'], 'type' => $c['pg_type'] ?? 'TEXT', 'role' => $c['role'] ?? null];
            }
        }

        $removed = [];
        foreach ($pgColumns as $pgCol) {
            $lower = strtolower($pgCol);
            if (in_array($lower, $systemCols, true)) continue;
            if (! in_array($lower, $sheetLower, true)) {
                $removed[] = $pgCol;
            }
        }

        $typeChanged = [];
        if ($previousMeta !== null && count($previousMeta) > 0) {
            $prevByName = [];
            foreach ($previousMeta as $c) {
                $prevByName[strtolower($c['pg_name'])] = $c;
            }
            foreach ($sheetColumns as $c) {
                $prev = $prevByName[strtolower($c['pg_name'])] ?? null;
                if ($prev && (
                    ($prev['pg_type'] ?? null) !== ($c['pg_type'] ?? null) ||
                    ($prev['role']    ?? null) !== ($c['role']    ?? null)
                )) {
                    $typeChanged[] = [
                        'name' => $c['pg_name'],
                        'from' => ($prev['pg_type'] ?? '?').'/'.($prev['role'] ?? '?'),
                        'to'   => ($c['pg_type']    ?? '?').'/'.($c['role']    ?? '?'),
                    ];
                }
            }
        }

        $parts = [];
        if (count($added))       $parts[] = '+'.count($added).' added';
        if (count($removed))     $parts[] = '-'.count($removed).' removed';
        if (count($typeChanged)) $parts[] = '~'.count($typeChanged).' type-drift';
        $summary = count($parts) > 0
            ? 'schema drift: '.implode(', ', $parts)
            : 'schema unchanged';

        return [
            'added'       => $added,
            'removed'     => $removed,
            'typeChanged' => $typeChanged,
            'total'       => count($sheetColumns),
            'summary'     => $summary,
        ];
    }

    // ════════════════════════════════════════════════════════════════════
    // 10.3 — SMART QUERY RELAXATION
    // ════════════════════════════════════════════════════════════════════

    /**
     * Generate progressively simpler SQL variants for a 0-row query.
     *
     * @return list<string>
     */
    public static function relaxSQL(string $sql): array
    {
        if ($sql === '') return [];
        $variants = [];

        // L1: drop all date-shaped predicates.
        // Order matters — BETWEEN must be matched first because it contains an internal `AND`
        // that would otherwise terminate the lazier $dateActual regex too early.
        $dateBetween = '/\s+AND\s+\w*(?:date|_actual)\w*\s+BETWEEN\s+\'[^\']*\'\s+AND\s+\'[^\']*\'/i';
        $dateLike = '/\s+AND\s+\w*date\w*\s+(?:I?LIKE)\s+\'[^\']*\'/i';
        $dateActual = '/\s+AND\s+\w*_actual\b[^)]*?(?=\s+AND\b|\s+GROUP\b|\s+ORDER\b|\s+LIMIT\b|$)/i';

        $v1 = (string) preg_replace($dateBetween, '', $sql);
        $v1 = (string) preg_replace($dateLike, '', $v1);
        $v1 = (string) preg_replace($dateActual, '', $v1);
        if ($v1 !== $sql) {
            $variants[] = $v1;
        }

        // L2: loosen the longest LIKE term (multi-word → first word only)
        preg_match_all('/(\w+)\s+(?:I?LIKE)\s+\'%([^%\']+)%\'/i', $sql, $matches, PREG_SET_ORDER);
        $longest = null;
        foreach ($matches as $m) {
            if (str_contains($m[2], ' ') && ($longest === null || strlen($m[2]) > strlen($longest['term']))) {
                $longest = ['full' => $m[0], 'col' => $m[1], 'term' => $m[2]];
            }
        }
        if ($longest !== null) {
            $firstWord = preg_split('/\s+/', $longest['term'])[0] ?? '';
            if ($firstWord !== '' && strlen($firstWord) >= 3) {
                $v2 = str_replace($longest['full'], $longest['col']." LIKE '%{$firstWord}%'", $sql);
                if ($v2 !== $sql) {
                    $variants[] = $v2;
                }
            }
        }

        // L3: combine L1 + L2
        if (count($variants) >= 2 && $longest !== null) {
            $firstWord = preg_split('/\s+/', $longest['term'])[0] ?? '';
            if ($firstWord !== '' && strlen($firstWord) >= 3) {
                $v3 = str_replace($longest['full'], $longest['col']." LIKE '%{$firstWord}%'", $variants[0]);
                if ($v3 !== $variants[0] && ! in_array($v3, $variants, true)) {
                    $variants[] = $v3;
                }
            }
        }

        return $variants;
    }

    // ════════════════════════════════════════════════════════════════════
    // 10.4 — RESULT VALIDATION
    // ════════════════════════════════════════════════════════════════════

    /**
     * Heuristic checks for "the SQL ran but the answer is bogus".
     *
     * @param  list<array<string, mixed>|object>  $rows
     * @return array{ok: bool, hint: ?string}
     */
    public static function validateResult(array $rows, string $query): array
    {
        if (count($rows) === 0) {
            return ['ok' => false, 'hint' => 'No rows returned.'];
        }
        $q = strtolower($query);

        $first = is_object($rows[0]) ? get_object_vars($rows[0]) : $rows[0];

        if (count($rows) === 1) {
            $keys = array_keys($first);
            $allNull = true;
            foreach ($keys as $k) {
                if ($first[$k] !== null) {
                    $allNull = false;
                    break;
                }
            }
            if ($allNull && count($keys) > 0) {
                return [
                    'ok'   => false,
                    'hint' => 'Result was a single row with all-NULL values. The WHERE clause likely matched no source rows. Try widening filters or checking column names match the user intent.',
                ];
            }

            // Single-row aggregate where every numeric is 0
            $numerics = array_filter(array_values($first), static fn ($v) => is_numeric($v));
            if (count($numerics) > 0
                && array_reduce($numerics, static fn ($acc, $v) => $acc && (float) $v === 0.0, true)
                && preg_match('/\b(total|sum|kitn[aei]|how much|count|average|avg|highest|lowest)\b/i', $q)
            ) {
                return [
                    'ok'   => false,
                    'hint' => 'Aggregate returned 0 for every numeric column. Filters may be too narrow (date / entity / category).',
                ];
            }
        }

        if (count($rows) <= 1
            && preg_match('/\b(top\s*\d+|list|sabhi|saare|all|kitne|wise|each|every|breakdown|month-?wise|city-?wise)\b/i', $q)
        ) {
            return [
                'ok'   => false,
                'hint' => 'User asked for a list/breakdown but only '.count($rows).' row returned. The GROUP BY may be wrong or filters too tight.',
            ];
        }

        return ['ok' => true, 'hint' => null];
    }

    // ════════════════════════════════════════════════════════════════════
    // HEALTH CHECK
    // ════════════════════════════════════════════════════════════════════

    /**
     * @return array{ok: bool, latencyMs: int, error?: string}
     */
    public static function pingDb(int $timeoutMs = 3000): array
    {
        $start = microtime(true);
        try {
            $rows = DB::select('SELECT 1 AS ok');
            $latency = (int) ((microtime(true) - $start) * 1000);
            if (count($rows) === 0) {
                return ['ok' => false, 'latencyMs' => $latency, 'error' => 'empty response'];
            }

            return ['ok' => true, 'latencyMs' => $latency];
        } catch (Throwable $e) {
            return [
                'ok'        => false,
                'latencyMs' => (int) ((microtime(true) - $start) * 1000),
                'error'     => $e->getMessage(),
            ];
        }
    }
}
