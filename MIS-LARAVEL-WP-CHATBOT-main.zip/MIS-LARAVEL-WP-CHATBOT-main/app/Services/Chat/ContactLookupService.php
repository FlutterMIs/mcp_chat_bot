<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * ContactLookupService — syncs CONTACTS tab from Google Sheet and provides
 * name-based lookup filtered by the tenant's phone number.
 */
final class ContactLookupService
{
    private const TABLE = 'contacts';

    /**
     * Sync the CONTACTS tab data into a simple `contacts` table.
     * Called during tenant sync or on-demand.
     */
    public static function syncFromSheet(string $sheetId): int
    {
        try {
            $tabs = \App\Services\Sheets\SheetSchemaDetector::discoverTabs($sheetId);
            $contactsTab = null;
            foreach ($tabs as $tab) {
                $tabName = $tab['name'] ?? '';
                if (stripos($tabName, 'contact') !== false || stripos($tabName, 'calendar') !== false || stripos($tabName, 'calander') !== false) {
                    $contactsTab = $tab;
                    break;
                }
            }
            // Fallback: use first tab if only one tab exists
            if ($contactsTab === null && count($tabs) === 1) {
                $contactsTab = $tabs[0];
            }
            if ($contactsTab === null) return 0;

            $data = \App\Services\Sheets\SheetSchemaDetector::fetchSheet($sheetId, $contactsTab['gid']);
            if (!is_array($data) || count($data) < 2) return 0;

            // fetchSheet returns [headers_array, [row1_assoc, row2_assoc, ...]]
            $rows = $data[1] ?? [];
            if (!is_array($rows) || count($rows) === 0) return 0;

            // Create table if not exists
            DB::statement("CREATE TABLE IF NOT EXISTS `contacts` (
                `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                `requested_number` VARCHAR(500) NULL,
                `company_name` VARCHAR(255) NULL,
                `client_name` VARCHAR(255) NULL,
                `client_number` VARCHAR(50) NULL,
                `client_email` VARCHAR(255) NULL,
                `ea_name` VARCHAR(255) NULL,
                `ea_number` VARCHAR(50) NULL,
                `ea_email` VARCHAR(255) NULL,
                `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

            DB::table(self::TABLE)->truncate();

            $inserted = 0;
            foreach ($rows as $row) {
                if (!is_array($row)) continue;
                $name = trim((string) ($row['CLIENT NAME'] ?? $row['client_name'] ?? $row['Client Name'] ?? ''));
                if ($name === '') continue;

                DB::table(self::TABLE)->insert([
                    'requested_number' => trim((string) ($row['REQUESTED NUMBER'] ?? $row['requested_number'] ?? '')),
                    'company_name'     => trim((string) ($row['COMPANY NAME'] ?? $row['company_name'] ?? '')),
                    'client_name'      => $name,
                    'client_number'    => trim((string) ($row['CLIENT NUMBER'] ?? $row['client_number'] ?? $row['CLIENT MOBILE'] ?? '')),
                    'client_email'     => trim((string) ($row['CLIENT EMAIL'] ?? $row['client_email'] ?? '')),
                    'ea_name'          => trim((string) ($row['EA NAME'] ?? $row['ea_name'] ?? '')),
                    'ea_number'        => trim((string) ($row['EA NUMBER'] ?? $row['ea_number'] ?? '')),
                    'ea_email'         => trim((string) ($row['EA EMAIL'] ?? $row['ea_email'] ?? '')),
                ]);
                $inserted++;
            }

            Log::info("[CONTACTS SYNC] {$inserted} contacts synced from sheet {$sheetId}");
            return $inserted;
        } catch (Throwable $e) {
            Log::error('[CONTACTS SYNC] ' . $e->getMessage());
            return 0;
        }
    }

    /**
     * Search contacts by name, filtered by tenant phone.
     *
     * @return list<array{client_name:string, client_number:string, client_email:string}>
     */
    public static function search(string $name, string $tenantPhone): array
    {
        try {
            // Check if table exists
            $exists = DB::select("SHOW TABLES LIKE 'contacts'");
            if (count($exists) === 0) return [];

            // Strip leading 91 for matching (REQUESTED NUMBER may have various formats)
            $phone = preg_replace('/^91/', '', preg_replace('/[^0-9]/', '', $tenantPhone));

            // Split name into words and search — any word match is sufficient
            $words = preg_split('/\s+/', trim($name));
            $conditions = [];
            $params = [];
            foreach ($words as $w) {
                $w = preg_replace('/[^a-zA-Z0-9]/', '', $w); // strip punctuation
                if (strlen($w) >= 3) {
                    $conditions[] = '`client_name` LIKE ?';
                    $params[] = '%' . $w . '%';
                }
            }
            if (count($conditions) === 0) {
                // Fallback: use the full name stripped of non-alpha
                $clean = preg_replace('/[^a-zA-Z0-9 ]/', '', $name);
                $conditions[] = '`client_name` LIKE ?';
                $params[] = '%' . trim($clean) . '%';
            }

            $where = '(' . implode(' OR ', $conditions) . ')';
            $rows = DB::select(
                "SELECT client_name, client_number, client_email, requested_number
                 FROM `contacts`
                 WHERE {$where}
                 ORDER BY `client_name`
                 LIMIT 15",
                $params
            );

            // Filter by tenant phone — REQUESTED NUMBER is comma-separated, check if tenant's phone appears
            $results = [];
            foreach ($rows as $r) {
                $reqNums = preg_replace('/[^0-9,]/', '', $r->requested_number ?? '');
                // Check if any number in the comma-list contains the tenant phone (last 10 digits)
                $match = false;
                foreach (explode(',', $reqNums) as $num) {
                    $num = trim($num);
                    if ($num !== '' && (str_contains($num, $phone) || str_contains($phone, substr($num, -10)))) {
                        $match = true;
                        break;
                    }
                }
                if ($match) {
                    $results[] = [
                        'client_name'   => $r->client_name,
                        'client_number' => $r->client_number,
                        'client_email'  => $r->client_email,
                    ];
                }
            }

            return $results;
        } catch (Throwable $e) {
            Log::warning('[CONTACTS SEARCH] ' . $e->getMessage());
            return [];
        }
    }

    private static function findCol(array $headers, array $names): ?int
    {
        foreach ($names as $n) {
            $idx = array_search($n, $headers);
            if ($idx !== false) return (int) $idx;
        }
        return null;
    }
}
