<?php

declare(strict_types=1);

namespace App\Services\Chat;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use NumberFormatter;
use Throwable;

/**
 * SmartFormatter — type-aware WhatsApp result formatter.
 *
 * Replaces the regex `₹`-on-everything formatter with role-driven formatting:
 *   currency → ₹X.XX with Indian commas + Cr/L suffix when ≥ 1L
 *   quantity → 3,040 KG (or just number when unit unknown)
 *   rate     → ₹70.00
 *   percent  → 12.50%
 *   count    → 47 (no ₹, no commas for small numbers)
 *   date/id/entity/location/category → preserved as-is
 *
 * Port of Node helpers/smart-format.js (Phase 6).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/smart-format.js
 */
final class SmartFormatter
{
    /**
     * Format a result-set as a WhatsApp-friendly message.
     *
     * Returns null when row count > 15 — caller should use aiFormat() / PDF / CSV.
     *
     * @param  list<array<string, mixed>|object>  $rows
     * @param  list<array<string, mixed>>  $tableColumns  columnsMeta from tenants.tables_metadata
     */
    public static function formatResults(string $query, array $rows, array $tableColumns = []): ?string
    {
        if (count($rows) === 0) {
            return null;
        }

        $rows = array_map(self::toAssoc(...), $rows);
        $roleMap = self::buildRoleMap($rows[0], $tableColumns);

        // Single row, few keys → vertical key:value layout
        if (count($rows) === 1 && count($rows[0]) <= 6) {
            $lines = [];
            foreach ($rows[0] as $key => $val) {
                if ($val === null || $val === '' || $val === []) continue;
                $meta = $roleMap[$key]
                    ?? $roleMap[strtolower($key)]
                    ?? ['role' => self::inferRoleFromKey($key, $val), 'original' => self::humanizeLabel($key)];
                if (self::isNoiseColumn($key, $meta)) continue;
                $label = self::humanizeLabel($meta['original'] ?? $key);
                $formatted = self::formatValue($val, $meta['role'] ?? 'text');
                if ($formatted !== '') {
                    $lines[] = "*{$label}:* {$formatted}";
                }
            }

            return '📊 '.implode("\n", $lines);
        }

        // Multi-row → numbered list with emoji bullets + aggregate summary
        if (count($rows) <= 15) {
            $emojis = ['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟','1️⃣1️⃣','1️⃣2️⃣','1️⃣3️⃣','1️⃣4️⃣','1️⃣5️⃣'];
            $keys = array_keys($rows[0]);
            $lines = [];
            foreach ($rows as $i => $row) {
                $parts = [];
                foreach ($keys as $k) {
                    $val = $row[$k] ?? null;
                    if ($val === null || $val === '' || $val === []) continue;
                    $meta = $roleMap[$k]
                        ?? $roleMap[strtolower($k)]
                        ?? ['role' => self::inferRoleFromKey($k, $val), 'original' => self::humanizeLabel($k)];
                    if (self::isNoiseColumn($k, $meta)) continue;
                    $formatted = self::formatValue($val, $meta['role'] ?? 'text');
                    if ($formatted !== '') {
                        $parts[] = $formatted;
                    }
                }
                $bullet = $emojis[$i] ?? ($i + 1).'.';
                $lines[] = $bullet.' '.implode(' — ', $parts);
            }

            $summary = self::buildAggregateSummary($rows, $keys, $roleMap);
            $out = '📋 *'.count($rows)." results:*\n\n".implode("\n", $lines);
            if ($summary !== null) {
                $out .= "\n\n".$summary;
            }

            return $out;
        }

        // Many rows → caller should use aiFormat() or PDF/CSV
        return null;
    }

    /**
     * Build aggregate-summary line for multi-row output: "📊 *Total across N:* ..."
     *
     * @param  list<array<string, mixed>>  $rows
     * @param  list<string>  $keys
     * @param  array<string, array<string, mixed>>  $roleMap
     */
    public static function buildAggregateSummary(array $rows, array $keys, array $roleMap): ?string
    {
        if (count($rows) < 2) {
            return null;
        }
        $numericRoles = ['currency', 'quantity', 'count', 'number', 'rate'];
        $summable = array_filter($keys, static function ($k) use ($roleMap, $rows, $numericRoles) {
            $meta = $roleMap[$k] ?? $roleMap[strtolower($k)] ?? null;
            $role = $meta['role'] ?? self::inferRoleFromKey($k, $rows[0][$k] ?? null);

            return in_array($role, $numericRoles, true);
        });

        if (count($summable) === 0) {
            return null;
        }

        $parts = [];
        foreach ($summable as $k) {
            $meta = $roleMap[$k] ?? $roleMap[strtolower($k)] ?? [
                'role'     => self::inferRoleFromKey($k, $rows[0][$k] ?? null),
                'original' => self::humanizeLabel($k),
            ];
            if (($meta['role'] ?? null) === 'rate') {
                // Averages don't sum meaningfully — skip
                continue;
            }
            $total = 0.0;
            $count = 0;
            foreach ($rows as $r) {
                $n = is_numeric($r[$k] ?? null) ? (float) $r[$k] : null;
                if ($n !== null) {
                    $total += $n;
                    $count++;
                }
            }
            if ($count === 0) continue;
            $label = self::humanizeLabel($meta['original'] ?? $k);
            $formatted = self::formatValue($total, $meta['role'] ?? 'text');
            if ($formatted !== '') {
                $parts[] = "*{$label}:* {$formatted}";
            }
        }

        if (count($parts) === 0) {
            return null;
        }

        return '📊 *Total across '.count($rows).':* '.implode(' | ', $parts);
    }

    /**
     * AI fallback formatter for > 15 rows. Pre-formats rows with proper types
     * before sending to gpt-4o-mini so the AI can't destroy currency formatting.
     *
     * @param  list<array<string, mixed>|object>  $rows
     * @param  list<array<string, mixed>>  $tableColumns
     */
    public static function aiFormat(string $query, array $rows, array $tableColumns = []): string
    {
        $rows = array_map(self::toAssoc(...), $rows);
        if (count($rows) === 0) {
            return '';
        }

        $roleMap = self::buildRoleMap($rows[0], $tableColumns);

        // Pre-format top 20 rows
        $preformatted = [];
        foreach (array_slice($rows, 0, 20) as $r) {
            $obj = [];
            foreach ($r as $k => $v) {
                $meta = $roleMap[$k]
                    ?? $roleMap[strtolower($k)]
                    ?? ['role' => self::inferRoleFromKey($k, $v), 'original' => self::humanizeLabel($k)];
                $label = self::humanizeLabel($meta['original'] ?? $k);
                $formatted = self::formatValue($v, $meta['role'] ?? 'text');
                $obj[$label] = $formatted !== '' ? $formatted : ($v ?? '');
            }
            $preformatted[] = $obj;
        }

        // Cost optimization: skip AI call, use template formatting directly.
        // The pre-formatted data is already clean with proper ₹/Cr formatting.
        return self::dumpPreformatted($preformatted, count($rows));
    }

    /**
     * Use GPT to format query results beautifully for WhatsApp.
     * Returns formatted string or null on failure (caller falls back to template).
     */
    public static function aiPrettyFormat(string $query, array $rows, array $tableColumns = [], ?string $tenantId = null, bool $webMode = false): ?string
    {
        $rows = array_map(self::toAssoc(...), $rows);
        if (count($rows) === 0) return null;

        $apiKey = (string) config('mis.openai_api_key', '');
        // AiGateway will resolve key — skip early-return if tenant has own key
        if ($apiKey === '' && !$tenantId) return null;

        // Pre-format rows with role-aware values (₹, dates etc)
        $roleMap = self::buildRoleMap($rows[0], $tableColumns);
        $formatted = [];
        foreach (array_slice($rows, 0, 30) as $r) {
            $obj = [];
            foreach ($r as $k => $v) {
                $meta = $roleMap[$k] ?? $roleMap[strtolower($k)] ?? ['role' => self::inferRoleFromKey($k, $v), 'original' => self::humanizeLabel($k)];
                $label = self::humanizeLabel($meta['original'] ?? $k);
                $obj[$label] = self::formatValue($v, $meta['role'] ?? 'text') ?: ($v ?? '');
            }
            $formatted[] = $obj;
        }

        $dataJson = json_encode($formatted, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        $totalRows = count($rows);

        // Inject admin-customizable prompt
        $extraInst = $tenantId ? \App\Models\TenantPrompt::getFormatInstruction($tenantId, $webMode) : '';

        try {
            $system = $webMode
                ? "You format data results for a web dashboard chat panel. Rules:\n- Use standard Markdown: **bold** for key values like **₹2.47 L**\n- Use `-` for bullet lists, `1.` for numbered lists\n- Group related data logically\n- Show totals/summaries at bottom if multiple rows\n- Currency already formatted (₹X.XX L/Cr) — keep as-is\n- Keep it concise but readable\n- If >10 rows, summarize key insights + show top entries\n- IMPORTANT: If any field contains a URL/link (starts with http), ALWAYS include it as a Markdown link: [View](url). NEVER drop or summarize URLs.\n- Reply ONLY with the formatted message, no explanation{$extraInst}"
                : "You format data results for WhatsApp messages. Rules:\n- Use WhatsApp bold: wrap key values in * like *₹2.47 L* (no spaces after opening * or before closing *)\n- Use relevant emojis (💰📞📧📄📌🔹📊✅❌📋)\n- Group related data logically\n- Show totals/summaries at bottom if multiple rows\n- Currency already formatted (₹X.XX L/Cr) — keep as-is\n- Keep it concise but readable\n- Use ━━━ as separators\n- If >10 rows, summarize key insights + show top entries\n- IMPORTANT: If any field contains a URL/link (starts with http), ALWAYS include it as-is with a label like 📄 Link: <url>. NEVER drop or summarize URLs.\n- Reply ONLY with the formatted message, no explanation{$extraInst}";
            $messages = [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => "User asked: \"{$query}\"\n\nData ({$totalRows} rows" . ($totalRows > 30 ? ', showing first 30' : '') . "):\n{$dataJson}"],
            ];
            $aiResult = \App\Services\AI\AiGateway::chat($tenantId, $messages, ['temperature' => 0.3, 'max_tokens' => 2000, 'timeout' => 15]);

            if (!$aiResult['ok']) return null;
            $content = $aiResult['content'];
            return $content && strlen($content) > 10 ? $content : null;
        } catch (Throwable $e) {
            Log::warning('[AI FORMAT] failed: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Format a single value given role + optional unit.
     */
    public static function formatValue(mixed $value, string $role, ?string $unit = null): string
    {
        if ($value === null || $value === '' || $value === []) {
            return '';
        }

        $formatted = match ($role) {
            'currency'                 => self::formatCurrency($value),
            'quantity'                 => self::formatQuantity($value, $unit),
            'rate'                     => self::formatRate($value),
            'percent'                  => self::formatPercent($value),
            'count', 'number'          => self::formatCount($value),
            default                    => self::formatPlain($value),
        };

        // Fallback for currency-on-text-value etc.
        if ($formatted === '' && $value !== null && $value !== '') {
            $formatted = self::formatPlain($value);
        }

        return $formatted;
    }

    public static function formatCurrency(mixed $n): string
    {
        if (! is_numeric($n)) return '';
        $num = (float) $n;
        if ($num === 0.0) return '₹0';
        $abs = abs($num);
        $sign = $num < 0 ? '-' : '';
        $formatted = self::indianFormat($abs, 2);
        if ($abs >= 1e7) return "{$sign}₹{$formatted} (₹".number_format($abs / 1e7, 2).' Cr)';
        if ($abs >= 1e5) return "{$sign}₹{$formatted} (₹".number_format($abs / 1e5, 2).' L)';

        return "{$sign}₹{$formatted}";
    }

    public static function formatQuantity(mixed $n, ?string $unit = null): string
    {
        if (! is_numeric($n)) return '';
        $num = (float) $n;
        $formatted = self::indianFormat($num, 3);

        return $unit ? "{$formatted} {$unit}" : $formatted;
    }

    public static function formatRate(mixed $n): string
    {
        if (! is_numeric($n)) return '';

        return '₹'.self::indianFormat((float) $n, 2);
    }

    public static function formatPercent(mixed $n): string
    {
        if (! is_numeric($n)) return '';

        return number_format((float) $n, 2).'%';
    }

    public static function formatCount(mixed $n): string
    {
        if (! is_numeric($n)) return '';
        $num = (float) $n;
        if (floor($num) === $num) {
            return self::indianFormat($num, 0);
        }

        return self::indianFormat($num, 2);
    }

    public static function formatPlain(mixed $v): string
    {
        if ($v === null) return '';

        return (string) $v;
    }

    /**
     * Indian-grouping number format with up to N fraction digits.
     * Trailing zeros after the decimal point are stripped.
     */
    private static function indianFormat(float $n, int $maxFractionDigits): string
    {
        $fmt = new NumberFormatter('en-IN', NumberFormatter::DECIMAL);
        $fmt->setAttribute(NumberFormatter::MAX_FRACTION_DIGITS, $maxFractionDigits);
        $out = $fmt->format($n);

        return is_string($out) ? $out : (string) $n;
    }

    /**
     * Internal/plumbing columns that clutter a user-facing card without adding
     * information: sync row ids (`_row_id`) and the raw sortable date duplicate
     * kept alongside a display-formatted date column (`role: date_actual`).
     */
    private static function isNoiseColumn(string $key, array $meta): bool
    {
        if (str_starts_with($key, '_')) return true;
        if (($meta['role'] ?? null) === 'date_actual') return true;

        return false;
    }

    /**
     * Infer role from result-set column name + value.
     * Used when AI generates aliases not present in tables_metadata.
     */
    public static function inferRoleFromKey(string $key, mixed $value = null): string
    {
        $k = strtolower($key);

        // Entity FIRST — must beat currency match for "sales_person"
        if (preg_match('/(^|_)(person|name|party|customer|vendor|client|supplier|employee|account)(_|$)|^name$|^party$|sales_?person|salesperson/', $k)) {
            return 'entity';
        }

        // ID-like
        if (preg_match('/voucher|invoice.*no|bill.*no|ref.*no|hsn|gst.*no|^id$|_id$/', $k)) return 'id';

        // Date
        if (preg_match('/^date$|_date$|^dt|created|updated|timestamp/', $k)) return 'date';

        // Location
        if (preg_match('/^city$|^state$|^country$|^location$|^region$|^area$|^address$|_city|_state|_country/', $k)) return 'location';

        // Type / category
        if (preg_match('/^type$|^category$|^class$|^status$|^priority$|^stage$|^group$|^unit$|invtype/', $k)) return 'category';

        // Count-like aliases
        if (preg_match('/^count$|_count$|^cnt$|^num_|^n_|^invoices?$|^orders?$|invoice_count|num_invoices|total_invoices|order_count|total_orders|total_count/', $k)) return 'count';

        // Currency-like
        if (preg_match('/amount|amt|price|cost|^total$|_total$|total_amount|total_amt|^sale$|^sales$|_sales$|revenue|income|expense|debit|credit|balance|gst|cgst|sgst|igst|tax|cess|discount|profit|margin|fees|^sum_|_sum$/', $k)) return 'currency';

        // Quantity
        if (preg_match('/^qty$|_qty$|quantity|weight|stock|units|^kg$|_kg$|total_qty|total_quantity|tot_qty/', $k)) return 'quantity';

        // Percent
        if (preg_match('/pct|percent|%/', $k)) return 'percent';

        // Rate / average
        if (preg_match('/^avg$|^average|^avg_|_avg$|^mean_|_mean$|per_kg|per_unit|^rate$|_rate$/', $k)) {
            if (is_numeric($value) && (float) $value > 1000) {
                return 'currency';
            }

            return 'rate';
        }

        // Sample-driven fallback
        if ($value !== null && $value !== '' && is_numeric($value)) {
            return 'number';
        }

        return 'text';
    }

    /**
     * Build role lookup map from tableColumns (exact match) + per-key inference.
     *
     * @param  array<string, mixed>  $resultRow
     * @param  list<array<string, mixed>>  $tableColumns
     * @return array<string, array<string, mixed>>
     */
    public static function buildRoleMap(array $resultRow, array $tableColumns = []): array
    {
        $map = [];
        foreach ($tableColumns as $c) {
            $pgName = $c['pg_name'] ?? null;
            if (! $pgName) continue;
            $map[$pgName] = [
                'role'     => $c['role']     ?? null,
                'original' => $c['original'] ?? null,
                'pg_type'  => $c['pg_type']  ?? null,
            ];
            $map[strtolower($pgName)] = $map[$pgName];
        }
        foreach (array_keys($resultRow) as $k) {
            if (! isset($map[$k]) && ! isset($map[strtolower($k)])) {
                $map[$k] = [
                    'role'     => self::inferRoleFromKey($k, $resultRow[$k]),
                    'original' => self::humanizeLabel($k),
                ];
            }
        }

        return $map;
    }

    public static function humanizeLabel(string $key): string
    {
        $s = str_replace('_', ' ', $key);
        $s = (string) preg_replace_callback('/\bgst\b/i',  static fn () => 'GST',  $s);
        $s = (string) preg_replace_callback('/\bcgst\b/i', static fn () => 'CGST', $s);
        $s = (string) preg_replace_callback('/\bsgst\b/i', static fn () => 'SGST', $s);
        $s = (string) preg_replace_callback('/\bigst\b/i', static fn () => 'IGST', $s);
        $s = (string) preg_replace_callback('/\bhsn\b/i',  static fn () => 'HSN',  $s);
        $s = (string) preg_replace_callback('/\bid\b/i',   static fn () => 'ID',   $s);

        return (string) preg_replace_callback('/\b\w/u', static fn ($m) => strtoupper($m[0]), $s);
    }

    // ──────────────── Internal helpers ────────────────

    /**
     * Convert stdClass → assoc array; pass-through arrays unchanged.
     *
     * @return array<string, mixed>
     */
    private static function toAssoc(mixed $row): array
    {
        if (is_object($row)) {
            return get_object_vars($row);
        }

        return is_array($row) ? $row : [];
    }

    /**
     * Last-resort dump when AI formatting fails — ensures the user sees data.
     *
     * @param  list<array<string, string>>  $rows
     */
    private static function dumpPreformatted(array $rows, int $totalCount): string
    {
        $lines = [];
        foreach ($rows as $i => $row) {
            $parts = [];
            foreach ($row as $k => $v) {
                $parts[] = "*{$k}:* {$v}";
            }
            $lines[] = ($i + 1).'. '.implode(' — ', $parts);
        }
        $out = "📋 *{$totalCount} results:*\n\n".implode("\n", $lines);
        if ($totalCount > 20) {
            $out .= "\n\n📌 _Total {$totalCount} entries. Top 20 shown._";
        }

        return $out;
    }

    // ════════════════════════════════════════════════════════════════════
    // WEB HTML TABLE (for web chat — matches Node.js buildTableHTML)
    // ════════════════════════════════════════════════════════════════════

    /**
     * Build a styled HTML table from SQL result rows — dark header, zebra rows,
     * Grand Total row, Indian Rs. formatting for amount columns.
     * Matches the Node.js `buildTableHTML()` output exactly.
     *
     * @param  list<\stdClass|array>  $rows
     * @return string  HTML string
     */
    public static function buildTableHTML(array $rows): string
    {
        if (count($rows) === 0) {
            return '<p style="padding:12px;color:#666">No data found.</p>';
        }

        $rows = array_map(self::toAssoc(...), $rows);
        $cols = array_keys($rows[0]);

        // Compact, modern typography: system/Inter stack, 13px, tighter padding, a soft
        // slate header instead of the old near-black, subtle 1px hairlines. Header is
        // position:sticky so column names stay visible while scrolling a tall table.
        $FONT = "-apple-system,BlinkMacSystemFont,'Inter','Segoe UI',Roboto,Arial,sans-serif";
        $TH = "padding:8px 12px;border-bottom:2px solid #e2e8f0;font-size:12.5px;font-family:{$FONT};font-weight:600;background:#f1f5f9;color:#334155;text-align:left;white-space:nowrap;letter-spacing:.01em;position:sticky;top:0";
        $TD = "padding:7px 12px;border-bottom:1px solid #eef2f6;font-size:13px;font-family:{$FONT};color:#1e293b;white-space:nowrap";

        // Detect amount columns (numeric, not phone/id/name etc.)
        $NON_AMT = '/phone|mobile|contact|gst_no|pan|_id$|^id$|no\.?$|num|number|invoice_no|voucher_no|ref|bill_ref|email|address|state|city|name|person|login|description|narration|particular|type|group|category|sub_group|design|month|^mon$|period|year|quarter|date|timestamp/i';
        $amtCols = [];
        foreach ($cols as $col) {
            if (preg_match($NON_AMT, $col)) continue;
            $samples = array_slice(array_column($rows, $col), 0, 5);
            $hasNumeric = false;
            foreach ($samples as $v) {
                if ($v === null || $v === '') continue;
                $cleaned = preg_replace('/[₹Rs.\s,]/', '', (string) $v);
                if (is_numeric($cleaned) && strlen($cleaned) < 15) { $hasNumeric = true; break; }
            }
            if ($hasNumeric) {
                // Extra check: if first non-empty value looks like a month label (Apr-25, Jan-2026), skip
                $firstVal = '';
                foreach ($samples as $v) { if ($v !== null && $v !== '') { $firstVal = (string) $v; break; } }
                if (preg_match('/^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)/i', $firstVal)) continue;
                $amtCols[] = $col;
            }
        }

        // Header
        $header = '';
        foreach ($cols as $c) {
            $label = self::humanizeLabel($c);
            $header .= "<th style=\"{$TH}\">{$label}</th>";
        }

        // Body rows + accumulate sums
        $colSums = array_fill_keys($amtCols, 0.0);
        $bodyRows = '';
        foreach ($rows as $i => $row) {
            $bg = $i % 2 === 0 ? '#ffffff' : '#f8fafc';
            $bodyRows .= "<tr style=\"background:{$bg}\">";
            foreach ($cols as $c) {
                $val = $row[$c] ?? null;
                if (in_array($c, $amtCols, true)) {
                    $num = (float) preg_replace('/[₹Rs.\s,]/', '', (string) ($val ?? '0'));
                    $colSums[$c] += $num;
                    $display = $num > 0 ? self::fmtAmt($num) : ($num < 0 ? '-'.self::fmtAmt(abs($num)) : '-');
                    $bodyRows .= "<td style=\"{$TD};text-align:right\">{$display}</td>";
                } else {
                    $display = ($val === null || $val === '' || $val === 'NA') ? '-' : htmlspecialchars((string) $val, ENT_QUOTES);
                    // Make URLs clickable
                    if (is_string($val) && preg_match('#^https?://#i', $val)) {
                        $label = preg_match('/\.pdf/i', $val) ? '📄 View PDF' : '🔗 View Link';
                        $display = '<a href="'.htmlspecialchars($val, ENT_QUOTES).'" target="_blank" style="color:#1a73e8;text-decoration:none;font-weight:500">'.$label.'</a>';
                    }
                    $bodyRows .= "<td style=\"{$TD}\">{$display}</td>";
                }
            }
            $bodyRows .= '</tr>';
        }

        // Grand Total row — accent-tinted, sits flush under the last data row.
        $totalRow = '';
        if (count($amtCols) > 0) {
            $totalTd = "padding:8px 12px;border-top:2px solid #e2e8f0;font-size:13px;font-family:{$FONT};color:#0f172a;font-weight:700;white-space:nowrap";
            $totalRow = '<tr style="background:#eef2ff">';
            foreach ($cols as $idx => $c) {
                if ($idx === 0) {
                    $totalRow .= "<td style=\"{$totalTd}\">Grand Total</td>";
                } elseif (in_array($c, $amtCols, true)) {
                    $totalRow .= "<td style=\"{$totalTd};text-align:right\">".self::fmtAmt($colSums[$c]).'</td>';
                } else {
                    $totalRow .= "<td style=\"{$totalTd}\"></td>";
                }
            }
            $totalRow .= '</tr>';
        }

        return "<div style=\"overflow-x:auto;font-family:{$FONT};border:1px solid #e2e8f0;border-radius:10px;box-shadow:0 1px 2px rgba(15,23,42,.04)\">"
            .'<table style="border-collapse:collapse;width:100%;min-width:360px">'
            ."<thead><tr>{$header}</tr></thead><tbody>{$bodyRows}{$totalRow}</tbody></table></div>"
            ."<div style=\"font-size:11.5px;color:#64748b;margin-top:6px;font-family:{$FONT}\">Total Records: <b style=\"color:#334155\">".count($rows).'</b></div>';
    }

    /**
     * Format a number as Indian Rs. with commas (Rs. 1,23,456).
     */
    private static function fmtAmt(float $n): string
    {
        if ($n === 0.0) return 'Rs. 0';
        $whole = (int) floor(abs($n));
        $s = (string) $whole;
        // Indian grouping: last 3, then groups of 2
        if (strlen($s) > 3) {
            $last3 = substr($s, -3);
            $rest = substr($s, 0, -3);
            $rest = preg_replace('/\B(?=(\d{2})+(?!\d))/', ',', $rest);
            $s = $rest . ',' . $last3;
        }
        return 'Rs. ' . $s;
    }
}
