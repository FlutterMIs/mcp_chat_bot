<?php

declare(strict_types=1);

namespace App\Services\Sheets;

use App\Models\Tenant;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;

/**
 * TenantTablesProvisioner — port of Node helpers/tenant-tables.js + helpers/sheets.js syncSheetToProperTables.
 *
 * Phase 6 architecture: each tab of a tenant's Google Sheet becomes a real PostgreSQL table
 * (not JSONB). Smart type detection (NUMERIC/DATE/TEXT) + role detection (currency/quantity/
 * entity/location/date/id/etc) drives the dashboard widgets, type-aware formatting, and
 * fuzzy entity search.
 *
 * Public surface:
 *   syncSheetToProperTables(string $tenantId, string $sheetUrl): array
 *     — orchestrates: discover tabs → fetch CSV → build metadata → ensure table
 *     → truncate → insert cleaned rows → write tables_metadata back to tenants row.
 *
 * Internals exposed for testing / reuse:
 *   sanitizeIdentifier, buildTenantTableName,
 *   cleanText, cleanNumeric, parseDate, formatDateIso, titleCase, cleanValue,
 *   detectPgType, detectColumnRole, buildColumnMetadata,
 *   buildCreateTableSQL, buildAlterAddColumnSQL, buildIndexSQL,
 *   execDDL, selectSQL, tableExists, getExistingColumns,
 *   ensureTable, dropTable, truncateTable, insertRows.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-tables.js
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/sheets.js (syncSheetToProperTables ~lines 171-271)
 */
final class TenantTablesProvisioner
{
    private const NULL_TOKENS = ['', 'na', 'n/a', 'null', 'undefined', '-', '--', 'none', 'nil', '#n/a', '#null!', '#div/0!', '#ref!'];

    private const RESERVED_WORDS = ['select', 'from', 'where', 'order', 'group', 'table', 'user', 'date', 'type', 'default', 'null', 'true', 'false', 'primary', 'key', 'index'];

    private const INSERT_BATCH_SIZE = 500;

    // ════════════════════════════════════════════════════════════════════
    // PUBLIC ORCHESTRATOR
    // ════════════════════════════════════════════════════════════════════

    /**
     * Sync a public Google Sheet to per-tab PostgreSQL tables for a tenant.
     *
     * Steps (per tab):
     *   1. Fetch CSV via SheetSchemaDetector.
     *   2. Build typed column metadata.
     *   3. ensureTable (CREATE or ALTER ADD COLUMN — never DROP).
     *   4. TRUNCATE + bulk INSERT cleaned rows.
     *
     * Persists `tables_metadata` + sets `proper_tables_created=true` on the tenant.
     *
     * @return array{
     *     synced_rows: int,
     *     tabs: list<array<string, mixed>>,
     *     tables_metadata: list<array<string, mixed>>,
     * }
     */
    public static function syncSheetToProperTables(string $tenantId, string $sheetUrl): array
    {
        $sheetId = SheetSchemaDetector::extractSheetId($sheetUrl);
        if ($sheetId === null) {
            throw new RuntimeException('Invalid Sheet URL');
        }

        $tabs = SheetSchemaDetector::discoverTabs($sheetId);
        $result = [
            'synced_rows'     => 0,
            'tabs'            => [],
            'tables_metadata' => [],
            'drift'           => [],
        ];

        // Z28 — load previous tables_metadata snapshot ONCE before the loop so each tab can
        // compare its NEW column metadata against its PREVIOUS metadata for type-drift detection.
        // Indexed by pg_table for O(1) lookup inside the loop.
        $prevByPgTable = [];
        try {
            $prevTenant = Tenant::query()->where('id', $tenantId)->first();
            $prevMeta = (array) ($prevTenant?->tables_metadata ?? []);
            foreach ($prevMeta as $entry) {
                $key = (string) ($entry['pg_table'] ?? '');
                if ($key !== '') $prevByPgTable[$key] = (array) ($entry['columns'] ?? []);
            }
        } catch (Throwable $e) {
            Log::info('[SCHEMA-DRIFT] previous metadata load failed: '.$e->getMessage());
        }

        foreach ($tabs as $tab) {
            try {
                // Auto-skip garbage tabs (Sheet2, Sheet3, or tabs with all generic column names)
                $tabNameLower = strtolower($tab['name'] ?? '');
                if (preg_match('/^sheet\d+$/i', $tab['name'] ?? '')) {
                    Log::info("[SYNC P6] {$tab['name']}: generic sheet name, skipped");
                    continue;
                }

                [$headers, $rows] = SheetSchemaDetector::fetchSheet($sheetId, $tab['gid']);
                if (count($rows) === 0) {
                    Log::info("[SYNC P6] {$tab['name']} (gid={$tab['gid']}): empty, skipped");
                    continue;
                }

                // Skip if all headers are generic (c_0, c_1, column_0, etc.) or less than 3 rows
                $genericCount = 0;
                foreach ($headers as $h) {
                    if (preg_match('/^(c_\d+|column_?\d*|col\d+|field\d+|untitled)$/i', $h)) $genericCount++;
                }
                if (count($headers) > 0 && $genericCount === count($headers)) {
                    Log::info("[SYNC P6] {$tab['name']}: all generic columns, skipped");
                    continue;
                }
                if (count($rows) < 3) {
                    Log::info("[SYNC P6] {$tab['name']}: only " . count($rows) . " rows, skipped");
                    continue;
                }

                // Build raw column descriptors with up to 30 sample values each
                $rawCols = [];
                foreach ($headers as $h) {
                    $values = [];
                    foreach ($rows as $r) {
                        $v = (string) ($r[$h] ?? '');
                        if ($v !== '' && trim($v) !== '') {
                            $values[] = $v;
                            if (count($values) >= 30) break;
                        }
                    }
                    $rawCols[] = ['name' => $h, 'samples' => $values];
                }

                $columnsMeta = self::buildColumnMetadata($rawCols);
                if (count($columnsMeta) === 0) {
                    Log::info("[SYNC P6] {$tab['name']}: no valid columns, skipped");
                    continue;
                }

                $pgTable = self::buildTenantTableName($tenantId, $tab['name']);

                // Z28 — detect schema drift BEFORE altering the table. ensureTable will then
                // physically ALTER ADD COLUMN for `added` cols. Removed cols stay in the DB
                // (preserve historical data — just logged). Type drift is informational only;
                // a human can decide whether to drop+recreate.
                $drift = null;
                try {
                    $existedBeforeSync = self::tableExists($pgTable);
                    if ($existedBeforeSync) {
                        $pgCols = self::getExistingColumns($pgTable);
                        $drift = self::detectSchemaDrift(
                            $pgCols,
                            $columnsMeta,
                            $prevByPgTable[$pgTable] ?? null
                        );
                        if (count($drift['added']) > 0 || count($drift['removed']) > 0 || count($drift['typeChanged']) > 0) {
                            Log::info("[SCHEMA-DRIFT] {$tab['name']} → {$pgTable}: {$drift['summary']}");
                            if (count($drift['added']) > 0) {
                                Log::info('  + added: '.implode(', ', array_map(
                                    static fn ($c) => "{$c['name']} ({$c['type']}/{$c['role']})",
                                    $drift['added']
                                )));
                            }
                            if (count($drift['removed']) > 0) {
                                Log::info('  - removed: '.implode(', ', $drift['removed']).' (kept in DB)');
                            }
                            if (count($drift['typeChanged']) > 0) {
                                Log::info('  ~ type-drift: '.implode(', ', array_map(
                                    static fn ($c) => "{$c['name']}: {$c['from']} → {$c['to']}",
                                    $drift['typeChanged']
                                )));
                            }
                        }
                    } else {
                        Log::info("[SCHEMA-DRIFT] {$tab['name']} → {$pgTable}: NEW table (".count($columnsMeta).' cols)');
                    }
                } catch (Throwable $e) {
                    Log::info("[SCHEMA-DRIFT] {$tab['name']}: drift-check skipped (".$e->getMessage().')');
                }

                self::ensureTable($pgTable, $columnsMeta);

                // Safety check: if sheet returns <50% of previous rows, skip truncate
                // to prevent data loss from partial sheet responses / API errors.
                $prevRowCount = 0;
                foreach ($prevMeta as $entry) {
                    if (($entry['pg_table'] ?? '') === $pgTable) {
                        $prevRowCount = (int) ($entry['row_count'] ?? 0);
                        break;
                    }
                }
                if ($prevRowCount > 20 && count($rows) < ($prevRowCount * 0.5)) {
                    Log::warning("[SYNC SAFETY] {$tab['name']}: sheet returned " . count($rows) . " rows but DB had {$prevRowCount} — skipping truncate to prevent data loss");
                    $result['tabs'][] = [
                        'name'  => $tab['name'],
                        'pg_table' => $pgTable,
                        'error' => "Safety: sheet returned " . count($rows) . " rows (previously {$prevRowCount}). Skipped to prevent data loss.",
                        'rows'  => 0,
                    ];
                    continue;
                }

                // MySQL: TRUNCATE is DDL (implicit commit), can't be inside a transaction.
                // Run it before the transaction, then INSERT + populate inside the txn.
                DB::statement("TRUNCATE TABLE `{$pgTable}`");
                DB::transaction(function () use ($pgTable, $rows, $columnsMeta, &$inserted) {
                    $inserted = self::insertRows($pgTable, $rows, $columnsMeta);
                    self::populateDateActualColumns($pgTable, $columnsMeta);
                });

                // Verify date_actual columns are populated. If not, retry outside transaction.
                $dateActuals = array_filter($columnsMeta, fn($c) => ($c['role'] ?? '') === 'date_actual' && !empty($c['source_text_column']));
                if (count($dateActuals) > 0 && $inserted > 0) {
                    $firstDateCol = reset($dateActuals)['pg_name'];
                    $nullCount = (int) DB::selectOne("SELECT COUNT(*) AS cnt FROM `{$pgTable}` WHERE `{$firstDateCol}` IS NULL")->cnt;
                    if ($nullCount > 0) {
                        Log::warning("[DATE-FIX] {$pgTable}: {$nullCount}/{$inserted} rows still NULL after txn — retrying");
                        self::populateDateActualColumns($pgTable, $columnsMeta);
                        $nullAfter = (int) DB::selectOne("SELECT COUNT(*) AS cnt FROM `{$pgTable}` WHERE `{$firstDateCol}` IS NULL")->cnt;
                        if ($nullAfter > 0) {
                            Log::warning("[DATE-FIX] {$pgTable}: still {$nullAfter} NULL after retry");
                        } else {
                            Log::info("[DATE-FIX] {$pgTable}: retry fixed all dates");
                        }
                    }
                }

                $result['synced_rows'] += $inserted;
                $tabSummary = [
                    'name'     => $tab['name'],
                    'pg_table' => $pgTable,
                    'gid'      => $tab['gid'],
                    'rows'     => $inserted,
                    'drift'    => $drift,  // null when this is a NEW table; otherwise the drift struct
                ];
                $result['tabs'][] = $tabSummary;

                if ($drift !== null && (count($drift['added']) > 0 || count($drift['removed']) > 0 || count($drift['typeChanged']) > 0)) {
                    $result['drift'][] = [
                        'tab'         => $tab['name'],
                        'pg_table'    => $pgTable,
                        'added'       => $drift['added'],
                        'removed'     => $drift['removed'],
                        'typeChanged' => $drift['typeChanged'],
                        'summary'     => $drift['summary'],
                    ];
                }
                $result['tables_metadata'][] = [
                    'source_name' => $tab['name'],
                    'pg_table'    => $pgTable,
                    'gid'         => $tab['gid'],
                    'row_count'   => $inserted,
                    'columns'     => $columnsMeta,
                    'synced_at'   => now()->toIso8601String(),
                ];
                Log::info("[SYNC P6] {$tab['name']} → {$pgTable}: {$inserted}/".count($rows).' rows');
            } catch (Throwable $e) {
                Log::error("[SYNC P6] {$tab['name']} FAILED: ".$e->getMessage());
                $result['tabs'][] = [
                    'name'  => $tab['name'],
                    'gid'   => $tab['gid'],
                    'error' => $e->getMessage(),
                    'rows'  => 0,
                ];
            }
        }

        // Persist metadata + flag on tenant
        Tenant::query()->where('id', $tenantId)->update([
            'tables_metadata'       => $result['tables_metadata'],
            'proper_tables_created' => count($result['tables_metadata']) > 0,
            'updated_at'            => now(),
        ]);

        // Auto-update column dictionary after sync
        try {
            \App\Services\AI\SchemaIntelligence::generate($tenantId, $result['tables_metadata']);
        } catch (\Throwable $e) {
            Log::warning('[SCHEMA INTEL] auto-update failed: ' . $e->getMessage());
        }

        return $result;
    }

    // ════════════════════════════════════════════════════════════════════
    // IDENTIFIER SANITIZATION
    // ════════════════════════════════════════════════════════════════════

    /** Make a string safe for MySQL identifier — snake_case, max 50 chars, can't start with digit. */
    public static function sanitizeIdentifier(string $str): string
    {
        if ($str === '') return 'col';
        $s = trim(strtolower($str));
        $s = (string) preg_replace('/[^a-z0-9]+/', '_', $s);
        $s = trim($s, '_');
        $s = (string) preg_replace('/_+/', '_', $s);
        $s = substr($s, 0, 50);
        if ($s === '') return 'col';
        if (preg_match('/^\d/', $s)) {
            $s = 'c_'.$s;
        }
        if (in_array($s, self::RESERVED_WORDS, true)) {
            $s = 'c_'.$s;
        }

        return $s;
    }

    /** Build the per-tenant table name: tenant_{shortid}_{table}. Total length capped at 60. */
    public static function buildTenantTableName(string $tenantId, string $sourceTableName): string
    {
        $shortId = substr(str_replace('-', '', $tenantId), 0, 8);
        $tableName = self::sanitizeIdentifier($sourceTableName);

        return substr("tenant_{$shortId}_{$tableName}", 0, 60);
    }

    // ════════════════════════════════════════════════════════════════════
    // VALUE CLEANING
    // ════════════════════════════════════════════════════════════════════

    public static function cleanText(mixed $val): ?string
    {
        if ($val === null) return null;
        $s = trim((string) $val);
        if ($s === '') return null;
        if (in_array(strtolower($s), self::NULL_TOKENS, true)) return null;

        return $s;
    }

    /** Reuses the SheetSchemaDetector helper to keep value-cleaning rules in one place. */
    public static function cleanNumeric(mixed $val): ?float
    {
        return SheetSchemaDetector::cleanNumeric($val);
    }

    /**
     * Parse a date string to ['Y' => 2026, 'm' => 4, 'd' => 2] tuple.
     * Supports D-Mon-YY / DD-Mon-YYYY / YYYY-MM-DD / DD/MM/YYYY / DD-MM-YYYY.
     *
     * @return array{Y: int, m: int, d: int}|null
     */
    public static function parseDate(mixed $val): ?array
    {
        if ($val === null) return null;
        $s = trim((string) $val);
        if ($s === '' || in_array(strtolower($s), self::NULL_TOKENS, true)) return null;

        $monthMap = ['jan' => 1, 'feb' => 2, 'mar' => 3, 'apr' => 4, 'may' => 5, 'jun' => 6, 'jul' => 7, 'aug' => 8, 'sep' => 9, 'oct' => 10, 'nov' => 11, 'dec' => 12];

        // Mon DD, YY  e.g. "Oct 5, 23, 7:20:08 PM" or "Jun 2, 26, 12:24:54 PM"
        if (preg_match('/^([A-Za-z]{3})\s+(\d{1,2}),\s*(\d{2,4})/', $s, $m)) {
            $month = $monthMap[strtolower($m[1])] ?? null;
            if ($month !== null) {
                $day = (int) $m[2];
                $year = (int) $m[3];
                if ($year < 100) $year += 2000;
                return self::validateYMD($year, $month, $day);
            }
        }

        // D-Mon-YY or DD-Mon-YYYY  e.g. "2-Apr-26", "11-May-2026"
        // Also handles DD/Mon/YYYY e.g. "03/Jun/2026 23:51:58"
        if (preg_match('#^(\d{1,2})[/-]([A-Za-z]{3})[/-](\d{2,4})#', $s, $m)) {
            $month = $monthMap[strtolower(substr($m[2], 0, 3))] ?? null;
            if ($month === null) return null;
            $day = (int) $m[1];
            $year = (int) $m[3];
            if ($year < 100) $year += 2000;

            return self::validateYMD($year, $month, $day);
        }

        // YYYY-MM-DD
        if (preg_match('/^(\d{4})-(\d{2})-(\d{2})/', $s, $m)) {
            return self::validateYMD((int) $m[1], (int) $m[2], (int) $m[3]);
        }

        // DD/MM/YYYY or DD-MM-YYYY
        if (preg_match('#^(\d{1,2})[/-](\d{1,2})[/-](\d{2,4})#', $s, $m)) {
            $year = (int) $m[3];
            if ($year < 100) $year += 2000;

            return self::validateYMD($year, (int) $m[2], (int) $m[1]);
        }

        // Universal fallback: strtotime handles 50+ date formats automatically
        $ts = @strtotime($s);
        if ($ts !== false && $ts > 0) {
            $y = (int) date('Y', $ts);
            $m = (int) date('m', $ts);
            $d = (int) date('d', $ts);
            if ($y >= 2000 && $y <= 2100) {
                return self::validateYMD($y, $m, $d);
            }
        }

        return null;
    }

    /** @return array{Y: int, m: int, d: int}|null */
    private static function validateYMD(int $y, int $m, int $d): ?array
    {
        if (! checkdate($m, $d, $y)) return null;

        return ['Y' => $y, 'm' => $m, 'd' => $d];
    }

    /** Format an ['Y','m','d'] tuple as 'YYYY-MM-DD' or null. */
    public static function formatDateIso(?array $ymd): ?string
    {
        if ($ymd === null) return null;

        return sprintf('%04d-%02d-%02d', $ymd['Y'], $ymd['m'], $ymd['d']);
    }

    /** Title-case a location/city name — "SONEPAT" / "sonepat" → "Sonepat". */
    public static function titleCase(string $s): string
    {
        return trim(ucwords(strtolower($s)));
    }

    /** Type+role aware value cleaner. Returns null/string/float — never an undefined-shaped value. */
    public static function cleanValue(mixed $val, string $pgType, ?string $role = null): mixed
    {
        if ($pgType === 'NUMERIC') {
            return self::cleanNumeric($val);
        }
        $cleaned = self::cleanText($val);
        if ($cleaned === null) return null;
        if ($role === 'location') {
            return self::titleCase($cleaned);
        }

        return $cleaned;
    }

    // ════════════════════════════════════════════════════════════════════
    // TYPE + ROLE DETECTION
    // ════════════════════════════════════════════════════════════════════

    /**
     * Decide PG type from column name + samples. Returns 'NUMERIC' or 'TEXT'.
     *
     * @param  list<string>  $samples
     */
    public static function detectPgType(string $columnName, array $samples = []): string
    {
        $nameLower = strtolower($columnName);

        // Names that ALWAYS imply numeric (override TEXT-leaning patterns)
        $numericForce = '/amount|amt|^value$|price|cost|total|qty|quantity|weight|^rate$|pct|percent|tax|cgst|sgst|igst|cess|discount|profit|margin|debit|credit|balance|score|stock/i';

        // Hard TEXT overrides — IDs/codes/voucher numbers
        $idTokens = '/(^|_|\s)(no|num|numbers?|code|id|hsn|hsncode|gstno|gstn|pincode|pin|phone|mobile|year|hash|irn|ack|acknum|voucher|ewaybill|invoice|bill_?ref|bill_?no)(_|$|\s)/i';
        $idFullName = '/^(hsncode|hsn|acknum|ackdate|irnnum|ewaybillnum|gstn|gstin|pan|tan|cin|udyam)$/i';

        if (! preg_match($numericForce, $nameLower) && (preg_match($idTokens, $nameLower) || preg_match($idFullName, $nameLower))) {
            return 'TEXT';
        }

        // Date columns → TEXT (preserve original format like "2-Apr-26")
        if (preg_match('/^date$|_date$|^date_|timestamp|^time$|_time$/i', $nameLower)) {
            return 'TEXT';
        }

        $numericHint = '/amount|amt|value|price|cost|total|sum|sale|revenue|income|expense|debit|credit|balance|qty|quantity|weight|stock|rate|pct|percent|score|count|days|kg|tax|gst|cgst|sgst|igst|cess|discount|profit|margin/i';

        // Sample-based detection
        $nonNull = [];
        foreach ($samples as $s) {
            $t = trim((string) $s);
            if ($t !== '' && ! in_array(strtolower($t), self::NULL_TOKENS, true)) {
                $nonNull[] = $t;
            }
        }

        if (count($nonNull) === 0) {
            return preg_match($numericHint, $nameLower) ? 'NUMERIC' : 'TEXT';
        }

        $numericCount = 0;
        foreach ($nonNull as $s) {
            if (self::cleanNumeric($s) !== null) {
                $numericCount++;
            }
        }
        $ratio = $numericCount / count($nonNull);

        if (preg_match($numericHint, $nameLower) && $ratio >= 0.4) return 'NUMERIC';
        if ($ratio >= 0.6) return 'NUMERIC';

        return 'TEXT';
    }

    /**
     * Decide column role for type-aware formatting.
     * Roles: currency, quantity, count, percent, rate, date, id, entity, location, category, number, text.
     *
     * @param  list<string>  $samples
     */
    public static function detectColumnRole(string $columnName, string $pgType, array $samples = []): string
    {
        $n = strtolower($columnName);
        $firstSample = (string) ($samples[0] ?? '');

        if (preg_match('/voucher|invoice.*no|bill.*no|bill_ref|ref_no|id$|^id|hsn|gst.*no|irn|ack|code$/', $n)) return 'id';
        if (preg_match('/^date$|_date$|^date_|timestamp|time/', $n)
            || preg_match('/^\d{1,2}-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-\d{2,4}$/i', $firstSample)) return 'date';

        if ($pgType === 'NUMERIC' && preg_match('/amount|amt|price|cost|total|sale|revenue|income|expense|debit|credit|balance|gst|cgst|sgst|igst|tax|cess|discount|profit|margin|fees/', $n)) return 'currency';
        if ($pgType === 'NUMERIC' && preg_match('/qty|quantity|weight|stock|units|count|days|kg/', $n)) return 'quantity';
        if ($pgType === 'NUMERIC' && preg_match('/pct|percent|rate.*%|%/', $n)) return 'percent';
        if ($pgType === 'NUMERIC' && preg_match('/^rate$|_rate$|rate_/', $n)) return 'rate';

        if ($pgType === 'TEXT' && preg_match('/name|party|customer|vendor|client|supplier|person|employee|account|particular/', $n)) return 'entity';
        if ($pgType === 'TEXT' && preg_match('/city|state|country|location|address|area|region/', $n)) return 'location';
        if ($pgType === 'TEXT' && preg_match('/type|category|group|class|status|priority|stage|^unit$|uom|level/', $n)) return 'category';

        if ($pgType === 'NUMERIC') return 'number';

        return 'text';
    }

    /**
     * Build full column metadata for a tab. Filters junk headers (empty / URL / >100 chars).
     * Auto-adds a companion DATE column ({pgname}_actual) for every detected date column.
     *
     * @param  list<array{name: string, samples: list<string>}>  $rawColumns
     * @return list<array<string, mixed>>
     */
    public static function buildColumnMetadata(array $rawColumns): array
    {
        $usedNames = ['id' => true, 'created_at' => true, 'updated_at' => true, '_row_id' => true];
        $cols = [];

        foreach ($rawColumns as $c) {
            $orig = (string) ($c['name'] ?? '');
            $trimmed = trim($orig);
            if ($trimmed === '') continue;
            if (str_starts_with($trimmed, 'http')) continue;
            if (strlen($trimmed) > 100) continue;

            $pgName = self::sanitizeIdentifier($orig);
            $attempt = $pgName;
            $n = 2;
            while (isset($usedNames[$attempt])) {
                $attempt = substr("{$pgName}_{$n}", 0, 50);
                $n++;
            }
            $pgName = $attempt;
            $usedNames[$pgName] = true;

            $samples = array_values(array_slice($c['samples'] ?? [], 0, 30));
            $pgType = self::detectPgType($orig, $samples);
            $role = self::detectColumnRole($orig, $pgType, $samples);

            $cols[] = [
                'original' => $orig,
                'pg_name'  => $pgName,
                'pg_type'  => $pgType,
                'role'     => $role,
                'samples'  => array_slice($samples, 0, 3),
            ];

            // Companion DATE column for date-typed text columns
            if ($role === 'date') {
                $dateActualName = substr("{$pgName}_actual", 0, 50);
                if (! isset($usedNames[$dateActualName])) {
                    $usedNames[$dateActualName] = true;
                    $cols[] = [
                        'original'            => "{$orig} (parsed)",
                        'pg_name'             => $dateActualName,
                        'pg_type'             => 'DATE',
                        'role'                => 'date_actual',
                        'source_text_column'  => $pgName,
                        'samples'             => [],
                    ];
                }
            }
        }

        return $cols;
    }

    // ════════════════════════════════════════════════════════════════════
    // DDL BUILDERS
    // ════════════════════════════════════════════════════════════════════

    /** @param list<array<string, mixed>> $columns */
    public static function buildCreateTableSQL(string $tableName, array $columns): string
    {
        $defs = [];
        foreach ($columns as $c) {
            $type = $c['pg_type'];
            // Map PG types to MySQL
            if ($type === 'NUMERIC') $type = 'DOUBLE';
            if ($type === 'DATE') $type = 'DATE';
            // TEXT stays TEXT
            $defs[] = '  `'.$c['pg_name'].'` '.$type;
        }
        $colDefs = implode(",\n", $defs);

        return "CREATE TABLE IF NOT EXISTS `{$tableName}` (\n  `_row_id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,\n{$colDefs}\n) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    }

    /**
     * @param  list<array<string, mixed>>  $newColumns
     * @return list<string>
     */
    public static function buildAlterAddColumnSQL(string $tableName, array $newColumns): array
    {
        $stmts = [];
        foreach ($newColumns as $c) {
            $type = $c['pg_type'];
            if ($type === 'NUMERIC') $type = 'DOUBLE';
            $stmts[] = "ALTER TABLE `{$tableName}` ADD COLUMN `{$c['pg_name']}` {$type};";
        }

        return $stmts;
    }

    /**
     * Indexes: B-tree on entity/id/category/date/location columns; GIN trigram on entity columns.
     *
     * @param  list<array<string, mixed>>  $columns
     * @return list<string>
     */
    public static function buildIndexSQL(string $tableName, array $columns): array
    {
        $stmts = [];
        foreach ($columns as $c) {
            $role = $c['role'] ?? null;
            if (! in_array($role, ['entity', 'id', 'category', 'date', 'location'], true)) continue;
            $type = $c['pg_type'] ?? 'TEXT';
            $idxName = substr("idx_{$tableName}_{$c['pg_name']}", 0, 60);
            // MySQL can't index TEXT without a prefix length; use first 100 chars
            $colSpec = ($type === 'TEXT') ? "`{$c['pg_name']}`(100)" : "`{$c['pg_name']}`";
            $stmts[] = "CREATE INDEX `{$idxName}` ON `{$tableName}` ({$colSpec});";
        }

        return $stmts;
    }

    // ════════════════════════════════════════════════════════════════════
    // SUPABASE OPERATIONS (via execute_ddl + execute_sql RPCs)
    // ════════════════════════════════════════════════════════════════════

    /** Execute DDL directly via DB::statement. */
    public static function execDDL(string $sql): void
    {
        try {
            DB::statement($sql);
        } catch (Throwable $e) {
            throw new RuntimeException('execDDL: '.$e->getMessage().' | SQL: '.substr($sql, 0, 200));
        }
    }

    /**
     * Run a SELECT via the execute_sql RPC.
     *
     * @return list<array<string, mixed>>
     */
    public static function selectSQL(string $sql): array
    {
        try {
            $rows = DB::select($sql);
            $out = [];
            foreach ($rows as $r) {
                $out[] = (array) $r;
            }

            return $out;
        } catch (Throwable $e) {
            throw new RuntimeException('select: '.$e->getMessage().' | SQL: '.substr($sql, 0, 200));
        }
    }

    /**
     * Z28 — Detect schema drift between sheet headers, existing PG columns, and
     * the previous tables_metadata snapshot. Returns three diff buckets so callers
     * (TenantSyncService, sync admin endpoint) can log changes per sync run AND
     * eventually WhatsApp-notify the tenant owner when columns change.
     *
     * Mirrors Node helpers/self-heal.js detectSchemaDrift exactly:
     *   - `added`       — column in sheet but not in PG (will be ALTER ADD COLUMN'd)
     *   - `removed`     — column in PG but not in sheet (kept in DB to preserve historical data; just logged)
     *   - `typeChanged` — column in both but role/pg_type differs from previous metadata
     *   - `summary`     — one-line human-readable text for log lines
     *
     * Four system columns are always excluded from `removed` so we don't false-
     * positive on `id`/`created_at`/`updated_at`/`_row_id` which are PG plumbing.
     *
     * @param  list<string>  $pgColumns                                              actual PG column names from getExistingColumns()
     * @param  list<array<string, mixed>>  $sheetColumns                             buildColumnMetadata() output
     * @param  list<array<string, mixed>>|null  $previousMeta                        previous tables_metadata[i].columns snapshot (for type-drift detection)
     * @return array{
     *     added: list<array{name:string,type:string,role:string}>,
     *     removed: list<string>,
     *     typeChanged: list<array{name:string,from:string,to:string}>,
     *     total: int,
     *     summary: string
     * }
     */
    public static function detectSchemaDrift(
        array $pgColumns,
        array $sheetColumns,
        ?array $previousMeta = null
    ): array {
        // Lowercase lookup sets (Postgres folds unquoted identifiers; case mismatch shouldn't trigger drift)
        $pgLower = [];
        foreach ($pgColumns as $c) {
            $pgLower[strtolower((string) $c)] = true;
        }
        $sheetLower = [];
        foreach ($sheetColumns as $c) {
            $sheetLower[strtolower((string) ($c['pg_name'] ?? ''))] = true;
        }

        $systemCols = ['id' => true, 'created_at' => true, 'updated_at' => true, '_row_id' => true];

        $added = [];
        $removed = [];
        $typeChanged = [];

        // 1. Added — in sheet but not in PG
        foreach ($sheetColumns as $c) {
            $key = strtolower((string) ($c['pg_name'] ?? ''));
            if ($key !== '' && ! isset($pgLower[$key])) {
                $added[] = [
                    'name' => (string) $c['pg_name'],
                    'type' => (string) ($c['pg_type'] ?? 'TEXT'),
                    'role' => (string) ($c['role'] ?? 'text'),
                ];
            }
        }

        // 2. Removed — in PG but not in sheet (skip system cols)
        foreach ($pgColumns as $pgCol) {
            $key = strtolower((string) $pgCol);
            if (isset($systemCols[$key])) continue;
            if (! isset($sheetLower[$key])) {
                $removed[] = (string) $pgCol;
            }
        }

        // 3. Type drift — column in both prev + new, but pg_type or role changed
        if ($previousMeta !== null && count($previousMeta) > 0) {
            $prevByName = [];
            foreach ($previousMeta as $c) {
                $key = strtolower((string) ($c['pg_name'] ?? ''));
                if ($key !== '') $prevByName[$key] = $c;
            }
            foreach ($sheetColumns as $c) {
                $key = strtolower((string) ($c['pg_name'] ?? ''));
                if ($key === '' || ! isset($prevByName[$key])) continue;
                $prev = $prevByName[$key];
                $prevType = (string) ($prev['pg_type'] ?? '');
                $prevRole = (string) ($prev['role']    ?? '');
                $newType  = (string) ($c['pg_type']    ?? '');
                $newRole  = (string) ($c['role']       ?? '');
                if ($prevType !== $newType || $prevRole !== $newRole) {
                    $typeChanged[] = [
                        'name' => (string) $c['pg_name'],
                        'from' => "{$prevType}/{$prevRole}",
                        'to'   => "{$newType}/{$newRole}",
                    ];
                }
            }
        }

        $parts = [];
        if (count($added) > 0)       $parts[] = '+'.count($added).' added';
        if (count($removed) > 0)     $parts[] = '-'.count($removed).' removed';
        if (count($typeChanged) > 0) $parts[] = '~'.count($typeChanged).' type-drift';
        $summary = count($parts) > 0
            ? 'schema drift: '.implode(', ', $parts)
            : 'schema unchanged';

        return [
            'added'       => $added,
            'removed'     => $removed,
            'typeChanged' => $typeChanged,
            'total'       => count($sheetColumns),
            'summary'     => $summary,
        ];
    }

    public static function tableExists(string $tableName): bool
    {
        $dbName = config('database.connections.mysql.database');
        $rows = self::selectSQL("SELECT 1 AS x FROM information_schema.tables WHERE table_schema='{$dbName}' AND table_name='{$tableName}' LIMIT 1");

        return count($rows) > 0;
    }

    /** @return list<string> */
    public static function getExistingColumns(string $tableName): array
    {
        $dbName = config('database.connections.mysql.database');
        $rows = self::selectSQL("SELECT column_name FROM information_schema.columns WHERE table_schema='{$dbName}' AND table_name='{$tableName}'");
        $out = [];
        foreach ($rows as $r) {
            $out[] = (string) ($r['column_name'] ?? $r['COLUMN_NAME'] ?? '');
        }

        return $out;
    }

    /**
     * CREATE or ALTER ADD COLUMN to match desired schema. Never drops columns.
     *
     * @param  list<array<string, mixed>>  $columns
     * @return array{created: bool, addedColumns: list<string>}
     */
    public static function ensureTable(string $tableName, array $columns): array
    {
        $exists = self::tableExists($tableName);
        if (! $exists) {
            self::execDDL(self::buildCreateTableSQL($tableName, $columns));
            foreach (self::buildIndexSQL($tableName, $columns) as $idxSql) {
                try {
                    self::execDDL($idxSql);
                } catch (Throwable $e) {
                    Log::info('[INDEX] '.$e->getMessage());
                }
            }
            $added = [];
            foreach ($columns as $c) {
                $added[] = $c['pg_name'];
            }

            return ['created' => true, 'addedColumns' => $added];
        }

        // ADD missing columns
        $existing = array_map('strtolower', self::getExistingColumns($tableName));
        $newCols = array_values(array_filter($columns, static fn ($c) => ! in_array(strtolower($c['pg_name']), $existing, true)));
        if (count($newCols) > 0) {
            foreach (self::buildAlterAddColumnSQL($tableName, $newCols) as $sql) {
                try {
                    self::execDDL($sql);
                } catch (Throwable $e) {
                    Log::info('[ALTER] '.$e->getMessage());
                }
            }
        }
        $addedNames = [];
        foreach ($newCols as $c) {
            $addedNames[] = $c['pg_name'];
        }

        return ['created' => false, 'addedColumns' => $addedNames];
    }

    public static function dropTable(string $tableName): void
    {
        self::execDDL("DROP TABLE IF EXISTS `{$tableName}`;");
    }

    public static function truncateTable(string $tableName): void
    {
        try {
            DB::statement("TRUNCATE TABLE `{$tableName}`");
        } catch (Throwable $e) {
            Log::info('[TRUNCATE] '.$e->getMessage());
        }
    }

    /**
     * Populate _actual DATE companion columns via pure SQL (MySQL STR_TO_DATE).
     * Handles formats: DD-Mon-YYYY, DD-Mon-YY, YYYY-MM-DD (with optional time suffixes).
     */
    public static function populateDateActualColumns(string $tableName, array $columns): void
    {
        $dateActuals = array_filter($columns, fn($c) => ($c['role'] ?? '') === 'date_actual' && !empty($c['source_text_column']));
        foreach ($dateActuals as $da) {
            $actual = $da['pg_name'];
            $source = $da['source_text_column'];
            try {
                // MySQL STR_TO_DATE handles the conversions
                DB::statement("
                    UPDATE `{$tableName}` SET `{$actual}` = CASE
                        WHEN `{$source}` REGEXP '^[[:space:]]*[A-Za-z]{3} [0-9]{1,2}, [0-9]{2,4}'
                            THEN STR_TO_DATE(TRIM(SUBSTRING_INDEX(`{$source}`, ',', 2)), '%b %e, %y')
                        WHEN `{$source}` REGEXP '^[0-9]{1,2}/[A-Za-z]{3}/[0-9]{4}'
                            THEN STR_TO_DATE(SUBSTRING_INDEX(`{$source}`, ' ', 1), '%d/%b/%Y')
                        WHEN `{$source}` REGEXP '^[0-9]{1,2}-[A-Za-z]{3}-[0-9]{4}'
                            THEN STR_TO_DATE(SUBSTRING_INDEX(`{$source}`, ' ', 1), '%d-%b-%Y')
                        WHEN `{$source}` REGEXP '^[0-9]{1,2}-[A-Za-z]{3}-[0-9]{2}([^0-9]|$)'
                            THEN STR_TO_DATE(SUBSTRING_INDEX(`{$source}`, ' ', 1), '%d-%b-%y')
                        WHEN `{$source}` REGEXP '^[0-9]{4}-[0-9]{2}-[0-9]{2}'
                            THEN STR_TO_DATE(SUBSTRING_INDEX(`{$source}`, ' ', 1), '%Y-%m-%d')
                        WHEN `{$source}` REGEXP '^[0-9]{1,2}/[0-9]{1,2}/[0-9]{2,4}'
                            THEN STR_TO_DATE(SUBSTRING_INDEX(`{$source}`, ' ', 1), '%m/%d/%y')
                        ELSE NULL
                    END
                    WHERE `{$source}` IS NOT NULL AND `{$source}` != ''
                ");
                Log::info("[DATE-FIX] {$tableName}.{$actual} populated via SQL");
            } catch (Throwable $e) {
                Log::warning("[DATE-FIX] {$tableName}.{$actual} failed: " . $e->getMessage());
            }
        }
    }

    /**
     * Bulk insert cleaned rows. Each batch is 500 rows; falls back to per-row insert on batch failure.
     *
     * @param  list<array<string, string>>  $rows  raw rows keyed by original header
     * @param  list<array<string, mixed>>  $columns  metadata
     */
    public static function insertRows(string $tableName, array $rows, array $columns): int
    {
        if (count($rows) === 0) return 0;

        // Header → metadata lookup (skip companion DATE columns from this map)
        $headerToCol = [];
        foreach ($columns as $c) {
            if (! empty($c['original']) && empty($c['source_text_column'])) {
                $headerToCol[$c['original']] = $c;
            }
        }
        // Date-actual companions (populated by parsing source-text col)
        $dateActualCols = array_values(array_filter($columns, static fn ($c) => ($c['role'] ?? null) === 'date_actual' && ! empty($c['source_text_column'])));

        $cleanedAll = [];
        foreach ($rows as $row) {
            $obj = [];
            // Pass 1: regular columns with role-aware cleaning
            foreach ($row as $origHeader => $val) {
                $c = $headerToCol[$origHeader] ?? null;
                if ($c === null) continue;
                $obj[$c['pg_name']] = self::cleanValue($val, $c['pg_type'], $c['role'] ?? null);
            }
            // Pass 2: companion DATE columns
            foreach ($dateActualCols as $dc) {
                $sourceCol = null;
                foreach ($columns as $cc) {
                    if (($cc['pg_name'] ?? null) === $dc['source_text_column']) {
                        $sourceCol = $cc;
                        break;
                    }
                }
                if ($sourceCol === null) continue;
                $rawDate = $row[$sourceCol['original']] ?? null;
                $parsed = self::parseDate($rawDate);
                $obj[$dc['pg_name']] = self::formatDateIso($parsed);
            }
            $cleanedAll[] = $obj;
        }

        $inserted = 0;
        $batches = array_chunk($cleanedAll, self::INSERT_BATCH_SIZE);
        foreach ($batches as $batchIdx => $batch) {
            try {
                DB::table($tableName)->insert($batch);
                $inserted += count($batch);
            } catch (Throwable $e) {
                Log::warning("[INSERT BATCH] {$tableName} batch {$batchIdx} failed: ".substr($e->getMessage(), 0, 200).' — falling back to per-row');
                foreach ($batch as $r) {
                    try {
                        DB::table($tableName)->insert($r);
                        $inserted++;
                    } catch (Throwable $e2) {
                        // Skip this row — log first 200 chars of error
                        Log::info('[INSERT ROW] skipped: '.substr($e2->getMessage(), 0, 200));
                    }
                }
            }
        }

        return $inserted;
    }
}
