<?php

declare(strict_types=1);

namespace App\Services\Sheets;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use RuntimeException;

/**
 * SheetSchemaDetector — read-only Google Sheets schema preview.
 *
 * Public entry: detect(string $sheetUrl): array — returns:
 *   {
 *     sheet_id: string,
 *     tables: [{ gid, name, columns: [{name, type, samples}], row_count }],
 *     total_rows: int,
 *   }
 *
 * Pipeline:
 *   1. extractSheetId — regex against /spreadsheets/d/<ID>
 *   2. discoverTabs — fetch /htmlview, parse `items.push({name:"...", gid:"..."})` regex
 *   3. For each tab: fetch /export?format=csv&gid=<gid>, parseCSV, build column metadata
 *   4. detectColumnTypeForUI — text|number|date hint for the UI preview only
 *
 * Requires the sheet to be public (anyone with link can view). For private sheets
 * the OAuth-based Google Sheets API would be needed — out of scope for this port.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/sheets.js (detectSchema, lines 124-152)
 */
final class SheetSchemaDetector
{
    /** Tokens that should be treated as NULL when classifying numeric columns. */
    private const NULL_TOKENS = ['', 'na', 'n/a', 'null', 'undefined', '-', '--', 'none', 'nil', '#n/a', '#null!', '#div/0!', '#ref!'];

    /**
     * Detect full schema across every tab of the given Google Sheet URL.
     *
     * @return array{sheet_id: string, tables: list<array<string, mixed>>, total_rows: int}
     *
     * @throws RuntimeException
     */
    public static function detect(string $sheetUrl): array
    {
        $sheetId = self::extractSheetId($sheetUrl);
        if ($sheetId === null) {
            throw new RuntimeException('Invalid Google Sheet URL');
        }

        $tabs = self::discoverTabs($sheetId);
        $tables = [];

        foreach ($tabs as $tab) {
            try {
                [$headers, $rows] = self::fetchSheet($sheetId, $tab['gid']);
                if (count($headers) === 0) continue;
                $tables[] = self::detectTabSchema($headers, $rows, $tab['name'], $tab['gid']);
            } catch (\Throwable $e) {
                Log::info("[SCHEMA] tab {$tab['name']} (gid={$tab['gid']}) skipped: ".$e->getMessage());
            }
        }

        // Fallback — if discovery + per-tab fetches all failed, try the gid embedded in the URL.
        if (count($tables) === 0) {
            $gid = self::extractGid($sheetUrl);
            [$headers, $rows] = self::fetchSheet($sheetId, $gid);
            if (count($headers) > 0) {
                $tables[] = self::detectTabSchema($headers, $rows, 'Sheet1', $gid);
            }
        }

        $totalRows = 0;
        foreach ($tables as $t) {
            $totalRows += (int) ($t['row_count'] ?? 0);
        }

        return [
            'sheet_id'   => $sheetId,
            'tables'     => $tables,
            'total_rows' => $totalRows,
        ];
    }

    public static function extractSheetId(string $url): ?string
    {
        return preg_match('#/spreadsheets/d/([a-zA-Z0-9_-]+)#', $url, $m) ? $m[1] : null;
    }

    public static function extractGid(string $url): string
    {
        return preg_match('/gid=(\d+)/', $url, $m) ? $m[1] : '0';
    }

    /**
     * Scrape the public /htmlview page for `items.push({name:"...", gid:"..."})`.
     * Falls back to extracting bare gids without names. Last resort: assume gid=0.
     *
     * @return list<array{name: string, gid: string}>
     */
    public static function discoverTabs(string $sheetId): array
    {
        $url = "https://docs.google.com/spreadsheets/d/{$sheetId}/htmlview";
        try {
            $resp = Http::timeout(20)->get($url);
            if (! $resp->ok()) {
                Log::info('[SCHEMA] htmlview returned non-200 — falling back to single-tab gid=0');

                return [['name' => 'Sheet1', 'gid' => '0']];
            }
            $html = $resp->body();
        } catch (\Throwable $e) {
            Log::warning('[SCHEMA] htmlview fetch failed: '.$e->getMessage());

            return [['name' => 'Sheet1', 'gid' => '0']];
        }

        $tabs = [];
        if (preg_match_all('/items\.push\(\{name:\s*"([^"]+)"[^}]*gid:\s*"(\d+)"/', $html, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $m) {
                $tabs[] = ['name' => $m[1], 'gid' => $m[2]];
            }
        }
        if (count($tabs) > 0) {
            return $tabs;
        }

        // Fallback: extract bare gids
        $seen = [];
        if (preg_match_all('/gid=(\d+)/', $html, $matches)) {
            foreach ($matches[1] as $g) {
                $seen[$g] = true;
            }
        }
        if (count($seen) === 0) {
            $seen['0'] = true;
        }

        $i = 0;
        $out = [];
        foreach (array_keys($seen) as $g) {
            $i++;
            $out[] = ['name' => "Sheet{$i}", 'gid' => $g];
        }

        return $out;
    }

    /**
     * Fetch a single tab as CSV and parse it.
     *
     * @return array{0: list<string>, 1: list<array<string, string>>}
     *
     * @throws RuntimeException
     */
    public static function fetchSheet(string $sheetId, string $gid): array
    {
        $url = "https://docs.google.com/spreadsheets/d/{$sheetId}/export?format=csv&gid={$gid}";
        $resp = Http::timeout(30)->get($url);
        if (! $resp->ok()) {
            throw new RuntimeException("Sheet fetch failed: {$resp->status()}");
        }

        return self::parseCSV($resp->body());
    }

    /**
     * RFC 4180 CSV parser — handles quoted fields containing commas, embedded newlines,
     * and double-quote-escaped quotes (`""`). Mirrors Node helpers/sheets.js parseCSV.
     *
     * @return array{0: list<string>, 1: list<array<string, string>>}
     */
    public static function parseCSV(string $csv): array
    {
        $allRows = [];
        $cur = '';
        $inQ = false;
        $row = [];
        $len = strlen($csv);
        for ($i = 0; $i < $len; $i++) {
            $ch = $csv[$i];
            if ($ch === '"') {
                if ($inQ && $i + 1 < $len && $csv[$i + 1] === '"') {
                    $cur .= '"';
                    $i++;
                } else {
                    $inQ = ! $inQ;
                }
            } elseif ($ch === ',' && ! $inQ) {
                $row[] = $cur;
                $cur = '';
            } elseif (($ch === "\n" || $ch === "\r") && ! $inQ) {
                if ($ch === "\r" && $i + 1 < $len && $csv[$i + 1] === "\n") {
                    $i++; // skip the \n in CRLF
                }
                $row[] = $cur;
                $cur = '';
                $hasContent = false;
                foreach ($row as $c) {
                    if ((string) $c !== '') { $hasContent = true; break; }
                }
                if ($hasContent) $allRows[] = $row;
                $row = [];
            } else {
                $cur .= $ch;
            }
        }
        // Trailing buffer
        if ($cur !== '' || count($row) > 0) {
            $row[] = $cur;
            $hasContent = false;
            foreach ($row as $c) {
                if ((string) $c !== '') { $hasContent = true; break; }
            }
            if ($hasContent) $allRows[] = $row;
        }

        if (count($allRows) < 2) {
            return [$allRows[0] ?? [], []];
        }

        $headers = array_map(static fn ($h) => trim((string) $h), $allRows[0]);
        $rows = [];
        $rowsRaw = array_slice($allRows, 1);
        foreach ($rowsRaw as $r) {
            $obj = [];
            foreach ($headers as $i => $h) {
                $obj[$h] = isset($r[$i]) ? (string) $r[$i] : '';
            }
            $rows[] = $obj;
        }

        return [$headers, $rows];
    }

    /**
     * Build per-tab schema: column names, UI type hint, samples.
     *
     * @param  list<string>  $headers
     * @param  list<array<string, string>>  $rows
     * @return array{name: string, gid: string, row_count: int, columns: list<array{name: string, type: string, samples: list<string>}>}
     */
    public static function detectTabSchema(array $headers, array $rows, string $tabName, string $gid): array
    {
        $columns = [];
        foreach ($headers as $header) {
            $values = array_map(static fn ($r) => (string) ($r[$header] ?? ''), $rows);
            $samples = [];
            foreach ($values as $v) {
                if ($v !== '' && trim($v) !== '') {
                    $samples[] = $v;
                    if (count($samples) >= 5) break;
                }
            }
            $columns[] = [
                'name'    => $header,
                'type'    => self::detectColumnTypeForUI($values),
                'samples' => $samples,
            ];
        }

        return [
            'name'      => $tabName,
            'gid'       => $gid,
            'row_count' => count($rows),
            'columns'   => $columns,
        ];
    }

    /**
     * Lightweight column-type hint for the UI preview only — NOT used for actual table creation
     * (proper-tables provisioner runs its own deeper detection per Phase 6 contract).
     *
     * @param  list<string>  $values
     */
    public static function detectColumnTypeForUI(array $values): string
    {
        $nonEmpty = [];
        foreach ($values as $v) {
            if ($v !== '' && trim($v) !== '') {
                $nonEmpty[] = $v;
            }
        }
        if (count($nonEmpty) === 0) {
            return 'text';
        }

        $sample = array_slice($nonEmpty, 0, 20);
        $n = 0;
        $d = 0;
        foreach ($sample as $v) {
            if (self::cleanNumeric($v) !== null) {
                $n++;
            } elseif (preg_match('/^\d{1,4}[-\/]\d{1,2}[-\/]\d{1,4}/', $v) || preg_match('/^\d{1,2}-[A-Z][a-z]{2}-\d{2}$/', $v)) {
                $d++;
            }
        }
        $total = count($sample);
        if ($total > 0 && $n / $total > 0.6) return 'number';
        if ($total > 0 && $d / $total > 0.6) return 'date';

        return 'text';
    }

    /**
     * Numeric value cleaner — strips ₹/$/€/£/¥/commas/%/whitespace, handles (123) and (-)123 negatives.
     * Returns null if not a clean number. Mirrors Node helpers/tenant-tables.js cleanNumeric exactly.
     */
    public static function cleanNumeric(mixed $val): ?float
    {
        if ($val === null) return null;
        $s = trim((string) $val);
        if ($s === '') return null;
        if (in_array(strtolower($s), self::NULL_TOKENS, true)) return null;

        $isNeg = false;
        if (preg_match('/^\(-\)/', $s)) {
            $isNeg = true;
            $s = (string) preg_replace('/^\(-\)\s*/', '', $s);
        }
        if (preg_match('/^\(.*\)$/', $s)) {
            $isNeg = true;
            $s = substr($s, 1, -1);
        }
        if (str_starts_with($s, '-')) {
            $isNeg = true;
            $s = substr($s, 1);
        }
        if (str_starts_with($s, '+')) {
            $s = substr($s, 1);
        }

        $s = (string) preg_replace('/[₹$€£¥,\s%]/u', '', $s);
        if ($s === '' || ! preg_match('/^\d*\.?\d+$/', $s)) return null;

        $n = (float) $s;
        if (! is_finite($n)) return null;

        return $isNeg ? -$n : $n;
    }
}
