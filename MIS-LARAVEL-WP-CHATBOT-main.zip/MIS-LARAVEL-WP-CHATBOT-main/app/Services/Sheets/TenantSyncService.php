<?php

declare(strict_types=1);

namespace App\Services\Sheets;

use App\Models\Tenant;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * TenantSyncService — Z25 (admin endpoints).
 *
 * Bulk + single-tenant sync for the /api/tenant/sync-all and
 * /api/tenant/{id}/resync admin endpoints. Mirrors Node helpers/tenant-sync.js
 * 1:1 (serial loop, 5-min throttle, per-tenant error isolation, drift logging).
 *
 * Usage:
 *   $r = TenantSyncService::syncAllTenants(['force' => true]);
 *   $r = TenantSyncService::syncOne($tenantId);
 *
 * Returns:
 *   syncAllTenants:  { tenants: list<{tenantId,name,ok,rows?,tabs?,error?,durationMs,skipped?}>,
 *                      durationMs, skipped?: bool }
 *   syncOne:         { tenantId,name,ok, rows?, tabs?, error?, durationMs }
 *
 * Throttle:
 *   Backed by Cache facade (file driver per Z3 setup). Key shape:
 *     "tenant_sync:last:{tenantId}"  → unix-seconds of last sync
 *   When ($now - $last) < MIN_SYNC_INTERVAL_SEC AND $force is false, the tenant
 *   is skipped with reason 'throttled'. Same 5-min default as Node.
 *
 * Why no WhatsApp drift notification yet:
 *   Node fires sendWhatsAppReply when columns change. Laravel's
 *   TenantTablesProvisioner doesn't expose drift info (Phase 23B left that as
 *   a TODO). When Phase 23D (queue jobs + scheduler) lands, the same path
 *   will be wired here — for now drift is logged but not pushed.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-sync.js
 */
final class TenantSyncService
{
    public const MIN_SYNC_INTERVAL_SEC = 300; // 5 minutes — Node parity

    /**
     * Sync every eligible tenant (proper_tables_created=true, status not paused/cancelled).
     *
     * @param  array{force?: bool}  $opts
     * @return array{
     *     tenants: list<array<string, mixed>>,
     *     durationMs: int,
     *     skipped?: bool,
     *     error?: string
     * }
     */
    public static function syncAllTenants(array $opts = []): array
    {
        $start = (int) (microtime(true) * 1000);
        $force = (bool) ($opts['force'] ?? false);

        try {
            $tenants = Tenant::query()
                ->select(['id', 'name', 'phone', 'sheet_url', 'status', 'proper_tables_created'])
                ->where('proper_tables_created', true)
                ->where(function ($q) {
                    $q->whereNull('status')
                      ->orWhereNotIn('status', ['paused', 'cancelled']);
                })
                ->get();
        } catch (Throwable $e) {
            Log::error('[TENANT-SYNC] List error: '.$e->getMessage());

            return [
                'tenants'    => [],
                'durationMs' => self::elapsed($start),
                'error'      => $e->getMessage(),
            ];
        }

        if ($tenants->isEmpty()) {
            return ['tenants' => [], 'durationMs' => self::elapsed($start)];
        }

        Log::info('[TENANT-SYNC] Starting sync for '.$tenants->count().' tenant(s)');

        $results = [];
        foreach ($tenants as $t) {
            $results[] = self::syncSingle($t->id, $t->name, $t->sheet_url, $force);
        }

        $out = ['tenants' => $results, 'durationMs' => self::elapsed($start)];

        // WhatsApp drift alerts for any tenant whose schema changed this run.
        try {
            \App\Services\Notifications\TenantNotificationService::notifyDrift($out);
        } catch (Throwable $e) {
            Log::warning('[TENANT-SYNC] drift notify failed: '.$e->getMessage());
        }

        return $out;
    }

    /**
     * Sync a single tenant by id. Bypasses throttle by default
     * (admin/self-service action — user explicitly asked for fresh data).
     *
     * @return array<string, mixed>  Same per-tenant shape as syncAllTenants entries.
     */
    public static function syncOne(string $tenantId, bool $force = true): array
    {
        $tenant = Tenant::query()
            ->select(['id', 'name', 'phone', 'sheet_url', 'status', 'proper_tables_created'])
            ->where('id', $tenantId)
            ->first();

        if (! $tenant) {
            return [
                'tenantId'   => $tenantId,
                'ok'         => false,
                'error'      => 'Tenant not found',
                'durationMs' => 0,
            ];
        }



        if (in_array((string) $tenant->status, ['paused', 'cancelled'], true)) {
            return [
                'tenantId'   => $tenantId,
                'name'       => $tenant->name,
                'ok'         => false,
                'error'      => "Tenant status is '{$tenant->status}'",
                'durationMs' => 0,
            ];
        }

        return self::syncSingle($tenant->id, $tenant->name, $tenant->sheet_url, $force);
    }

    /**
     * Clear throttle for a single tenant — next sync runs immediately.
     */
    public static function clearThrottle(string $tenantId): void
    {
        Cache::forget(self::throttleKey($tenantId));
    }

    // ─────────────────────────────────────────────────────────────────────
    // Internals
    // ─────────────────────────────────────────────────────────────────────

    /**
     * @return array<string, mixed>
     */
    private static function syncSingle(
        string $tenantId,
        ?string $name,
        ?string $sheetUrl,
        bool $force
    ): array {
        $tStart = (int) (microtime(true) * 1000);

        // Throttle check
        if (! $force) {
            $last = (int) (Cache::get(self::throttleKey($tenantId), 0));
            $age = time() - $last;
            if ($last > 0 && $age < self::MIN_SYNC_INTERVAL_SEC) {
                Log::info("[TENANT-SYNC] {$name}: throttled (last synced {$age}s ago)");

                return [
                    'tenantId'   => $tenantId,
                    'name'       => $name,
                    'ok'         => true,
                    'skipped'    => 'throttled',
                    'lastSyncAgeSec' => $age,
                    'durationMs' => self::elapsed($tStart),
                ];
            }
        }

        // Collect ALL active sheet URLs for this tenant
        $sheetUrls = [];

        // 1. From tenant_sheets table (multi-sheet)
        $tenantSheets = \App\Models\TenantSheet::query()
            ->where('tenant_id', $tenantId)
            ->where('status', 'active')
            ->get(['id', 'sheet_url']);
        foreach ($tenantSheets as $ts) {
            if ($ts->sheet_url) $sheetUrls[$ts->sheet_url] = $ts->id;
        }

        // 2. Fallback: legacy tenants.sheet_url (if no tenant_sheets rows exist)
        if (empty($sheetUrls) && $sheetUrl) {
            $sheetUrls[$sheetUrl] = null;
        }

        if (empty($sheetUrls)) {
            return [
                'tenantId'   => $tenantId,
                'name'       => $name,
                'ok'         => false,
                'error'      => 'no sheet_url',
                'durationMs' => self::elapsed($tStart),
            ];
        }

        try {
            $totalRows = 0;
            $totalTabs = 0;
            $allDrift = [];
            $allTabErrors = [];
            $mergedMeta = [];

            foreach ($sheetUrls as $url => $sheetRecordId) {
                $r = TenantTablesProvisioner::syncSheetToProperTables($tenantId, $url);

                $tabs = $r['tabs'] ?? [];
                $totalTabs += count($tabs);
                $totalRows += (int) ($r['synced_rows'] ?? 0);
                $allTabErrors = array_merge($allTabErrors, array_values(array_filter($tabs, fn ($t) => isset($t['error']))));

                if (!empty($r['drift'])) $allDrift = array_merge($allDrift, $r['drift']);

                // Merge tables_metadata (flat array of tab objects)
                $newMeta = $r['tables_metadata'] ?? [];
                $newTabs = is_array($newMeta) ? (isset($newMeta['tabs']) ? $newMeta['tabs'] : $newMeta) : [];
                foreach ($newTabs as $tab) {
                    $found = false;
                    foreach ($mergedMeta as $i => $et) {
                        if (($et['pg_table'] ?? '') === ($tab['pg_table'] ?? '')) {
                            $mergedMeta[$i] = $tab;
                            $found = true;
                            break;
                        }
                    }
                    if (!$found) $mergedMeta[] = $tab;
                }

                // Update last_synced_at on the tenant_sheets record
                if ($sheetRecordId) {
                    \App\Models\TenantSheet::query()->where('id', $sheetRecordId)->update(['last_synced_at' => now()]);
                }
            }

            // Mark this tenant as freshly synced
            Cache::put(self::throttleKey($tenantId), time(), self::MIN_SYNC_INTERVAL_SEC * 2);

            // Persist merged metadata
            try {
                Tenant::query()->where('id', $tenantId)->update([
                    'tables_metadata' => $mergedMeta,
                ]);
            } catch (Throwable $persistErr) {
                Log::warning('[TENANT-SYNC] tables_metadata persist failed: '.$persistErr->getMessage());
            }

            $driftEvents = 0;
            foreach ($allDrift as $d) {
                $driftEvents += count($d['added'] ?? []) + count($d['removed'] ?? []) + count($d['typeChanged'] ?? []);
            }
            $duration = self::elapsed($tStart);

            Log::info(
                "[TENANT-SYNC] ✓ {$name}: {$totalRows} rows across {$totalTabs} tab(s) from ".count($sheetUrls)." sheet(s) in {$duration}ms"
                .(count($allTabErrors) > 0 ? ' ('.count($allTabErrors).' tab error(s))' : '')
                .($driftEvents > 0 ? " — {$driftEvents} drift event(s)" : '')
            );

            return [
                'tenantId'    => $tenantId,
                'name'        => $name,
                'ok'          => true,
                'rows'        => $totalRows,
                'tabs'        => $totalTabs,
                'sheets'      => count($sheetUrls),
                'tabErrors'   => $allTabErrors,
                'drift'       => $allDrift,
                'driftEvents' => $driftEvents,
                'durationMs'  => $duration,
            ];
        } catch (Throwable $e) {
            $duration = self::elapsed($tStart);
            Log::error("[TENANT-SYNC] ✗ {$name}: ".$e->getMessage());

            return [
                'tenantId'   => $tenantId,
                'name'       => $name,
                'ok'         => false,
                'error'      => $e->getMessage(),
                'durationMs' => $duration,
            ];
        }
    }

    private static function throttleKey(string $tenantId): string
    {
        return "tenant_sync:last:{$tenantId}";
    }

    private static function elapsed(int $startMs): int
    {
        return (int) (microtime(true) * 1000) - $startMs;
    }
}
