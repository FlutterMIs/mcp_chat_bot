<?php

declare(strict_types=1);

namespace App\Services\Notifications;

use App\Models\Tenant;
use App\Services\Google\CalendarService;
use App\Services\WhatsApp\Client;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Symfony\Component\Mailer\Mailer;
use Symfony\Component\Mailer\Transport;
use Symfony\Component\Mime\Email;
use Throwable;

/**
 * TenantNotificationService — Phase 23D notification dispatchers.
 *
 * Port of Node helpers/tenant-notifications.js. Iterates every calendar-connected
 * tenant and pushes WhatsApp (+ optional email) notifications:
 *
 *   checkReminders()        — every minute; WA reminder 15 min before each meeting
 *   sendDailySchedules()    — 8 AM IST; each tenant's day plan (WA + email)
 *   emailBookingConfirmation() — best-effort guest/owner email after a booking
 *
 * Dedup state lives in Cache (file driver) — survives across the separate
 * processes that Laravel's per-minute scheduler spawns (in-memory Sets, which
 * Node uses, would reset every run under cron-driven schedule:run).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/tenant-notifications.js
 * @see /Users/saranshrajput/Desktop/mis-chatbot/helpers/notifications.js
 */
final class TenantNotificationService
{
    /**
     * List tenants with a connected, active calendar.
     *
     * @return \Illuminate\Support\Collection<int, Tenant>
     */
    public static function listConnectedTenants()
    {
        return Tenant::query()
            ->select(['id', 'name', 'phone', 'email', 'calendar_id', 'calendar_refresh_token', 'calendar_connected', 'status'])
            ->where('calendar_connected', true)
            ->whereNotIn('status', ['paused', 'cancelled'])
            ->get()
            ->filter(fn (Tenant $t) => $t->calendar_refresh_token && $t->phone)
            ->values();
    }

    /**
     * Scan each connected tenant for events 15–16 min out; send a one-time WA reminder.
     */
    public static function checkReminders(): void
    {
        $tenants = self::listConnectedTenants();
        if ($tenants->isEmpty()) {
            return;
        }

        $in15 = (new \DateTimeImmutable('+15 minutes'))->format('c');
        $in16 = (new \DateTimeImmutable('+16 minutes'))->format('c');
        $tz = new \DateTimeZone(CalendarService::TIMEZONE);

        foreach ($tenants as $t) {
            try {
                $events = CalendarService::getEvents($t->calendar_refresh_token, (string) ($t->calendar_id ?: 'primary'), $in15, $in16);
                foreach ($events as $e) {
                    $key = "reminder_sent:{$t->id}:{$e['id']}";
                    if (Cache::has($key)) {
                        continue;
                    }
                    $time = $e['start'] ? (new \DateTimeImmutable($e['start']))->setTimezone($tz)->format('h:i A') : '';
                    $meet = preg_match('/https:\/\/meet\.[a-z.\/-]+\S+/i', (string) ($e['description'] ?? ''), $m)
                        ? $m[0] : (string) ($e['htmlLink'] ?? '');
                    $title = $e['summary'] ?: 'Meeting';
                    $msg = "🔔 *REMINDER — Meeting in 15 min!*\n\n📌 {$title}\n⏰ {$time}".($meet !== '' ? "\n🔗 {$meet}" : '');

                    if (Client::sendText($t->phone, $msg)) {
                        Cache::put($key, true, 1800); // 30-min dedup window
                    }
                }
            } catch (Throwable $e) {
                Log::error("[TENANT REMINDER] {$t->name}: ".$e->getMessage());
            }
        }
    }

    /**
     * Send each connected tenant their day's schedule (WA + email). Intended to run at 8 AM IST.
     * Per-tenant Cache dedup guards against double-sends within the same day.
     */
    public static function sendDailySchedules(): void
    {
        // Only fire at 8 AM IST (scheduler ticks hourly; this guard + per-day Cache
        // dedup means at most one send per tenant per day).
        $nowIst = new \DateTimeImmutable('now', new \DateTimeZone(CalendarService::TIMEZONE));
        if ((int) $nowIst->format('G') !== 8) {
            return;
        }

        $tenants = self::listConnectedTenants();
        if ($tenants->isEmpty()) {
            return;
        }

        $todayKey = (new \DateTimeImmutable('today', new \DateTimeZone(CalendarService::TIMEZONE)))->format('Y-m-d');
        $tz = new \DateTimeZone(CalendarService::TIMEZONE);

        foreach ($tenants as $t) {
            $dedupKey = "daily_sent:{$t->id}";
            if (Cache::get($dedupKey) === $todayKey) {
                continue;
            }

            try {
                $events = CalendarService::getTodayEvents($t->calendar_refresh_token, (string) ($t->calendar_id ?: 'primary'));
                $greeting = '☀️ *Good Morning'.($t->name ? ', '.$t->name : '').'!*';

                if (count($events) === 0) {
                    $waMsg = "{$greeting}\n\n📅 No meetings scheduled today.\n\nEnjoy a relaxed day! 🎉";
                } else {
                    $lines = [];
                    foreach ($events as $i => $e) {
                        $time = $e['start'] ? (new \DateTimeImmutable($e['start']))->setTimezone($tz)->format('h:i A') : '';
                        $lines[] = ($i + 1).". ⏰ {$time} — ".($e['summary'] ?: 'Meeting');
                    }
                    $n = count($events);
                    $waMsg = "{$greeting}\n\n📅 *Today's schedule ({$n} meeting".($n === 1 ? '' : 's')."):*\n\n"
                        .implode("\n", $lines)."\n\n_Have a productive day!_ 💪";
                }

                Client::sendText($t->phone, $waMsg);

                if ($t->email && str_contains((string) $t->email, '@')) {
                    self::sendEmail((string) $t->email, "📅 Today's Schedule — {$todayKey}", self::buildDailyEmailHtml($t->name, $events, $tz));
                }

                Cache::put($dedupKey, $todayKey, 90000); // ~25h
                Log::info("[TENANT DAILY] {$t->name} ({$todayKey}): ".count($events).' meetings');
            } catch (Throwable $e) {
                Log::error("[TENANT DAILY] {$t->name}: ".$e->getMessage());
            }
        }
    }

    /**
     * Send a WhatsApp drift alert to each tenant owner whose sync reported
     * schema changes (added/removed/type-changed columns). Takes the result
     * array returned by TenantSyncService::syncAllTenants() / syncOne().
     *
     * @param  array<string, mixed>  $syncResult  shape: {tenants:[{tenantId,name,driftEvents,drift,...}]} OR a single per-tenant entry
     */
    public static function notifyDrift(array $syncResult): void
    {
        $entries = isset($syncResult['tenants']) && is_array($syncResult['tenants'])
            ? $syncResult['tenants']
            : [$syncResult];

        foreach ($entries as $t) {
            $driftEvents = (int) ($t['driftEvents'] ?? 0);
            if ($driftEvents <= 0) {
                continue;
            }
            $tenantId = (string) ($t['tenantId'] ?? '');
            if ($tenantId === '') {
                continue;
            }
            // Dedup: don't re-alert the same tenant for ~1h (sync runs every 15 min).
            $key = "drift_alert:{$tenantId}";
            if (Cache::has($key)) {
                continue;
            }

            $phone = Tenant::query()->where('id', $tenantId)->value('phone');
            if (! $phone) {
                continue;
            }

            $summaries = [];
            foreach (($t['drift'] ?? []) as $d) {
                if (! empty($d['summary'])) {
                    $tab = (string) ($d['tab'] ?? $d['pg_table'] ?? '');
                    $summaries[] = '• '.($tab !== '' ? "*{$tab}*: " : '').$d['summary'];
                }
            }
            $name = (string) ($t['name'] ?? '');
            $msg = "🔧 *Schema update detected*".($name !== '' ? " for *{$name}*" : '')
                ."\n\nYour sheet structure changed and I've adapted automatically:\n\n"
                .implode("\n", $summaries)
                ."\n\n_Your data is synced and ready. No action needed._";

            if (Client::sendText((string) $phone, $msg)) {
                Cache::put($key, true, 3600);
            }
        }
    }

    /**
     * Best-effort booking notice — WhatsApp summary to the owner + confirmation email to owner+guests.
     *
     * @param  array{summary?:string, startTime?:?string, endTime?:?string, meetLink?:string}  $event
     * @param  list<string>  $guests
     */
    public static function notifyBooking(Tenant $tenant, array $event, array $guests, string $waMessage): void
    {
        if ($tenant->phone) {
            try {
                Client::sendText((string) $tenant->phone, $waMessage);
            } catch (Throwable $e) {
                Log::warning('[BOOK WA] '.$e->getMessage());
            }
        }
        self::emailBookingConfirmation($tenant, $event, $guests);
    }

    /** Best-effort cancellation notice — WhatsApp to owner + email to owner. */
    public static function notifyCancellation(Tenant $tenant, string $title): void
    {
        $clean = str_replace(['<', '>'], '', $title);
        if ($tenant->phone) {
            try {
                Client::sendText((string) $tenant->phone, "❌ *Meeting cancelled*\n\n📌 {$clean}");
            } catch (Throwable $e) {
                Log::warning('[CANCEL WA] '.$e->getMessage());
            }
        }
        if ($tenant->email && str_contains((string) $tenant->email, '@')) {
            self::sendEmail((string) $tenant->email, "Meeting Cancelled: {$clean}",
                '<div style="font-family:Arial,sans-serif;max-width:500px;margin:0 auto;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden">'
                .'<div style="background:#e53935;color:white;padding:16px;text-align:center"><h2 style="margin:0">❌ Meeting Cancelled</h2></div>'
                .'<div style="padding:20px"><p style="margin:0">Your meeting <b>'.$clean.'</b> has been cancelled.</p></div></div>');
        }
    }

    /**
     * Best-effort booking confirmation email to guests + owner. No-op if no email set.
     *
     * @param  array{summary?:string, startTime?:?string, endTime?:?string, meetLink?:string, htmlLink?:string}  $event
     * @param  list<string>  $guests
     */
    public static function emailBookingConfirmation(Tenant $tenant, array $event, array $guests = []): void
    {
        $recipients = array_values(array_filter(array_unique(array_merge(
            $guests,
            $tenant->email ? [(string) $tenant->email] : []
        )), static fn ($e) => is_string($e) && str_contains($e, '@')));

        if ($recipients === []) {
            return;
        }

        $html = self::buildBookingEmailHtml($event);
        $subject = 'Meeting Confirmed: '.($event['summary'] ?? 'Meeting');
        foreach ($recipients as $to) {
            self::sendEmail($to, $subject, $html);
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Email transport (Gmail SMTP via app password — matches Node port)
    // ─────────────────────────────────────────────────────────────────────

    private static function sendEmail(string $to, string $subject, string $html): void
    {
        $pass = (string) config('mis.gmail_app_password', '');
        $from = (string) config('mis.gmail_user', '');
        if ($pass === '' || $from === '') {
            return; // email not configured — silently skip
        }

        try {
            $dsn = 'smtp://'.rawurlencode($from).':'.rawurlencode($pass).'@smtp.gmail.com:587?encryption=tls';
            $mailer = new Mailer(Transport::fromDsn($dsn));
            $mailer->send(
                (new Email())
                    ->from($from)
                    ->to($to)
                    ->subject($subject)
                    ->html($html)
            );
        } catch (Throwable $e) {
            Log::warning('[EMAIL] '.$e->getMessage());
        }
    }

    /** @param list<array<string,mixed>> $events */
    private static function buildDailyEmailHtml(?string $tenantName, array $events, \DateTimeZone $tz): string
    {
        $headerDate = (new \DateTimeImmutable('now', $tz))->format('l, j F Y');
        $rows = count($events) === 0
            ? '<tr><td style="padding:12px;text-align:center;color:#666" colspan="2">No meetings today 🎉</td></tr>'
            : implode('', array_map(static function (array $e) use ($tz) {
                $time = $e['start'] ? (new \DateTimeImmutable($e['start']))->setTimezone($tz)->format('h:i A') : '';
                $title = str_replace(['<', '>'], '', (string) ($e['summary'] ?: 'Meeting'));

                return "<tr><td style=\"padding:6px 12px;border-bottom:1px solid #eee\">{$time}</td><td style=\"padding:6px 12px;border-bottom:1px solid #eee\">{$title}</td></tr>";
            }, $events));
        $name = $tenantName ? '<p style="margin:4px 0 0;opacity:0.85;font-size:13px">'.str_replace(['<', '>'], '', $tenantName).'</p>' : '';

        return '<div style="font-family:Arial,sans-serif;max-width:520px;margin:0 auto;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden">'
            .'<div style="background:#1a73e8;color:white;padding:16px;text-align:center"><h2 style="margin:0">☀️ Today\'s Schedule</h2>'
            ."<p style=\"margin:4px 0 0;opacity:0.9\">{$headerDate}</p>{$name}</div>"
            .'<div style="padding:16px"><table style="width:100%;border-collapse:collapse">'
            .'<tr style="background:#f5f5f5"><th style="padding:8px 12px;text-align:left">Time</th><th style="padding:8px 12px;text-align:left">Meeting</th></tr>'
            ."{$rows}</table></div></div>";
    }

    /** @param array<string,mixed> $event */
    private static function buildBookingEmailHtml(array $event): string
    {
        $tz = new \DateTimeZone(CalendarService::TIMEZONE);
        $start = ! empty($event['startTime']) ? (new \DateTimeImmutable((string) $event['startTime']))->setTimezone($tz) : null;
        $end = ! empty($event['endTime']) ? (new \DateTimeImmutable((string) $event['endTime']))->setTimezone($tz) : null;
        $date = $start ? $start->format('l, j F Y') : '';
        $time = $start ? $start->format('h:i A') : '';
        $endTime = $end ? $end->format('h:i A') : '';
        $title = str_replace(['<', '>'], '', (string) ($event['summary'] ?? 'Meeting'));
        $meet = (string) ($event['meetLink'] ?? '');
        $meetRow = $meet !== '' ? "<tr><td style=\"padding:8px 0;color:#666\">Video Call</td><td style=\"padding:8px 0\"><a href=\"{$meet}\" style=\"color:#1a73e8\">{$meet}</a></td></tr>" : '';

        return '<div style="font-family:Arial,sans-serif;max-width:500px;margin:0 auto;border:1px solid #e0e0e0;border-radius:8px;overflow:hidden">'
            .'<div style="background:#4CAF50;color:white;padding:16px;text-align:center"><h2 style="margin:0">✅ Meeting Confirmed</h2></div>'
            .'<div style="padding:20px"><table style="width:100%;border-collapse:collapse">'
            ."<tr><td style=\"padding:8px 0;color:#666\">Title</td><td style=\"padding:8px 0;font-weight:bold\">{$title}</td></tr>"
            ."<tr><td style=\"padding:8px 0;color:#666\">Date</td><td style=\"padding:8px 0\">{$date}</td></tr>"
            ."<tr><td style=\"padding:8px 0;color:#666\">Time</td><td style=\"padding:8px 0\">{$time} - {$endTime}</td></tr>"
            ."{$meetRow}</table></div></div>";
    }
}
