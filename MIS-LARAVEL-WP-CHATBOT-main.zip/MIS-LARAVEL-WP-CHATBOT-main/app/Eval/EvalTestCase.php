<?php

declare(strict_types=1);

namespace App\Eval;

/**
 * Single eval test case definition.
 */
final class EvalTestCase
{
    public function __construct(
        public readonly string $id,
        public readonly string $category,
        public readonly string $query,
        public readonly array $assertions,
        public readonly ?string $description = null,
        public readonly ?string $tenantId = null,
        public readonly ?string $phone = null,
    ) {}

    public static function make(string $id, string $category, string $query, array $assertions, ?string $description = null): self
    {
        return new self($id, $category, $query, $assertions, $description);
    }
}
