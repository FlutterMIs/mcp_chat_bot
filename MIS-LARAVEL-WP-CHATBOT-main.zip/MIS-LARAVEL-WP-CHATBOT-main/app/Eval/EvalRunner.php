<?php

declare(strict_types=1);

namespace App\Eval;

use App\Services\Chat\TenantRouter;
use App\Services\Chat\ExternalApiService;
use App\Services\AI\AiOrchestrator;
use Illuminate\Support\Facades\Log;

/**
 * EvalRunner — executes test cases against the live pipeline and scores results.
 *
 * Assertion types:
 *   'intent' => 'DATA_QUERY'            — expected intent in response
 *   'tool' => 'query_database'          — orchestrator picked this tool
 *   'reply_contains' => 'string'        — reply text contains this
 *   'reply_not_contains' => 'string'    — reply must NOT contain this
 *   'reply_regex' => '/pattern/'        — reply matches regex
 *   'sql_contains' => 'SUM('           — generated SQL contains this
 *   'sql_not_contains' => 'timestamp'  — SQL must NOT contain this
 *   'sql_table' => 'tenant_xxx_sales'  — SQL queries this table
 *   'rows_gt' => 0                     — result has more than N rows
 *   'rows_eq' => 1                     — result has exactly N rows
 *   'has_media' => true                — response includes media attachment
 *   'elapsed_lt' => 15000              — response time under N ms
 *   'not_empty' => true                — reply is not empty
 *   'orchestrator_tool' => 'query_database'  — test orchestrator decision only (no execution)
 */
final class EvalRunner
{
    private array $results = [];
    private bool $dryRun = false;
    private bool $orchestratorOnly = false;
    private ?string $defaultTenantId = null;
    private ?string $defaultPhone = null;

    public function __construct(
        ?string $tenantId = null,
        ?string $phone = null,
        bool $dryRun = false,
        bool $orchestratorOnly = false
    ) {
        $this->defaultTenantId = $tenantId;
        $this->defaultPhone = $phone;
        $this->dryRun = $dryRun;
        $this->orchestratorOnly = $orchestratorOnly;

        // If no phone specified, use the tenant owner's phone (bypasses access filters)
        if (!$this->defaultPhone && $tenantId) {
            $tenant = \App\Models\Tenant::find($tenantId);
            $this->defaultPhone = $tenant?->phone ?? '919999999999';
        } elseif (!$this->defaultPhone) {
            $this->defaultPhone = '919999999999';
        }
    }

    /**
     * Run all test cases and return results.
     *
     * @param  EvalTestCase[]  $cases
     * @return array{passed: int, failed: int, skipped: int, total: int, details: array}
     */
    public function run(array $cases, ?string $filterCategory = null): array
    {
        $this->results = [];

        foreach ($cases as $case) {
            if ($filterCategory && $case->category !== $filterCategory) {
                continue;
            }

            $result = $this->executeCase($case);
            $this->results[] = $result;
        }

        $passed = count(array_filter($this->results, fn($r) => $r['status'] === 'PASS'));
        $failed = count(array_filter($this->results, fn($r) => $r['status'] === 'FAIL'));
        $skipped = count(array_filter($this->results, fn($r) => $r['status'] === 'SKIP'));

        return [
            'passed'  => $passed,
            'failed'  => $failed,
            'skipped' => $skipped,
            'total'   => count($this->results),
            'score'   => count($this->results) > 0 ? round(($passed / count($this->results)) * 100, 1) : 0,
            'details' => $this->results,
        ];
    }

    private function executeCase(EvalTestCase $case): array
    {
        $tenantId = $case->tenantId ?? $this->defaultTenantId;
        $phone = $case->phone ?? $this->defaultPhone;

        if (!$tenantId) {
            return $this->buildResult($case, 'SKIP', [], 'No tenant ID configured');
        }

        // Orchestrator-only mode: just test the decision, don't execute the full pipeline
        if ($this->orchestratorOnly || $this->hasOnlyOrchestratorAssertions($case)) {
            return $this->executeOrchestratorOnly($case, $tenantId);
        }

        if ($this->dryRun) {
            return $this->buildResult($case, 'SKIP', [], 'Dry run — would execute: "' . $case->query . '"');
        }

        // Execute the full pipeline
        try {
            $response = TenantRouter::handle($phone, $case->query, false, false, $tenantId);
        } catch (\Throwable $e) {
            return $this->buildResult($case, 'FAIL', [], 'Exception: ' . $e->getMessage());
        }

        // Run assertions
        $failures = $this->checkAssertions($case->assertions, $response);

        return $this->buildResult(
            $case,
            empty($failures) ? 'PASS' : 'FAIL',
            $failures,
            null,
            $response
        );
    }

    private function executeOrchestratorOnly(EvalTestCase $case, string $tenantId): array
    {
        try {
            $tenant = \App\Models\Tenant::query()
                ->select(['id', 'tables_metadata'])
                ->find($tenantId);

            if (!$tenant) {
                return $this->buildResult($case, 'SKIP', [], 'Tenant not found');
            }

            $tablesMeta = $tenant->tables_metadata ?? [];
            $decision = AiOrchestrator::decide($tenantId, $case->query, $tablesMeta);

            $response = [
                'orchestrator_tool' => $decision['tool'] ?? null,
                'orchestrator_params' => $decision['params'] ?? [],
                'intent' => $decision ? 'ORCHESTRATOR_DECIDED' : 'ORCHESTRATOR_FAILED',
            ];

            $failures = $this->checkAssertions($case->assertions, $response);

            return $this->buildResult($case, empty($failures) ? 'PASS' : 'FAIL', $failures, null, $response);
        } catch (\Throwable $e) {
            return $this->buildResult($case, 'FAIL', [], 'Orchestrator exception: ' . $e->getMessage());
        }
    }

    private function checkAssertions(array $assertions, array $response): array
    {
        $failures = [];

        foreach ($assertions as $type => $expected) {
            $pass = match ($type) {
                'intent' => ($response['intent'] ?? '') === $expected
                    || ($expected === 'DATA_QUERY' && in_array($response['intent'] ?? '', ['DATA_QUERY', 'MULTI_STEP_QUERY', 'CHART_QUERY', 'IMAGE_QUERY'], true))
                    || ($expected === 'LEDGER' && str_starts_with($response['intent'] ?? '', 'LEDGER'))
                    || ($expected === 'EXTERNAL_API' && ($response['intent'] ?? '') === 'EXTERNAL_API')
                    || ($expected === 'SWITCH_DB' && str_starts_with($response['intent'] ?? '', 'SWITCH_DB')),
                'tool', 'orchestrator_tool' => ($response['orchestrator_tool'] ?? '') === $expected,
                'reply_contains' => str_contains($response['reply'] ?? '', $expected),
                'reply_not_contains' => !str_contains($response['reply'] ?? '', $expected),
                'reply_regex' => (bool) preg_match($expected, $response['reply'] ?? ''),
                'sql_contains' => !isset($response['sql']) || str_contains($response['sql'] ?? '', $expected),
                'sql_not_contains' => !isset($response['sql']) || !str_contains($response['sql'] ?? '', $expected),
                'sql_table' => !isset($response['sql']) || (bool) preg_match('/\b' . preg_quote($expected, '/') . '\b/', $response['sql'] ?? ''),
                'rows_gt' => ($response['rows'] ?? 0) > $expected,
                'rows_eq' => ($response['rows'] ?? 0) === $expected,
                'has_media' => isset($response['media']) === $expected,
                'elapsed_lt' => ($response['elapsed_ms'] ?? 99999) < $expected,
                'not_empty' => !empty(trim($response['reply'] ?? '')),
                'reply_not_empty' => !empty(trim($response['reply'] ?? '')),
                default => null,
            };

            if ($pass === null) {
                $failures[] = "Unknown assertion type: {$type}";
            } elseif (!$pass) {
                $actual = match ($type) {
                    'intent' => $response['intent'] ?? 'NULL',
                    'tool', 'orchestrator_tool' => $response['orchestrator_tool'] ?? 'NULL',
                    'reply_contains', 'reply_not_contains', 'reply_regex' => mb_substr($response['reply'] ?? '', 0, 100),
                    'sql_contains', 'sql_not_contains', 'sql_table' => mb_substr($response['sql'] ?? 'NO SQL', 0, 150),
                    'rows_gt', 'rows_eq' => (string) ($response['rows'] ?? 0),
                    'has_media' => isset($response['media']) ? 'true' : 'false',
                    'elapsed_lt' => (string) ($response['elapsed_ms'] ?? '?'),
                    default => '?',
                };
                $failures[] = "{$type}: expected={$expected}, actual={$actual}";
            }
        }

        return $failures;
    }

    private function hasOnlyOrchestratorAssertions(EvalTestCase $case): bool
    {
        foreach (array_keys($case->assertions) as $key) {
            if (!in_array($key, ['orchestrator_tool', 'tool'])) {
                return false;
            }
        }
        return !empty($case->assertions);
    }

    private function buildResult(EvalTestCase $case, string $status, array $failures, ?string $note = null, ?array $response = null): array
    {
        return [
            'id'       => $case->id,
            'category' => $case->category,
            'query'    => $case->query,
            'status'   => $status,
            'failures' => $failures,
            'note'     => $note,
            'elapsed'  => $response['elapsed_ms'] ?? null,
            'intent'   => $response['intent'] ?? null,
            'sql'      => isset($response['sql']) ? mb_substr($response['sql'], 0, 200) : null,
        ];
    }
}
