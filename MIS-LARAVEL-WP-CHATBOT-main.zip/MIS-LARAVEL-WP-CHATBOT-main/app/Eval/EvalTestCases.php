<?php

declare(strict_types=1);

namespace App\Eval;

/**
 * EvalTestCases — 55+ curated test cases covering all 15 known problem categories.
 * Sources: PROJECT_ROADMAP sessions Z41–Z55 (every bug that was fixed).
 *
 * Categories:
 *  1. date_parsing         — correct date column selection + date range extraction
 *  2. cross_table          — queries spanning multiple tables (sales vs expenses)
 *  3. external_api         — delegation/checklist/call logs/leads routing
 *  4. disambiguation       — ambiguous queries trigger clarification
 *  5. pdf_vs_sql           — data-list queries go to SQL, not PDF
 *  6. invoice_links        — invoice queries include PDF/Drive links
 *  7. ledger               — correct entity extraction for ledger/khata
 *  8. amount_column        — picks correct amount column (GST vs taxable)
 *  9. fuzzy_match          — fuzzy entity matching works
 * 10. format_instruction   — respects "without X" / "only Y" / "in Hindi"
 * 11. hindi_queries        — Hindi/Hinglish query understanding
 * 12. silent_correction    — "galat hai" invalidates previous
 * 13. cache_memory         — repeat queries use cache
 * 14. orchestrator_routing — GPT picks correct tool
 * 15. count_vs_sum         — "kitne" = COUNT, not SUM
 */
final class EvalTestCases
{
    /**
     * @return EvalTestCase[]
     */
    public static function all(): array
    {
        return array_merge(
            self::dateParsing(),
            self::crossTable(),
            self::externalApi(),
            self::disambiguation(),
            self::pdfVsSql(),
            self::invoiceLinks(),
            self::ledger(),
            self::amountColumn(),
            self::fuzzyMatch(),
            self::formatInstruction(),
            self::hindiQueries(),
            self::silentCorrection(),
            self::orchestratorRouting(),
            self::countVsSum(),
            self::edgeCases(),
        );
    }

    public static function dateParsing(): array
    {
        return [
            EvalTestCase::make('DATE-01', 'date_parsing',
                'total expenses in 2025',
                ['intent' => 'DATA_QUERY', 'sql_contains' => '_actual', 'rows_gt' => -1],
                'Must use PRIMARY DATE column (c_date_actual), not sync timestamp'),
            EvalTestCase::make('DATE-02', 'date_parsing',
                'this month ki total sales',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'timestamp_actual'],
                'Current month filter on correct date column'),
            EvalTestCase::make('DATE-03', 'date_parsing',
                'last week ke invoices',
                ['intent' => 'DATA_QUERY', 'sql_contains' => '_actual'],
                'Last week relative date parsing'),
            EvalTestCase::make('DATE-04', 'date_parsing',
                'january 2026 expenses',
                ['intent' => 'DATA_QUERY', 'sql_contains' => '2026'],
                'Specific month+year filter'),
            EvalTestCase::make('DATE-05', 'date_parsing',
                'aaj ki entries',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'CURDATE'],
                'Today filter using CURDATE or today date'),
        ];
    }

    public static function crossTable(): array
    {
        return [
            EvalTestCase::make('CROSS-01', 'cross_table',
                'sales vs expenses this month',
                ['intent' => 'DATA_QUERY', 'not_empty' => true],
                'Cross-table comparison must join/union two tables'),
            EvalTestCase::make('CROSS-02', 'cross_table',
                'total receipts vs total payments',
                ['intent' => 'DATA_QUERY', 'not_empty' => true],
                'Two aggregates from different tables'),
            EvalTestCase::make('CROSS-03', 'cross_table',
                'profit this month (sales minus expenses)',
                ['intent' => 'DATA_QUERY', 'not_empty' => true],
                'Computed value from two tables'),
        ];
    }

    public static function externalApi(): array
    {
        return [
            EvalTestCase::make('API-01', 'external_api',
                'show my delegation tasks',
                ['intent' => 'EXTERNAL_API', 'reply_not_empty' => true],
                'Delegation keyword → external API'),
            EvalTestCase::make('API-02', 'external_api',
                'meri checklist dikhao',
                ['intent' => 'EXTERNAL_API', 'reply_not_empty' => true],
                'Checklist in Hindi → external API'),
            EvalTestCase::make('API-03', 'external_api',
                'yesterday call summary',
                ['intent' => 'EXTERNAL_API', 'reply_not_empty' => true],
                'Call logs with date extraction'),
            EvalTestCase::make('API-04', 'external_api',
                'show my leads',
                ['intent' => 'EXTERNAL_API', 'reply_not_empty' => true],
                'Leads query → external API'),
            EvalTestCase::make('API-05', 'external_api',
                'expired delegation tasks',
                ['intent' => 'EXTERNAL_API', 'reply_not_empty' => true],
                'Expired tasks keyword must hit delegation API'),
            EvalTestCase::make('API-06', 'external_api',
                'daily task list',
                ['intent' => 'EXTERNAL_API', 'reply_not_empty' => true],
                'Daily task → checklist API'),
        ];
    }

    public static function disambiguation(): array
    {
        return [
            EvalTestCase::make('DIS-01', 'disambiguation',
                'pending tasks',
                ['reply_contains' => 'Delegation', 'reply_contains' => 'Checklist'],
                'Ambiguous "pending tasks" should ask: delegation or checklist?'),
            EvalTestCase::make('DIS-02', 'disambiguation',
                'my tasks',
                ['reply_not_empty' => true],
                'Ambiguous "my tasks" should clarify or pick one'),
        ];
    }

    public static function pdfVsSql(): array
    {
        return [
            EvalTestCase::make('PDF-01', 'pdf_vs_sql',
                'first 5 invoices',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'LIMIT 5'],
                'Data-list query MUST go to SQL, not PDF knowledge'),
            EvalTestCase::make('PDF-02', 'pdf_vs_sql',
                'last 10 sales',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'LIMIT 10'],
                'Last N records → SQL pipeline'),
            EvalTestCase::make('PDF-03', 'pdf_vs_sql',
                'top 3 customers by amount',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'ORDER BY'],
                'Top N aggregation → SQL with ORDER BY + LIMIT'),
            EvalTestCase::make('PDF-04', 'pdf_vs_sql',
                'recent 5 expenses',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'LIMIT'],
                'Recent N → SQL not PDF'),
        ];
    }

    public static function invoiceLinks(): array
    {
        return [
            EvalTestCase::make('INV-01', 'invoice_links',
                'send me last 3 invoices',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'invoice'],
                'Invoice query should SELECT pdf/link/url columns'),
            EvalTestCase::make('INV-02', 'invoice_links',
                'SAI LIFE ka invoice bhejo',
                ['intent' => 'DATA_QUERY', 'not_empty' => true],
                'Specific company invoice with link'),
        ];
    }

    public static function ledger(): array
    {
        return [
            EvalTestCase::make('LED-01', 'ledger',
                'pansari industries ka ledger',
                ['intent' => 'LEDGER', 'not_empty' => true],
                'Entity extraction works for "X ka ledger"'),
            EvalTestCase::make('LED-02', 'ledger',
                'give me pansari ledger',
                ['intent' => 'LEDGER', 'not_empty' => true],
                'Stop words stripped: "give me" removed, "pansari" extracted'),
            EvalTestCase::make('LED-03', 'ledger',
                'show ledger of bawa enterprises',
                ['intent' => 'LEDGER', 'not_empty' => true],
                '"show ledger of X" pattern'),
            EvalTestCase::make('LED-04', 'ledger',
                'khata dikhao NPL ka',
                ['intent' => 'LEDGER', 'not_empty' => true],
                'Hindi "khata" = ledger, reverse word order'),
        ];
    }

    public static function amountColumn(): array
    {
        return [
            EvalTestCase::make('AMT-01', 'amount_column',
                'total sales this month',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'SUM', 'rows_gt' => -1],
                'SUM on correct amount column'),
            EvalTestCase::make('AMT-02', 'amount_column',
                'total sales without GST',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'taxable'],
                'Without GST → use taxable_value column'),
            EvalTestCase::make('AMT-03', 'amount_column',
                'total amount with GST',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'gst'],
                'With GST → use amount_with_gst column'),
        ];
    }

    public static function fuzzyMatch(): array
    {
        return [
            EvalTestCase::make('FUZ-01', 'fuzzy_match',
                'pansaari ki sales',
                ['not_empty' => true],
                'Slight misspelling "pansaari" → fuzzy matches "pansari"'),
            EvalTestCase::make('FUZ-02', 'fuzzy_match',
                'baawa enterprises ka data',
                ['not_empty' => true],
                'Misspelling "baawa" → fuzzy matches "bawa"'),
        ];
    }

    public static function formatInstruction(): array
    {
        return [
            EvalTestCase::make('FMT-01', 'format_instruction',
                'delegation list without task id and timestamp',
                ['intent' => 'EXTERNAL_API', 'reply_not_contains' => 'task_id'],
                'User said "without task id" → exclude from output'),
            EvalTestCase::make('FMT-02', 'format_instruction',
                'show invoices only invoice number and amount',
                ['intent' => 'DATA_QUERY', 'not_empty' => true],
                '"only X and Y" → response shows only those fields'),
            EvalTestCase::make('FMT-03', 'format_instruction',
                'total sales btao Hindi mein',
                ['intent' => 'DATA_QUERY', 'not_empty' => true],
                '"Hindi mein" → response in Hindi'),
        ];
    }

    public static function hindiQueries(): array
    {
        return [
            EvalTestCase::make('HIN-01', 'hindi_queries',
                'meri total sales kitni hai is month',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'SUM'],
                'Hinglish query correctly generates SUM SQL'),
            EvalTestCase::make('HIN-02', 'hindi_queries',
                'pichle mahine ke invoices dikhao',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'LIMIT'],
                'Hindi "pichle mahine" = last month'),
            EvalTestCase::make('HIN-03', 'hindi_queries',
                'sabse zyada sales kisko hui',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'ORDER BY'],
                'Hindi "sabse zyada" = highest/top'),
            EvalTestCase::make('HIN-04', 'hindi_queries',
                'kitne customer hain total',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'COUNT'],
                '"kitne" = how many = COUNT'),
            EvalTestCase::make('HIN-05', 'hindi_queries',
                'aaj ka total collection',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'SUM'],
                '"aaj ka total" = today SUM'),
        ];
    }

    public static function silentCorrection(): array
    {
        return [
            EvalTestCase::make('COR-01', 'silent_correction',
                'nahi galat hai, GST ke bina btao',
                ['not_empty' => true],
                'Negation triggers silent correction + retries without GST'),
            EvalTestCase::make('COR-02', 'silent_correction',
                'wrong, show without tax',
                ['not_empty' => true],
                'English negation "wrong" triggers correction'),
        ];
    }

    public static function orchestratorRouting(): array
    {
        return [
            EvalTestCase::make('ORC-01', 'orchestrator_routing',
                'total sales this month',
                ['orchestrator_tool' => 'query_database'],
                'Sales query → database tool'),
            EvalTestCase::make('ORC-02', 'orchestrator_routing',
                'book a meeting tomorrow at 3pm with Rahul',
                ['orchestrator_tool' => 'manage_calendar'],
                'Meeting booking → calendar tool'),
            EvalTestCase::make('ORC-03', 'orchestrator_routing',
                'what is the SOP for invoice creation',
                ['orchestrator_tool' => 'search_knowledge'],
                'SOP/policy question → knowledge search tool'),
            EvalTestCase::make('ORC-04', 'orchestrator_routing',
                'show my delegation tasks',
                ['orchestrator_tool' => 'query_external_api'],
                'Delegation → external API tool'),
            EvalTestCase::make('ORC-05', 'orchestrator_routing',
                'pansari ka khata dikhao',
                ['orchestrator_tool' => 'get_ledger'],
                'Khata/ledger → ledger tool'),
            EvalTestCase::make('ORC-06', 'orchestrator_routing',
                'top 5 customers by sales',
                ['orchestrator_tool' => 'query_database'],
                'Aggregation query → database tool'),
            EvalTestCase::make('ORC-07', 'orchestrator_routing',
                'show me a bar chart of monthly sales',
                ['orchestrator_tool' => 'query_database'],
                'Chart request → database with chart_type'),
            EvalTestCase::make('ORC-08', 'orchestrator_routing',
                'call log summary for this week',
                ['orchestrator_tool' => 'query_external_api'],
                'Call logs → external API tool'),
        ];
    }

    public static function countVsSum(): array
    {
        return [
            EvalTestCase::make('CNT-01', 'count_vs_sum',
                'kitne invoice bane is month',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'COUNT'],
                '"kitne invoice bane" = COUNT of invoices, NOT SUM'),
            EvalTestCase::make('CNT-02', 'count_vs_sum',
                'how many customers do I have',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'COUNT'],
                '"how many" = COUNT'),
            EvalTestCase::make('CNT-03', 'count_vs_sum',
                'total number of sales in April',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'COUNT'],
                '"total number of" = COUNT not SUM(amount)'),
            EvalTestCase::make('CNT-04', 'count_vs_sum',
                'total sales amount this month',
                ['intent' => 'DATA_QUERY', 'sql_contains' => 'SUM'],
                '"total sales amount" = SUM (not count)'),
        ];
    }

    public static function edgeCases(): array
    {
        return [
            EvalTestCase::make('EDGE-01', 'edge_cases',
                'hi',
                ['intent' => 'GREETING'],
                'Simple greeting detected'),
            EvalTestCase::make('EDGE-02', 'edge_cases',
                'kaise ho',
                ['intent' => 'IGNORE'],
                'Casual chit-chat ignored'),
            EvalTestCase::make('EDGE-03', 'edge_cases',
                'a',
                ['intent' => 'CLARIFY_NEEDED'],
                'Single char → ask for more detail'),
            EvalTestCase::make('EDGE-04', 'edge_cases',
                'switch database',
                ['reply_contains' => 'database'],
                'Switch DB intent detected'),
        ];
    }

    /**
     * Get all unique categories.
     * @return string[]
     */
    public static function categories(): array
    {
        return [
            'date_parsing', 'cross_table', 'external_api', 'disambiguation',
            'pdf_vs_sql', 'invoice_links', 'ledger', 'amount_column',
            'fuzzy_match', 'format_instruction', 'hindi_queries',
            'silent_correction', 'orchestrator_routing', 'count_vs_sum', 'edge_cases',
        ];
    }
}
