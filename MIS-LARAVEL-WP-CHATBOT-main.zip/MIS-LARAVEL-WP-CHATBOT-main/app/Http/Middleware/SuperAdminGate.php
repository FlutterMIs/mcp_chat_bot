<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Restricts access to super-admin-only routes.
 * Checks the phone from the request (header X-Phone or query/body phone)
 * against the fixed super_admin_phones list in config/mis.php.
 * Also allows tenant owners for member-management endpoints.
 */
final class SuperAdminGate
{
    public function handle(Request $request, Closure $next): Response
    {
        $phone = $request->header('X-Phone')
            ?: $request->input('phone', '');
        $phone = preg_replace('/[^0-9]/', '', (string) $phone);

        $superAdminPhones = config('mis.super_admin_phones', []);

        // Super admin — full access
        if ($phone && in_array($phone, $superAdminPhones, true)) {
            return $next($request);
        }

        // Owner — allowed for /members endpoints only (manage own team)
        if ($phone && str_contains($request->path(), 'members')) {
            $isOwner = \App\Models\Tenant::where('phone', $phone)->exists()
                || \App\Models\TenantPhone::where('phone', $phone)->exists();
            if ($isOwner) {
                return $next($request);
            }
        }

        return response()->json(['error' => 'Access denied. Super admin only.'], 403);
    }
}
