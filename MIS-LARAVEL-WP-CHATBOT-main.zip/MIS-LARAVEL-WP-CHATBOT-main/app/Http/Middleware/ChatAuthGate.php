<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Services\Auth\ChatTokenService;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

/**
 * ChatAuthGate — phone-token middleware for /api/chat.
 *
 * Two-mode rollout (controlled by env CHAT_AUTH_STRICT):
 *
 *   strict (true) — production-mode. Rejects:
 *     - 401 when X-Chat-Token is missing / malformed / bad-signature / expired
 *     - 403 when the token's phone does not match the request body's phone
 *
 *   loose (false, default) — rollout-mode. Logs warnings on bad/missing/mismatched
 *     tokens but lets the request through, so existing clients (web /chat that hasn't
 *     started issuing tokens yet) keep working. Once login.html starts calling
 *     /api/auth/issue-token, flip CHAT_AUTH_STRICT=true to enforce.
 *
 * On successful verification, sets `$request->attributes->set('chat_auth', [phone, exp])`
 * for downstream handlers to read.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~lines 4397-4426 — chatAuthGate)
 */
final class ChatAuthGate
{
    public function handle(Request $request, Closure $next): Response
    {
        $strict = self::isStrict();
        $bodyPhone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', '')) ?? '';
        $headerToken = $request->header('X-Chat-Token', '') ?? '';

        $verify = ChatTokenService::verifyToken($headerToken);

        if (! $verify['ok']) {
            if ($strict) {
                return response()->json([
                    'reply'      => '⚠️ Session expired. Please reload and sign in again.',
                    'type'       => 'text',
                    'auth_error' => $verify['error'] ?? 'unknown',
                ], 401);
            }
            // Loose mode — log only when a token was actually attempted (don't spam on
            // every tokenless request during rollout)
            if ($headerToken !== '') {
                Log::warning('[CHAT AUTH] invalid token', [
                    'error' => $verify['error'] ?? 'unknown',
                    'phone' => $bodyPhone,
                ]);
            }

            return $next($request);
        }

        // Token verified — but does the embedded phone match the request body?
        if ($bodyPhone !== '' && ($verify['phone'] ?? '') !== $bodyPhone) {
            if ($strict) {
                return response()->json([
                    'reply'      => '⚠️ Token does not match phone. Please reload and sign in again.',
                    'type'       => 'text',
                    'auth_error' => 'phone-mismatch',
                ], 403);
            }
            Log::warning('[CHAT AUTH] phone mismatch', [
                'token_phone' => $verify['phone'] ?? null,
                'body_phone'  => $bodyPhone,
            ]);
        }

        $request->attributes->set('chat_auth', [
            'phone' => $verify['phone'] ?? null,
            'exp'   => $verify['exp']   ?? null,
        ]);

        return $next($request);
    }

    private static function isStrict(): bool
    {
        return filter_var(config('mis.chat_auth_strict', false), FILTER_VALIDATE_BOOLEAN);
    }
}
