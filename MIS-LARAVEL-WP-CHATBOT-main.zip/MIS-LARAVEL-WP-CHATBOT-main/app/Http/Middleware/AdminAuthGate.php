<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

/**
 * AdminAuthGate — API key middleware for admin endpoints.
 *
 * Verifies the request carries a valid x-api-key header (or ?api_key= query param)
 * matching config('mis.admin_api_key'). Used to gate the tenant-sync admin endpoints
 * (POST /api/tenant/sync-all, POST /api/tenant/{id}/resync).
 *
 * Behavior:
 *   - 500 if ADMIN_API_KEY is not configured server-side (misconfiguration, fail loud).
 *   - 401 if the header/query is missing or doesn't match.
 *   - hash_equals for timing-safe comparison (matches ChatTokenService approach).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~line 183 — requireAuth)
 */
final class AdminAuthGate
{
    public function handle(Request $request, Closure $next): Response
    {
        $expected = (string) config('mis.admin_api_key', '');
        if ($expected === '') {
            Log::error('[ADMIN AUTH] ADMIN_API_KEY not configured');

            return response()->json([
                'error' => 'Admin auth not configured server-side',
            ], 500);
        }

        $provided = (string) ($request->header('x-api-key') ?? $request->query('api_key', ''));
        if ($provided === '' || ! hash_equals($expected, $provided)) {
            return response()->json([
                'error' => 'Unauthorized',
            ], 401);
        }

        return $next($request);
    }
}
