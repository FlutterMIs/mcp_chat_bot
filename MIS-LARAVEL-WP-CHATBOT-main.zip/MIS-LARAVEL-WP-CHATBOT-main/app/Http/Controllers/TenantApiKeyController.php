<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\TenantApiKey;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class TenantApiKeyController extends Controller
{
    /** GET /api/tenant/api-keys?phone= */
    public function index(Request $request): JsonResponse
    {
        $tenantId = $this->resolveTenantId($request);
        if (!$tenantId) return response()->json(['error' => 'Tenant not found'], 404);

        $keys = TenantApiKey::where('tenant_id', $tenantId)->orderByDesc('created_at')->get()
            ->map(fn($k) => [
                'id' => $k->id,
                'label' => $k->label,
                'api_key_masked' => '...' . substr($k->api_key, -6),
                'base_url' => $k->base_url,
                'access_level' => $k->access_level,
                'status' => $k->status,
                'created_at' => $k->created_at,
            ]);

        return response()->json($keys);
    }

    /** POST /api/tenant/api-keys */
    public function store(Request $request): JsonResponse
    {
        $tenantId = $this->resolveTenantId($request);
        if (!$tenantId) return response()->json(['error' => 'Tenant not found'], 404);

        $label = trim((string) $request->input('label'));
        $apiKey = trim((string) $request->input('api_key'));
        $baseUrl = trim((string) $request->input('base_url'));
        $access = $request->input('access_level', 'owner');

        if (!$label || !$apiKey || !$baseUrl) {
            return response()->json(['error' => 'label, api_key, base_url required'], 400);
        }
        if (!in_array($access, ['everyone', 'team', 'owner'])) $access = 'owner';

        $key = TenantApiKey::create([
            'tenant_id' => $tenantId,
            'label' => $label,
            'api_key' => $apiKey,
            'base_url' => rtrim($baseUrl, '/'),
            'access_level' => $access,
        ]);

        return response()->json(['ok' => true, 'id' => $key->id]);
    }

    /** PUT /api/tenant/api-keys/{id} */
    public function update(Request $request, $id): JsonResponse
    {
        $tenantId = $this->resolveTenantId($request);
        if (!$tenantId) return response()->json(['error' => 'Tenant not found'], 404);

        $key = TenantApiKey::where('id', $id)->where('tenant_id', $tenantId)->first();
        if (!$key) return response()->json(['error' => 'Key not found'], 404);

        if ($request->has('label')) $key->label = trim($request->input('label'));
        if ($request->has('api_key') && trim($request->input('api_key'))) $key->api_key = trim($request->input('api_key'));
        if ($request->has('base_url')) $key->base_url = rtrim(trim($request->input('base_url')), '/');
        if ($request->has('access_level')) {
            $al = $request->input('access_level');
            if (in_array($al, ['everyone', 'team', 'owner'])) $key->access_level = $al;
        }
        if ($request->has('status')) {
            $st = $request->input('status');
            if (in_array($st, ['active', 'paused'])) {
                $key->status = $st;

                if (in_array($key->type, [1, 2])) {
                    $tenant = \App\Models\Tenant::find($tenantId);
                    if ($st === 'active') {
                        // Pause the other WA key types
                        TenantApiKey::where('tenant_id', $tenantId)
                            ->whereIn('type', [1, 2])
                            ->where('id', '!=', $key->id)
                            ->update(['status' => 'paused']);

                        if ($tenant) {
                            $tenant->wa_channel_mode = $key->type === 1 ? 'professional' : 'unprofessional';
                            $tenant->wa_key_mode = 'own';
                            $tenant->save();
                        }
                    } else if ($st === 'paused') {
                        // If pausing, check if any other is active
                        $hasActive = TenantApiKey::where('tenant_id', $tenantId)
                            ->whereIn('type', [1, 2])
                            ->where('id', '!=', $key->id)
                            ->where('status', 'active')
                            ->exists();
                        if (!$hasActive && $tenant) {
                            $tenant->wa_key_mode = 'shared';
                            $tenant->save();
                        }
                    }
                }
            }
        }
        $key->save();

        return response()->json(['ok' => true]);
    }

    /** DELETE /api/tenant/api-keys/{id} */
    public function destroy(Request $request, $id): JsonResponse
    {
        $tenantId = $this->resolveTenantId($request);
        if (!$tenantId) return response()->json(['error' => 'Tenant not found'], 404);

        TenantApiKey::where('id', $id)->where('tenant_id', $tenantId)->delete();
        return response()->json(['ok' => true]);
    }

    private function resolveTenantId(Request $request): ?string
    {
        $phone = $request->input('phone') ?? $request->header('X-Phone');
        if (!$phone) return null;
        $tenant = \App\Models\Tenant::where('phone', $phone)->first();
        return $tenant?->id;
    }
}
