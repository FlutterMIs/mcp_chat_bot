<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\TenantLink;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use App\Models\TenantPdfChunk;
use App\Services\Chat\PdfKnowledgeService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

final class TenantLinkController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $tenantId = self::resolve($request->query('phone', ''));
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        $links = TenantLink::where('tenant_id', $tenantId)->orderByDesc('created_at')->get();
        return response()->json(['links' => $links]);
    }

    public function store(Request $request): JsonResponse
    {
        $tenantId = self::resolve($request->input('phone', ''));
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        $title = trim($request->input('title', ''));
        $url = trim($request->input('url', ''));
        if ($title === '' || $url === '') return response()->json(['error' => 'title and url required'], 400);

        $link = TenantLink::create([
            'tenant_id'    => $tenantId,
            'title'        => $title,
            'description'  => $request->input('description', ''),
            'url'          => $url,
            'category'     => $request->input('category', '') ?: 'link',
            'access_level' => $request->input('access_level', 'all'),
        ]);

        // Auto-index content based on extension: PDF, DOCX, XLSX, XLS, CSV, TXT, MD, or Webpage
        $pathInfo = parse_url($url, PHP_URL_PATH);
        $ext = $pathInfo ? strtolower(pathinfo($pathInfo, PATHINFO_EXTENSION)) : '';
        $isDoc = in_array($ext, ['pdf', 'docx', 'xlsx', 'xls', 'csv', 'txt', 'md']) || preg_match('/drive\.google\.com/i', $url);

        if ($isDoc) {
            PdfKnowledgeService::indexFromUrl($tenantId, $url, $title);
        } else {
            PdfKnowledgeService::indexFromWebUrl($tenantId, $url, $title);
        }

        return response()->json(['ok' => true, 'link' => $link]);
    }

    public function upload(Request $request): JsonResponse
    {
        $tenantId = self::resolve($request->input('phone', ''));
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        $request->validate([
            'file' => 'required|file|max:10240', // 10MB limit
            'title' => 'required|string|max:255',
            'description' => 'nullable|string|max:1000',
            'access_level' => 'required|string|in:all,team,owner',
        ]);

        $file = $request->file('file');
        $title = trim($request->input('title'));
        $ext = strtolower($file->getClientOriginalExtension());

        $allowed = ['pdf', 'docx', 'xlsx', 'xls', 'csv', 'txt', 'md'];
        if (!in_array($ext, $allowed)) {
            return response()->json(['error' => 'Only PDF, DOCX, XLSX, XLS, CSV, TXT, MD files are allowed.'], 400);
        }

        // Store file securely on public disk
        $path = $file->storeAs("tenant_files/{$tenantId}", Str::random(20) . ".{$ext}", 'public');
        $url = asset("storage/{$path}");

        // Create TenantLink entry
        $link = TenantLink::create([
            'tenant_id'    => $tenantId,
            'title'        => $title,
            'description'  => $request->input('description', '') ?? '',
            'url'          => $url,
            'category'     => 'file',
            'access_level' => $request->input('access_level', 'all'),
        ]);

        // Process indexing
        $realPath = Storage::disk('public')->path($path);
        $chunks = PdfKnowledgeService::indexLocalFile($tenantId, $realPath, $url, $title);

        return response()->json([
            'ok' => true,
            'link' => $link,
            'chunks' => $chunks,
            'message' => $chunks > 0 ? "File uploaded and indexed successfully!" : "File uploaded but no text content was found."
        ]);
    }

    public function destroy(Request $request, $id): JsonResponse
    {
        $tenantId = self::resolve($request->query('phone', ''));
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        $link = TenantLink::where('id', $id)->where('tenant_id', $tenantId)->first();
        if ($link) {
            // Drop related chunks from DB
            TenantPdfChunk::where('tenant_id', $tenantId)->where('source_url', $link->url)->delete();

            // If the file is stored locally, delete it from storage
            if (str_contains($link->url, '/storage/tenant_files/')) {
                // Extract relative path after /storage/
                $relativePath = substr($link->url, strpos($link->url, '/storage/tenant_files/') + 9);
                // Decode URL characters in path
                $relativePath = rawurldecode($relativePath);
                Storage::disk('public')->delete($relativePath);
            }

            $link->delete();
        }

        return response()->json(['ok' => true]);
    }

    public function indexPdfs(Request $request): JsonResponse
    {
        $tenantId = self::resolve($request->input('phone', ''));
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        $links = TenantLink::where('tenant_id', $tenantId)->get();
        $indexed = 0;
        foreach ($links as $link) {
            $pathInfo = parse_url($link->url, PHP_URL_PATH);
            $ext = $pathInfo ? strtolower(pathinfo($pathInfo, PATHINFO_EXTENSION)) : '';
            $isDoc = in_array($ext, ['pdf', 'docx', 'xlsx', 'xls', 'csv', 'txt', 'md']) || preg_match('/drive\.google\.com/i', $link->url);

            if ($isDoc) {
                $chunks = PdfKnowledgeService::indexFromUrl($tenantId, $link->url, $link->title);
            } else {
                $chunks = PdfKnowledgeService::indexFromWebUrl($tenantId, $link->url, $link->title);
            }
            if ($chunks > 0) $indexed++;
        }

        return response()->json(['ok' => true, 'indexed' => $indexed, 'total_links' => $links->count()]);
    }

    public function analyze(Request $request): JsonResponse
    {
        $tenantId = self::resolve($request->input('phone', ''));
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        $url = trim($request->input('doc_url', ''));
        if ($url === '') {
            return response()->json(['error' => 'URL is required.'], 400);
        }

        // Auto-index content based on extension
        $pathInfo = parse_url($url, PHP_URL_PATH);
        $ext = $pathInfo ? strtolower(pathinfo($pathInfo, PATHINFO_EXTENSION)) : '';
        $isDoc = in_array($ext, ['pdf', 'docx', 'xlsx', 'xls', 'csv', 'txt', 'md']) || preg_match('/drive\.google\.com/i', $url);

        $title = $request->input('title') ?: ($isDoc ? 'Analyzed Document' : 'Analyzed Webpage');

        // Create TenantLink entry
        $link = TenantLink::create([
            'tenant_id'    => $tenantId,
            'title'        => $title,
            'description'  => 'Analyzed via Chat Tools',
            'url'          => $url,
            'category'     => $isDoc ? 'file' : 'link',
            'access_level' => 'all',
        ]);

        if ($isDoc) {
            $chunks = PdfKnowledgeService::indexFromUrl($tenantId, $url, $title);
        } else {
            $chunks = PdfKnowledgeService::indexFromWebUrl($tenantId, $url, $title);
        }

        if ($chunks === 0) {
            return response()->json(['error' => 'Could not extract any content from the document/webpage.'], 400);
        }

        // Fetch chunks to create a summary
        $loadedChunks = \App\Models\TenantPdfChunk::where('tenant_id', $tenantId)->where('source_url', $url)->limit(3)->pluck('content')->toArray();
        $contextText = implode("\n", $loadedChunks);

        // Call GPT to summarize the content
        $summary = "No summary could be generated.";
        try {
            $resp = \App\Services\AI\AiGateway::chat($tenantId, [
                ['role' => 'system', 'content' => 'Summarize the following document content in a short, friendly paragraph for a business user. Keep it under 200 words.'],
                ['role' => 'user', 'content' => $contextText]
            ]);
            if ($resp['ok']) {
                $summary = $resp['content'];
            }
        } catch (\Throwable $e) {}

        return response()->json([
            'ok' => true,
            'summary' => "Indexed successfully into your knowledge base ($chunks chunks created)!\n\n" . $summary,
            'link' => $link
        ]);
    }

    public function uploadFile(Request $request): JsonResponse
    {
        $tenantId = self::resolve($request->input('phone', ''));
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        $request->validate([
            'file' => 'required|file|max:10240', // 10MB limit
        ]);

        $file = $request->file('file');
        $ext = strtolower($file->getClientOriginalExtension());
        $title = $file->getClientOriginalName();

        $allowed = ['pdf', 'docx', 'xlsx', 'xls', 'csv', 'txt', 'md'];
        if (!in_array($ext, $allowed)) {
            return response()->json(['error' => 'Unsupported file format. Supported: PDF, DOCX, XLSX, XLS, CSV, TXT, MD.'], 400);
        }

        // Store file securely
        $path = $file->storeAs("tenant_files/{$tenantId}", Str::random(20) . ".{$ext}", 'public');
        $url = asset("storage/{$path}");

        // Create TenantLink entry
        $link = TenantLink::create([
            'tenant_id'    => $tenantId,
            'title'        => $title,
            'description'  => 'Uploaded via Chat Tools',
            'url'          => $url,
            'category'     => 'file',
            'access_level' => 'all',
        ]);

        // Process indexing
        $realPath = Storage::disk('public')->path($path);
        $chunks = PdfKnowledgeService::indexLocalFile($tenantId, $realPath, $url, $title);

        if ($chunks === 0) {
            return response()->json(['error' => 'Could not extract any content from the uploaded file.'], 400);
        }

        // Fetch chunks to create a summary
        $loadedChunks = \App\Models\TenantPdfChunk::where('tenant_id', $tenantId)->where('source_url', $url)->limit(3)->pluck('content')->toArray();
        $contextText = implode("\n", $loadedChunks);

        // Call GPT to summarize the content
        $summary = "No summary could be generated.";
        try {
            $resp = \App\Services\AI\AiGateway::chat($tenantId, [
                ['role' => 'system', 'content' => 'Summarize the following document content in a short, friendly paragraph for a business user. Keep it under 200 words.'],
                ['role' => 'user', 'content' => $contextText]
            ]);
            if ($resp['ok']) {
                $summary = $resp['content'];
            }
        } catch (\Throwable $e) {}

        return response()->json([
            'ok' => true,
            'summary' => "Uploaded and indexed successfully ($chunks chunks created)!\n\n" . $summary,
            'link' => $link
        ]);
    }

    private static function resolve(string $phone): ?string
    {
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($phone) < 10) return null;
        $d = UserDatabase::query()->select('tenant_id')->where('phone', $phone)->where('is_default', true)->first();
        if ($d?->tenant_id) return $d->tenant_id;
        $o = Tenant::query()->select('id')->where('phone', $phone)->first();
        return $o?->id;
    }
}
