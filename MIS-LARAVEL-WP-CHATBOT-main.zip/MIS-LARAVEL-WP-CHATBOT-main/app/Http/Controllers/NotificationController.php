<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\TenantNotification;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use Carbon\CarbonImmutable;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * Notifications API — 3 actions:
 *   GET  /api/notifications?phone=&limit=&unread=             — list
 *   POST /api/notifications/{id}/read    body: { phone }      — mark single read
 *   POST /api/notifications/mark-all-read body: { phone }     — mark all read
 *
 * Authorisation model matches Node — a notification is visible if its `phone`
 * matches OR its `tenant_id` matches the resolved tenant for the caller's phone.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~lines 4134-4233)
 */
final class NotificationController extends Controller
{
    /** GET /api/notifications */
    public function index(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        if (! $phone) {
            return response()->json(['error' => 'phone required'], 400);
        }

        $tenantId = $this->resolveTenantId($phone);
        if (! $tenantId) {
            // Match Node's lenient behaviour for unrecognised phone — return empty list, not 404
            return response()->json(['notifications' => [], 'unread_count' => 0]);
        }

        $limit = min(200, max(1, (int) $request->query('limit', 50)));
        $unreadOnly = in_array((string) $request->query('unread', ''), ['true', '1'], true);

        try {
            $q = TenantNotification::query()
                ->where(function ($w) use ($phone, $tenantId) {
                    $w->where('phone', $phone)->orWhere('tenant_id', $tenantId);
                })
                ->orderByDesc('created_at')
                ->limit($limit);
            if ($unreadOnly) {
                $q->whereNull('read_at');
            }
            $rows = $q->get();

            $unreadCount = TenantNotification::query()
                ->where(function ($w) use ($phone, $tenantId) {
                    $w->where('phone', $phone)->orWhere('tenant_id', $tenantId);
                })
                ->whereNull('read_at')
                ->count();

            return response()->json([
                'notifications' => $rows->map(static fn (TenantNotification $n): array => [
                    'id'         => $n->id,
                    'kind'       => $n->kind,
                    'title'      => $n->title,
                    'message'    => $n->message,
                    'severity'   => $n->severity ?? 'info',
                    'read'       => $n->read_at !== null,
                    'created_at' => $n->created_at?->toIso8601String(),
                    'metadata'   => $n->metadata ?? [],
                ])->all(),
                'unread_count' => $unreadCount,
            ]);
        } catch (Throwable $e) {
            Log::error('Notifications list failed', ['phone' => $phone, 'error' => $e->getMessage()]);

            return response()->json(['error' => 'Could not load notifications'], 500);
        }
    }

    /** POST /api/notifications/{id}/read */
    public function read(Request $request, int $id): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        if (! $id || ! $phone) {
            return response()->json(['error' => 'id + phone required'], 400);
        }

        $tenantId = $this->resolveTenantId($phone);
        if (! $tenantId) {
            return response()->json(['error' => 'No tenant'], 404);
        }

        try {
            TenantNotification::query()
                ->where('id', $id)
                ->where(function ($w) use ($phone, $tenantId) {
                    $w->where('phone', $phone)->orWhere('tenant_id', $tenantId);
                })
                ->whereNull('read_at')
                ->update(['read_at' => CarbonImmutable::now()]);

            return response()->json(['ok' => true]);
        } catch (Throwable $e) {
            Log::error('Mark notification read failed', ['id' => $id, 'error' => $e->getMessage()]);

            return response()->json(['error' => 'Could not mark read'], 500);
        }
    }

    /** POST /api/notifications/mark-all-read */
    public function markAllRead(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        if (! $phone) {
            return response()->json(['error' => 'phone required'], 400);
        }

        $tenantId = $this->resolveTenantId($phone);
        if (! $tenantId) {
            return response()->json(['error' => 'No tenant'], 404);
        }

        try {
            TenantNotification::query()
                ->where(function ($w) use ($phone, $tenantId) {
                    $w->where('phone', $phone)->orWhere('tenant_id', $tenantId);
                })
                ->whereNull('read_at')
                ->update(['read_at' => CarbonImmutable::now()]);

            return response()->json(['ok' => true]);
        } catch (Throwable $e) {
            Log::error('Mark all read failed', ['phone' => $phone, 'error' => $e->getMessage()]);

            return response()->json(['error' => 'Could not mark all read'], 500);
        }
    }

    /** 3-step tenant resolution (matches DashboardController/PageController). */
    private function resolveTenantId(string $phone): ?string
    {
        $defaultDb = UserDatabase::query()->select('tenant_id')
            ->where('phone', $phone)->where('is_default', true)->first();
        if ($defaultDb?->tenant_id) {
            return $defaultDb->tenant_id;
        }

        $owner = Tenant::query()->select('id')->where('phone', $phone)->first();
        if ($owner?->id) {
            return $owner->id;
        }

        $mapping = TenantPhone::query()->select('tenant_id')->where('phone', $phone)->first();

        return $mapping?->tenant_id;
    }
}
