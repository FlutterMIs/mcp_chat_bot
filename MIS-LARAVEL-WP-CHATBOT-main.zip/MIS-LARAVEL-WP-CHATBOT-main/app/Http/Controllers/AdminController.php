<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Services\Sheets\TenantSyncService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * AdminController — Z25.
 *
 * Admin endpoints (gated by AdminAuthGate via the `admin-auth` middleware
 * alias):
 *
 *   POST /api/tenant/sync-all
 *     Body: { force?: bool }   // bypasses 5-min per-tenant throttle when true
 *     Response: { ok: true, tenants: [...], durationMs }
 *
 *   POST /api/tenant/{id}/resync
 *     Body: { force?: bool }   // default true (admin/self-service action)
 *     Response: { ok: true, ...syncResult }
 *
 * Skipped endpoints (Node legacy, not ported — see roadmap Z23 + Z25):
 *   - GET/POST /access  → MIS-Work-India access_control.json (legacy)
 *   - GET/POST /sync    → MIS Main Google Sheet sync (Laravel doesn't host MIS Main)
 *   - /sync/status      → reads sync_log table; no Laravel writers yet (Phase 23D)
 *   - /api/access/*     → access_control.json admin (legacy)
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~line 3090 — /api/tenant/sync-all)
 */
final class AdminController extends Controller
{
    /**
     * POST /api/tenant/sync-all
     */
    public function syncAll(Request $request): JsonResponse
    {
        $force = (bool) $request->boolean('force', false);

        try {
            $r = TenantSyncService::syncAllTenants(['force' => $force]);

            return response()->json([
                'ok' => true,
                ...$r,
            ]);
        } catch (Throwable $e) {
            Log::error('[ADMIN sync-all] '.$e->getMessage());

            return response()->json([
                'ok'    => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * POST /api/tenant/{id}/resync
     */
    public function resync(Request $request, string $id): JsonResponse
    {
        // Defaults to true (explicit user action — bypass throttle), but
        // callable with { force: false } if a caller wants to respect throttle.
        $force = (bool) $request->boolean('force', true);

        try {
            $r = TenantSyncService::syncOne($id, $force);
            $http = ($r['ok'] ?? false) ? 200 : 400;

            return response()->json([
                'ok' => (bool) ($r['ok'] ?? false),
                ...$r,
            ], $http);
        } catch (Throwable $e) {
            Log::error("[ADMIN resync {$id}] ".$e->getMessage());

            return response()->json([
                'ok'    => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
