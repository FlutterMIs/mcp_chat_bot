<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\SendOtpRequest;
use App\Services\Auth\OtpService;
use App\Services\Chat\TenantRouter;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

final class OtpController extends Controller
{
    /** POST /api/tenant/send-otp {phone} — sends 6-digit OTP via WhatsApp */
    public function send(SendOtpRequest $request): JsonResponse
    {
        $phone = $request->validated('phone');

        // Server-side resend cooldown — the real guard (frontend countdown is just UX on top
        // of this). Prevents API spam even if the client timer is bypassed or the page reloads.
        $retryAfter = OtpService::secondsUntilResend($phone);
        if ($retryAfter > 0) {
            return response()->json([
                'ok'          => false,
                'error'       => 'Please wait before requesting another OTP.',
                'retry_after' => $retryAfter,
            ], 429);
        }

        // Only send OTP if phone is registered OR is a super admin
        $isSuperAdmin = in_array($phone, config('mis.super_admin_phones', []), true);
        $tenantId = TenantRouter::resolveTenantId($phone);

        if (!$isSuperAdmin && !$tenantId) {
            return response()->json(['error' => 'Phone not registered. Contact admin.'], 404);
        }

        $sent = OtpService::send($phone, $tenantId);
        return response()->json([
            'ok'          => $sent,
            'message'     => $sent ? 'OTP sent via WhatsApp' : 'Failed to send OTP',
            'retry_after' => $sent ? OtpService::secondsUntilResend($phone) : 0,
        ]);
    }

    /** POST /api/tenant/verify-otp {phone, otp} — verifies OTP code */
    public function verify(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $otp = trim((string) $request->input('otp', ''));

        if (strlen($phone) < 10 || strlen($otp) !== 6) {
            return response()->json(['error' => 'Phone and 6-digit OTP required'], 400);
        }

        if (OtpService::verify($phone, $otp)) {
            return response()->json(['ok' => true, 'verified' => true]);
        }

        return response()->json(['ok' => false, 'verified' => false, 'error' => 'Invalid or expired OTP'], 401);
    }
}
