<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\MessageLog;
use App\Models\Tenant;
use App\Models\UserDatabase;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

/**
 * Client-facing read-only viewer for the message_logs audit trail — lets a tenant
 * confirm what the bot actually sent/received across WhatsApp and web chat.
 */
final class MessageLogController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $tenantId = self::resolve($request->query('phone', ''));
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        $query = MessageLog::where('tenant_id', $tenantId);

        $direction = (string) $request->query('direction', '');
        if (in_array($direction, ['in', 'out'], true)) {
            $query->where('direction', $direction);
        }

        $platform = (string) $request->query('platform', '');
        if (in_array($platform, ['whatsapp', 'web'], true)) {
            $query->where('platform', $platform);
        }

        $perPage = min((int) $request->query('per_page', 50), 100);

        return response()->json(
            $query->orderByDesc('created_at')->paginate($perPage)
        );
    }

    private static function resolve(string $phone): ?string
    {
        $phone = preg_replace('/[^0-9]/', '', $phone);
        if (strlen($phone) < 10) return null;
        $d = UserDatabase::query()->select('tenant_id')->where('phone', $phone)->where('is_default', true)->first();
        if ($d?->tenant_id) return $d->tenant_id;
        $o = Tenant::query()->select('id')->where('phone', $phone)->first();
        return $o?->id;
    }
}
