<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use App\Services\Dashboard\DashboardEngine;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * GET /api/dashboard?phone=&range=&tenant_id=
 *
 * Returns the dashboard payload for the tenant resolved from the phone.
 * 3-step resolution order (matches Node /api/dashboard):
 *   1. user_databases.is_default = true → tenant_id
 *   2. tenants.phone → tenant_id (owner)
 *   3. tenant_phones.phone → tenant_id (mapped user)
 * If `tenant_id` is given as query param, skip resolution and use it directly.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~line 3476)
 */
final class DashboardController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        $range = (string) $request->query('range', 'month');
        $explicitTenantId = $request->query('tenant_id');

        if (! $phone || strlen($phone) < 10) {
            return response()->json(['error' => 'phone required'], 400);
        }

        try {
            $tenantId = $explicitTenantId ? (string) $explicitTenantId : $this->resolveTenantId($phone);
            if (! $tenantId) {
                return response()->json(['error' => 'No tenant found for this phone'], 404);
            }

            $t0 = microtime(true);
            // 10-minute cache per tenant+range. Background cache-warming
            // scheduler refreshes every 5 min so users always hit warm cache.
            $cacheKey = "dashboard:{$tenantId}:{$range}";
            $dash = Cache::remember($cacheKey, 600, function () use ($tenantId, $range) {
                return DashboardEngine::build($tenantId, ['range' => $range]);
            });
            $dash['elapsed_ms'] = (int) ((microtime(true) - $t0) * 1000);
            $dash['cached'] = ($dash['elapsed_ms'] < 100);

            return response()->json($dash);
        } catch (Throwable $e) {
            Log::error('Dashboard generation failed', [
                'phone' => $phone,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json([
                'error' => 'Dashboard generation failed: '.$e->getMessage(),
            ], 500);
        }
    }

    /**
     * 3-step tenant resolution from phone. Returns null if no tenant found.
     */
    private function resolveTenantId(string $phone): ?string
    {
        // Step 1 — user_databases default DB
        $defaultDb = UserDatabase::query()
            ->select('tenant_id')
            ->where('phone', $phone)
            ->where('is_default', true)
            ->first();
        if ($defaultDb?->tenant_id) {
            return $defaultDb->tenant_id;
        }

        // Step 2 — tenants.phone (owner)
        $owner = Tenant::query()
            ->select('id')
            ->where('phone', $phone)
            ->first();
        if ($owner?->id) {
            return $owner->id;
        }

        // Step 3 — tenant_phones mapping
        $mapping = TenantPhone::query()
            ->select('tenant_id')
            ->where('phone', $phone)
            ->first();

        return $mapping?->tenant_id;
    }
}
