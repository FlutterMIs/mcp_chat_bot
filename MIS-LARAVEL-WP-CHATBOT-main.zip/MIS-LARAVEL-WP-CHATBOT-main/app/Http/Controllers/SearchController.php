<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use App\Services\Dashboard\TenantSearchService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * GET /api/search?phone=&q=&limit=&tenant_id=
 *
 * Spotlight ⌘K search across the tenant's customers, suppliers, items, invoices.
 * Same 3-step phone resolution as DashboardController. Requires q ≥ 2 chars.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~line 4550)
 */
final class SearchController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        $q     = trim((string) $request->query('q', ''));
        $limit = min(50, max(1, (int) $request->query('limit', 20)));
        $explicitTenantId = $request->query('tenant_id');

        if (! $phone && ! $explicitTenantId) {
            return response()->json(['error' => 'phone required'], 400);
        }

        if (mb_strlen($q) < 2) {
            return response()->json([
                'results' => [],
                'message' => 'Enter at least 2 characters',
            ]);
        }

        try {
            $tenantId = $explicitTenantId ? (string) $explicitTenantId : $this->resolveTenantId($phone);
            if (! $tenantId) {
                return response()->json(['error' => 'No tenant found for this phone'], 404);
            }

            $t0 = microtime(true);
            $out = TenantSearchService::search($tenantId, $q, $limit);
            $out['elapsed_ms'] = (int) ((microtime(true) - $t0) * 1000);

            return response()
                ->json($out)
                ->header('Cache-Control', 'no-store');
        } catch (Throwable $e) {
            Log::error('Search failed', ['phone' => $phone, 'q' => $q, 'error' => $e->getMessage()]);

            return response()->json(['error' => 'Search failed: '.$e->getMessage()], 500);
        }
    }

    /** 3-step tenant resolution. */
    private function resolveTenantId(string $phone): ?string
    {
        $defaultDb = UserDatabase::query()->select('tenant_id')
            ->where('phone', $phone)->where('is_default', true)->first();
        if ($defaultDb?->tenant_id) {
            return $defaultDb->tenant_id;
        }
        $owner = Tenant::query()->select('id')->where('phone', $phone)->first();
        if ($owner?->id) {
            return $owner->id;
        }
        $mapping = TenantPhone::query()->select('tenant_id')->where('phone', $phone)->first();

        return $mapping?->tenant_id;
    }
}
