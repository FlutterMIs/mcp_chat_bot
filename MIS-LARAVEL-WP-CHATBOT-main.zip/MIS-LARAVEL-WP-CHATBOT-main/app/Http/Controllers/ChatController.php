<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\SendMessageRequest;
use App\Http\Resources\ChatResponseResource;
use App\Models\MessageLog;
use App\Services\Chat\MarkdownRenderer;
use App\Services\Chat\SmartFormatter;
use App\Services\Chat\TenantRouter;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * POST /chat   body: { phone, message, session_id? }
 *
 * Web chat endpoint. Returns HTML tables + chartMeta + base64 attachments
 * for the web frontend (matches Node.js server.js /chat response format).
 *
 * Response shapes:
 *   { reply: "<html table>", type: "html", chartMeta?: {...} }
 *   { reply: "text", type: "text" }
 *   { reply: "text", type: "text", attachments: [{type,name,mime,base64}] }
 *   { reply: "text", type: "suggestions", options: [...] }
 */
final class ChatController extends Controller
{
    public function __invoke(SendMessageRequest $request): ChatResponseResource|JsonResponse
    {
        $phone = $request->validated('phone');
        $message = $request->validated('message');

        try {
            $result = TenantRouter::handle($phone, $message);
            $webResp = self::toWebResponse($result);

            // Save to chat_history
            $tenantId = $result['tenant']['id'] ?? null;
            $sessionId = (string) $request->input('session_id', $phone);
            try {
                DB::table('chat_history')->insert([
                    ['session_id' => $sessionId, 'role' => 'user', 'content' => $message, 'tenant_id' => $tenantId, 'created_at' => now()],
                    ['session_id' => $sessionId, 'role' => 'assistant', 'content' => mb_substr($webResp['reply'] ?? '', 0, 5000), 'tenant_id' => $tenantId, 'created_at' => now()],
                ]);
            } catch (Throwable $e) {
                Log::warning('[ChatHistory] save failed: ' . $e->getMessage());
            }

            // message_logs audit trail — mirrors WebhookController's WhatsApp logging so
            // the client-facing message log viewer covers both channels uniformly.
            try {
                MessageLog::create([
                    'tenant_id'    => $tenantId,
                    'platform'     => 'web',
                    'direction'    => 'in',
                    'phone'        => $phone,
                    'session_id'   => $sessionId,
                    'message_type' => 'text',
                    'message'      => mb_substr($message, 0, 5000),
                ]);
                MessageLog::create([
                    'tenant_id'    => $tenantId,
                    'platform'     => 'web',
                    'direction'    => 'out',
                    'phone'        => $phone,
                    'session_id'   => $sessionId,
                    'message_type' => 'text',
                    'message'      => mb_substr($webResp['reply'] ?? '', 0, 5000),
                ]);
            } catch (Throwable $e) {
                Log::warning('[MessageLog] save failed: ' . $e->getMessage());
            }

            return new ChatResponseResource($webResp);
        } catch (Throwable $e) {
            Log::error('Chat handle failed', [
                'phone'   => $phone,
                'message' => mb_substr($message, 0, 200),
                'error'   => $e->getMessage(),
                'trace'   => $e->getTraceAsString(),
            ]);

            return response()->json([
                'reply' => '⚠️ Something went wrong on the server. Please try again.',
                'type'  => 'text',
                'error' => 'chat_failed',
            ], 500);
        }
    }

    public function getHistory(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $sessionId = (string) $request->input('session_id', $phone);

        if ($phone === '' || strlen($phone) < 10) {
            return response()->json(['error' => 'phone required'], 400);
        }

        $rows = DB::table('chat_history')
            ->where('session_id', $sessionId)
            ->orderBy('created_at', 'asc')
            ->limit(100)
            ->get(['role', 'content', 'created_at']);

        return response()->json(['history' => $rows]);
    }

    /**
     * Convert TenantRouter result → web chat response format.
     * - LEDGER_QUERY → summary + transaction HTML table + PDF download link
     * - DATA_QUERY with SQL rows → re-run SQL and build HTML table
     * - CHART_QUERY → HTML table + chartMeta
     * - LEDGER_DISAMBIGUATE → suggestions
     * - Media (PDF/image/document) → base64 attachment, attached to whichever
     *   branch above returns (never dropped just because a table was also built —
     *   e.g. a >50-row auto-exported PDF used to be silently discarded here).
     */
    private static function toWebResponse(array $result): array
    {
        $intent = $result['intent'] ?? '';
        $reply = $result['reply'] ?? '';
        $media = $result['media'] ?? null;
        $sql = $result['sql'] ?? null;
        $rowCount = $result['rows'] ?? 0;

        // Ledger/fuzzy disambiguation → suggestions type
        if (in_array($intent, ['LEDGER_DISAMBIGUATE', 'FUZZY_SUGGESTIONS'], true)) {
            $options = $result['matches'] ?? $result['suggestions'] ?? [];
            return [
                'reply'   => $reply,
                'type'    => 'suggestions',
                'options' => array_slice($options, 0, 8),
            ];
        }

        // Built once, attached to whichever branch below actually returns — a table
        // being rendered inline is not a reason to drop the downloadable file.
        $attachments = [];
        if ($media) {
            $att = self::mediaToAttachment($media);
            if ($att !== null) {
                $attachments[] = $att;
            }
        }

        // LEDGER_QUERY → opening/closing summary + transaction table + PDF link.
        // The web panel renders type:'html' verbatim (no client-side markdown pass),
        // so the (already web-Markdown) summary is converted to HTML here first.
        if ($intent === 'LEDGER_QUERY' && !empty($result['raw_rows'])) {
            try {
                $html = MarkdownRenderer::toHtml($reply).SmartFormatter::buildTableHTML($result['raw_rows']);
                $resp = [
                    'reply'      => $html,
                    'type'       => 'html',
                    'intent'     => $intent,
                    'tenant'     => $result['tenant'] ?? null,
                    'elapsed_ms' => $result['elapsed_ms'] ?? null,
                ];
                if (!empty($result['pdf_url'])) {
                    $resp['pdf_url'] = $result['pdf_url'];
                }
                if (count($attachments) > 0) {
                    $resp['attachments'] = $attachments;
                }

                return $resp;
            } catch (Throwable $e) {
                Log::info('[ChatController] Ledger HTML table build failed: ' . $e->getMessage());
            }
        }

        // MULTI_STEP_QUERY (cross-table/complex questions routed through MultiStepAgent,
        // e.g. "party statement for all customers") → short AI intro + table from the
        // last step's rows. MultiStepAgent::synthesize() already produces a one-line
        // intro (not a per-record breakdown) when raw_rows is tabular on the web
        // channel, so no extra dedup logic is needed here — just render both.
        if ($intent === 'MULTI_STEP_QUERY' && !empty($result['raw_rows'])) {
            try {
                $html = MarkdownRenderer::toHtml($reply).SmartFormatter::buildTableHTML($result['raw_rows']);
                $resp = [
                    'reply'      => $html,
                    'type'       => 'html',
                    'intent'     => $intent,
                    'tenant'     => $result['tenant'] ?? null,
                    'elapsed_ms' => $result['elapsed_ms'] ?? null,
                ];
                if (count($attachments) > 0) {
                    $resp['attachments'] = $attachments;
                }

                return $resp;
            } catch (Throwable $e) {
                Log::info('[ChatController] Multi-step HTML table build failed: ' . $e->getMessage());
            }
        }

        // DATA_QUERY with SQL → build HTML table from cached result
        if ($intent === 'DATA_QUERY' && $sql && $rowCount > 0) {
            try {
                $rows = $result['raw_rows'] ?? DB::select($sql);
                if (count($rows) > 0) {
                    $html = SmartFormatter::buildTableHTML($rows);
                    $resp = [
                        'reply'      => $html,
                        'type'       => 'html',
                        'intent'     => $intent,
                        'tenant'     => $result['tenant'] ?? null,
                        'elapsed_ms' => $result['elapsed_ms'] ?? null,
                    ];
                    if (count($attachments) > 0) {
                        $resp['attachments'] = $attachments;
                    }

                    return $resp;
                }
            } catch (Throwable $e) {
                Log::info('[ChatController] HTML table build failed: ' . $e->getMessage());
            }
        }

        // CHART_QUERY → HTML table + chartMeta
        if ($intent === 'CHART_QUERY' && $sql) {
            try {
                $rows = $result['raw_rows'] ?? DB::select($sql);
                if (count($rows) > 0) {
                    $html = SmartFormatter::buildTableHTML($rows);
                    $resp = [
                        'reply'      => $html,
                        'type'       => 'html',
                        'intent'     => $intent,
                        'tenant'     => $result['tenant'] ?? null,
                        'elapsed_ms' => $result['elapsed_ms'] ?? null,
                    ];
                    if (isset($result['chart'])) {
                        $resp['chartMeta'] = [
                            'chartType' => $result['chart']['type'] ?? 'bar',
                            'title'     => $result['chart']['title'] ?? 'Chart',
                            'labelCol'  => $result['chart']['label_col'] ?? null,
                            'valueCol'  => $result['chart']['value_col'] ?? null,
                        ];
                    }
                    if (count($attachments) > 0) {
                        $resp['attachments'] = $attachments;
                    }

                    return $resp;
                }
            } catch (Throwable $e) {
                Log::info('[ChatController] Chart HTML re-query failed: ' . $e->getMessage());
            }
        }

        $resp = [
            'reply'      => $reply,
            'type'       => 'text',
            'intent'     => $intent,
            'tenant'     => $result['tenant'] ?? null,
            'elapsed_ms' => $result['elapsed_ms'] ?? null,
        ];

        if (count($attachments) > 0) {
            $resp['attachments'] = $attachments;
        }

        return $resp;
    }

    /**
     * Convert a media payload (PDF/image/document) to a base64 web attachment.
     */
    private static function mediaToAttachment(?array $media): ?array
    {
        if ($media === null) return null;

        $type = $media['type'] ?? '';
        $path = $media['path'] ?? '';

        if ($path === '' || !file_exists($path)) return null;

        $contents = file_get_contents($path);
        if ($contents === false) return null;

        $base64 = base64_encode($contents);
        $filename = $media['filename'] ?? basename($path);
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        $mimeMap = [
            'pdf'  => 'application/pdf',
            'csv'  => 'text/csv',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'png'  => 'image/png',
            'jpg'  => 'image/jpeg',
            'jpeg' => 'image/jpeg',
        ];
        $mime = $mimeMap[$ext] ?? 'application/octet-stream';

        return [
            'type'    => $type === 'image' ? 'image' : 'document',
            'name'    => $filename,
            'mime'    => $mime,
            'base64'  => $base64,
            'caption' => $media['caption'] ?? null,
        ];
    }

}
