<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\BookMeetingRequest;
use App\Models\Tenant;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use App\Services\Google\CalendarService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * CalendarController — OAuth2 init + callback for per-tenant Google Calendar.
 *
 *   GET /api/tenant/calendar/auth?tenant_id={uuid}
 *       → redirect to Google consent URL (state=tenant_id)
 *
 *   GET /api/tenant/calendar/callback?code={code}&state={tenant_id}
 *       → exchange code for tokens, store refresh_token on tenant row,
 *         flip calendar_connected=true, return success HTML
 *
 * Mounted in routes/web.php (NOT routes/api.php) because OAuth callbacks
 * arrive without API auth and need to render HTML. CSRF is excepted via
 * `validateCsrfTokens(except: ['api/tenant/calendar/*'])` in bootstrap/app.php
 * (only the callback POST would need it; current routes are GET so CSRF
 * doesn't apply, but excepting future-proofs for /disconnect endpoints).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~lines 5037-5080)
 */
final class CalendarController extends Controller
{
    /**
     * Step 1: redirect tenant to Google consent screen.
     *
     * GET /api/tenant/calendar/auth?tenant_id={uuid}
     */
    public function init(Request $request): RedirectResponse|Response
    {
        $tenantId = (string) $request->query('tenant_id', '');
        if ($tenantId === '') {
            return response('tenant_id query parameter required', 400);
        }

        // Validate tenant exists before initiating OAuth — saves a confusing flow
        // where Google redirects back to a callback that can't find the tenant.
        $tenant = Tenant::query()->select('id', 'name')->where('id', $tenantId)->first();
        if (! $tenant) {
            return response('Tenant not found', 404);
        }

        try {
            $url = CalendarService::getAuthURL($tenantId);
            Log::info("[CALENDAR OAUTH INIT] tenant={$tenantId} ({$tenant->name})");

            return redirect()->away($url);
        } catch (Throwable $e) {
            Log::error('[CALENDAR OAUTH INIT] '.$e->getMessage());

            return response('OAuth setup failed: '.$e->getMessage(), 500);
        }
    }

    /**
     * Step 2: Google redirects here with the auth code.
     *
     * GET /api/tenant/calendar/callback?code={code}&state={tenant_id}
     *
     * Exchanges code for tokens, stores refresh_token on the tenant, returns success HTML.
     */
    public function callback(Request $request): Response
    {
        $code = (string) $request->query('code', '');
        $tenantId = (string) $request->query('state', '');

        if ($code === '' || $tenantId === '') {
            return response($this->errorHtml('Missing code or state parameter'), 400);
        }

        try {
            $tokens = CalendarService::exchangeCode($code);
        } catch (Throwable $e) {
            Log::error('[CALENDAR OAUTH CALLBACK] exchange failed: '.$e->getMessage());

            return response($this->errorHtml('Calendar connection failed: '.$e->getMessage()), 500);
        }

        $refreshToken = (string) ($tokens['refresh_token'] ?? '');
        if ($refreshToken === '') {
            // Google only returns refresh_token on FIRST consent. If the user has previously
            // approved + we lost the token, they need to revoke + reconnect.
            Log::warning('[CALENDAR OAUTH CALLBACK] no refresh_token in response — user may need to revoke first');

            return response($this->errorHtml(
                'No refresh token received from Google.<br>'
                .'Please revoke access at <a href="https://myaccount.google.com/permissions" target="_blank">myaccount.google.com/permissions</a> '
                .'and try connecting again.'
            ), 400);
        }

        // Store on the tenant row
        try {
            $tenant = Tenant::query()->where('id', $tenantId)->first();
            if (! $tenant) {
                return response($this->errorHtml('Tenant not found.'), 404);
            }

            $tenant->calendar_id = 'primary';
            $tenant->calendar_refresh_token = $refreshToken;
            $tenant->calendar_connected = true;
            $tenant->save();

            Log::info("[CALENDAR OAUTH CALLBACK] tenant={$tenantId} ({$tenant->name}) → calendar_connected=true");
        } catch (Throwable $e) {
            Log::error('[CALENDAR OAUTH CALLBACK] DB write failed: '.$e->getMessage());

            return response($this->errorHtml('Could not save calendar credentials: '.$e->getMessage()), 500);
        }

        return response($this->successHtml(), 200);
    }

    private function successHtml(): string
    {
        return <<<'HTML'
            <!doctype html>
            <html><head><meta charset="utf-8"><title>Calendar Connected</title></head>
            <body style="font-family:sans-serif;text-align:center;padding:60px;background:#0a0a0a;color:#e5e5e5">
              <h1 style="color:#22c55e">✅ Calendar Connected!</h1>
              <p>Redirecting back to settings...</p>
              <script>
                if (window.opener && !window.opener.closed) {
                  window.opener.postMessage({ type: 'CALENDAR_AUTH', status: 'ok', message: 'Calendar connected successfully!' }, '*');
                  window.close();
                } else {
                  window.location.href = '/settings';
                }
              </script>
            </body></html>
            HTML;
    }

    /** Stylised error page. */
    private function errorHtml(string $message): string
    {
        $safe = htmlspecialchars($message, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        // We inject the safe message securely into the script as a JS string literal.
        $jsMessage = json_encode($message);

        return <<<HTML
            <!doctype html>
            <html><head><meta charset="utf-8"><title>Calendar Connection Failed</title></head>
            <body style="font-family:sans-serif;text-align:center;padding:60px;background:#0a0a0a;color:#e5e5e5">
              <h1 style="color:#ef4444">⚠️ Calendar Connection Failed</h1>
              <p>{$safe}</p>
              <script>
                if (window.opener && !window.opener.closed) {
                  window.opener.postMessage({ type: 'CALENDAR_AUTH', status: 'error', message: {$jsMessage} }, '*');
                  window.close();
                } else {
                  // If not opened in a popup, fallback to redirect or keep the static page open
                  setTimeout(() => {
                    window.location.href = '/settings';
                  }, 3000);
                }
              </script>
            </body></html>
            HTML;
    }

    // ════════════════════════════════════════════════════════════════════
    // WEB UI ENDPOINTS (Phase 23F) — used by public/calendar.html
    // ════════════════════════════════════════════════════════════════════

    /**
     * GET /api/tenant/calendar/events?phone=&from=YYYY-MM-DD&to=YYYY-MM-DD
     *
     * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~line 3911)
     */
    public function events(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        if ($phone === '') {
            return response()->json(['error' => 'phone required'], 400);
        }

        $r = $this->getCalendarTenant($phone);
        if (isset($r['error'])) {
            return response()->json(['error' => $r['error']], $r['code']);
        }
        $t = $r['tenant'];

        $today = new \DateTimeImmutable('today', new \DateTimeZone(CalendarService::TIMEZONE));
        $from = ($f = (string) $request->query('from', ''))
            ? (new \DateTimeImmutable($f.'T00:00:00', new \DateTimeZone(CalendarService::TIMEZONE)))->format('c')
            : $today->modify('first day of previous month')->format('c');
        $to = ($tq = (string) $request->query('to', ''))
            ? (new \DateTimeImmutable($tq.'T23:59:59', new \DateTimeZone(CalendarService::TIMEZONE)))->format('c')
            : $today->modify('last day of next month')->format('c');

        try {
            $events = CalendarService::getEvents($t->calendar_refresh_token, (string) ($t->calendar_id ?: 'primary'), $from, $to);
        } catch (Throwable $e) {
            Log::error('[CAL EVENTS] '.$e->getMessage());

            return response()->json(['error' => 'Could not load events'], 500);
        }

        return response()->json([
            'tenant' => ['id' => $t->id, 'name' => $t->name],
            'range'  => ['from' => $from, 'to' => $to],
            'events' => array_map(static fn (array $e) => [
                'id'          => $e['id'],
                'title'       => $e['summary'] ?: '(untitled)',
                'description' => $e['description'],
                'start'       => $e['start'],
                'end'         => $e['end'],
                'all_day'     => $e['all_day'],
                'attendees'   => $e['attendees'],
                'location'    => $e['location'],
                'meet_link'   => preg_match('/https:\/\/meet\.[a-z.\/-]+\S+/i', $e['description'], $m) ? $m[0] : '',
            ], $events),
        ]);
    }

    /**
     * POST /api/tenant/calendar/book
     * Body: { phone, title, start, end?, description?, guests?:[email], force? }
     */
    public function book(BookMeetingRequest $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $title = trim((string) $request->input('title', ''));
        $start = (string) $request->input('start', '');
        if ($phone === '') return response()->json(['error' => 'phone required'], 400);
        if ($title === '') return response()->json(['error' => 'title required'], 400);
        if ($start === '') return response()->json(['error' => 'start required (ISO datetime)'], 400);

        try {
            $startDate = new \DateTimeImmutable($start);
        } catch (Throwable) {
            return response()->json(['error' => 'Invalid start datetime'], 400);
        }
        if ($startDate->getTimestamp() < time() - 60) {
            return response()->json(['error' => 'Cannot book in the past'], 400);
        }
        $endDate = ($end = (string) $request->input('end', ''))
            ? new \DateTimeImmutable($end)
            : $startDate->modify('+1 hour');
        if ($endDate <= $startDate) {
            return response()->json(['error' => 'End must be after start'], 400);
        }

        $r = $this->getCalendarTenant($phone);
        if (isset($r['error'])) {
            return response()->json(['error' => $r['error']], $r['code']);
        }
        $t = $r['tenant'];
        $calId = (string) ($t->calendar_id ?: 'primary');

        // Conflict detection (unless force=true)
        if (! $request->boolean('force')) {
            try {
                $overlap = CalendarService::getEvents($t->calendar_refresh_token, $calId, $startDate->format('c'), $endDate->format('c'));
            } catch (Throwable $e) {
                $overlap = [];
            }
            if (count($overlap) > 0) {
                return response()->json([
                    'error'     => 'Time slot conflicts with existing event(s)',
                    'conflicts' => array_map(static fn (array $e) => [
                        'id' => $e['id'], 'title' => $e['summary'], 'start' => $e['start'], 'end' => $e['end'],
                    ], $overlap),
                    'hint'      => 'Pass force=true to book anyway',
                ], 409);
            }
        }

        $guests = $request->input('guests', []);
        $cleanGuests = is_array($guests)
            ? array_values(array_filter(array_map(
                static fn ($g) => strtolower(trim((string) $g)),
                $guests
            ), static fn ($g) => (bool) preg_match('/^[^\s@]+@[^\s@]+\.[^\s@]+$/', $g)))
            : [];

        try {
            $event = CalendarService::createEvent($t->calendar_refresh_token, $calId, [
                'title'       => mb_substr($title, 0, 200),
                'startTime'   => $startDate->format('c'),
                'endTime'     => $endDate->format('c'),
                'description' => mb_substr((string) $request->input('description', ''), 0, 1000),
                'guests'      => $cleanGuests,
            ]);
        } catch (Throwable $e) {
            Log::error('[CAL BOOK] '.$e->getMessage());

            return response()->json(['error' => 'Booking failed'], 500);
        }

        // Best-effort booking confirmation email to guests + owner.
        try {
            \App\Services\Notifications\TenantNotificationService::emailBookingConfirmation($t, $event, $cleanGuests);
        } catch (Throwable $e) {
            Log::warning('[CAL BOOK EMAIL] '.$e->getMessage());
        }

        return response()->json(['ok' => true, 'event' => [
            'id'        => $event['eventId'],
            'title'     => $event['summary'],
            'start'     => $event['startTime'],
            'end'       => $event['endTime'],
            'meet_link' => $event['meetLink'] ?? '',
        ]]);
    }

    /**
     * POST /api/tenant/calendar/reschedule
     * Body: { phone, event_id, new_start, new_end? }
     */
    public function reschedule(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $eventId = (string) $request->input('event_id', '');
        $newStart = (string) $request->input('new_start', '');
        if ($phone === '') return response()->json(['error' => 'phone required'], 400);
        if ($eventId === '') return response()->json(['error' => 'event_id required'], 400);
        if ($newStart === '') return response()->json(['error' => 'new_start required'], 400);

        try {
            $startDate = new \DateTimeImmutable($newStart);
        } catch (Throwable) {
            return response()->json(['error' => 'Invalid new_start'], 400);
        }
        if ($startDate->getTimestamp() < time() - 60) {
            return response()->json(['error' => 'Cannot reschedule to the past'], 400);
        }
        $endDate = ($end = (string) $request->input('new_end', ''))
            ? new \DateTimeImmutable($end)
            : $startDate->modify('+1 hour');

        $r = $this->getCalendarTenant($phone);
        if (isset($r['error'])) {
            return response()->json(['error' => $r['error']], $r['code']);
        }
        $t = $r['tenant'];

        try {
            $updated = CalendarService::updateEvent($t->calendar_refresh_token, (string) ($t->calendar_id ?: 'primary'), $eventId, [
                'startTime' => $startDate->format('c'),
                'endTime'   => $endDate->format('c'),
            ]);
        } catch (Throwable $e) {
            Log::error('[CAL RESCHEDULE] '.$e->getMessage());

            return response()->json(['error' => 'Reschedule failed'], 500);
        }

        return response()->json(['ok' => true, 'event' => [
            'id'    => $updated['eventId'],
            'title' => $updated['summary'],
            'start' => $updated['startTime'],
            'end'   => $updated['endTime'],
        ]]);
    }

    /**
     * POST /api/tenant/calendar/cancel
     * Body: { phone, event_id }
     */
    public function cancel(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $eventId = (string) $request->input('event_id', '');
        if ($phone === '') return response()->json(['error' => 'phone required'], 400);
        if ($eventId === '') return response()->json(['error' => 'event_id required'], 400);

        $r = $this->getCalendarTenant($phone);
        if (isset($r['error'])) {
            return response()->json(['error' => $r['error']], $r['code']);
        }
        $t = $r['tenant'];

        try {
            CalendarService::deleteEvent($t->calendar_refresh_token, (string) ($t->calendar_id ?: 'primary'), $eventId);
        } catch (Throwable $e) {
            Log::error('[CAL CANCEL] '.$e->getMessage());

            return response()->json(['error' => 'Cancel failed'], 500);
        }

        return response()->json(['ok' => true]);
    }

    /**
     * POST /api/tenant/calendar/disconnect
     * Body: { phone }
     */
    public function disconnect(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        if ($phone === '') {
            return response()->json(['error' => 'phone required'], 400);
        }

        $tenantId = $this->resolveTenantId($phone);
        if (! $tenantId) {
            return response()->json(['error' => 'No tenant for this phone'], 404);
        }

        $t = Tenant::query()->where('id', $tenantId)->first();
        if (! $t) {
            return response()->json(['error' => 'Tenant not found'], 404);
        }

        $t->calendar_connected = false;
        $t->calendar_refresh_token = null;
        $t->calendar_id = null;
        $t->save();

        return response()->json(['ok' => true]);
    }

    /**
     * Resolve tenant by phone + verify calendar connected.
     * Returns ['tenant' => Tenant] on success, or ['error' => string, 'code' => int].
     *
     * @return array{tenant?: Tenant, error?: string, code?: int}
     */
    private function getCalendarTenant(string $phone): array
    {
        $tenantId = $this->resolveTenantId($phone);
        if (! $tenantId) {
            return ['error' => 'No tenant for this phone', 'code' => 404];
        }

        $t = Tenant::query()
            ->select(['id', 'name', 'calendar_id', 'calendar_connected', 'calendar_refresh_token', 'email'])
            ->where('id', $tenantId)
            ->first();
        if (! $t) {
            return ['error' => 'Tenant not found', 'code' => 404];
        }
        if (! $t->calendar_connected || ! $t->calendar_refresh_token) {
            return ['error' => 'Calendar not connected', 'code' => 412];
        }

        return ['tenant' => $t];
    }

    /** 3-step phone → tenant_id resolution (default DB → owner → mapped). */
    private function resolveTenantId(string $phone): ?string
    {
        $defaultDb = UserDatabase::query()->select('tenant_id')
            ->where('phone', $phone)->where('is_default', true)->first();
        if ($defaultDb?->tenant_id) {
            return $defaultDb->tenant_id;
        }
        $owner = Tenant::query()->select('id')->where('phone', $phone)->first();
        if ($owner?->id) {
            return $owner->id;
        }

        return TenantPhone::query()->select('tenant_id')->where('phone', $phone)->first()?->tenant_id;
    }
}
