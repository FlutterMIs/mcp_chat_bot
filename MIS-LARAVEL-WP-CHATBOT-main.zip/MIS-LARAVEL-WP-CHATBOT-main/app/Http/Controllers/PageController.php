<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use App\Services\Dashboard\PageEngine;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * GET /api/page/{kind}?phone=&from=&to=&q=&page=&as_of=&party=&tenant_id=
 *
 * Dispatcher for the 4 drill-down pages: sales | outstanding | stock | ledger.
 * Resolves the tenant from phone (same 3-step lookup as DashboardController),
 * then defers to PageEngine::build($tenantId, $kind, $opts).
 *
 * Per-page query params honoured:
 *   • sales       — q (party search), page (1-indexed pagination)
 *   • outstanding — as_of (ISO date)
 *   • stock       — (none — full snapshot)
 *   • ledger      — q / party (party search)
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js  (~/api/page/* routes)
 */
final class PageController extends Controller
{
    private const ALLOWED_KINDS = ['sales', 'outstanding', 'stock', 'ledger'];

    public function __invoke(Request $request, string $kind): JsonResponse
    {
        $kind = strtolower($kind);
        if (! in_array($kind, self::ALLOWED_KINDS, true)) {
            return response()->json(['error' => 'Unknown page: '.$kind], 404);
        }

        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        if (! $phone || strlen($phone) < 10) {
            return response()->json(['error' => 'phone required'], 400);
        }

        try {
            $tenantId = $request->query('tenant_id')
                ? (string) $request->query('tenant_id')
                : $this->resolveTenantId($phone);
            if (! $tenantId) {
                return response()->json(['error' => 'No tenant found for this phone'], 404);
            }

            // Forward only known opts — keeps PageEngine surface minimal
            $opts = array_filter([
                'from'   => $request->query('from'),
                'to'     => $request->query('to'),
                'q'      => $request->query('q'),
                'page'   => $request->query('page'),
                'as_of'  => $request->query('as_of'),
                'party'  => $request->query('party'),
            ], static fn ($v) => $v !== null && $v !== '');

            $t0 = microtime(true);
            // 10-minute cache per (tenant, kind, opts). Background cache-warming
            // scheduler refreshes every 5 min so users always hit warm cache.
            $cacheKey = 'page:'.$tenantId.':'.$kind.':'.md5(json_encode($opts));
            $payload = Cache::remember($cacheKey, 600, function () use ($tenantId, $kind, $opts) {
                return PageEngine::build($tenantId, $kind, $opts);
            });
            $payload['elapsed_ms'] = (int) ((microtime(true) - $t0) * 1000);
            $payload['cached'] = ($payload['elapsed_ms'] < 100);

            $status = isset($payload['error']) ? 500 : 200;

            return response()->json($payload, $status);
        } catch (Throwable $e) {
            Log::error('Page generation failed', [
                'phone' => $phone,
                'kind'  => $kind,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);

            return response()->json([
                'error' => 'Page generation failed: '.$e->getMessage(),
            ], 500);
        }
    }

    /** 3-step tenant resolution (matches DashboardController). */
    private function resolveTenantId(string $phone): ?string
    {
        $defaultDb = UserDatabase::query()
            ->select('tenant_id')
            ->where('phone', $phone)
            ->where('is_default', true)
            ->first();
        if ($defaultDb?->tenant_id) {
            return $defaultDb->tenant_id;
        }

        $owner = Tenant::query()
            ->select('id')
            ->where('phone', $phone)
            ->first();
        if ($owner?->id) {
            return $owner->id;
        }

        $mapping = TenantPhone::query()
            ->select('tenant_id')
            ->where('phone', $phone)
            ->first();

        return $mapping?->tenant_id;
    }
}
