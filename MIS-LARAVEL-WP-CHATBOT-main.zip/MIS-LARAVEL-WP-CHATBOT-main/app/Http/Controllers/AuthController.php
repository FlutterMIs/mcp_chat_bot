<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\IssueTokenRequest;
use App\Services\Auth\ChatTokenService;
use App\Services\Chat\TenantRouter;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * AuthController — phone-token issuance endpoint.
 *
 * Endpoints:
 *   POST /api/auth/issue-token  { phone }  →  { token, exp, ttl_sec }
 *
 * Issues a chat token only after confirming the phone resolves to a known tenant.
 * Light per-phone rate limit (5/min) prevents token-mill DoS and casual misuse.
 *
 * Frontend usage: login.html / register.html call this after phone-verify, store
 * the returned token in localStorage, and attach it as `X-Chat-Token` header on
 * every /api/chat request. Token has 24-hr TTL; on 401 from /api/chat, frontend
 * re-issues a fresh token.
 *
 * Note: Node also accepts phones in `access_control.json` (legacy MIS Work India
 * users). Laravel skips that integration intentionally — it's a Node-only legacy
 * concern that doesn't apply to the boss-handover demo flow.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~lines 4358-4395 — POST /api/auth/issue-token)
 */
final class AuthController extends Controller
{
    /** Rate limit: max 5 token issues per phone per 60 seconds. */
    private const RATE_LIMIT_MAX = 5;
    private const RATE_LIMIT_WINDOW = 60;

    public function issueToken(IssueTokenRequest $request): JsonResponse
    {
        $phone = $request->validated('phone');

        if ((string) config('mis.chat_token_secret', '') === '') {
            Log::error('[/api/auth/issue-token] CHAT_TOKEN_SECRET not configured');

            return response()->json(['error' => 'CHAT_TOKEN_SECRET not configured on server'], 500);
        }

        // Rate limit — 5/min per phone via cache counter
        $rlKey = "token_issue:{$phone}";
        $hits = (int) Cache::get($rlKey, 0);
        if ($hits >= self::RATE_LIMIT_MAX) {
            return response()->json(
                ['error' => 'Too many token requests, slow down.'],
                429,
                ['Retry-After' => (string) self::RATE_LIMIT_WINDOW]
            );
        }
        Cache::put($rlKey, $hits + 1, now()->addSeconds(self::RATE_LIMIT_WINDOW));

        // Verify phone resolves to a tenant (owner / mapped / default DB)
        $tenantId = TenantRouter::resolveTenantId($phone);
        if ($tenantId === null) {
            return response()->json(['error' => 'Phone not registered'], 404);
        }

        try {
            $token = ChatTokenService::issueToken($phone);
            $verify = ChatTokenService::verifyToken($token); // re-verify to extract exp

            return response()->json([
                'token'   => $token,
                'exp'     => $verify['exp'] ?? null,
                'ttl_sec' => ChatTokenService::TTL_SECONDS,
            ], 200, ['Cache-Control' => 'no-store']);
        } catch (Throwable $e) {
            Log::error('[/api/auth/issue-token] '.$e->getMessage());

            return response()->json(['error' => 'Could not issue token'], 500);
        }
    }
}
