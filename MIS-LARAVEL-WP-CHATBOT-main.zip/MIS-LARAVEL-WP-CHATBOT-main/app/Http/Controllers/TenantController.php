<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\CheckPhoneRequest;
use App\Http\Requests\SignupRequest;
use App\Http\Requests\UpdateProfileRequest;
use App\Models\Tenant;
use App\Models\TenantApiKey;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use App\Services\Sheets\SheetSchemaDetector;
use App\Services\Sheets\TenantTablesProvisioner;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Throwable;

/**
 * Tenant onboarding + profile endpoints.
 *
 *   POST /api/tenant/check-phone     body: { phone }
 *     Returns: { exists: bool, tenant?: { id, name, sheet_url, schema_json, created_at } }
 *
 *   GET  /api/tenant/profile?phone=
 *     Returns: { tenant_id, name, email, phone, calendar_connected, calendar_email,
 *                last_sync_at, databases: [{tenant_id, name, role}], active_db_id }
 *
 *   POST /api/tenant/detect-schema   body: { sheet_url }
 *     Returns: { sheet_id, tables: [{gid, name, row_count, columns:[{name,type,samples}]}], total_rows }
 *
 *   POST /api/tenant/update-profile  body: { phone, name?, email? }
 *     Returns: { ok: true, id, name, email }
 *
 *   POST /api/tenant/signup          body: { phone, name, email?, business_description?,
 *                                            sheet_url, mode?, schema?,
 *                                            add_to_existing?, tenant_id? }
 *     Returns: { success, tenant_id, name, phone, sync, sync_done, message }
 *     OR if returning user without choice: { requires_choice: true, existing: [...] }
 *
 * Phone resolution order (matches Node /api/tenant/profile + /api/dashboard):
 *   1. user_databases default (is_default=true)
 *   2. tenants.phone (owner)
 *   3. tenant_phones (mapped/secondary user)
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js
 *      (POST /api/tenant/check-phone ~line 3448, GET /api/tenant/profile ~line 3702,
 *       POST /api/tenant/detect-schema ~line 4668, POST /api/tenant/update-profile ~line 3779,
 *       POST /api/tenant/signup ~line 4692)
 */
final class TenantController extends Controller
{
    /**
     * POST /api/tenant/check-phone
     */
    public function checkPhone(CheckPhoneRequest $request): JsonResponse
    {
        $phone = $request->validated('phone');

        try {
            // --- Role detection ---
            $superAdminPhones = config('mis.super_admin_phones', []);
            $role = 'member';
            $permissions = ['dashboard', 'chat'];
            $tenant = null;
            $isOwner = false;

            // 1. Super Admin check
            if (in_array($phone, $superAdminPhones, true)) {
                $role = 'super_admin';
                $permissions = ['*'];
                // Super admin still needs a tenant context — pick the first one they own
                $tenant = Tenant::query()
                    ->select(['id', 'name', 'sheet_url', 'schema_json', 'created_at'])
                    ->where('phone', $phone)
                    ->first();
                if (! $tenant) {
                    // Or pick any tenant (admin can see all)
                    $tenant = Tenant::query()
                        ->select(['id', 'name', 'sheet_url', 'schema_json', 'created_at'])
                        ->first();
                }
            }

            // 2. Owner check
            if (! $tenant) {
                $tenant = Tenant::query()
                    ->select(['id', 'name', 'sheet_url', 'schema_json', 'created_at'])
                    ->where('phone', $phone)
                    ->first();
                if ($tenant) {
                    $isOwner = true;
                    if ($role !== 'super_admin') {
                        $role = 'owner';
                        $permissions = ['dashboard', 'chat', 'sales', 'outstanding', 'stock', 'ledger', 'calendar', 'reports', 'settings', 'members'];
                    }
                }
            }

            // 3. Mapped phone (tenant_phones)
            if (! $tenant) {
                $mapping = TenantPhone::query()->where('phone', $phone)->first();
                if ($mapping?->tenant_id) {
                    $tenant = Tenant::query()
                        ->select(['id', 'name', 'sheet_url', 'schema_json', 'created_at'])
                        ->where('id', $mapping->tenant_id)
                        ->first();
                    if ($tenant && $role !== 'super_admin') {
                        $role = 'owner';
                        $permissions = ['dashboard', 'chat', 'sales', 'outstanding', 'stock', 'ledger', 'calendar', 'reports', 'settings', 'members'];
                    }
                }
            }

            // 4. Member check (user_databases)
            if (! $tenant) {
                $userDb = UserDatabase::query()->where('phone', $phone)->first();
                if ($userDb?->tenant_id) {
                    $tenant = Tenant::query()
                        ->select(['id', 'name', 'sheet_url', 'schema_json', 'created_at'])
                        ->where('id', $userDb->tenant_id)
                        ->first();
                    if ($tenant && $role !== 'super_admin') {
                        $role = 'member';
                        $permissions = json_decode($userDb->permissions ?? '["dashboard","chat"]', true) ?: ['dashboard', 'chat'];
                    }
                }
            }

            if (! $tenant) {
                // Super admin can access even with no tenant
                if ($role === 'super_admin') {
                    return response()->json([
                        'exists'      => true,
                        'role'        => 'super_admin',
                        'permissions' => ['*'],
                        'tenant'      => null,
                    ]);
                }
                return response()->json(['exists' => false]);
            }

            return response()->json([
                'exists'      => true,
                'role'        => $role,
                'permissions' => $permissions,
                'tenant'      => [
                    'id'          => $tenant->id,
                    'name'        => $tenant->name,
                    'sheet_url'   => $tenant->sheet_url,
                    'schema_json' => $tenant->schema_json,
                    'created_at'  => $tenant->created_at?->toIso8601String(),
                ],
            ]);
        } catch (Throwable $e) {
            Log::warning('[check-phone] failed: '.$e->getMessage());

            return response()->json(['exists' => false]);
        }
    }

    /**
     * GET /api/tenant/profile?phone=...
     */
    public function profile(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        if ($phone === '') {
            return response()->json(['error' => 'phone required'], 400);
        }

        try {
            $activeId = self::resolveActiveTenantId($phone);
            if (! $activeId) {
                // Super admin without tenant — return minimal profile so frontend doesn't break
                $superAdmins = config('mis.super_admin_phones', []);
                if (in_array($phone, $superAdmins, true)) {
                    return response()->json([
                        'tenant_id'          => null,
                        'name'               => 'Super Admin',
                        'email'              => '',
                        'phone'              => $phone,
                        'sheet_url'          => '',
                        'calendar_connected' => false,
                        'calendar_email'     => '',
                        'last_sync_at'       => null,
                        'databases'          => [],
                        'active_db_id'       => null,
                    ]);
                }
                return response()->json(['error' => 'No tenant for this phone'], 404);
            }

            /** @var Tenant|null $t */
            $t = Tenant::query()
                ->select(['id', 'name', 'email', 'phone', 'sheet_url', 'calendar_connected', 'tables_metadata', 'updated_at', 'wa_key_mode', 'wa_channel_mode', 'wa_connected_number', 'webhook_token', 'ai_vendor', 'ai_model', 'ai_api_key'])
                ->where('id', $activeId)
                ->first();

            if (! $t) {
                return response()->json(['error' => 'Tenant not found'], 404);
            }

            // Derive last_sync_at from tables_metadata.tabs.*.synced_at; fall back to updated_at.
            // Node-parity: walk tabs, take the most recent synced_at (or aliases last_synced / last_sync_at).
            $lastSync = null;
            $meta = $t->tables_metadata;
            if (is_array($meta) && count($meta) > 0) {
                $tabs = $meta['tabs'] ?? $meta;
                if (is_array($tabs)) {
                    foreach ($tabs as $tab) {
                        if (! is_array($tab)) continue;
                        $ts = $tab['synced_at'] ?? $tab['last_synced'] ?? $tab['last_sync_at'] ?? null;
                        if (! is_string($ts) || $ts === '') continue;
                        if ($lastSync === null || strtotime($ts) > strtotime($lastSync)) {
                            $lastSync = $ts;
                        }
                    }
                }
            }
            if ($lastSync === null) {
                $lastSync = $t->updated_at?->toIso8601String();
            }

            // Build the user's database list:
            //   1. owned (tenants.phone == phone)
            //   2. linked via user_databases
            $dbs = [];

            $owned = Tenant::query()->select(['id', 'name'])->where('phone', $phone)->get();
            foreach ($owned as $o) {
                $dbs[$o->id] = [
                    'tenant_id' => $o->id,
                    'name'      => $o->name,
                    'role'      => 'owner',
                ];
            }

            $links = UserDatabase::query()
                ->select(['tenant_id', 'alias'])
                ->where('phone', $phone)
                ->get();
            foreach ($links as $l) {
                if (! $l->tenant_id) continue;
                $linked = Tenant::query()->select(['id', 'name'])->where('id', $l->tenant_id)->first();
                if (! $linked) continue;
                $existing = $dbs[$linked->id] ?? null;
                $dbs[$linked->id] = [
                    'tenant_id' => $linked->id,
                    'name'      => $l->alias ?: $linked->name,
                    'role'      => $existing['role'] ?? 'member',
                ];
            }

            $unproKeyRecord = TenantApiKey::where('tenant_id', $t->id)->where('type', 2)->first();
            $proKeyRecord = TenantApiKey::where('tenant_id', $t->id)->where('type', 1)->first();
            $unproKey = $unproKeyRecord ? $unproKeyRecord->api_key : null;
            $proKey = $proKeyRecord ? $proKeyRecord->api_key : null;
            $deviceId = $proKeyRecord ? $proKeyRecord->device_id : null;

            if ($t->wa_key_mode === 'shared' || !$unproKey) {
                $unproKey = config('mis.wa_unpro_api_key');
            }
            if ($t->wa_key_mode === 'shared' || !$proKey) {
                $proKey = config('mis.wa_pro_api_key');
            }
            if ($t->wa_key_mode === 'shared' || !$deviceId) {
                $deviceId = config('mis.wa_pro_phone_id');
            }

            return response()->json([
                'tenant_id'          => $t->id,
                'name'               => $t->name ?? '',
                'email'              => $t->email ?? '',
                'phone'              => $t->phone ?? $phone,
                'sheet_url'          => $t->sheet_url ?? '',
                'calendar_connected' => (bool) $t->calendar_connected,
                'calendar_email'     => '', // not stored in current schema (Node parity)
                'last_sync_at'       => $lastSync,
                'databases'          => array_values($dbs),
                'active_db_id'       => $activeId,
                'wa_key_mode'        => $t->wa_key_mode ?? 'shared',
                'wa_api_key'         => $unproKey ? ('…' . substr($unproKey, -6)) : null,
                'wa_pro_api_key'     => $proKey ? ('…' . substr($proKey, -6)) : null,
                'wa_connected_number' => $t->wa_connected_number,
                'wa_channel_mode'    => $t->wa_channel_mode ?? 'unprofessional',
                'wa_device_id'       => $deviceId,
                'webhook_token'      => $t->webhook_token,
                'ai_vendor'          => $t->ai_vendor,
                'ai_model'           => $t->ai_model,
                'ai_api_key'         => $t->ai_api_key ? ('…' . substr($t->ai_api_key, -6)) : null,
            ]);
        } catch (Throwable $e) {
            Log::error('[/api/tenant/profile] '.$e->getMessage(), [
                'trace' => substr($e->getTraceAsString(), 0, 500),
            ]);

            return response()->json(['error' => 'Could not load profile'], 500);
        }
    }

    /**
     * GET /api/tenant/ai-status?phone=
     *
     * Read-only view for the Settings page: which AI model is CURRENTLY active for
     * this tenant's chatbot (resolved — own key vs shared vs none), the effective
     * base system prompt the bot runs, and the tenant's additional custom prompts.
     *
     * Returns: {
     *   model: { ok, vendor, model, source }, // source: own_key | shared | none
     *   system_prompt: string,                // effective base SQL-generation prompt
     *   additional_prompts: { response_style, data_format, bot_personality, company_context }
     * }
     */
    public function aiStatus(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        if ($phone === '') {
            return response()->json(['error' => 'phone required'], 400);
        }

        try {
            $tenantId = self::resolveActiveTenantId($phone);

            // Super admin without a tenant still runs on the shared/env model.
            if (! $tenantId) {
                $superAdmins = config('mis.super_admin_phones', []);
                if (! in_array($phone, $superAdmins, true)) {
                    return response()->json(['error' => 'No tenant for this phone'], 404);
                }
                return response()->json([
                    'model'              => \App\Services\AI\AiGateway::describe(null),
                    'system_prompt'      => '(No tenant/schema linked to this phone — the shared model answers with no tenant-specific schema prompt.)',
                    'additional_prompts' => [],
                ]);
            }

            $tenant = Tenant::query()
                ->select(['id', 'name', 'business_description', 'system_prompt', 'schema_json', 'tables_metadata', 'proper_tables_created'])
                ->where('id', $tenantId)
                ->first();
            if (! $tenant) {
                return response()->json(['error' => 'Tenant not found'], 404);
            }

            // Build the EFFECTIVE base system prompt the bot actually uses. Proper-tables
            // tenants use the schema-aware SQL prompt; legacy tenants use the JSONB prompt.
            $tablesMeta = is_array($tenant->tables_metadata) ? ($tenant->tables_metadata['tabs'] ?? $tenant->tables_metadata) : [];
            if ($tenant->proper_tables_created && ! empty($tablesMeta)) {
                $messages = \App\Services\Chat\PromptBuilder::buildSqlMessages($tenant, '{user question}', $tablesMeta, 'data');
                $systemPrompt = $messages[0]['content'] ?? '';
            } else {
                $systemPrompt = \App\Services\Chat\PromptBuilder::generateSystemPrompt($tenant);
            }

            return response()->json([
                'model'              => \App\Services\AI\AiGateway::describe($tenantId),
                'system_prompt'      => $systemPrompt,
                'additional_prompts' => \App\Models\TenantPrompt::allFor($tenantId),
            ]);
        } catch (Throwable $e) {
            Log::error('[/api/tenant/ai-status] '.$e->getMessage(), [
                'trace' => substr($e->getTraceAsString(), 0, 500),
            ]);

            return response()->json(['error' => 'Could not load AI status'], 500);
        }
    }

    /**
     * GET /api/tenant/prompts?phone=
     *
     * Owner-facing view of the tenant's additional/custom chatbot prompts (the 4
     * TenantPrompt keys). These are appended to the hard-coded base prompts at
     * runtime to tune formatting, tone, and business context per tenant.
     */
    public function getPrompts(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        if ($phone === '') {
            return response()->json(['error' => 'phone required'], 400);
        }

        $tenantId = self::resolveActiveTenantId($phone);
        if (! $tenantId) {
            return response()->json(['error' => 'No tenant for this phone'], 404);
        }

        return response()->json([
            'prompts' => \App\Models\TenantPrompt::allFor($tenantId),
            'keys'    => \App\Models\TenantPrompt::KEYS,
        ]);
    }

    /**
     * POST /api/tenant/prompts
     * Body: { phone, response_style?, data_format?, bot_personality?, company_context? }
     *
     * Owner/super-admin only — these prompts steer the tenant's chatbot behaviour,
     * so a team member or client must not be able to rewrite them. Empty value for a
     * key clears it (bot reverts to the base prompt for that aspect).
     */
    public function savePrompts(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        if ($phone === '') {
            return response()->json(['error' => 'phone required'], 400);
        }

        $tenantId = self::resolveActiveTenantId($phone);
        if (! $tenantId) {
            return response()->json(['error' => 'No tenant for this phone'], 404);
        }

        if (! self::isTenantAdmin($phone, $tenantId)) {
            return response()->json(['error' => 'Only the account owner can edit chatbot prompts.'], 403);
        }

        $saved = 0;
        foreach (\App\Models\TenantPrompt::KEYS as $key) {
            if (! $request->has($key)) {
                continue;
            }
            $val = trim((string) $request->input($key, ''));
            if ($val === '') {
                \App\Models\TenantPrompt::where('tenant_id', $tenantId)->where('prompt_key', $key)->delete();
                Cache::forget("tenant_prompt:{$tenantId}:{$key}");
            } else {
                // Bound length — a prompt overlay shouldn't balloon the token budget.
                \App\Models\TenantPrompt::set($tenantId, $key, mb_substr($val, 0, 2000));
            }
            $saved++;
        }

        return response()->json(['ok' => true, 'saved' => $saved]);
    }

    /**
     * Is this phone allowed to manage this tenant's config (prompts, access)?
     * True only for the tenant owner (tenants.phone) or a configured super-admin.
     */
    private static function isTenantAdmin(string $phone, string $tenantId): bool
    {
        if (in_array($phone, (array) config('mis.super_admin_phones', []), true)) {
            return true;
        }

        return Tenant::query()->where('id', $tenantId)->where('phone', $phone)->exists();
    }

    /**
     * POST /api/tenant/detect-schema
     * Body: { sheet_url }
     */
    public function detectSchema(Request $request): JsonResponse
    {
        $sheetUrl = trim((string) $request->input('sheet_url', ''));
        if ($sheetUrl === '') {
            return response()->json(['error' => 'sheet_url required'], 400);
        }
        // Cheap sanity check — detector also validates, but giving early friendly 400 is better UX
        if (! preg_match('#^https://docs\.google\.com/spreadsheets/#', $sheetUrl)) {
            return response()->json(['error' => 'sheet_url must be a Google Sheets link'], 400);
        }
        if (strlen($sheetUrl) > 500) {
            return response()->json(['error' => 'sheet_url too long'], 400);
        }

        try {
            $schema = SheetSchemaDetector::detect($sheetUrl);

            return response()->json($schema);
        } catch (Throwable $e) {
            Log::warning('[detect-schema] '.$e->getMessage());

            return response()->json(['error' => $e->getMessage()], 400);
        }
    }

    /**
     * POST /api/tenant/update-profile
     * Body: { phone, name?, email? }
     */
    public function updateProfile(UpdateProfileRequest $request): JsonResponse
    {
        $phone = $request->validated('phone');

        $tenantId = self::resolveActiveTenantId($phone);
        if (! $tenantId) {
            // Super admin: auto-create tenant on first profile save
            $superAdmins = config('mis.super_admin_phones', []);
            if (in_array($phone, $superAdmins, true)) {
                $nm = trim((string) $request->input('name', '')) ?: 'MIS-1';
                $em = strtolower(trim((string) $request->input('email', '')));
                $t = Tenant::query()->create(['name' => $nm, 'phone' => $phone, 'email' => $em ?: null]);
                TenantPhone::query()->create(['tenant_id' => $t->id, 'phone' => $phone, 'role' => 'owner']);
                UserDatabase::query()->create([
                    'id' => Str::uuid()->toString(),
                    'phone' => $phone, 'tenant_id' => $t->id, 'alias' => $nm, 'is_default' => true,
                ]);
                return response()->json(['ok' => true, 'id' => $t->id, 'name' => $t->name, 'email' => $t->email ?? '']);
            }
            return response()->json(['error' => 'No tenant for this phone'], 404);
        }

        $update = [];

        if ($request->has('name')) {
            $name = trim((string) $request->input('name'));
            if ($name === '' || mb_strlen($name) < 2) {
                return response()->json(['error' => 'Name too short (min 2 chars)'], 400);
            }
            $name = mb_substr(strip_tags($name), 0, 100);
            $update['name'] = $name;
        }

        if ($request->has('email')) {
            $email = strtolower(trim((string) $request->input('email')));
            $email = mb_substr($email, 0, 254);
            if ($email !== '' && ! filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return response()->json(['error' => 'Invalid email'], 400);
            }
            $update['email'] = $email;
        }

        // WA key settings (owner only)
        if ($request->has('wa_key_mode')) {
            $mode = (string) $request->input('wa_key_mode');
            if (! in_array($mode, ['shared', 'own'], true)) {
                return response()->json(['error' => 'wa_key_mode must be shared or own'], 400);
            }
            $update['wa_key_mode'] = $mode;
            if ($mode === 'shared') {
                TenantApiKey::where('tenant_id', $tenantId)->whereIn('type', [1, 2])->update(['status' => 'paused']);
                $update['wa_connected_number'] = null;
            }
        }
        if ($request->has('wa_api_key')) {
            $key = trim((string) $request->input('wa_api_key'));
            if ($key !== '' && !str_starts_with($key, '…')) {
                TenantApiKey::updateOrCreate(
                    ['tenant_id' => $tenantId, 'type' => 2],
                    ['api_key' => $key, 'base_url' => '', 'status' => 'active', 'label' => 'Unprofessional WA Key', 'access_level' => 'everyone']
                );
                $update['wa_key_mode'] = 'own';
            }
        }
        if ($request->has('wa_pro_api_key') || $request->has('wa_device_id')) {
            $proKeyRecord = TenantApiKey::firstOrNew(['tenant_id' => $tenantId, 'type' => 1]);
            $proKeyRecord->base_url = '';
            $proKeyRecord->status = 'active';
            $proKeyRecord->label = 'Professional WA Key';
            $proKeyRecord->access_level = 'everyone';
            if (! $proKeyRecord->exists) {
                $proKeyRecord->api_key = '';
            }

            $changed = false;
            if ($request->has('wa_pro_api_key')) {
                $proKey = trim((string) $request->input('wa_pro_api_key'));
                if ($proKey !== '' && !str_starts_with($proKey, '…')) {
                    $proKeyRecord->api_key = $proKey;
                    $update['wa_key_mode'] = 'own';
                    $changed = true;
                }
            }

            if ($request->has('wa_device_id')) {
                $deviceId = trim((string) $request->input('wa_device_id'));
                if ($deviceId !== '') {
                    $proKeyRecord->device_id = mb_substr($deviceId, 0, 100);
                    $changed = true;
                }
            }

            if ($changed) {
                $proKeyRecord->save();
            }
        }

        if ($request->has('wa_connected_number')) {
            $num = preg_replace('/[^0-9]/', '', (string) $request->input('wa_connected_number'));
            $update['wa_connected_number'] = $num !== '' ? $num : null;
        }

        // WA channel mode (professional / unprofessional)
        if ($request->has('wa_channel_mode')) {
            $channelMode = (string) $request->input('wa_channel_mode');
            if (!in_array($channelMode, ['unprofessional', 'professional'], true)) {
                return response()->json(['error' => 'wa_channel_mode must be unprofessional or professional'], 400);
            }
            $update['wa_channel_mode'] = $channelMode;

            // Toggle active/paused status on the tenant api keys
            if ($channelMode === 'professional') {
                TenantApiKey::where('tenant_id', $tenantId)->where('type', 1)->update(['status' => 'active']);
                TenantApiKey::where('tenant_id', $tenantId)->where('type', 2)->update(['status' => 'paused']);
            } else {
                TenantApiKey::where('tenant_id', $tenantId)->where('type', 2)->update(['status' => 'active']);
                TenantApiKey::where('tenant_id', $tenantId)->where('type', 1)->update(['status' => 'paused']);
            }
        }


        // AI config
        if ($request->has('ai_vendor')) {
            $vendor = (string) $request->input('ai_vendor');
            if (!in_array($vendor, ['openai', 'gemini', ''], true)) {
                return response()->json(['error' => 'ai_vendor must be openai or gemini'], 400);
            }
            $update['ai_vendor'] = $vendor !== '' ? $vendor : null;
        }
        if ($request->has('ai_model')) {
            $model = trim((string) $request->input('ai_model'));
            $update['ai_model'] = $model !== '' ? mb_substr($model, 0, 50) : null;
        }
        if ($request->has('ai_api_key')) {
            $aiKey = trim((string) $request->input('ai_api_key'));
            if ($aiKey !== '' && !str_starts_with($aiKey, '…')) {
                $update['ai_api_key'] = \Illuminate\Support\Facades\Crypt::encryptString($aiKey);
            } elseif ($aiKey === '') {
                $update['ai_api_key'] = null;
                $update['ai_vendor'] = null;
                $update['ai_model'] = null;
            }
        }

        if (count($update) === 0) {
            return response()->json(['error' => 'Nothing to update'], 400);
        }

        try {
            /** @var Tenant|null $t */
            $t = Tenant::query()->where('id', $tenantId)->first();
            if (! $t) {
                return response()->json(['error' => 'Tenant not found'], 404);
            }
            foreach ($update as $col => $val) {
                $t->{$col} = $val;
            }
            $t->save();

            // Clear bot-numbers cache when WA connected number changes
            if (isset($update['wa_connected_number']) || isset($update['wa_key_mode'])) {
                Cache::forget('bot_connected_numbers');
            }

            return response()->json([
                'ok'    => true,
                'id'    => $t->id,
                'name'  => $t->name,
                'email' => $t->email ?? '',
            ]);
        } catch (Throwable $e) {
            Log::error('[update-profile] '.$e->getMessage());

            return response()->json(['error' => 'Could not update profile'], 500);
        }
    }

    /**
     * POST /api/tenant/signup
     * Body: { phone, name, email?, business_description?, sheet_url, mode?, schema?, add_to_existing?, tenant_id? }
     *
     * Self-service onboarding — creates tenant row, dispatches proper-tables sync,
     * returns tenant_id + sync status. Defenses:
     *   - Strict input validation: phone 10-15 digits, name >= 2 chars, sheet URL must be Google Sheets
     *   - HTML/script tags stripped
     *   - Returning-user choice support: if phone already owns tenant(s), 200 with `requires_choice`
     *   - mode='new_separate' or `add_to_existing` + `tenant_id` resolves the choice
     *   - Sync runs synchronously here for simplicity; future improvement = queue dispatch
     *
     * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~line 4692)
     */
    public function signup(SignupRequest $request): JsonResponse
    {
        // ── 1. Light rate-limiting via cache (matches Node 3/hr per IP, 2/hr per phone) ──
        $ip = $request->ip();
        $ipKey = "signup_ip:{$ip}";
        $ipHits = (int) Cache::get($ipKey, 0);
        if ($ipHits >= 3) {
            return response()->json(['error' => 'Too many signup attempts. Try again in an hour.'], 429);
        }

        // ── 2. Input validation ──
        $phoneRaw = (string) $request->input('phone', '');
        $cleanPhone = substr(preg_replace('/[^0-9]/', '', $phoneRaw), 0, 15);
        if (strlen($cleanPhone) < 10 || strlen($cleanPhone) > 15) {
            return response()->json(['error' => 'Valid phone number required (10-15 digits with country code)'], 400);
        }

        $phoneKey = "signup_phone:{$cleanPhone}";
        $phoneHits = (int) Cache::get($phoneKey, 0);
        if ($phoneHits >= 2) {
            return response()->json(['error' => 'Too many attempts for this number. Try in an hour.'], 429);
        }

        $sanitize = static fn (string $s) => trim((string) preg_replace('/[<>]/', '', $s));

        $cleanName = mb_substr($sanitize((string) $request->input('name', '')), 0, 100);
        if (mb_strlen($cleanName) < 2) {
            return response()->json(['error' => 'Business name required (min 2 chars)'], 400);
        }

        $cleanEmail = strtolower(mb_substr($sanitize((string) $request->input('email', '')), 0, 254));
        if ($cleanEmail !== '' && ! filter_var($cleanEmail, FILTER_VALIDATE_EMAIL)) {
            return response()->json(['error' => 'Invalid email format'], 400);
        }

        $sheetUrl = (string) $request->input('sheet_url', '');
        if ($sheetUrl !== '') {
            if (! preg_match('#^https://docs\.google\.com/spreadsheets/#', $sheetUrl)) {
                return response()->json(['error' => 'Sheet URL must be a Google Sheets link'], 400);
            }
            if (strlen($sheetUrl) > 500) {
                return response()->json(['error' => 'Sheet URL too long'], 400);
            }
        }

        $cleanDesc = mb_substr($sanitize((string) $request->input('business_description', '')), 0, 500);
        $schema = $request->input('schema'); // optional pre-detected schema
        if ($schema !== null && ! is_array($schema)) {
            return response()->json(['error' => 'Invalid schema'], 400);
        }
        if ($schema !== null && strlen(json_encode($schema)) > 500_000) {
            return response()->json(['error' => 'Schema too large'], 400);
        }

        // ── 3. Returning-user detection ──
        $existingT = Tenant::query()->select(['id', 'name'])->where('phone', $cleanPhone)->first();
        $existingP = TenantPhone::query()->select('tenant_id')->where('phone', $cleanPhone)->first();
        $userDbs = UserDatabase::query()->select(['tenant_id', 'alias', 'is_default'])->where('phone', $cleanPhone)->get();

        $ownedIds = [];
        if ($existingT) $ownedIds[$existingT->id] = true;
        if ($existingP?->tenant_id) $ownedIds[$existingP->tenant_id] = true;
        foreach ($userDbs as $d) {
            if ($d->tenant_id) $ownedIds[$d->tenant_id] = true;
        }

        $requestedMode = $request->input('mode');
        $addToExisting = (bool) $request->input('add_to_existing', false);
        $requestedTenantId = $request->input('tenant_id');

        // ── 4. ADD-TO-EXISTING path ──
        if ($addToExisting) {
            if (! is_string($requestedTenantId) || $requestedTenantId === '') {
                return response()->json(['error' => 'tenant_id required for add_to_existing'], 400);
            }
            if (! isset($ownedIds[$requestedTenantId])) {
                return response()->json(['error' => 'Phone does not own this tenant'], 403);
            }

            $existing = Tenant::query()->where('id', $requestedTenantId)->first();
            if (! $existing) {
                return response()->json(['error' => 'Tenant not found'], 404);
            }

            $oldSchema = is_array($existing->schema_json) ? $existing->schema_json : ['tables' => []];
            $newTables = $schema['tables'] ?? [];
            $merged = $oldSchema['tables'] ?? [];
            foreach ($newTables as $nt) {
                $found = false;
                foreach ($merged as $i => $mt) {
                    if (($mt['name'] ?? null) === ($nt['name'] ?? null)) {
                        $merged[$i] = $nt;
                        $found = true;
                        break;
                    }
                }
                if (! $found) $merged[] = $nt;
            }
            $totalRows = 0;
            foreach ($merged as $t) {
                $totalRows += (int) ($t['row_count'] ?? 0);
            }

            $existing->schema_json = ['tables' => $merged, 'total_rows' => $totalRows];
            if ($sheetUrl !== '') {
                $existing->sheet_url = $sheetUrl;
                $existing->sheet_id = SheetSchemaDetector::extractSheetId($sheetUrl);
            }
            if ($cleanDesc !== '') {
                $existing->business_description = $cleanDesc;
            }
            $existing->save();

            $udExists = UserDatabase::query()->where('phone', $cleanPhone)->where('tenant_id', $requestedTenantId)->exists();
            if ($udExists) {
                UserDatabase::query()->where('phone', $cleanPhone)->where('tenant_id', $requestedTenantId)
                    ->update(['alias' => $existing->name, 'is_default' => false]);
            } else {
                UserDatabase::query()->create([
                    'id' => Str::uuid()->toString(),
                    'phone' => $cleanPhone,
                    'tenant_id' => $requestedTenantId,
                    'alias' => $existing->name,
                    'is_default' => true,
                ]);
            }

            $syncResult = null;
            if ($sheetUrl !== '') {
                try {
                    $syncResult = TenantTablesProvisioner::syncSheetToProperTables($requestedTenantId, $sheetUrl);
                } catch (Throwable $e) {
                    Log::error('[SIGNUP ADD SYNC] '.$e->getMessage());
                }
            }

            self::bumpRateLimits($ipKey, $phoneKey, $ipHits, $phoneHits);
            Log::info("[SIGNUP] add-to-existing: {$existing->name} (+{$cleanPhone}) from ip {$ip}");

            return response()->json([
                'success'   => true,
                'tenant_id' => $requestedTenantId,
                'name'      => $existing->name,
                'mode'      => 'added_to_existing',
                'sync'      => $syncResult,
                'message'   => 'New sheet added! Sync ran in the background.',
            ]);
        }

        // ── 5. Choice prompt for returning users ──
        if (count($ownedIds) > 0 && $requestedMode !== 'new_separate') {
            $list = Tenant::query()->select(['id', 'name'])->whereIn('id', array_keys($ownedIds))->get();
            $existing = [];
            foreach ($list as $t) {
                $existing[] = ['id' => $t->id, 'name' => $t->name];
            }

            return response()->json([
                'requires_choice' => true,
                'message'         => 'You already own '.count($existing).' database(s). Would you like to create a new separate one or add to an existing one?',
                'existing'        => $existing,
            ]);
        }

        // ── 6. NEW TENANT ──
        $sheetId = $sheetUrl !== '' ? SheetSchemaDetector::extractSheetId($sheetUrl) : null;
        $tenantData = [
            'name'                 => $cleanName,
            'phone'                => $cleanPhone,
            'email'                => $cleanEmail !== '' ? $cleanEmail : null,
            'sheet_url'            => $sheetUrl !== '' ? $sheetUrl : null,
            'sheet_id'             => $sheetId,
            'business_description' => $cleanDesc,
            'schema_json'          => $schema,
        ];

        try {
            $tenant = Tenant::query()->create($tenantData);
        } catch (Throwable $e) {
            Log::error('[SIGNUP DB] '.$e->getMessage());
            if (preg_match('/duplicate key|tenants_phone_key|unique constraint/i', $e->getMessage())) {
                return response()->json([
                    'error'              => 'To create a separate new DB, the admin must apply migration 007 (drop UNIQUE on tenants.phone). Until then, please use "Add to existing".',
                    'migration_required' => true,
                ], 409);
            }

            return response()->json(['error' => 'Registration failed. Please try again.'], 500);
        }

        // Link phone + default DB
        try {
            TenantPhone::query()->create(['tenant_id' => $tenant->id, 'phone' => $tenant->phone, 'role' => 'owner']);
        } catch (Throwable $e) {
            Log::warning('[SIGNUP] tenant_phones insert failed: '.$e->getMessage());
        }
        try {
            UserDatabase::query()->create([
                'id'         => Str::uuid()->toString(),
                'phone'      => $tenant->phone,
                'tenant_id'  => $tenant->id,
                'alias'      => $tenant->name,
                'is_default' => true,
            ]);
        } catch (Throwable $e) {
            Log::warning('[SIGNUP] user_databases insert failed: '.$e->getMessage());
        }

        // Synchronous proper-tables sync (queue dispatch is the future improvement)
        $syncResult = null;
        if ($sheetUrl !== '') {
            try {
                $syncResult = TenantTablesProvisioner::syncSheetToProperTables($tenant->id, $sheetUrl);
                Log::info("[SIGNUP SYNC] {$tenant->name} (+{$tenant->phone}): ".($syncResult['synced_rows'] ?? 0).' rows across '.count($syncResult['tabs'] ?? []).' tables');
            } catch (Throwable $e) {
                Log::error("[SIGNUP SYNC] {$tenant->name}: ".$e->getMessage());
                // Don't fail the whole signup — tenant row is created, user can re-sync later
            }
        }

        self::bumpRateLimits($ipKey, $phoneKey, $ipHits, $phoneHits);
        Log::info("[SIGNUP] new tenant: {$tenant->name} (+{$tenant->phone}) from ip {$ip}");

        return response()->json([
            'success'    => true,
            'tenant_id'  => $tenant->id,
            'name'       => $tenant->name,
            'phone'      => $tenant->phone,
            'sync'       => $syncResult,
            'sync_done'  => $syncResult !== null,
            'message'    => $sheetUrl !== ''
                ? ($syncResult !== null
                    ? 'Registration complete! '.($syncResult['synced_rows'] ?? 0).' rows synced. Head to chat.'
                    : 'Registration complete but sync failed. Head to chat — you can re-sync later from settings.')
                : 'Registration complete! Head over to the chat tab to start.',
        ]);
    }

    /** Increment rate-limit counters in cache (1 hour TTL — matches Node behaviour). */
    private static function bumpRateLimits(string $ipKey, string $phoneKey, int $ipHits, int $phoneHits): void
    {
        try {
            Cache::put($ipKey, $ipHits + 1, now()->addHour());
            Cache::put($phoneKey, $phoneHits + 1, now()->addHour());
        } catch (Throwable $e) {
            // best-effort
        }
    }

    /**
     * POST /api/tenant/sync-now  body: { phone }
     * User-facing sync trigger (no admin auth). Resolves tenant from phone, runs sync.
     */
    public function syncNow(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) ($request->input('phone') ?? ''));
        if (! $phone || strlen($phone) < 10) {
            return response()->json(['error' => 'phone required'], 400);
        }

        $tenantId = self::resolveActiveTenantId($phone);
        if (! $tenantId) {
            return response()->json(['error' => 'No tenant for this phone'], 404);
        }

        try {
            $result = \App\Services\Sheets\TenantSyncService::syncOne($tenantId, true);
            if (! $result['ok']) {
                return response()->json(['error' => $result['error'] ?? 'Sync failed'], 400);
            }
            // Clear page caches and immediately re-warm so user hits fresh data
            Cache::forget("dashboard:{$tenantId}:month");
            foreach (['sales', 'outstanding', 'stock', 'ledger'] as $kind) {
                Cache::forget("page:{$tenantId}:{$kind}:" . md5(json_encode([])));
            }
            // Re-warm dashboard cache with fresh data
            try {
                $dash = \App\Services\Dashboard\DashboardEngine::build($tenantId, ['range' => 'month']);
                Cache::put("dashboard:{$tenantId}:month", $dash, 600);
            } catch (Throwable $warmErr) {
                Log::warning("[SYNC-NOW] cache warm failed: " . $warmErr->getMessage());
            }
            return response()->json([
                'ok' => true,
                'message' => "Synced {$result['rows']} rows across {$result['tabs']} tab(s)",
                'rows' => $result['rows'],
                'tabs' => $result['tabs'],
            ]);
        } catch (Throwable $e) {
            Log::error('[SYNC-NOW] ' . $e->getMessage());
            return response()->json(['error' => 'Sync failed: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Same 3-step phone resolution used by every tenant-aware endpoint.
     * Centralised here so the duplication across 5 controllers (DashboardController,
     * PageController, NotificationController, SearchController, BriefingController)
     * can be folded into this method via Trait extraction in a future refactor.
     */
    private static function resolveActiveTenantId(string $phone): ?string
    {
        $defaultDb = UserDatabase::query()->select('tenant_id')
            ->where('phone', $phone)->where('is_default', true)->first();
        if ($defaultDb?->tenant_id) {
            return $defaultDb->tenant_id;
        }
        $owner = Tenant::query()->select('id')->where('phone', $phone)->first();
        if ($owner?->id) {
            return $owner->id;
        }
        $mapping = TenantPhone::query()->select('tenant_id')->where('phone', $phone)->first();

        return $mapping?->tenant_id;
    }
}
