<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\AddSheetRequest;
use App\Models\Tenant;
use App\Models\TenantPhone;
use App\Models\TenantSheet;
use App\Models\UserDatabase;
use App\Services\Sheets\SheetSchemaDetector;
use App\Services\Sheets\TenantTablesProvisioner;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

final class TenantSheetController extends Controller
{
    private const MAX_SHEETS_PER_TENANT = 50;

    /**
     * GET /api/tenant/sheets?phone=
     */
    public function index(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        if (strlen($phone) < 10) {
            return response()->json(['error' => 'phone required'], 400);
        }

        $tenantId = self::resolveActiveTenantId($phone);
        if (!$tenantId) {
            // Super admin without tenant — return empty list (they'll add a sheet which auto-creates tenant)
            $superAdmins = config('mis.super_admin_phones', []);
            if (in_array($phone, $superAdmins, true)) {
                return response()->json(['sheets' => [], 'tenant_id' => null]);
            }
            return response()->json(['error' => 'No tenant for this phone'], 404);
        }

        $sheets = TenantSheet::query()
            ->where('tenant_id', $tenantId)
            ->whereIn('status', ['active', 'paused'])
            ->orderBy('created_at', 'asc')
            ->get(['id', 'sheet_url', 'sheet_id', 'label', 'status', 'last_synced_at', 'created_at']);

        return response()->json(['sheets' => $sheets, 'tenant_id' => $tenantId]);
    }

    /**
     * POST /api/tenant/sheets/add
     * Body: { phone, sheet_url, label? }
     */
    public function add(AddSheetRequest $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        if (strlen($phone) < 10) {
            return response()->json(['error' => 'phone required'], 400);
        }

        $tenantId = self::resolveActiveTenantId($phone);

        // Auto-create tenant for super admin / owner who doesn't have one yet
        if (!$tenantId) {
            $superAdmins = config('mis.super_admin_phones', []);
            if (!in_array($phone, $superAdmins, true)) {
                return response()->json(['error' => 'No tenant for this phone'], 404);
            }
            // Auto-create tenant for super admin
            $name = trim((string) $request->input('name', '')) ?: 'MIS-1';
            $email = trim((string) $request->input('email', ''));
            $tenant = \App\Models\Tenant::query()->create([
                'name' => $name,
                'phone' => $phone,
                'email' => $email ?: null,
            ]);
            \App\Models\TenantPhone::query()->create(['tenant_id' => $tenant->id, 'phone' => $phone, 'role' => 'owner']);
            \App\Models\UserDatabase::query()->create([
                'id' => \Illuminate\Support\Str::uuid()->toString(),
                'phone' => $phone,
                'tenant_id' => $tenant->id,
                'alias' => $tenant->name,
                'is_default' => true,
            ]);
            $tenantId = $tenant->id;
        }

        $sheetUrl = trim((string) $request->input('sheet_url', ''));
        if (!preg_match('#^https://docs\.google\.com/spreadsheets/#', $sheetUrl)) {
            return response()->json(['error' => 'Valid Google Sheets URL required'], 400);
        }

        $label = mb_substr(trim((string) $request->input('label', '')), 0, 100);

        // Check limit
        $count = TenantSheet::query()
            ->where('tenant_id', $tenantId)
            ->whereIn('status', ['active', 'paused'])
            ->count();
        if ($count >= self::MAX_SHEETS_PER_TENANT) {
            return response()->json(['error' => "Maximum " . self::MAX_SHEETS_PER_TENANT . " sheets allowed"], 400);
        }

        // Check duplicate
        $sheetId = SheetSchemaDetector::extractSheetId($sheetUrl);
        $exists = TenantSheet::query()
            ->where('tenant_id', $tenantId)
            ->where('sheet_id', $sheetId)
            ->whereIn('status', ['active', 'paused'])
            ->exists();
        if ($exists) {
            return response()->json(['error' => 'This sheet is already connected'], 409);
        }

        // Create
        $sheet = TenantSheet::query()->create([
            'tenant_id' => $tenantId,
            'sheet_url' => $sheetUrl,
            'sheet_id' => $sheetId,
            'label' => $label ?: 'Sheet ' . ($count + 1),
            'status' => 'active',
        ]);

        // Sync immediately
        $syncResult = null;
        try {
            $syncResult = TenantTablesProvisioner::syncSheetToProperTables($tenantId, $sheetUrl);
            $sheet->update(['last_synced_at' => now()]);

            // Update tenant tables_metadata (merge with existing)
            $tenant = Tenant::query()->find($tenantId);
            if ($tenant) {
                $existingMeta = $tenant->tables_metadata ?? [];
                $newMeta = $syncResult['tables_metadata'] ?? [];
                // tables_metadata is a flat array of tab objects [{source_name, pg_table, ...}]
                $existingTabs = is_array($existingMeta) ? (isset($existingMeta['tabs']) ? $existingMeta['tabs'] : $existingMeta) : [];
                $newTabs = is_array($newMeta) ? (isset($newMeta['tabs']) ? $newMeta['tabs'] : $newMeta) : [];
                foreach ($newTabs as $tab) {
                    $found = false;
                    foreach ($existingTabs as $i => $et) {
                        if (($et['pg_table'] ?? '') === ($tab['pg_table'] ?? '')) {
                            $existingTabs[$i] = $tab;
                            $found = true;
                            break;
                        }
                    }
                    if (!$found) $existingTabs[] = $tab;
                }
                $tenant->update(['tables_metadata' => $existingTabs, 'proper_tables_created' => true]);
            }
        } catch (Throwable $e) {
            Log::error('[SHEET-ADD] sync failed: ' . $e->getMessage());
        }

        return response()->json([
            'ok' => true,
            'sheet' => $sheet,
            'sync' => $syncResult ? ['rows' => $syncResult['synced_rows'] ?? 0, 'tabs' => count($syncResult['tabs'] ?? [])] : null,
        ]);
    }

    /**
     * DELETE /api/tenant/sheets/{id}?phone=
     */
    public function remove(Request $request, string $id): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', $request->input('phone', '')));
        if (strlen($phone) < 10) {
            return response()->json(['error' => 'phone required'], 400);
        }

        $tenantId = self::resolveActiveTenantId($phone);
        if (!$tenantId) {
            return response()->json(['error' => 'No tenant for this phone'], 404);
        }

        $sheet = TenantSheet::query()
            ->where('id', $id)
            ->where('tenant_id', $tenantId)
            ->first();

        if (!$sheet) {
            return response()->json(['error' => 'Sheet not found'], 404);
        }

        $sheet->update(['status' => 'removed']);

        // Drop DB tables belonging to this sheet + clean metadata
        $tenant = Tenant::query()->find($tenantId);
        $droppedTables = [];
        if ($tenant && is_array($tenant->tables_metadata)) {
            // Get this sheet's tab gids
            $sheetGids = [];
            try {
                $sheetId = $sheet->sheet_id ?: SheetSchemaDetector::extractSheetId($sheet->sheet_url);
                if ($sheetId) {
                    $tabs = SheetSchemaDetector::discoverTabs($sheetId);
                    $sheetGids = array_map(fn($t) => (string) ($t['gid'] ?? ''), $tabs);
                }
            } catch (Throwable $e) {
                Log::warning("[SHEET-REMOVE] could not discover tabs: " . $e->getMessage());
            }

            $meta = $tenant->tables_metadata;
            $keepMeta = [];
            foreach ($meta as $tab) {
                $belongsToSheet = !empty($sheetGids) && in_array((string) ($tab['gid'] ?? ''), $sheetGids, true);
                if ($belongsToSheet) {
                    $pgTable = $tab['pg_table'] ?? '';
                    if ($pgTable !== '') {
                        try {
                            \Illuminate\Support\Facades\DB::statement("DROP TABLE IF EXISTS `{$pgTable}`");
                            $droppedTables[] = $pgTable;
                        } catch (Throwable $e) {
                            Log::warning("[SHEET-REMOVE] drop failed {$pgTable}: " . $e->getMessage());
                        }
                    }
                } else {
                    $keepMeta[] = $tab;
                }
            }

            $tenant->update([
                'tables_metadata' => empty($keepMeta) ? null : $keepMeta,
                'proper_tables_created' => !empty($keepMeta),
            ]);
        }

        return response()->json(['ok' => true, 'dropped_tables' => $droppedTables]);
    }

    private static function resolveActiveTenantId(string $phone): ?string
    {
        $defaultDb = UserDatabase::query()->select('tenant_id')
            ->where('phone', $phone)->where('is_default', true)->first();
        if ($defaultDb?->tenant_id) return $defaultDb->tenant_id;

        $owner = Tenant::query()->select('id')->where('phone', $phone)->first();
        if ($owner?->id) return $owner->id;

        $mapping = TenantPhone::query()->select('tenant_id')->where('phone', $phone)->first();
        return $mapping?->tenant_id;
    }
}
