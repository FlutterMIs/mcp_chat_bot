<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Http\Requests\CreateClientRequest;
use App\Http\Requests\CreateMemberRequest;
use App\Models\Tenant;
use App\Models\TenantApiKey;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use App\Models\AdminActivityLog;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Throwable;

/**
 * Super Admin panel endpoints (gated by SuperAdminGate middleware).
 * All routes require X-Phone header with a super_admin phone.
 */
final class SuperAdminController extends Controller
{
    /** GET /api/admin/stats */
    public function stats(): JsonResponse
    {
        return response()->json([
            'total_clients'  => Tenant::count(),
            'total_members'  => UserDatabase::count(),
            'queries_today'  => DB::table('tenant_query_logs')
                ->whereDate('created_at', now()->toDateString())->count(),
            'messages_today' => DB::table('message_logs')
                ->whereDate('created_at', now()->toDateString())->count(),
        ]);
    }

    /** GET /api/admin/clients */
    public function listClients(): JsonResponse
    {
        $clients = Tenant::query()
            ->select(['id', 'name', 'phone', 'email', 'sheet_url', 'proper_tables_created', 'wa_key_mode', 'created_at'])
            ->orderByDesc('created_at')
            ->get();
        return response()->json($clients);
    }

    /** POST /api/admin/clients */
    public function createClient(CreateClientRequest $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $name  = trim((string) $request->input('name', ''));
        if (!$phone || strlen($phone) < 10) return response()->json(['error' => 'Valid phone required'], 400);
        if (!$name || strlen($name) < 2) return response()->json(['error' => 'Name required (min 2 chars)'], 400);

        if (Tenant::where('phone', $phone)->exists()) {
            return response()->json(['error' => 'Client with this phone already exists'], 409);
        }

        $tenant = new Tenant();
        $tenant->id = Str::uuid()->toString();
        $tenant->name = $name;
        $tenant->phone = $phone;
        $tenant->email = $request->input('email', '');
        $tenant->sheet_url = $request->input('sheet_url', '');
        $tenant->wa_key_mode = in_array($request->input('wa_key_mode'), ['shared', 'own'], true)
            ? $request->input('wa_key_mode')
            : 'shared';
        $tenant->save();

        // Also create tenant_phones entry
        DB::table('tenant_phones')->insert([
            'id' => Str::uuid()->toString(),
            'tenant_id' => $tenant->id,
            'phone' => $phone,
            'role' => 'owner',
            'created_at' => now(),
        ]);

        $adminPhone = $request->header('X-Phone') ?: $request->input('phone', 'system');
        $adminPhone = preg_replace('/[^0-9]/', '', (string) $adminPhone);
        AdminActivityLog::create([
            'action' => 'create_client',
            'performed_by' => $adminPhone ?: 'system',
            'target_id' => $tenant->id,
            'target_name' => $tenant->name,
            'details' => ['sheet_url' => $tenant->sheet_url],
        ]);

        return response()->json(['ok' => true, 'id' => $tenant->id, 'name' => $name], 201);
    }

    /** DELETE /api/admin/clients/{id} */
    public function deleteClient(string $id, Request $request): JsonResponse
    {
        $tenant = Tenant::find($id);
        if (!$tenant) return response()->json(['error' => 'Not found'], 404);

        $adminPhone = $request->header('X-Phone') ?: $request->input('phone', 'system');
        $adminPhone = preg_replace('/[^0-9]/', '', (string) $adminPhone);

        $tenant->deleted_by = $adminPhone ?: 'system';
        $tenant->save();
        $tenant->delete();

        AdminActivityLog::create([
            'action' => 'soft_delete_client',
            'performed_by' => $adminPhone ?: 'system',
            'target_id' => $tenant->id,
            'target_name' => $tenant->name,
        ]);

        return response()->json(['ok' => true]);
    }

    /** POST /api/admin/clients/{id}/remove-wa-key — switch tenant back to shared key */
    public function removeWaKey(string $id): JsonResponse
    {
        $tenant = Tenant::find($id);
        if (!$tenant) return response()->json(['error' => 'Not found'], 404);
        $tenant->wa_key_mode = 'shared';
        $tenant->wa_connected_number = null;
        $tenant->save();
        TenantApiKey::where('tenant_id', $tenant->id)->whereIn('type', [1, 2])->delete();
        Cache::forget('bot_connected_numbers');
        return response()->json(['ok' => true]);
    }

    /** POST /api/admin/clients/{id}/sheet — update sheet_url for a tenant */
    public function updateSheet(string $id, Request $request): JsonResponse
    {
        $tenant = Tenant::find($id);
        if (!$tenant) return response()->json(['error' => 'Not found'], 404);
        $sheetUrl = trim((string) $request->input('sheet_url', ''));
        if (!$sheetUrl || !str_contains($sheetUrl, 'docs.google.com/spreadsheets')) {
            return response()->json(['error' => 'Valid Google Sheet URL required'], 400);
        }
        $tenant->sheet_url = $sheetUrl;
        $tenant->save();
        return response()->json(['ok' => true]);
    }

    /** POST /api/admin/clients/{id}/provision — first-time sync (creates tables + imports data) */
    public function provision(string $id, Request $request): JsonResponse
    {
        $tenant = Tenant::find($id);
        if (!$tenant) return response()->json(['error' => 'Not found'], 404);

        // Allow passing sheet_url to update it before provisioning
        $sheetUrl = trim((string) $request->input('sheet_url', ''));
        if ($sheetUrl && str_contains($sheetUrl, 'docs.google.com/spreadsheets')) {
            $tenant->sheet_url = $sheetUrl;
            $tenant->save();
        }

        if (!$tenant->sheet_url) {
            return response()->json(['error' => 'No sheet URL configured for this client'], 400);
        }

        try {
            $result = \App\Services\Sheets\TenantTablesProvisioner::syncSheetToProperTables($tenant->id, $tenant->sheet_url);
            return response()->json([
                'ok' => true,
                'rows' => $result['synced_rows'] ?? 0,
                'tabs' => count($result['tabs'] ?? []),
            ]);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error("[ADMIN PROVISION] {$tenant->name}: " . $e->getMessage());
            return response()->json(['error' => 'Sync failed: ' . $e->getMessage()], 500);
        }
    }

    /** GET /api/admin/members */
    public function listMembers(): JsonResponse
    {
        $members = UserDatabase::query()
            ->select(['user_databases.id', 'user_databases.phone', 'user_databases.tenant_id', 'user_databases.alias', 'user_databases.permissions', 'tenants.name as tenant_name'])
            ->leftJoin('tenants', 'tenants.id', '=', 'user_databases.tenant_id')
            ->orderByDesc('user_databases.created_at')
            ->get()
            ->map(fn($m) => [
                'id' => $m->id,
                'phone' => $m->phone,
                'tenant_id' => $m->tenant_id,
                'tenant_name' => $m->tenant_name,
                'alias' => $m->alias,
                'permissions' => json_decode($m->permissions ?? '["dashboard","chat"]', true),
            ]);
        return response()->json($members);
    }

    /** POST /api/admin/members */
    public function createMember(CreateMemberRequest $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $tenantId = (string) $request->input('tenant_id', '');
        if (!$phone || strlen($phone) < 10) return response()->json(['error' => 'Valid phone required'], 400);
        if (!$tenantId) return response()->json(['error' => 'Client (tenant_id) required'], 400);

        if (!Tenant::where('id', $tenantId)->exists()) {
            return response()->json(['error' => 'Client not found'], 404);
        }

        if (UserDatabase::where('phone', $phone)->where('tenant_id', $tenantId)->exists()) {
            return response()->json(['error' => 'Member already exists for this client'], 409);
        }

        $perms = $request->input('permissions', ['dashboard', 'chat']);
        DB::table('user_databases')->insert([
            'id' => Str::uuid()->toString(),
            'phone' => $phone,
            'tenant_id' => $tenantId,
            'alias' => $request->input('alias', '') ?: null,
            'is_default' => true,
            'permissions' => json_encode($perms),
            'created_at' => now(),
        ]);

        return response()->json(['ok' => true], 201);
    }

    /** DELETE /api/admin/members/{id} */
    public function deleteMember(string $id): JsonResponse
    {
        $deleted = DB::table('user_databases')->where('id', $id)->delete();
        if (!$deleted) return response()->json(['error' => 'Not found'], 404);
        return response()->json(['ok' => true]);
    }

    /** PUT /api/admin/members/{id} — update permissions/alias */
    public function updateMember(string $id, Request $request): JsonResponse
    {
        $row = DB::table('user_databases')->where('id', $id)->first();
        if (!$row) return response()->json(['error' => 'Not found'], 404);

        $update = [];
        if ($request->has('permissions')) {
            $update['permissions'] = json_encode($request->input('permissions'));
        }
        if ($request->has('alias')) {
            $update['alias'] = $request->input('alias') ?: null;
        }
        if (empty($update)) return response()->json(['error' => 'Nothing to update'], 400);

        DB::table('user_databases')->where('id', $id)->update($update);
        return response()->json(['ok' => true]);
    }

    /** GET /api/admin/prompts?tenant_id= */
    public function getPrompts(Request $request): JsonResponse
    {
        $tenantId = $request->input('tenant_id');
        if (!$tenantId) return response()->json(['error' => 'tenant_id required'], 400);

        return response()->json(\App\Models\TenantPrompt::allFor($tenantId));
    }

    /** POST /api/admin/prompts */
    public function savePrompts(Request $request): JsonResponse
    {
        $tenantId = $request->input('tenant_id');
        if (!$tenantId) return response()->json(['error' => 'tenant_id required'], 400);

        $saved = 0;
        foreach (\App\Models\TenantPrompt::KEYS as $key) {
            $val = $request->input($key);
            if ($val !== null) {
                $val = trim((string) $val);
                if ($val === '') {
                    \App\Models\TenantPrompt::where('tenant_id', $tenantId)->where('prompt_key', $key)->delete();
                    Cache::forget("tenant_prompt:{$tenantId}:{$key}");
                } else {
                    \App\Models\TenantPrompt::set($tenantId, $key, $val);
                }
                $saved++;
            }
        }

        return response()->json(['ok' => true, 'saved' => $saved]);
    }

    /** GET /api/admin/clients/trashed */
    public function listTrashedClients(): JsonResponse
    {
        $clients = Tenant::onlyTrashed()
            ->select(['id', 'name', 'phone', 'email', 'sheet_url', 'deleted_by', 'deleted_at'])
            ->orderByDesc('deleted_at')
            ->get();
        return response()->json($clients);
    }

    /** POST /api/admin/clients/{id}/restore */
    public function restoreClient(string $id, Request $request): JsonResponse
    {
        $tenant = Tenant::onlyTrashed()->find($id);
        if (!$tenant) return response()->json(['error' => 'Not found in trash'], 404);

        $adminPhone = $request->header('X-Phone') ?: $request->input('phone', 'system');
        $adminPhone = preg_replace('/[^0-9]/', '', (string) $adminPhone);

        $tenant->deleted_by = null;
        $tenant->restore();

        AdminActivityLog::create([
            'action' => 'restore_client',
            'performed_by' => $adminPhone ?: 'system',
            'target_id' => $tenant->id,
            'target_name' => $tenant->name,
        ]);

        return response()->json(['ok' => true]);
    }

    /** DELETE /api/admin/clients/{id}/force */
    public function forceDeleteClient(string $id, Request $request): JsonResponse
    {
        $tenant = Tenant::withTrashed()->find($id);
        if (!$tenant) return response()->json(['error' => 'Not found'], 404);

        $adminPhone = $request->header('X-Phone') ?: $request->input('phone', 'system');
        $adminPhone = preg_replace('/[^0-9]/', '', (string) $adminPhone);

        $tenantId = $tenant->id;
        $tenantName = $tenant->name;

        // 1. Drop dynamic tables starting with tenant_{shortid}_%
        $shortId = substr(str_replace('-', '', $tenantId), 0, 8);
        $tables = DB::select("SHOW TABLES LIKE 'tenant_{$shortId}_%'");
        $droppedTables = [];
        foreach ($tables as $t) {
            $tableName = array_values((array)$t)[0];
            DB::statement("DROP TABLE IF EXISTS `{$tableName}`");
            $droppedTables[] = $tableName;
        }

        // 2. Delete child records
        DB::table('tenant_phones')->where('tenant_id', $tenantId)->delete();
        DB::table('tenant_sheets')->where('tenant_id', $tenantId)->delete();
        DB::table('sheet_tab_access')->where('tenant_id', $tenantId)->delete();
        DB::table('tenant_links')->where('tenant_id', $tenantId)->delete();
        DB::table('tenant_pdf_chunks')->where('tenant_id', $tenantId)->delete();
        DB::table('user_databases')->where('tenant_id', $tenantId)->delete();
        DB::table('tenant_query_logs')->where('tenant_id', $tenantId)->delete();
        DB::table('tenant_notifications')->where('tenant_id', $tenantId)->delete();
        DB::table('tenant_prompts')->where('tenant_id', $tenantId)->delete();
        DB::table('tenant_api_keys')->where('tenant_id', $tenantId)->delete();
        DB::table('query_memory')->where('tenant_id', $tenantId)->delete();
        DB::table('chat_history')->where('tenant_id', $tenantId)->delete();
        DB::table('calendar_logs')->where('tenant_id', $tenantId)->delete();

        // 3. Force delete the tenant row
        $tenant->forceDelete();

        // 4. Log the action
        AdminActivityLog::create([
            'action' => 'force_delete_client',
            'performed_by' => $adminPhone ?: 'system',
            'target_id' => $tenantId,
            'target_name' => $tenantName,
            'details' => ['dropped_tables' => $droppedTables],
        ]);

        return response()->json(['ok' => true]);
    }

    /** GET /api/admin/activity-logs */
    public function listActivityLogs(): JsonResponse
    {
        $logs = AdminActivityLog::query()
            ->orderByDesc('created_at')
            ->get();
        return response()->json($logs);
    }
}
