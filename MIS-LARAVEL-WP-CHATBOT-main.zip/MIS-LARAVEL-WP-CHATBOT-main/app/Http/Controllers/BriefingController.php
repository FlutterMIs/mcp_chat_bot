<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use App\Services\Dashboard\BriefingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * GET /api/briefing?phone=&range=&tenant_id=
 *
 * Returns a 3-sentence AI-generated business briefing. Cached 1 hour per
 * (tenant, range). Same 3-step phone resolution as DashboardController.
 *
 * Graceful degradation: if OPENAI_API_KEY missing or API fails, returns a
 * plain message + `error: true` flag (200 OK — frontend shows fallback text).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~line 3556)
 */
final class BriefingController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        $range = (string) $request->query('range', 'month');

        if (! $phone) {
            return response()->json(['error' => 'phone required'], 400);
        }

        try {
            $tenantId = $this->resolveTenantId($phone);
            if (! $tenantId) {
                return response()->json(['error' => 'No tenant for this phone'], 404);
            }

            $payload = BriefingService::generate($tenantId, $range);

            return response()->json($payload);
        } catch (Throwable $e) {
            Log::error('Briefing failed', ['phone' => $phone, 'range' => $range, 'error' => $e->getMessage()]);

            return response()->json(['error' => 'Briefing generation failed: '.$e->getMessage()], 500);
        }
    }

    /** 3-step tenant resolution. */
    private function resolveTenantId(string $phone): ?string
    {
        $defaultDb = UserDatabase::query()->select('tenant_id')
            ->where('phone', $phone)->where('is_default', true)->first();
        if ($defaultDb?->tenant_id) {
            return $defaultDb->tenant_id;
        }
        $owner = Tenant::query()->select('id')->where('phone', $phone)->first();
        if ($owner?->id) {
            return $owner->id;
        }
        $mapping = TenantPhone::query()->select('tenant_id')->where('phone', $phone)->first();

        return $mapping?->tenant_id;
    }
}
