<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\MessageLog;
use App\Services\Chat\DriveFileHandler;
use App\Services\Chat\TenantRouter;
use App\Services\WhatsApp\Client;
use App\Services\WhatsApp\WhisperTranscriber;
use Illuminate\Contracts\Cache\LockTimeoutException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * WhatsApp webhook handler — text + voice paths.
 *
 *   GET  /whatsapp     — Meta webhook verification (echoes hub.challenge)
 *   POST /whatsapp     — Inbound message webhook from wa.apimis.in / Meta
 *
 * Pipeline for POST:
 *   1. Optional HMAC-SHA256 verification (x-hub-signature-256 header) +
 *      shared-secret fallback (x-webhook-secret header). Strict mode via
 *      WEBHOOK_STRICT=true env.
 *   2. Parse wa.apimis.in payload to extract sender phone + (audio|text).
 *      Falls back to Meta's nested entry[0].changes[0].value.messages[0]
 *      shape for direct Cloud API webhooks.
 *   2b/3c. Idempotency + gateway gating: a tenant's number can have BOTH the
 *      professional (Meta Cloud API, payload object="whatsapp_business_account")
 *      and unprofessional (flat payload) webhooks configured simultaneously on
 *      the provider side. A message-id dedup catches provider retries; a gateway
 *      gate (payload shape vs tenant's active wa_channel_mode) catches the same
 *      message arriving twice from two different gateways at once.
 *   3. For audio messages: download via Client::downloadAudioFromUrl (filePath)
 *      or Client::downloadMetaMedia (Meta nested mediaId), then transcribe via
 *      WhisperTranscriber::transcribe(language='hi'). Failure on any step →
 *      friendly "couldn't understand audio, please type" reply.
 *   4. Route through TenantRouter::handle($phone, $text) — same SQL+self-heal
 *      pipeline as /api/chat. Runs inline/synchronously in this same request —
 *      NO queue, job, or supervisor involved (shared/LiteSpeed hosting can't run
 *      queue workers, and dispatchAfterResponse/dispatchSync don't survive LSPHP
 *      terminating the process after the response is sent).
 *   5. Send reply back via Client::sendText() (channel_mode 'professional' vs
 *      'unprofessional' API selection happens inside Client::resolveChannelConfig).
 *   6. If TenantRouter returns `media` (chart PNG / PDF / CSV / product images), dispatch
 *      it via Client::sendImage / sendDocument / sendImageByUrl after the text reply.
 *      Tmp file paths are unlinked once dispatch completes (mirrors Node's fs.unlinkSync).
 *   7. Respond 200 to the provider once everything above has completed.
 *
 * Access control IS enforced on this path: step 5 routes through the same
 * TenantRouter::handle() as the web /chat endpoint, so computeAccessFilter()
 * applies each sender's TEAM/CLIENT row filters (and owner/super-admin bypass)
 * to WhatsApp replies exactly as it does on the web — a WhatsApp client only
 * ever sees rows their phone is permitted to see.
 *
 * NOT yet implemented (deferred to follow-up sessions):
 *   - Multi-DB switching ("switch db" admin command)
 *   - Fall-through to MIS Main chatbot for non-tenant phones
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~lines 2258-2470)
 */
final class WebhookController extends Controller
{
    /**
     * GET /whatsapp — verification echo for Meta hub.challenge handshake.
     */
    public function verify(Request $request): \Illuminate\Http\Response
    {
        $mode = (string) $request->query('hub_mode', '');
        $challenge = (string) $request->query('hub_challenge', '');
        Log::info('[WEBHOOK VERIFY] query: '.json_encode($request->query()));

        // Laravel converts dotted query keys (hub.challenge) to underscores; check both.
        if ($mode === '' && $request->query('hub.mode') !== null) {
            $mode = (string) $request->query('hub.mode');
            $challenge = (string) $request->query('hub.challenge', '');
        }

        if ($mode === 'subscribe') {
            return response($challenge !== '' ? $challenge : 'OK', 200);
        }

        return response('OK', 200);
    }

    /**
     * POST /wh/{token} — per-tenant webhook. Resolves tenant from URL token.
     * Eliminates cross-channel echo loops since each tenant has a unique URL.
     */
    public function handleByToken(Request $request, string $token): JsonResponse
    {
        // Resolve tenant from token
        $tenant = \App\Models\Tenant::where('webhook_token', $token)->first();
        if (!$tenant) {
            Log::warning("[WEBHOOK] unknown token: {$token}");
            return response()->json(['error' => 'Invalid webhook token'], 404);
        }

        // Inject tenant_id into request so handle() can use it as the pre-resolved tenant
        $request->merge(['__webhook_tenant_id' => $tenant->id]);

        Log::info("[WEBHOOK /wh/{$token}] routed to tenant: {$tenant->name} ({$tenant->id})");

        // Delegate to the main handler (which will skip isBotNumber since tenant is pre-resolved)
        return $this->handle($request);
    }

    /**
     * POST /whatsapp — inbound message handler.
     */
    public function handle(Request $request): JsonResponse
    {
        // Reject oversized payloads (>1MB)
        if (strlen($request->getContent()) > 1_048_576) {
            Log::warning('[WEBHOOK] payload too large: ' . strlen($request->getContent()) . ' bytes');
            return response()->json(['error' => 'payload too large'], 413);
        }

        Log::info('🔥 WHATSAPP WEBHOOK HIT | '.now()->format('Y-m-d H:i:s'));
        $body = $request->all();
        Log::info('[PAYLOAD] '.substr(json_encode($body), 0, 500));

        // 1. Optional HMAC / shared-secret verification
        Log::info('[STEP 1] verifying webhook signature…');
        $verified = self::verifySignature($request);
        Log::info('[STEP 1] signature result: ok='.($verified['ok'] ? 'true' : 'false').' reason='.$verified['reason']);
        if (! $verified['ok']) {
            $strict = filter_var(config('mis.webhook_strict', false), FILTER_VALIDATE_BOOLEAN);
            Log::warning("[WEBHOOK AUTH] {$verified['reason']} — strict=".($strict ? 'true' : 'false'));
            if ($strict) {
                Log::warning('[STEP 1] STRICT mode ON → rejecting webhook with 401');
                return response()->json(['error' => 'Unauthorized webhook'], 401);
            }
        }

        // 2. Skip outgoing-message echoes
        Log::info('[STEP 2] boundType='.json_encode($body['boundType'] ?? null));
        if (($body['boundType'] ?? null) === 'out') {
            Log::info('[STEP 2] this is an OUTGOING echo (boundType=out) → ignoring to avoid reply loop');
            return response()->json(['success' => true, 'ignored' => true]);
        }

        // 2b. Idempotency — the provider retries a webhook delivery if it doesn't get a
        // fast 200 (common while the AI pipeline is running). Without this, a retry
        // reprocesses the same inbound message and sends a second WhatsApp reply.
        // Cache::add is atomic on the database cache driver, so two racing requests
        // for the same message id can't both pass.
        $msgId = (string) ($body['messageId']
            ?? $body['id']
            ?? $body['entry'][0]['changes'][0]['value']['messages'][0]['id']
            ?? '');
        if ($msgId !== '') {
            if (! Cache::add("wa_seen:{$msgId}", 1, now()->addMinutes(10))) {
                Log::info("[STEP 2b] duplicate delivery of messageId={$msgId} — ignoring");
                return response()->json(['success' => true, 'duplicate' => true]);
            }
        }

        // 3. Extract sender phone — wa.apimis.in shape first, then Meta shape
        $phone = (string) ($body['senderNumber']
            ?? $body['from']
            ?? $body['entry'][0]['changes'][0]['value']['messages'][0]['from']
            ?? '');
        Log::info('[STEP 3] extracted sender phone="'.$phone.'"');
        if ($phone === '') {
            Log::info('[STEP 3] no sender phone found in payload — ignoring');

            return response()->json(['success' => true, 'ignored' => true]);
        }

        $preResolvedTenantId = $request->input('__webhook_tenant_id');

        // 3b. Ignore messages FROM the bot's own connected numbers (cross-channel echo prevention).
        // SKIP this check when tenant is pre-resolved via /wh/{token} — unique URLs eliminate echo loops.
        if (!$request->has('__webhook_tenant_id') && self::isBotNumber($phone)) {
            Log::info("[STEP 3b] sender {$phone} is a bot-connected number → ignoring to prevent echo loop");
            return response()->json(['success' => true, 'ignored' => 'bot-self-message']);
        }

        // 3c. Gateway gating — a tenant's WhatsApp number can have BOTH the professional
        // (official Meta Cloud API, via wa.apimis.in — payload has top-level
        // object="whatsapp_business_account") and unprofessional (app.mis.work, flat
        // payload shape) webhooks configured on the provider side at the same time,
        // even though only one is the tenant's active channel_mode. When that happens,
        // one inbound message arrives as two separate webhook deliveries with two
        // different message ids, so the STEP 2b dedup above doesn't catch it (each id
        // is only a duplicate within its own gateway). Drop the delivery here if its
        // gateway isn't the tenant's currently configured active channel.
        $payloadChannelMode = (($body['object'] ?? null) === 'whatsapp_business_account') ? 'professional' : 'unprofessional';
        $gateTenantId = $preResolvedTenantId ?: TenantRouter::resolveTenantId($phone);
        if ($gateTenantId) {
            $activeChannelMode = (string) (\App\Models\Tenant::query()->where('id', $gateTenantId)->value('wa_channel_mode') ?: 'unprofessional');
            if ($payloadChannelMode !== $activeChannelMode) {
                Log::info("[STEP 3c] ignoring inbound — payload gateway={$payloadChannelMode} but tenant active channel={$activeChannelMode} (tenant={$gateTenantId})");
                return response()->json(['success' => true, 'ignored' => 'inactive-gateway']);
            }
        }

        // 4. Extract message text — wa.apimis.in flat keys + Meta nested
        $itemType = (string) ($body['itemType']
            ?? $body['entry'][0]['changes'][0]['value']['messages'][0]['type']
            ?? '');
        Log::info('[STEP 4] itemType="'.$itemType.'"');

        $isAudio = false;
        $text = '';

        if ($itemType === 'ptt' || $itemType === 'audio') {
            // ── VOICE PATH ────────────────────────────────────────────────
            // Two source variants per Node parity:
            //   1. wa.apimis.in flat: body.filePath = pre-signed S3 URL
            //   2. Meta nested:       body.entry[0].changes[0].value.messages[0].audio.id
            Log::info('[STEP 4a] VOICE message detected → entering audio path');
            $audioUrl = (string) ($body['filePath'] ?? '');
            $mediaId = (string) ($body['entry'][0]['changes'][0]['value']['messages'][0]['audio']['id'] ?? '');
            Log::info('[STEP 4a] audioUrl='.($audioUrl !== '' ? 'present' : 'empty').' mediaId='.($mediaId !== '' ? 'present' : 'empty'));

            if ($audioUrl === '' && $mediaId === '') {
                Log::info("[STEP 4a] audio from {$phone} but no source (filePath / mediaId) → asking for text");
                self::dispatchReply($phone, "⚠️ Could not download the audio. Please try again or send as text.", $preResolvedTenantId);

                return response()->json(['success' => true, 'ignored' => 'audio-no-source']);
            }

            Log::info('[STEP 4a] downloading audio via '.($audioUrl !== '' ? 'downloadAudioFromUrl' : 'downloadMetaMedia').'…');
            $audioBytes = $audioUrl !== ''
                ? Client::downloadAudioFromUrl($audioUrl)
                : Client::downloadMetaMedia($mediaId);
            Log::info('[STEP 4a] audio download result: '.(is_string($audioBytes) ? strlen($audioBytes).' bytes' : 'NULL/empty'));

            if ($audioBytes === null || $audioBytes === '') {
                Log::warning("[STEP 4a] audio download failed for {$phone}");
                self::dispatchReply($phone, "⚠️ Could not download the audio. Please try again or send as text.", $preResolvedTenantId);

                return response()->json(['success' => false, 'error' => 'audio-download-failed']);
            }

            // Whisper API — Hindi default since most tenant users speak Hinglish/Hindi
            Log::info('[STEP 4a] sending audio to Whisper for transcription…');
            $transcript = WhisperTranscriber::transcribe($audioBytes, 'hi', 'audio/ogg');
            Log::info('[STEP 4a] Whisper result: '.($transcript === null ? 'NULL (failed)' : '"'.mb_substr($transcript, 0, 120).'"'));

            if ($transcript === null) {
                self::dispatchReply($phone, "⚠️ Could not understand the audio. Please send your question as text.", $preResolvedTenantId);

                return response()->json(['success' => false, 'error' => 'transcription-failed']);
            }

            $text = $transcript;
            $isAudio = true;
            Log::info("[WEBHOOK AUDIO] from={$phone} transcript=".mb_substr($text, 0, 120));
        } else {
            Log::info('[STEP 4b] TEXT message → extracting body from payload');
            $text = (string) ($body['message']
                ?? $body['value']
                ?? $body['text']
                ?? $body['Body']
                ?? $body['entry'][0]['changes'][0]['value']['messages'][0]['text']['body']
                ?? '');
        }

        $text = trim(preg_replace('/^mis[\s-]?bot\s*/i', '', $text));
        Log::info('[STEP 5] final message text="'.mb_substr($text, 0, 200).'"');

        if ($text === '') {
            Log::info('[STEP 5] message body empty after cleanup — ignoring');

            return response()->json(['success' => true, 'ignored' => true]);
        }

        // 5b. Fallback idempotency for payload shapes with no message id (STEP 2b covers
        // the common case) — catches exact-duplicate rapid retries via a short-TTL hash
        // without permanently blocking a legitimately repeated question later on.
        if ($msgId === '') {
            $hashKey = 'wa_seen_hash:'.sha1($phone.'|'.$text);
            if (! Cache::add($hashKey, 1, now()->addSeconds(20))) {
                Log::info("[STEP 5b] duplicate delivery (no messageId, content hash matched) for {$phone} — ignoring");
                return response()->json(['success' => true, 'duplicate' => true]);
            }
        }

        Log::info('[WP QUERY] '.($isAudio ? '🎤 ' : '').$text." | FROM: {$phone}");
        Log::info('[STEP 6] writing inbound audit log to message_logs…');
        self::logIncoming($phone, $text, $isAudio ? 'audio' : 'text');

        // 5. Route through TenantRouter → reply via WhatsApp
        // Per-phone rate limit: max 10 msgs/min to prevent abuse/cost overrun
        $rateLimitKey = "wa_rate:{$phone}";
        $msgCount = (int) Cache::get($rateLimitKey, 0);
        if ($msgCount >= 10) {
            Log::warning("[RATE LIMIT] phone={$phone} hit 10 msgs/min cap");
            return response()->json(['success' => true, 'ignored' => 'rate-limited']);
        }
        Cache::put($rateLimitKey, $msgCount + 1, 60);

        // Process inline, synchronously, in-request — no queue/job/supervisor involved.
        // dispatchAfterResponse/dispatchSync don't work on LiteSpeed shared hosting
        // (LSPHP terminates before after-response callbacks fire), so this must complete
        // before the HTTP response is returned.

        // Per-phone lock — prevents a near-simultaneous retry for the same phone from
        // running TenantRouter + sending a reply in parallel with this request (the
        // message-id/hash dedup above closes the "already finished" race; this closes
        // the "still in flight" race). If the lock can't be acquired, the other request
        // is already handling this message, so we skip rather than risk a second send.
        try {
            Cache::lock("wa_lock:{$phone}", 30)->block(5, function () use ($phone, $text, $isAudio, $preResolvedTenantId) {
                $result = TenantRouter::handle($phone, $text, true, $isAudio, $preResolvedTenantId);
                $reply = $result['reply'] ?? '';
                $resolvedTenantId = $result['tenant']['id'] ?? null;

                // Only use tenant's own key when message came via per-tenant webhook (/wh/{token}).
                // Shared webhook (/whatsapp) → shared key → reply from shared number.
                $sendTenantId = $preResolvedTenantId ? $resolvedTenantId : null;

                if ($reply !== '') {
                    self::dispatchReply($phone, $reply, $sendTenantId);
                }

                if (isset($result['media']) && is_array($result['media'])) {
                    self::dispatchMedia($phone, $result['media'], $reply, $sendTenantId);
                }

                if ($reply !== '' && !isset($result['media'])) {
                    DriveFileHandler::sendDriveFiles($phone, $reply, $sendTenantId);
                }
            });
        } catch (LockTimeoutException $e) {
            Log::warning("[WEBHOOK LOCK] could not acquire lock for {$phone} within 5s — likely a concurrent duplicate delivery, skipping to avoid double send");
        } catch (Throwable $e) {
            Log::error('[WEBHOOK PROCESS] ' . $e->getMessage());
            self::dispatchReply($phone, '⚠️ Something went wrong. Please try again.', $preResolvedTenantId);
        }

        Log::info('[STEP 7] processed message for ' . $phone);
        return response()->json(['success' => true]);
    }

    /**
     * Verify webhook signature.
     * 1. Meta-style HMAC-SHA256 in X-Hub-Signature-256 over raw request body.
     * 2. Shared-secret in x-webhook-secret header (wa.apimis.in style — current production).
     *
     * @return array{ok: bool, reason: string}
     */
    private static function verifySignature(Request $request): array
    {
        $secret = (string) config('mis.webhook_secret', '');
        $hubSig = (string) $request->header('x-hub-signature-256', '');
        $shared = (string) $request->header('x-webhook-secret', '');

        if ($secret === '') {
            return ['ok' => true, 'reason' => 'no-secret-configured'];
        }

        // Meta-style HMAC
        if ($hubSig !== '' && str_starts_with($hubSig, 'sha256=')) {
            $expected = 'sha256='.hash_hmac('sha256', $request->getContent(), $secret);
            if (hash_equals($expected, $hubSig)) {
                return ['ok' => true, 'reason' => 'hmac-ok'];
            }

            return ['ok' => false, 'reason' => 'hmac-mismatch'];
        }

        // Shared-secret style (timing-safe equality)
        if ($shared !== '') {
            if (hash_equals($secret, $shared)) {
                return ['ok' => true, 'reason' => 'shared-ok'];
            }

            return ['ok' => false, 'reason' => 'shared-mismatch'];
        }

        return ['ok' => false, 'reason' => 'no-auth-header'];
    }

    /** Send a WhatsApp text reply, fire-and-forget. */
    private static function dispatchReply(string $phone, string $text, ?string $tenantId = null): void
    {
        try {
            $text = self::toWhatsAppMarkdown($text);
            Log::info('[SEND] calling Client::sendText → to='.$phone.' len='.strlen($text));
            $ok = Client::sendText($phone, $text, $tenantId);
            Log::info('[SEND] Client::sendText returned: '.($ok ? 'TRUE (gateway accepted)' : 'FALSE (gateway/send failed)'));
            self::logOutgoing($phone, $text, 'text', $tenantId);
        } catch (Throwable $e) {
            Log::error('[WEBHOOK REPLY] '.$e->getMessage());
        }
    }

    /**
     * WhatsApp only understands single-asterisk *bold* (and _italic_). AI-generated
     * replies sometimes ignore the prompt instruction and emit standard **bold**
     * markdown anyway — left as-is it shows up as literal asterisks on the phone.
     * Normalize here, at the single outbound choke point, rather than patching every
     * TenantRouter return site.
     */
    private static function toWhatsAppMarkdown(string $text): string
    {
        return preg_replace('/\*\*(.+?)\*\*/s', '*$1*', $text) ?? $text;
    }

    /**
     * Send WhatsApp media after a text reply, fire-and-forget.
     *
     * Supports the three shapes Node TenantRouter emits (helpers/tenant-router.js):
     *   • `{type:'image', path:'/tmp/chart_xxx.png', caption?:string}` → upload + sendImage
     *   • `{type:'document', path:'/tmp/file.pdf', caption?:string, filename?:string}` → upload + sendDocument
     *   • `{type:'images', items:[{url, caption}, ...]}` → loop, sendImageByUrl per item (cap 20, 700ms gap)
     *
     * Caption precedence: media-level `caption` > fallback `$replyText`. Tmp files referenced
     * by `path` are unlinked after dispatch completes (mirrors Node `fs.unlinkSync` cleanup).
     *
     * @param  array<string, mixed>  $media
     */
    private static function dispatchMedia(string $phone, array $media, string $replyText = '', ?string $tenantId = null): void
    {
        $type = (string) ($media['type'] ?? '');

        try {
            // Variant 1: list of image URLs (product photos with public links — no upload step)
            if ($type === 'images' && isset($media['items']) && is_array($media['items'])) {
                $items = array_slice($media['items'], 0, 20);
                foreach ($items as $i => $item) {
                    $url = (string) ($item['url'] ?? $item['link'] ?? '');
                    if ($url === '') continue;
                    $caption = (string) ($item['caption'] ?? '');
                    Client::sendImageByUrl($phone, $url, $caption, $tenantId);
                    self::logOutgoing($phone, $caption !== '' ? $caption : $url, 'image', $tenantId);
                    if ($i + 1 < count($items)) {
                        usleep(350_000); // gap between sends — reduced from 700ms (was ported 1:1 from Node's throttle, no gateway limit requires it that high)
                    }
                }

                return;
            }

            // Variant 2: file at $path → upload + send
            $path = (string) ($media['path'] ?? '');
            if ($path === '') {
                Log::warning("[WEBHOOK MEDIA] type={$type} but no path/items — nothing to dispatch");

                return;
            }

            $caption = (string) ($media['caption'] ?? $replyText);

            try {
                if ($type === 'image') {
                    Client::sendImage($phone, $path, $caption, $tenantId);
                    self::logOutgoing($phone, $caption, 'image', $tenantId);
                } else {
                    // document / pdf / csv / xlsx / unknown — all go through sendDocument
                    $filename = isset($media['filename']) ? (string) $media['filename'] : null;
                    Client::sendDocument($phone, $path, $caption, $filename, $tenantId);
                    self::logOutgoing($phone, $caption !== '' ? $caption : ($filename ?? $path), 'document', $tenantId);
                }
            } finally {
                // Cleanup tmp file regardless of upload success — same as Node fs.unlinkSync
                // in the finally block of helpers/whatsapp.js sendWhatsAppMedia.
                if (is_file($path) && str_starts_with($path, sys_get_temp_dir())) {
                    @unlink($path);
                }
            }
        } catch (Throwable $e) {
            Log::error('[WEBHOOK MEDIA] '.$e->getMessage());
        }
    }

    /**
     * Check if a phone number belongs to one of the bot's connected WhatsApp numbers.
     * Prevents cross-channel echo loops when multiple channels share the same webhook URL.
     * Cached for 5 minutes to avoid DB hit on every webhook.
     */
    private static function isBotNumber(string $phone): bool
    {
        $botNumbers = Cache::remember('bot_connected_numbers', 300, function () {
            $numbers = \Illuminate\Support\Facades\DB::table('tenants')
                ->whereNotNull('wa_connected_number')
                ->where('wa_connected_number', '!=', '')
                ->pluck('wa_connected_number')
                ->toArray();
            // Also include the shared MIS number (channel 46282)
            $shared = (string) config('mis.wa_connected_number', '');
            if ($shared !== '') {
                $numbers[] = $shared;
            }
            return $numbers;
        });

        return in_array($phone, $botNumbers, true);
    }

    /** Best-effort message audit log; never throws. */
    private static function logIncoming(string $phone, string $text, string $messageType = 'text'): void
    {
        try {
            MessageLog::create([
                'platform'     => 'whatsapp',
                'direction'    => 'in',
                'phone'        => $phone,
                'message_type' => $messageType,
                'message'      => mb_substr($text, 0, 5000),
            ]);
        } catch (Throwable $e) {
            Log::warning('[WEBHOOK LOG] '.$e->getMessage());
        }
    }

    /** Best-effort outbound message audit log; never throws. */
    private static function logOutgoing(string $phone, string $text, string $messageType = 'text', ?string $tenantId = null): void
    {
        try {
            MessageLog::create([
                'tenant_id'    => $tenantId,
                'platform'     => 'whatsapp',
                'direction'    => 'out',
                'phone'        => $phone,
                'message_type' => $messageType,
                'message'      => mb_substr($text, 0, 5000),
            ]);
        } catch (Throwable $e) {
            Log::warning('[WEBHOOK LOG] '.$e->getMessage());
        }
    }
}
