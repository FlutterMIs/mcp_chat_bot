<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use App\Services\Dashboard\TableClassifier;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * ReportsController — dynamic reports catalogue.
 *
 * GET /api/reports/list?phone=...&tenant_id=...
 *   → { tenant: {id, name}, detected_roles: [...], reports: [...], formats: ['pdf', 'xlsx'] }
 *
 * Filters the static REPORT_CATALOG against the tenant's actually-detected table roles.
 * A tenant with only a sales sheet sees ~4 reports; one with sales + purchases sees ~9.
 *
 * Frontend `public/reports.html` calls this on page load and renders the returned cards.
 * Each card triggers a download via the existing `/api/page/{kind}` endpoints (Z6).
 *
 * Roles are classified via DashboardEngine's TableClassifier (the SAME logic that drives
 * dashboard widget filtering) — guarantees a tenant who sees a "Sales" KPI on the dashboard
 * also sees the "Sales Summary" report in the catalogue.
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~lines 4579-4664 — REPORT_CATALOG + /api/reports/list)
 */
final class ReportsController extends Controller
{
    /**
     * Static report catalogue. Each entry declares which classified table-roles it requires.
     * If a tenant lacks any required role, the report is filtered out.
     *
     * `requiresColumn` (optional): the named role-column must resolve on the role's table
     * (e.g. sales-by-city needs the sales table to have a city/location column).
     */
    private const CATALOG = [
        ['id' => 'sales-summary',    'title' => 'Sales Summary',    'icon' => 'trending-up', 'desc' => 'Total revenue, invoice count, average ticket, top customers and items for the selected period.', 'source' => 'sales',       'requires' => ['sales']],
        ['id' => 'top-customers',    'title' => 'Top Customers',    'icon' => 'users',       'desc' => 'Top customers by total sales for the selected period.',                                              'source' => 'sales',       'requires' => ['sales']],
        ['id' => 'top-items',        'title' => 'Top Items',        'icon' => 'boxes',       'desc' => 'Top items by revenue contribution for the selected period.',                                          'source' => 'sales',       'requires' => ['sales']],
        ['id' => 'sales-by-city',    'title' => 'Sales by City',    'icon' => 'map-pin',     'desc' => 'Geographic split of revenue across cities/locations.',                                                 'source' => 'sales',       'requires' => ['sales'],       'requiresColumn' => ['role' => 'sales', 'col' => 'city']],
        ['id' => 'purchase-summary', 'title' => 'Purchase Summary', 'icon' => 'shopping-cart', 'desc' => 'Total purchases, supplier count, top suppliers/items for the selected period.',                       'source' => 'purchases',   'requires' => ['purchases']],
        ['id' => 'top-suppliers',    'title' => 'Top Suppliers',    'icon' => 'truck',       'desc' => 'Top suppliers by purchase value for the selected period.',                                            'source' => 'purchases',   'requires' => ['purchases']],
        ['id' => 'outstanding-aging','title' => 'Outstanding Aging','icon' => 'hourglass',   'desc' => 'Receivables broken into 0-30, 31-60, 61-90, 90+ day buckets with top defaulters.',                  'source' => 'outstanding', 'requires' => ['purchases']],
        ['id' => 'stock-valuation',  'title' => 'Stock Valuation',  'icon' => 'package',     'desc' => 'Item-wise inventory value, top SKUs by stock worth, slow-moving alerts.',                              'source' => 'stock',       'requires' => ['sales', 'purchases']],
        ['id' => 'ledger-summary',   'title' => 'Ledger Summary',   'icon' => 'book-open',   'desc' => 'Party-wise net balance (sales − purchases) for every counterparty.',                                  'source' => 'ledger',      'requires' => ['sales']],
        ['id' => 'expense-summary',  'title' => 'Expense Summary',  'icon' => 'receipt',     'desc' => 'Period-wise expenses with category breakdown.',                                                       'source' => 'expenses',    'requires' => ['expenses']],
    ];

    public function __invoke(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', '')) ?? '';
        $explicitTenantId = (string) $request->query('tenant_id', '');

        if ($phone === '' && $explicitTenantId === '') {
            return response()->json(['error' => 'phone required'], 400);
        }

        $tenantId = $explicitTenantId !== ''
            ? $explicitTenantId
            : self::resolveTenantId($phone);

        if ($tenantId === null || $tenantId === '') {
            return response()->json(['error' => 'No tenant found for this phone'], 404);
        }

        try {
            $tenant = Tenant::query()
                ->select(['id', 'name', 'tables_metadata'])
                ->where('id', $tenantId)
                ->first();
            if (! $tenant) {
                return response()->json(['error' => 'Tenant not found'], 404);
            }

            $tablesMeta = $tenant->tables_metadata ?? [];
            if (! is_array($tablesMeta)) {
                $tablesMeta = [];
            }

            // Build role index — keep the largest table per role (most rows wins on ties)
            $roles = [];
            foreach ($tablesMeta as $meta) {
                $kind = TableClassifier::classify($meta);
                if ($kind === 'other') continue;

                $rowCount = (int) ($meta['row_count'] ?? 0);
                if (! isset($roles[$kind]) || $rowCount > (int) ($roles[$kind]['table']['row_count'] ?? 0)) {
                    $roles[$kind] = [
                        'table' => $meta,
                        'cols'  => TableClassifier::resolveColumns($meta, $kind),
                    ];
                }
            }
            $availableRoleKeys = array_keys($roles);

            // Filter catalogue by detected roles + optional column requirements
            $reports = [];
            foreach (self::CATALOG as $r) {
                $allRequiredPresent = true;
                foreach ($r['requires'] as $req) {
                    if (! isset($roles[$req])) {
                        $allRequiredPresent = false;
                        break;
                    }
                }
                if (! $allRequiredPresent) continue;

                if (isset($r['requiresColumn'])) {
                    $needRole = $r['requiresColumn']['role'];
                    $needCol = $r['requiresColumn']['col'];
                    $cols = $roles[$needRole]['cols'] ?? [];
                    $resolved = $cols[$needCol] ?? null;
                    if (! $resolved || empty($resolved['pg_name'])) {
                        continue;
                    }
                }

                $reports[] = [
                    'id'     => $r['id'],
                    'title'  => $r['title'],
                    'desc'   => $r['desc'],
                    'icon'   => $r['icon'],
                    'source' => $r['source'],
                ];
            }

            return response()->json([
                'tenant'         => ['id' => $tenant->id, 'name' => $tenant->name],
                'detected_roles' => $availableRoleKeys,
                'reports'        => $reports,
                'formats'        => ['pdf', 'xlsx'],
            ], 200, ['Cache-Control' => 'no-store']);
        } catch (Throwable $e) {
            Log::error('[/api/reports/list] '.$e->getMessage(), [
                'trace' => substr($e->getTraceAsString(), 0, 500),
            ]);

            return response()->json(['error' => 'Could not list reports: '.$e->getMessage()], 500);
        }
    }

    /**
     * 3-step phone resolution. Mirrors TenantRouter::resolveTenantId — duplicated here to
     * keep the controller self-contained (same pattern other read controllers use).
     */
    private static function resolveTenantId(string $phone): ?string
    {
        $defaultDb = UserDatabase::query()->select('tenant_id')
            ->where('phone', $phone)->where('is_default', true)->first();
        if ($defaultDb?->tenant_id) {
            return $defaultDb->tenant_id;
        }
        $owner = Tenant::query()->select('id')->where('phone', $phone)->first();
        if ($owner?->id) {
            return $owner->id;
        }
        $mapping = TenantPhone::query()->select('tenant_id')->where('phone', $phone)->first();

        return $mapping?->tenant_id;
    }
}
