<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\Tenant;
use App\Models\TenantPhone;
use App\Models\UserDatabase;
use App\Services\Chat\ChatSuggestionsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

/**
 * GET /api/chat-suggestions?phone=&limit=&tenant_id=
 *
 * Schema-aware chat composer chips. Anonymous / unknown phone gets generic
 * fallback chips (never an error — keeps the chat UI useful for not-yet-
 * onboarded users).
 *
 * @see /Users/saranshrajput/Desktop/mis-chatbot/server.js (~line 3608)
 */
final class ChatSuggestionsController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        $limit = min(8, max(2, (int) $request->query('limit', 6)));
        $explicitTenantId = $request->query('tenant_id');

        // Anonymous → generic fallback. Never errors.
        if ((! $phone || strlen($phone) < 10) && ! $explicitTenantId) {
            $fallback = ChatSuggestionsService::build(null, ['limit' => $limit]);

            return response()->json([
                'tenant' => null,
                'roles'  => [],
                'chips'  => $fallback['chips'],
            ]);
        }

        try {
            $tenantId = $explicitTenantId ? (string) $explicitTenantId : $this->resolveTenantId($phone);
            if (! $tenantId) {
                $fallback = ChatSuggestionsService::build(null, ['limit' => $limit]);

                return response()->json([
                    'tenant' => null,
                    'roles'  => [],
                    'chips'  => $fallback['chips'],
                ]);
            }

            $tenant = Tenant::query()
                ->select(['id', 'name', 'tables_metadata'])
                ->where('id', $tenantId)
                ->first();
            if (! $tenant) {
                $fallback = ChatSuggestionsService::build(null, ['limit' => $limit]);

                return response()->json([
                    'tenant' => null,
                    'roles'  => [],
                    'chips'  => $fallback['chips'],
                ]);
            }

            $built = ChatSuggestionsService::build(
                is_array($tenant->tables_metadata) ? $tenant->tables_metadata : null,
                ['limit' => $limit]
            );

            return response()->json([
                'tenant' => ['id' => $tenant->id, 'name' => $tenant->name],
                'roles'  => $built['roles'],
                'chips'  => $built['chips'],
            ]);
        } catch (Throwable $e) {
            // UI never breaks — return generic chips with a soft warning flag
            Log::warning('chat-suggestions failed, returning generic fallback', [
                'phone' => $phone,
                'error' => $e->getMessage(),
            ]);
            $fallback = ChatSuggestionsService::build(null, ['limit' => $limit]);

            return response()->json([
                'tenant' => null,
                'roles'  => [],
                'chips'  => $fallback['chips'],
                '_warn'  => 'fallback chips returned due to internal error',
            ]);
        }
    }

    /** 3-step tenant resolution. */
    private function resolveTenantId(string $phone): ?string
    {
        $defaultDb = UserDatabase::query()->select('tenant_id')
            ->where('phone', $phone)->where('is_default', true)->first();
        if ($defaultDb?->tenant_id) {
            return $defaultDb->tenant_id;
        }
        $owner = Tenant::query()->select('id')->where('phone', $phone)->first();
        if ($owner?->id) {
            return $owner->id;
        }
        $mapping = TenantPhone::query()->select('tenant_id')->where('phone', $phone)->first();

        return $mapping?->tenant_id;
    }
}
