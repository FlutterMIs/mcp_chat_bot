<?php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Models\SheetTabAccess;
use App\Models\Tenant;
use App\Models\TenantPhone;
use App\Models\TenantSheet;
use App\Models\UserDatabase;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Throwable;

final class TabAccessController extends Controller
{
    /**
     * GET /api/tenant/tab-access?phone=
     * Returns all tab access configs for the tenant.
     */
    public function index(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        $tenantId = self::resolve($phone);
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        $configs = SheetTabAccess::query()
            ->where('tenant_id', $tenantId)
            ->orderBy('tenant_sheet_id')
            ->orderBy('tab_name')
            ->get();

        $sheets = TenantSheet::query()
            ->where('tenant_id', $tenantId)
            ->whereIn('status', ['active', 'paused'])
            ->get(['id', 'label', 'sheet_url', 'sheet_id']);

        return response()->json(['configs' => $configs, 'sheets' => $sheets]);
    }

    /**
     * POST /api/tenant/tab-access
     * Body: { phone, configs: [{ tenant_sheet_id, tab_name, pg_table, access_all, access_team, team_match_column, access_client, client_match_column }] }
     */
    public function save(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->input('phone', ''));
        $tenantId = self::resolve($phone);
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        // Permission gate: only the tenant OWNER or a super-admin may change who can
        // see which data. resolve() above matches ANY linked phone (including team
        // members and clients), so without this a non-admin could rewrite the access
        // rules for the whole tenant. The page itself is owner-only (sidebar link is
        // data-requires="owner"), but that's client-side — this enforces it server-side.
        if (!self::isTenantAdmin($phone, $tenantId)) {
            return response()->json(['error' => 'Only the account owner can change access control.'], 403);
        }

        $configs = $request->input('configs', []);
        if (!is_array($configs)) return response()->json(['error' => 'configs must be array'], 400);

        $saved = 0;
        foreach ($configs as $c) {
            if (empty($c['tab_name'])) continue;

            SheetTabAccess::query()->updateOrCreate(
                [
                    'tenant_id' => $tenantId,
                    'tenant_sheet_id' => $c['tenant_sheet_id'] ?? null,
                    'tab_name' => $c['tab_name'],
                ],
                [
                    'pg_table' => $c['pg_table'] ?? null,
                    'access_all' => (bool) ($c['access_all'] ?? false),
                    'access_team' => (bool) ($c['access_team'] ?? false),
                    'team_match_column' => $c['team_match_column'] ?? null,
                    'access_client' => (bool) ($c['access_client'] ?? false),
                    'client_match_column' => $c['client_match_column'] ?? null,
                ]
            );
            $saved++;
        }

        return response()->json(['ok' => true, 'saved' => $saved]);
    }

    /**
     * GET /api/tenant/sheet-columns?phone=&tenant_sheet_id=
     * Returns tabs + their columns for the given sheet.
     */
    public function columns(Request $request): JsonResponse
    {
        $phone = preg_replace('/[^0-9]/', '', (string) $request->query('phone', ''));
        $tenantId = self::resolve($phone);
        if (!$tenantId) return response()->json(['error' => 'No tenant'], 404);

        $sheetId = $request->query('tenant_sheet_id', '');

        // Get tenant's tables_metadata which has all tabs + columns
        $tenant = Tenant::query()->select('tables_metadata')->where('id', $tenantId)->first();
        $meta = $tenant->tables_metadata ?? [];
        $tabs = isset($meta['tabs']) ? $meta['tabs'] : (is_array($meta) ? $meta : []);

        // If specific sheet requested, filter by source
        // Otherwise return all tabs
        $result = [];
        foreach ($tabs as $tab) {
            $tabInfo = [
                'tab_name' => $tab['source_name'] ?? $tab['source_tab'] ?? $tab['name'] ?? '',
                'pg_table' => $tab['pg_table'] ?? '',
                'columns' => [],
            ];
            foreach ($tab['columns'] ?? [] as $col) {
                $tabInfo['columns'][] = $col['pg_name'] ?? $col['name'] ?? '';
            }
            $result[] = $tabInfo;
        }

        return response()->json(['tabs' => $result]);
    }

    private static function resolve(string $phone): ?string
    {
        if (strlen($phone) < 10) return null;
        $d = UserDatabase::query()->select('tenant_id')->where('phone', $phone)->where('is_default', true)->first();
        if ($d?->tenant_id) return $d->tenant_id;
        $o = Tenant::query()->select('id')->where('phone', $phone)->first();
        if ($o?->id) return $o->id;
        $m = TenantPhone::query()->select('tenant_id')->where('phone', $phone)->first();
        return $m?->tenant_id;
    }

    /**
     * Is this phone allowed to manage the tenant's access control?
     * True only for the tenant owner (tenants.phone) or a configured super-admin.
     * Mirrors the owner/super-admin bypass in TenantRouter::computeAccessFilter.
     */
    private static function isTenantAdmin(string $phone, string $tenantId): bool
    {
        if (in_array($phone, (array) config('mis.super_admin_phones', []), true)) {
            return true;
        }

        return Tenant::query()->where('id', $tenantId)->where('phone', $phone)->exists();
    }
}
