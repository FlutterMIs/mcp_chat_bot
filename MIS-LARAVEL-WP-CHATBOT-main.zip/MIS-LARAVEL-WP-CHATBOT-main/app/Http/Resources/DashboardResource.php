<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Transforms dashboard payload for consistent API shape.
 */
class DashboardResource extends JsonResource
{
    public static $wrap = null;

    public function toArray(Request $request): array
    {
        return [
            'tenant'         => $this->resource['tenant'] ?? null,
            'range'          => $this->resource['range'] ?? 'month',
            'widgets'        => $this->resource['widgets'] ?? [],
            'detected_roles' => $this->resource['detected_roles'] ?? [],
            'cached'         => $this->resource['cached'] ?? false,
            'elapsed_ms'     => $this->resource['elapsed_ms'] ?? null,
        ];
    }
}
