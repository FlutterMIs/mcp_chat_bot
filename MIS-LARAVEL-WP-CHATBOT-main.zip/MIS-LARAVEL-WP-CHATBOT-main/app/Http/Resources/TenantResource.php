<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Transforms Tenant model for API responses (check-phone, profile).
 */
class TenantResource extends JsonResource
{
    public static $wrap = null;

    public function toArray(Request $request): array
    {
        return [
            'id'         => $this->id,
            'name'       => $this->name,
            'sheet_url'  => $this->when($this->sheet_url, $this->sheet_url),
            'created_at' => $this->created_at?->toIso8601String(),
        ];
    }
}
