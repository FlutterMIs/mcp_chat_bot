<?php
declare(strict_types=1);
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
class CalendarEventResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->resource['id'] ?? null,
            'title' => $this->resource['title'] ?? $this->resource['summary'] ?? '',
            'start' => $this->resource['start'] ?? null,
            'end' => $this->resource['end'] ?? null,
            'all_day' => $this->resource['all_day'] ?? false,
            'location' => $this->resource['location'] ?? null,
            'attendees' => $this->resource['attendees'] ?? [],
            'meet_link' => $this->resource['meet_link'] ?? null,
        ];
    }
}
