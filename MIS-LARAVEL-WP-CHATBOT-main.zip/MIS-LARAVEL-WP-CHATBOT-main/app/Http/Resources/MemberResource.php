<?php
declare(strict_types=1);
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
class MemberResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'phone' => $this->phone,
            'alias' => $this->alias,
            'permissions' => json_decode($this->permissions ?? '[]', true),
            'is_default' => (bool) $this->is_default,
        ];
    }
}
