<?php
declare(strict_types=1);
namespace App\Http\Resources;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;
class SheetResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'sheet_url' => $this->sheet_url,
            'label' => $this->label,
            'status' => $this->status,
            'last_synced_at' => $this->last_synced_at,
        ];
    }
}
