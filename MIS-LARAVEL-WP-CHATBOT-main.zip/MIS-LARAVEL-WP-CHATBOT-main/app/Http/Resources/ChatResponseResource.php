<?php

declare(strict_types=1);

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

/**
 * Transforms chat response array into consistent API shape.
 *
 * Usage: return new ChatResponseResource($responseArray);
 */
class ChatResponseResource extends JsonResource
{
    /** Disable wrapping in "data" key — chat responses are flat. */
    public static $wrap = null;

    public function toArray(Request $request): array
    {
        return [
            'reply'       => $this->resource['reply'] ?? '',
            'type'        => $this->resource['type'] ?? 'text',
            'intent'      => $this->resource['intent'] ?? null,
            'tenant'      => $this->resource['tenant'] ?? null,
            'elapsed_ms'  => $this->resource['elapsed_ms'] ?? null,
            'chartMeta'   => $this->when(isset($this->resource['chartMeta']), $this->resource['chartMeta'] ?? null),
            'attachments' => $this->when(! empty($this->resource['attachments']), $this->resource['attachments'] ?? null),
            'options'     => $this->when(isset($this->resource['options']), $this->resource['options'] ?? null),
        ];
    }
}
