<?php

declare(strict_types=1);

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SignupRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'phone' => ['required', 'regex:/^\d{10,15}$/'],
            'name' => ['required', 'string', 'max:100'],
            'email' => ['nullable', 'email'],
            'sheet_url' => ['required_without:add_to_existing', 'url'],
            'business_description' => ['nullable', 'string', 'max:500'],
            'add_to_existing' => ['nullable', 'boolean'],
            'tenant_id' => ['nullable', 'uuid'],
        ];
    }

    protected function prepareForValidation(): void
    {
        if ($this->has('phone')) {
            $this->merge(['phone' => preg_replace('/\D/', '', $this->input('phone'))]);
        }
    }
}
