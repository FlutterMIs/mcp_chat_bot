<?php

declare(strict_types=1);

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class CreateClientRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'phone' => ['required', 'regex:/^\d{10,15}$/'],
            'name' => ['required', 'string', 'max:100'],
            'email' => ['nullable', 'email'],
            'sheet_url' => ['nullable', 'url'],
            'wa_key_mode' => ['nullable', 'in:shared,own'],
        ];
    }

    protected function prepareForValidation(): void
    {
        if ($this->has('phone')) {
            $this->merge(['phone' => preg_replace('/\D/', '', $this->input('phone'))]);
        }
    }
}
