<?php

declare(strict_types=1);

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class BookMeetingRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'phone' => ['required', 'regex:/^\d{10,15}$/'],
            'title' => ['required', 'string', 'max:200'],
            'date' => ['required', 'date'],
            'time' => ['nullable', 'string'],
            'duration' => ['nullable', 'integer', 'min:15', 'max:480'],
            'guest_email' => ['nullable', 'email'],
            'force' => ['nullable', 'boolean'],
        ];
    }

    protected function prepareForValidation(): void
    {
        if ($this->has('phone')) {
            $this->merge(['phone' => preg_replace('/\D/', '', $this->input('phone'))]);
        }
    }
}
