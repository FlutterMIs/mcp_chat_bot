<?php

declare(strict_types=1);

namespace App\DataTransferObjects;

final readonly class ChatRequest
{
    public function __construct(
        public string $phone,
        public string $message,
        public ?string $sessionId = null,
        public string $source = 'web', // 'web' | 'whatsapp'
    ) {}

    public static function fromArray(array $data): self
    {
        return new self(
            phone: $data['phone'],
            message: $data['message'],
            sessionId: $data['session_id'] ?? null,
            source: $data['source'] ?? 'web',
        );
    }
}
