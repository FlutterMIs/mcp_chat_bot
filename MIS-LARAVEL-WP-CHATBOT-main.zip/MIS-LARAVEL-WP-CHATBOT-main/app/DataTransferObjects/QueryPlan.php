<?php

declare(strict_types=1);

namespace App\DataTransferObjects;

use App\Enums\QueryMode;

final readonly class QueryPlan
{
    public function __construct(
        public string $sql,
        public QueryMode $mode,
        public string $confidence = 'HIGH', // HIGH | MEDIUM | LOW
        public ?string $formatInstruction = null,
        public ?string $naturalQuery = null,
    ) {}

    public function isLowConfidence(): bool
    {
        return $this->confidence === 'LOW';
    }
}
