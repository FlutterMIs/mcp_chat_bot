<?php

declare(strict_types=1);

namespace App\DataTransferObjects;

use App\Enums\UserRole;
use App\Models\Tenant;

final readonly class TenantContext
{
    public function __construct(
        public Tenant $tenant,
        public UserRole $role,
        public string $phone,
        public ?AccessFilter $accessFilter = null,
    ) {}

    public function hasFullAccess(): bool
    {
        return $this->role->hasFullAccess();
    }

    public function tenantId(): string
    {
        return $this->tenant->id;
    }

    public function tenantName(): string
    {
        return $this->tenant->name;
    }
}
