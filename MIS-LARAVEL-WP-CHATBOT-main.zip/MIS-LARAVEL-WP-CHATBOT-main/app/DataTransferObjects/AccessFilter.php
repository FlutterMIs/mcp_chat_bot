<?php

declare(strict_types=1);

namespace App\DataTransferObjects;

use App\Enums\UserRole;

final readonly class AccessFilter
{
    public function __construct(
        public UserRole $role,
        public array $allowedTables = [],
        public array $mandatoryWheres = [],
    ) {}

    public function hasMandatoryWheres(): bool
    {
        return ! empty($this->mandatoryWheres);
    }

    public function isRestricted(): bool
    {
        return ! empty($this->mandatoryWheres) || ! empty($this->allowedTables);
    }
}
