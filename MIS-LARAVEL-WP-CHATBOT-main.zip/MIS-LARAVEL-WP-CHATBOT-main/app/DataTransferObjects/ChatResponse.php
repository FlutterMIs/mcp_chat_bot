<?php

declare(strict_types=1);

namespace App\DataTransferObjects;

use App\Enums\ChatIntent;

final readonly class ChatResponse
{
    public function __construct(
        public string $reply,
        public ChatIntent $intent,
        public ?string $sql = null,
        public ?array $rows = null,
        public ?array $media = null,
        public ?int $elapsedMs = null,
        public ?string $tenantName = null,
    ) {}

    public static function noTenant(): self
    {
        return new self(reply: '', intent: ChatIntent::Ignore);
    }

    public static function greeting(string $reply): self
    {
        return new self(reply: $reply, intent: ChatIntent::Greeting);
    }

    public function hasMedia(): bool
    {
        return $this->media !== null;
    }

    public function toArray(): array
    {
        return array_filter([
            'reply'      => $this->reply,
            'intent'     => $this->intent->value,
            'sql'        => $this->sql,
            'rows'       => $this->rows,
            'media'      => $this->media,
            'elapsed_ms' => $this->elapsedMs,
            'tenant'     => $this->tenantName,
        ], fn ($v) => $v !== null);
    }
}
