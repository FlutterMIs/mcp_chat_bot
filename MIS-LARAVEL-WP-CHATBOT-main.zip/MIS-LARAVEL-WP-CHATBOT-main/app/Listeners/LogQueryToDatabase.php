<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\QueryProcessed;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Throwable;

class LogQueryToDatabase implements ShouldQueue
{
    public function handle(QueryProcessed $event): void
    {
        try {
            DB::table('tenant_query_logs')->insert([
                'id'         => (string) \Illuminate\Support\Str::uuid(),
                'tenant_id'  => $event->tenantId,
                'phone'      => $event->phone,
                'query'      => $event->query,
                'intent'     => $event->intent,
                'sql'        => $event->sql,
                'row_count'  => $event->rowCount,
                'elapsed_ms' => $event->elapsedMs,
                'created_at' => now(),
            ]);
        } catch (Throwable $e) {
            Log::warning('[LogQueryToDatabase] ' . $e->getMessage());
        }
    }
}
