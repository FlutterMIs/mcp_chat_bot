<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\TenantSynced;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Throwable;

class WarmDashboardCache implements ShouldQueue
{
    public function handle(TenantSynced $event): void
    {
        try {
            // Clear stale cache so next request rebuilds fresh
            Cache::forget("dashboard:{$event->tenantId}:month");
            Cache::forget("page:{$event->tenantId}:sales");
            Cache::forget("page:{$event->tenantId}:outstanding");
            Cache::forget("page:{$event->tenantId}:stock");
            Cache::forget("page:{$event->tenantId}:ledger");
        } catch (Throwable $e) {
            Log::warning('[WarmDashboardCache] ' . $e->getMessage());
        }
    }
}
