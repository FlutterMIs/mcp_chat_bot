<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\QueryProcessed;
use App\Services\AI\QueryMemory;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Log;
use Throwable;

class SaveToQueryMemory implements ShouldQueue
{
    public function handle(QueryProcessed $event): void
    {
        if (! $event->sql || $event->rowCount === 0) {
            return;
        }

        try {
            QueryMemory::save(
                $event->tenantId,
                $event->query,
                $event->sql,
                $event->rowCount,
            );
        } catch (Throwable $e) {
            Log::warning('[SaveToQueryMemory] ' . $e->getMessage());
        }
    }
}
