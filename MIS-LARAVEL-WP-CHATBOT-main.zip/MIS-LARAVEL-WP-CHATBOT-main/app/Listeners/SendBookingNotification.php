<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\MeetingBooked;
use App\Services\Notifications\TenantNotificationService;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Log;
use Throwable;

class SendBookingNotification implements ShouldQueue
{
    public function handle(MeetingBooked $event): void
    {
        try {
            TenantNotificationService::notifyBooking(
                $event->tenantId,
                $event->phone,
                $event->title,
                $event->startTime,
                $event->guestEmail,
            );
        } catch (Throwable $e) {
            Log::warning('[SendBookingNotification] ' . $e->getMessage());
        }
    }
}
