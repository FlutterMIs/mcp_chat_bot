<?php

declare(strict_types=1);

namespace App\Events;

use Illuminate\Foundation\Events\Dispatchable;

class QueryFailed
{
    use Dispatchable;

    public function __construct(
        public readonly string $tenantId,
        public readonly string $phone,
        public readonly string $query,
        public readonly string $error,
        public readonly ?string $sql = null,
    ) {}
}
