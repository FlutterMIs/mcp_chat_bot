<?php

declare(strict_types=1);

namespace App\Events;

use Illuminate\Foundation\Events\Dispatchable;

class TenantSynced
{
    use Dispatchable;

    public function __construct(
        public readonly string $tenantId,
        public readonly int $rowCount = 0,
        public readonly int $tabCount = 0,
        public readonly array $drift = [],
    ) {}
}
