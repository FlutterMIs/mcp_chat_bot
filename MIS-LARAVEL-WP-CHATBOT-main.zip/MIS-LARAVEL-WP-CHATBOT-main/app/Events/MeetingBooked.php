<?php

declare(strict_types=1);

namespace App\Events;

use Illuminate\Foundation\Events\Dispatchable;

class MeetingBooked
{
    use Dispatchable;

    public function __construct(
        public readonly string $tenantId,
        public readonly string $phone,
        public readonly string $title,
        public readonly string $startTime,
        public readonly ?string $guestEmail = null,
    ) {}
}
