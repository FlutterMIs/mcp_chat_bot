<?php

declare(strict_types=1);

namespace App\Events;

use Illuminate\Foundation\Events\Dispatchable;

class QueryProcessed
{
    use Dispatchable;

    public function __construct(
        public readonly string $tenantId,
        public readonly string $phone,
        public readonly string $query,
        public readonly string $intent,
        public readonly ?string $sql = null,
        public readonly int $rowCount = 0,
        public readonly int $elapsedMs = 0,
    ) {}
}
