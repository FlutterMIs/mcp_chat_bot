<?php
declare(strict_types=1);
namespace App\Events;
use Illuminate\Foundation\Events\Dispatchable;
class SheetRemoved
{
    use Dispatchable;
    public function __construct(
        public readonly string $tenantId,
        public readonly string $sheetId,
        public readonly array $droppedTables = [],
    ) {}
}
