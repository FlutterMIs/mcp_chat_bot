<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TenantApiKey extends Model
{
    protected $fillable = ['tenant_id', 'label', 'api_key', 'base_url', 'access_level', 'status', 'type', 'device_id'];

    /**
     * Get active keys accessible by a given role.
     */
    public static function accessible(string $tenantId, string $role): array
    {
        $levels = match ($role) {
            'super_admin', 'owner' => ['everyone', 'team', 'owner'],
            'member' => ['everyone', 'team'],
            default => ['everyone'],
        };

        return self::where('tenant_id', $tenantId)
            ->where('status', 'active')
            ->whereIn('access_level', $levels)
            ->get()
            ->toArray();
    }
}
