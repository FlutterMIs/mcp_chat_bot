<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;

class SheetTabAccess extends Model
{
    use HasUuids;

    protected $table = 'sheet_tab_access';
    protected $keyType = 'string';
    public $incrementing = false;
    protected $guarded = ['id'];

    protected $casts = [
        'access_all' => 'boolean',
        'access_team' => 'boolean',
        'access_client' => 'boolean',
    ];
}
