<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * TenantData — legacy JSONB row cache.
 *
 * Phase 6 (proper-tables) replaced this for active queries, but rows are still
 * written for tenants who haven't migrated to per-table schema yet.
 *
 * @property string $id
 * @property string $tenant_id
 * @property string $sheet_name
 * @property ?string $table_name
 * @property array $row_data
 * @property ?int $row_index
 */
class TenantData extends Model
{
    use HasUuids;

    protected $table = 'tenant_data';

    protected $keyType = 'string';

    public $incrementing = false;

    public $timestamps = false; // synced_at managed via DB default

    const CREATED_AT = null;

    const UPDATED_AT = 'synced_at';

    protected $guarded = ['id'];

    protected $casts = [
        'row_data'  => 'array',
        'row_index' => 'integer',
        'synced_at' => 'datetime',
    ];

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }
}
