<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * AdminActivityLog — captures administrative events for audit trails.
 *
 * @property int $id
 * @property string $action
 * @property string $performed_by
 * @property ?string $target_id
 * @property ?string $target_name
 * @property ?array $details
 * @property \Carbon\Carbon $created_at
 */
final class AdminActivityLog extends Model
{
    protected $table = 'admin_activity_logs';

    public $timestamps = false; // only using created_at

    protected $fillable = [
        'action',
        'performed_by',
        'target_id',
        'target_name',
        'details',
    ];

    protected $casts = [
        'details'    => 'array',
        'created_at' => 'datetime',
    ];
}
