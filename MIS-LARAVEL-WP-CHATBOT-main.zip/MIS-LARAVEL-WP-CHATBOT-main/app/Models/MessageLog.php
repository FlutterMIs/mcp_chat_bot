<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * MessageLog — every inbound + outbound chat message audit trail.
 *
 * @property int $id
 * @property ?string $tenant_id
 * @property string $platform     whatsapp | web
 * @property string $direction    in | out
 * @property ?string $phone
 * @property ?string $session_id
 * @property string $message_type text | audio | image | document
 * @property ?string $message     truncated to 5000 chars at insert time
 * @property \Illuminate\Support\Carbon $created_at
 */
class MessageLog extends Model
{
    protected $table = 'message_logs';

    public $timestamps = false;

    const CREATED_AT = 'created_at';

    const UPDATED_AT = null;

    protected $guarded = ['id'];

    protected $casts = [
        'created_at' => 'datetime',
    ];
}
