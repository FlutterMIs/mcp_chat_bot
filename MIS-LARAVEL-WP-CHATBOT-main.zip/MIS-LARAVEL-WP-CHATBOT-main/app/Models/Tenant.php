<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;

/**
 * Tenant — central record per customer/business in the SaaS platform.
 *
 * Owns:
 *   - tenantPhones: extra WhatsApp numbers that can query this tenant's data
 *   - userDatabases: phone-to-tenant mappings (one phone can own many tenants)
 *   - queryLogs: AI query audit trail
 *   - notifications: bell-icon feed entries
 *
 * @property string $id
 * @property string $name
 * @property string $phone
 * @property ?string $email
 * @property ?string $sheet_url
 * @property ?string $sheet_id
 * @property ?string $business_description
 * @property ?string $system_prompt
 * @property ?array $schema_json
 * @property string $status
 * @property string $plan
 * @property int $queries_this_month
 * @property int $query_limit
 * @property ?string $calendar_id
 * @property ?string $calendar_refresh_token
 * @property bool $calendar_connected
 * @property bool $proper_tables_created
 * @property array $tables_metadata
 * @property string $wa_key_mode        'shared' or 'own'
 * @property ?string $wa_connected_number
 * @property string $wa_channel_mode      'unprofessional' or 'professional'
 * @property ?string $webhook_token
 */
class Tenant extends Model
{
    use HasUuids, SoftDeletes;

    protected $table = 'tenants';

    protected $keyType = 'string';

    public $incrementing = false;

    public $timestamps = true;

    protected $fillable = [
        'name',
        'phone',
        'email',
        'sheet_url',
        'sheet_id',
        'business_description',
        'system_prompt',
        'schema_json',
        'status',
        'plan',
        'queries_this_month',
        'query_limit',
        'calendar_id',
        'calendar_refresh_token',
        'calendar_connected',
        'wa_key_mode',
        'wa_connected_number',
        'wa_channel_mode',
        'wa_pro_api_key',
        'webhook_token',
        'ai_vendor',
        'ai_model',
        'ai_api_key',
        'proper_tables_created',
        'tables_metadata',
        'deleted_by',
    ];

    protected static function booted(): void
    {
        static::creating(function (Tenant $tenant) {
            if (empty($tenant->webhook_token)) {
                $tenant->webhook_token = self::generateUniqueToken();
            }
        });
    }

    /** Generate a unique 10-char alphanumeric token. */
    public static function generateUniqueToken(): string
    {
        do {
            $token = Str::lower(Str::random(10));
        } while (static::where('webhook_token', $token)->exists());
        return $token;
    }

    protected $casts = [
        'schema_json'           => 'array',
        'tables_metadata'       => 'array',
        'queries_this_month'    => 'integer',
        'query_limit'           => 'integer',
        'calendar_connected'    => 'boolean',
        'proper_tables_created' => 'boolean',
        'created_at'            => 'datetime',
        'updated_at'            => 'datetime',
    ];

    public function tenantPhones(): HasMany
    {
        return $this->hasMany(TenantPhone::class);
    }

    public function userDatabases(): HasMany
    {
        return $this->hasMany(UserDatabase::class);
    }

    public function queryLogs(): HasMany
    {
        return $this->hasMany(TenantQueryLog::class);
    }

    public function notifications(): HasMany
    {
        return $this->hasMany(TenantNotification::class);
    }

    public function tenantData(): HasMany
    {
        return $this->hasMany(TenantData::class);
    }

    /**
     * Convenience accessor — returns true if the tenant has a non-empty
     * tables_metadata array (i.e. Phase 6 proper-tables sync has run).
     */
    public function hasProperTables(): bool
    {
        return $this->proper_tables_created && ! empty($this->tables_metadata);
    }
}
