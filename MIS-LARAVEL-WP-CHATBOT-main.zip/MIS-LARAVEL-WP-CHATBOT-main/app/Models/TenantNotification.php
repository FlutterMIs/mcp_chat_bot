<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * TenantNotification — bell-icon notification feed entry.
 *
 * Sources: schema_drift, sync_error, calendar_book, calendar_remind,
 * tenant_signup, info | warning | error.
 *
 * @property int $id
 * @property string $tenant_id
 * @property ?string $phone
 * @property string $kind
 * @property string $title
 * @property ?string $message
 * @property array $metadata
 * @property string $severity  info | warning | error
 * @property ?\Illuminate\Support\Carbon $read_at
 * @property \Illuminate\Support\Carbon $created_at
 */
class TenantNotification extends Model
{
    protected $table = 'tenant_notifications';

    public $timestamps = false;

    const CREATED_AT = 'created_at';

    const UPDATED_AT = null;

    protected $guarded = ['id'];

    protected $casts = [
        'metadata'   => 'array',
        'read_at'    => 'datetime',
        'created_at' => 'datetime',
    ];

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    /** Scope: only unread notifications. */
    public function scopeUnread(Builder $q): Builder
    {
        return $q->whereNull('read_at');
    }

    public function markRead(): void
    {
        if (! $this->read_at) {
            $this->forceFill(['read_at' => now()])->save();
        }
    }
}
