<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * SyncLog — per-table sync run history (Google Sheets + XLSX).
 *
 * @property int $id
 * @property string $sheet_name
 * @property int $rows_synced
 * @property string $status   "success" | "error: <message>"
 * @property \Illuminate\Support\Carbon $created_at
 */
class SyncLog extends Model
{
    protected $table = 'sync_log';

    public $timestamps = false;

    const CREATED_AT = 'created_at';

    const UPDATED_AT = null;

    protected $guarded = ['id'];

    protected $casts = [
        'rows_synced' => 'integer',
        'created_at'  => 'datetime',
    ];
}
