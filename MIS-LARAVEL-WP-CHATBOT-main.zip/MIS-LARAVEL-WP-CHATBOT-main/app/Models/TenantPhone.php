<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * TenantPhone — one WhatsApp number that can query a tenant's data.
 *
 * @property string $id
 * @property string $tenant_id
 * @property string $phone
 * @property string $role  owner | admin | user
 */
class TenantPhone extends Model
{
    use HasUuids;

    protected $table = 'tenant_phones';

    protected $keyType = 'string';

    public $incrementing = false;

    public $timestamps = false; // only created_at exists; we set it via DB default

    protected $guarded = ['id'];

    protected $casts = [
        'created_at' => 'datetime',
    ];

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }
}
