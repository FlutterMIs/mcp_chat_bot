<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * ChatHistory — replayable conversation buffer for /chat reload (last 50 msgs).
 *
 * @property int $id
 * @property string $session_id
 * @property string $role   system | user | assistant
 * @property string $content
 * @property ?string $tenant_id
 * @property \Illuminate\Support\Carbon $created_at
 */
class ChatHistory extends Model
{
    protected $table = 'chat_history';

    public $timestamps = false;

    const CREATED_AT = 'created_at';

    const UPDATED_AT = null;

    protected $guarded = ['id'];

    protected $casts = [
        'created_at' => 'datetime',
    ];

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }
}
