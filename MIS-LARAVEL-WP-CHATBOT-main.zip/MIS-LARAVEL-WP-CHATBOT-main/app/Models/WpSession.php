<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * WpSession — multi-turn calendar / ledger pending-state per phone.
 *
 * Phone is the primary key; data is a free-form JSONB blob holding whatever
 * the in-flight conversation needs (e.g. pending booking title, awaiting-time
 * flag, ledger disambiguation choices).
 *
 * @property string $phone
 * @property array $data
 * @property \Illuminate\Support\Carbon $updated_at
 */
class WpSession extends Model
{
    protected $table = 'wp_sessions';

    protected $primaryKey = 'phone';

    protected $keyType = 'string';

    public $incrementing = false;

    public $timestamps = false;

    const CREATED_AT = null;

    const UPDATED_AT = 'updated_at';

    protected $guarded = [];

    protected $casts = [
        'data'       => 'array',
        'updated_at' => 'datetime',
    ];
}
