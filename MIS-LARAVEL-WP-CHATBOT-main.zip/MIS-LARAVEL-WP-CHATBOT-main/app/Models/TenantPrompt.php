<?php

declare(strict_types=1);

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Cache;

class TenantPrompt extends Model
{
    public $timestamps = false;

    protected $fillable = ['tenant_id', 'prompt_key', 'prompt_value', 'updated_at'];

    /** Valid prompt keys that admins can edit */
    public const KEYS = [
        'response_style',    // How bot formats website/PDF answers
        'data_format',       // How bot formats data query replies
        'bot_personality',   // Greeting, tone, sign-off
        'company_context',   // Background info about the business
    ];

    /**
     * Get a prompt value for a tenant (cached 5 min).
     */
    public static function get(string $tenantId, string $key): ?string
    {
        return Cache::remember("tenant_prompt:{$tenantId}:{$key}", 30, function () use ($tenantId, $key) {
            return self::where('tenant_id', $tenantId)->where('prompt_key', $key)->value('prompt_value');
        });
    }

    /**
     * Get all prompts for a tenant as key=>value array.
     */
    public static function allFor(string $tenantId): array
    {
        $rows = self::where('tenant_id', $tenantId)->pluck('prompt_value', 'prompt_key')->toArray();
        // Return all keys with empty string defaults
        $result = [];
        foreach (self::KEYS as $k) {
            $result[$k] = $rows[$k] ?? '';
        }
        return $result;
    }

    /**
     * Save a prompt (upsert) and clear cache.
     */
    public static function set(string $tenantId, string $key, string $value): void
    {
        self::updateOrCreate(
            ['tenant_id' => $tenantId, 'prompt_key' => $key],
            ['prompt_value' => $value, 'updated_at' => now()]
        );
        Cache::forget("tenant_prompt:{$tenantId}:{$key}");
    }

    /**
     * Universal format instruction for AI formatting calls.
     * Returns the full system-level instruction string to inject into any AI formatting prompt.
     * Returns empty string if no custom format is set.
     *
     * @param  bool  $webMode  true = web chat panel (plain Markdown fallback wording),
     *                         false = WhatsApp (default — unchanged from before).
     */
    public static function getFormatInstruction(string $tenantId, bool $webMode = false): string
    {
        $format = self::get($tenantId, 'data_format') ?? '';
        if ($format === '') return '';
        $fallback = $webMode
            ? "If the data type doesn't match any format template above, use clean Markdown with **bold** labels and `-` bullet lists."
            : "If the data type doesn't match any format template above, use clean WhatsApp formatting with *bold* labels and emojis. Always use WhatsApp *bold* (not markdown **bold**).";
        return "\n\nCRITICAL CUSTOM FORMAT (follow EXACTLY, override all other formatting rules):\n{$format}\n\n{$fallback}";
    }
}
