<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * UserDatabase — many-to-many mapping between phones and tenants.
 *
 * One phone can be linked to multiple separate databases (e.g. owner of two
 * shops). is_default marks the auto-selected DB for that phone; users change
 * it via the `switch db` chat command.
 *
 * @property string $id
 * @property string $phone
 * @property string $tenant_id
 * @property ?string $alias
 * @property bool $is_default
 */
class UserDatabase extends Model
{
    use HasUuids;

    protected $table = 'user_databases';

    protected $keyType = 'string';

    public $incrementing = false;

    public $timestamps = false;

    const CREATED_AT = 'created_at';

    const UPDATED_AT = null;

    protected $guarded = ['id'];

    protected $casts = [
        'is_default' => 'boolean',
        'created_at' => 'datetime',
    ];

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }
}
