<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * CalendarLog — booking / reschedule / cancel event log.
 *
 * @property int $id
 * @property ?string $phone
 * @property ?string $tenant_id
 * @property string $action  booked | cancelled | rescheduled
 * @property ?string $event_id
 * @property ?string $title
 * @property ?string $guest
 * @property ?string $guest_email
 * @property ?\Illuminate\Support\Carbon $starts_at
 * @property ?\Illuminate\Support\Carbon $ends_at
 * @property array $metadata
 * @property \Illuminate\Support\Carbon $created_at
 */
class CalendarLog extends Model
{
    protected $table = 'calendar_logs';

    public $timestamps = false;

    const CREATED_AT = 'created_at';

    const UPDATED_AT = null;

    protected $guarded = ['id'];

    protected $casts = [
        'metadata'   => 'array',
        'starts_at'  => 'datetime',
        'ends_at'    => 'datetime',
        'created_at' => 'datetime',
    ];

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }
}
