<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * TenantQueryLog — audit row per AI query.
 *
 * Captures the original natural-language input, generated SQL, formatted
 * response and OpenAI tokens consumed. Drives the per-month query quota and
 * is invaluable for debugging AI hallucinations.
 *
 * @property string $id
 * @property string $tenant_id
 * @property ?string $phone
 * @property ?string $query
 * @property ?string $sql_generated
 * @property ?string $response
 * @property ?int $tokens_used
 */
class TenantQueryLog extends Model
{
    use HasUuids;

    protected $table = 'tenant_query_logs';

    protected $keyType = 'string';

    public $incrementing = false;

    public $timestamps = false;

    const CREATED_AT = 'created_at';

    const UPDATED_AT = null;

    protected $guarded = ['id'];

    protected $casts = [
        'tokens_used' => 'integer',
        'created_at'  => 'datetime',
    ];

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }
}
