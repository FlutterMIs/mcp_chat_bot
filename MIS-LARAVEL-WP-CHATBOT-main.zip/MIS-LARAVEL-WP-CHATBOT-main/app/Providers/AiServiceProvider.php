<?php

declare(strict_types=1);

namespace App\Providers;

use App\Contracts\AI\AiClientInterface;
use App\Services\AI\AiGateway;
use Illuminate\Support\ServiceProvider;

class AiServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(AiClientInterface::class, AiGateway::class);
    }
}
