<?php

declare(strict_types=1);

namespace App\Providers;

use App\Events\MeetingBooked;
use App\Events\MeetingCancelled;
use App\Events\QueryFailed;
use App\Events\QueryProcessed;
use App\Events\TenantSynced;
use App\Listeners\LogQueryToDatabase;
use App\Listeners\SaveToQueryMemory;
use App\Listeners\SendBookingNotification;
use App\Listeners\WarmDashboardCache;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    /** @var array<class-string, array<int, class-string>> */
    protected $listen = [
        QueryProcessed::class => [
            LogQueryToDatabase::class,
            SaveToQueryMemory::class,
        ],
        QueryFailed::class => [
            LogQueryToDatabase::class,
        ],
        MeetingBooked::class => [
            SendBookingNotification::class,
        ],
        MeetingCancelled::class => [
            // SendCancellationNotification::class (future)
        ],
        TenantSynced::class => [
            WarmDashboardCache::class,
        ],
    ];
}
