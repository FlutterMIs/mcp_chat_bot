<?php

declare(strict_types=1);

namespace App\Providers;

use App\Contracts\Chat\ResponseFormatterInterface;
use App\Contracts\WhatsApp\WhatsAppClientInterface;
use App\Services\Chat\SmartFormatter;
use App\Services\WhatsApp\Client;
use Illuminate\Support\ServiceProvider;

class ChatServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->app->bind(ResponseFormatterInterface::class, SmartFormatter::class);
        $this->app->bind(WhatsAppClientInterface::class, Client::class);
    }
}
