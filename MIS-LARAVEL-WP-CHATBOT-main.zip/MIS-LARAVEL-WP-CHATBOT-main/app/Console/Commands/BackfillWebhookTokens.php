<?php

namespace App\Console\Commands;

use App\Models\Tenant;
use Illuminate\Console\Command;

class BackfillWebhookTokens extends Command
{
    protected $signature = 'tenants:backfill-tokens';
    protected $description = 'Generate webhook_token for existing tenants that do not have one';

    public function handle(): int
    {
        $tenants = Tenant::whereNull('webhook_token')->get();
        $count = 0;

        foreach ($tenants as $tenant) {
            $tenant->webhook_token = Tenant::generateUniqueToken();
            $tenant->save();
            $count++;
        }

        $this->info("Generated webhook tokens for {$count} tenant(s).");
        return 0;
    }
}
