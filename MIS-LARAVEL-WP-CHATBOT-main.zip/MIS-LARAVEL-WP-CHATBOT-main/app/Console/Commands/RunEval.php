<?php

namespace App\Console\Commands;

use App\Eval\EvalRunner;
use App\Eval\EvalTestCases;
use Illuminate\Console\Command;

class RunEval extends Command
{
    protected $signature = 'eval:run
        {--tenant= : Tenant ID to run against}
        {--phone= : Phone number for tests}
        {--category= : Run only this category}
        {--dry-run : Show test cases without executing}
        {--orchestrator : Test orchestrator decisions only (no DB queries)}
        {--verbose-failures : Show full SQL and reply on failures}';

    protected $description = 'Run the MIS chatbot evaluation suite (55+ test cases across 15 categories)';

    public function handle(): int
    {
        $tenantId = $this->option('tenant');
        $phone = $this->option('phone');
        $category = $this->option('category');
        $dryRun = (bool) $this->option('dry-run');
        $orchestratorOnly = (bool) $this->option('orchestrator');
        $verboseFailures = (bool) $this->option('verbose-failures');

        // Auto-detect tenant if not provided
        if (!$tenantId) {
            $tenant = \App\Models\Tenant::query()->whereNotNull('tables_metadata')->first();
            if ($tenant) {
                $tenantId = $tenant->id;
                $this->line("Auto-detected tenant: <info>{$tenant->name}</info> ({$tenantId})");
            } else {
                $this->error('No tenant with synced data found. Use --tenant=ID');
                return 1;
            }
        }

        $cases = EvalTestCases::all();
        $totalCases = count($cases);

        $this->newLine();
        $this->line("🧪 <info>MIS Chatbot Eval Suite</info>");
        $this->line("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $this->line("  Tenant:       {$tenantId}");
        $this->line("  Mode:         " . ($dryRun ? 'DRY RUN' : ($orchestratorOnly ? 'ORCHESTRATOR ONLY' : 'FULL PIPELINE')));
        $this->line("  Category:     " . ($category ?? 'ALL'));
        $this->line("  Total cases:  {$totalCases}");
        $this->line("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $this->newLine();

        if ($category && !in_array($category, EvalTestCases::categories())) {
            $this->error("Unknown category: {$category}");
            $this->line("Available: " . implode(', ', EvalTestCases::categories()));
            return 1;
        }

        $runner = new EvalRunner($tenantId, $phone, $dryRun, $orchestratorOnly);
        $results = $runner->run($cases, $category);

        // Display results
        foreach ($results['details'] as $r) {
            $icon = match ($r['status']) {
                'PASS' => '✅',
                'FAIL' => '❌',
                'SKIP' => '⏭️',
            };

            $line = "{$icon} [{$r['id']}] {$r['query']}";

            if ($r['status'] === 'FAIL' && !empty($r['failures'])) {
                $line .= " — <fg=red>" . implode('; ', $r['failures']) . "</>";
                $this->line($line);
                if ($verboseFailures && $r['sql']) {
                    $this->line("     SQL: <fg=gray>{$r['sql']}</>");
                }
            } elseif ($r['status'] === 'SKIP') {
                $line .= " — <fg=yellow>{$r['note']}</>";
                $this->line($line);
            } else {
                $elapsed = $r['elapsed'] ? " ({$r['elapsed']}ms)" : '';
                $this->line("{$line}{$elapsed}");
            }
        }

        // Summary
        $this->newLine();
        $this->line("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        $scoreColor = $results['score'] >= 90 ? 'green' : ($results['score'] >= 70 ? 'yellow' : 'red');
        $this->line("  <fg={$scoreColor}>Score: {$results['score']}%</> ({$results['passed']}/{$results['total']} passed)");
        $this->line("  ✅ Passed: {$results['passed']}  ❌ Failed: {$results['failed']}  ⏭️ Skipped: {$results['skipped']}");
        $this->line("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

        // Category breakdown
        if (!$category) {
            $this->newLine();
            $this->line("<info>Category Breakdown:</info>");
            $catStats = [];
            foreach ($results['details'] as $r) {
                $cat = $r['category'];
                if (!isset($catStats[$cat])) $catStats[$cat] = ['pass' => 0, 'fail' => 0, 'skip' => 0];
                $catStats[$cat][$r['status'] === 'PASS' ? 'pass' : ($r['status'] === 'FAIL' ? 'fail' : 'skip')]++;
            }
            foreach ($catStats as $cat => $s) {
                $total = $s['pass'] + $s['fail'] + $s['skip'];
                $pct = $total > 0 ? round(($s['pass'] / $total) * 100) : 0;
                $icon = $pct === 100 ? '🟢' : ($pct >= 50 ? '🟡' : '🔴');
                $this->line("  {$icon} {$cat}: {$s['pass']}/{$total} ({$pct}%)");
            }
        }

        return $results['failed'] > 0 ? 1 : 0;
    }
}
