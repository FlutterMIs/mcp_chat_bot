<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use App\Models\TenantApiKey;
use App\Models\Tenant;

class SyncExternalApis extends Command
{
    protected $signature = 'sync:external-apis {--tenant= : Specific tenant ID} {--force : Drop and recreate tables}';
    protected $description = 'Sync all external API data (apps.apimis.co.in) into local MySQL tables for accurate SQL querying';

    private const ENDPOINTS = [
        'call_logs'       => ['path' => '/getAllCallRecords', 'dateParams' => ['fromDate', 'toDate']],
        'delegation'      => ['path' => '/googleSheetDelegation', 'dateParams' => ['fromDate', 'toDate']],
        'checklist'       => ['path' => '/googleSheetchecklist', 'dateParams' => ['fromDate', 'toDate']],
        'leads'           => ['path' => '/leadDataSheet', 'dateParams' => ['fromDate', 'toDate']],
        'lead_followups'  => ['path' => '/leadFollowupSheet', 'dateParams' => ['startDate', 'endDate']],
        'visiting_cards'  => ['path' => '/visitingGetDataSheet', 'dateParams' => ['fromDate', 'toDate']],
    ];

    public function handle(): int
    {
        $tenantId = $this->option('tenant');
        $force = (bool) $this->option('force');

        $tenants = $tenantId
            ? Tenant::where('id', $tenantId)->get()
            : Tenant::all();

        foreach ($tenants as $tenant) {
            $keys = TenantApiKey::where('tenant_id', $tenant->id)->where('status', 'active')->get();
            if ($keys->isEmpty()) continue;

            $this->info("Syncing tenant: {$tenant->name} ({$tenant->id})");
            $prefix = 'tenant_' . substr($tenant->id, 0, 8) . '_api_';

            foreach ($keys as $key) {
                foreach (self::ENDPOINTS as $name => $config) {
                    $table = $prefix . $name;
                    $this->syncEndpoint($table, $config, $key->api_key, $key->base_url, $name, $tenant->id, $force);
                }
            }

            // Update tenant's tables_metadata to include API tables
            $this->updateMetadata($tenant, $prefix);
        }

        $this->info('Done.');
        return 0;
    }

    private function syncEndpoint(string $table, array $config, string $apiKey, string $baseUrl, string $name, string $tenantId, bool $force): void
    {
        $url = rtrim($baseUrl, '/') . $config['path'];
        [$dateFrom, $dateTo] = $config['dateParams'];

        $body = ['clientApiKey' => $apiKey, $dateFrom => '2020-01-01', $dateTo => date('Y-m-d')];
        $resp = Http::timeout(60)->post($url, $body);

        if (!$resp->ok()) {
            $this->warn("  ✗ {$name}: HTTP {$resp->status()}");
            return;
        }

        $data = $resp->json();
        $records = $data['data'] ?? $data['records'] ?? [];

        if (!is_array($records) || empty($records)) {
            $this->line("  ○ {$name}: 0 records");
            return;
        }

        // Create or update table
        if ($force || !Schema::hasTable($table)) {
            $this->createTable($table, $records[0]);
        }

        // Truncate and re-insert (full sync)
        DB::table($table)->truncate();

        // Insert in chunks
        $chunks = array_chunk($records, 100);
        foreach ($chunks as $chunk) {
            $rows = array_map(fn($r) => $this->normalizeRow($r, $table), $chunk);
            try {
                DB::table($table)->insert($rows);
            } catch (\Throwable $e) {
                Log::warning("[SyncAPI] Insert failed for {$table}: " . $e->getMessage());
            }
        }

        $this->info("  ✓ {$name}: " . count($records) . " records → {$table}");
    }

    private function createTable(string $table, array $sampleRow): void
    {
        Schema::dropIfExists($table);

        $textFields = ['remarks', 'address', 'querymessage', 'companyaddress', 'locality', 'aisummary', 'aitranscription', 'callrecording', 'taskfile', 'taskaudio', 'fileupload', 'cardimage', 'addinfo', 'locationcoordinates'];

        $cols = [];
        foreach ($sampleRow as $key => $val) {
            $colName = $this->sanitizeColumn($key);
            $type = in_array($colName, $textFields) || strlen((string)$val) > 200 ? 'TEXT' : 'VARCHAR(255)';
            $cols[] = "`{$colName}` {$type} NULL";
        }
        $cols[] = "`synced_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP";

        $sql = "CREATE TABLE `{$table}` (id BIGINT AUTO_INCREMENT PRIMARY KEY, " . implode(', ', $cols) . ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
        DB::statement($sql);
    }

    private function normalizeRow(array $record, string $table): array
    {
        $row = [];
        foreach ($record as $key => $val) {
            $colName = $this->sanitizeColumn($key);
            $row[$colName] = is_array($val) ? json_encode($val) : (string)($val ?? '');
        }
        $row['synced_at'] = now();
        return $row;
    }

    private function sanitizeColumn(string $name): string
    {
        return strtolower(preg_replace('/[^a-zA-Z0-9_]/', '_', $name));
    }

    private function updateMetadata(Tenant $tenant, string $prefix): void
    {
        $meta = $tenant->tables_metadata ?? [];
        $apiTables = [];

        foreach (self::ENDPOINTS as $name => $config) {
            $table = $prefix . $name;
            if (!Schema::hasTable($table)) continue;

            $columns = DB::select("SHOW COLUMNS FROM `{$table}`");
            $colMeta = [];
            foreach ($columns as $col) {
                if (in_array($col->Field, ['id', 'synced_at'])) continue;
                $colMeta[] = [
                    'pg_column' => $col->Field,
                    'pg_name' => $col->Field,
                    'pg_type' => str_contains($col->Type, 'int') ? 'numeric' : 'text',
                    'original_name' => $col->Field,
                ];
            }

            $apiTables[] = [
                'source_name' => ucwords(str_replace('_', ' ', $name)),
                'pg_table' => $table,
                'columns' => $colMeta,
                'source' => 'external_api',
            ];
        }

        // Merge with existing metadata (keep sheet-based tables, add/update API tables)
        $existing = is_array($meta) ? array_filter($meta, fn($t) => ($t['source'] ?? 'sheet') !== 'external_api') : [];
        $merged = array_merge($existing, $apiTables);

        $tenant->tables_metadata = $merged;
        $tenant->save();
    }
}
