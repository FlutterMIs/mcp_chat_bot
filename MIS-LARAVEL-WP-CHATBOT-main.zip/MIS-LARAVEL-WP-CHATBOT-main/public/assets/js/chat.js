(function(){
  'use strict';



  if (!window.MIS || !window.MIS.auth) return;
  const PHONE = window.MIS.auth.getPhone();
  const TENANT_NAME = window.MIS.auth.getTenantName();
  let SESSION_ID = sessionStorage.getItem('mis_session_id');
  if (!SESSION_ID) {
    SESSION_ID = 'web_' + Math.random().toString(36).slice(2, 12);
    sessionStorage.setItem('mis_session_id', SESSION_ID);
  }

  // ── Topbar greeting personalisation (chat-app style) ────────────────
  const tbSubEl    = document.getElementById('today-date');
  const tenantNameEl = document.getElementById('tenant-name');
  const tenantAvatar = document.getElementById('tenantAvatar');
  const heroTitle = document.getElementById('heroTitle');
  const tbAvatar = document.getElementById('avatar-init');

  const displayName = TENANT_NAME || (PHONE ? '+' + PHONE.slice(-4) : 'Guest');
  tenantNameEl.textContent = displayName;
  tenantAvatar.textContent = (displayName[0] || 'M').toUpperCase();
  tbAvatar.textContent = (PHONE || 'U').slice(-2);

  // Live "Good afternoon · synced X ago" subtitle, auto-tick every 30s
  let lastSyncAt = Date.now();
  function greetWord() {
    const h = new Date().getHours();
    return h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
  }
  function syncLabel() {
    const sec = Math.floor((Date.now() - lastSyncAt) / 1000);
    if (sec < 30)   return 'just synced';
    if (sec < 90)   return 'synced 1m ago';
    if (sec < 3600) return 'synced ' + Math.floor(sec / 60) + 'm ago';
    if (sec < 86400)return 'synced ' + Math.floor(sec / 3600) + 'h ago';
    return 'synced earlier';
  }
  function refreshSubtitle() {
    tbSubEl.textContent = greetWord() + ' · ' + syncLabel();
  }
  refreshSubtitle();
  setInterval(refreshSubtitle, 30000);

  // Hero title (only if hero is visible — empty chat)
  if (heroTitle) heroTitle.textContent = greetWord() + ' 👋';

  // ── State ────────────────────────────────────────────────────────────
  let history = [];                  // [{role, content}, ...]

  // ── Persistent chat log (survives reload + tab switch) ───────────────
  const CHATLOG_KEY = 'mis_chatlog_' + (PHONE || 'guest');
  let convo = [];                    // [{role, content, type, ts}, ...]
  function saveConvo() {
    try { localStorage.setItem(CHATLOG_KEY, JSON.stringify(convo.slice(-120))); } catch (e) {}
  }
  function logMsg(role, content, type, attachments) {
    convo.push({ role, content, type: type || 'text', ts: Date.now(), attachments: attachments || [] });
    saveConvo();
  }
  let pendingExactName = null;       // for ledger disambiguation
  let chatStream = document.getElementById('chatStream');
  let heroEl = document.getElementById('chatHero');
  let chipsRow = document.getElementById('chipsRow');
  let composer = document.getElementById('composer');
  let msgInput = document.getElementById('msgInput');

  // ── Auto-grow textarea ──────────────────────────────────────────────
  function autosize(el) {
    el.style.height = 'auto';
    el.style.height = Math.min(el.scrollHeight, 180) + 'px';
  }
  msgInput.addEventListener('input', () => autosize(msgInput));
  msgInput.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.keyCode === 13) && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  });
  composer.addEventListener('submit', (e) => {
    e.preventDefault();
    sendMessage();
  });

  // ── Suggestion chips loader ──────────────────────────────────────────
  async function loadChips() {
    try {
      const url = '/api/chat-suggestions?phone=' + encodeURIComponent(PHONE) + '&limit=6';
      const r = await fetch(url);
      const d = await r.json();
      renderChips(d.chips || []);
    } catch (e) {
      console.warn('chip load failed', e);
      chipsRow.innerHTML = '';
    }
  }

  function renderChips(chips) {
    chipsRow.innerHTML = '';
    chips.forEach((c, i) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'chip';
      btn.dataset.i = String(i);
      btn.dataset.kind = c.kind || 'generic';
      btn.dataset.action = 'chip';
      btn.dataset.prompt = c.prompt || c.label;
      btn.innerHTML = '<i data-lucide="' + (c.icon || 'sparkles') + '"></i> <span>' + escapeHTML(c.label) + '</span>';
      chipsRow.appendChild(btn);
    });
    if (window.lucide) lucide.createIcons();
  }
  function hideChipsOnFirstMessage() {
    chipsRow.style.display = 'none';
    heroEl.style.display = 'none';
  }

  // ── Helpers: HTML cleanup, markdown, attachments ─────────────────────
  function escapeHTML(s) {
    return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  // Inline-level conversions within a single line: links then bold (bold last so
  // "**[x](y)**" still works), applied to already-escaped text. Mirrors
  // MarkdownRenderer::inline() in app/Services/Chat/MarkdownRenderer.php.
  function renderInline(text) {
    text = text.replace(
      /\[([^\]\n]+)\]\((https?:\/\/[^\s)]+)\)/g,
      '<a href="$2" target="_blank" rel="noopener" style="color:#1a73e8;text-decoration:none;font-weight:500">$1</a>'
    );
    text = text.replace(/\*\*([^*\n]+)\*\*/g, '<b>$1</b>');
    text = text.replace(/\*([^*\n]+)\*/g, '<b>$1</b>');
    return text;
  }

  // Convert the subset of Markdown the AI actually produces (bold, bullet/numbered
  // lists, links, paragraphs) into HTML. Mirrors MarkdownRenderer::toHtml() server-side
  // so plain type:'text' replies (RAG answers, greetings, short summaries) render
  // real lists/links instead of leaking raw "- " / "[text](url)" markdown.
  function renderText(content) {
    let safe = escapeHTML(content);
    safe = safe.replace(/\bundefined\b|\bnull\b|\bEMPTY\b/gi, '–');

    const lines = safe.split(/\r\n|\r|\n/);
    const blocks = [];
    let para = [];
    let list = [];
    let listType = null;

    const flushPara = () => {
      if (!para.length) return;
      blocks.push(para.join('<br>'));
      para = [];
    };
    const flushList = () => {
      if (!list.length) return;
      const tag = listType === 'ol' ? 'ol' : 'ul';
      blocks.push('<' + tag + ' style="margin:4px 0 8px 22px;padding:0">' + list.map(i => '<li>' + i + '</li>').join('') + '</' + tag + '>');
      list = [];
      listType = null;
    };

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (line === '') { flushPara(); flushList(); continue; }

      let m = line.match(/^#{1,6}\s+(.*)$/);
      if (m) { flushPara(); flushList(); blocks.push('<b>' + renderInline(m[1]) + '</b>'); continue; }

      m = line.match(/^[-*]\s+(.*)$/);
      if (m) {
        if (listType === 'ol') flushList();
        flushPara();
        listType = 'ul';
        list.push(renderInline(m[1]));
        continue;
      }

      m = line.match(/^\d+[.)]\s+(.*)$/);
      if (m) {
        if (listType === 'ul') flushList();
        flushPara();
        listType = 'ol';
        list.push(renderInline(m[1]));
        continue;
      }

      flushList();
      para.push(renderInline(line));
    }
    flushPara();
    flushList();

    return blocks.join('<br>');
  }

  function fixHTML(html) {
    html = String(html || '');
    html = html.replace(/\bundefined\b/gi, '–').replace(/\bnull\b/gi, '–').replace(/\bEMPTY\b/g, '–');
    const M = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    html = html.replace(/\b(20\d{2})-(0[1-9]|1[0-2])-(\d{2})\b/g, (_, y, mo, d) => d + '-' + M[parseInt(mo)-1] + '-' + y.slice(2));
    html = html.replace(/\b(20\d{2})-(0[1-9]|1[0-2])\b/g, (_, y, mo) => M[parseInt(mo)-1] + '-' + y.slice(2));
    return html.replace(/^(\s*<br\s*\/?>\s*)+/gi, '').replace(/(\s*<br\s*\/?>\s*)+$/gi, '').trim();
  }

  function makeLinksClickable(container) {
    container.querySelectorAll('td').forEach(td => {
      const t = td.textContent.trim();
      if ((t.startsWith('http://') || t.startsWith('https://')) && !td.querySelector('a')) {
        td.innerHTML = '<a href="' + t + '" target="_blank" rel="noopener">📄 View</a>';
      }
    });
  }

  // ── Image lightbox ───────────────────────────────────────────────────
  const lightbox = document.getElementById('lightbox');
  const lightboxImg = document.getElementById('lightboxImg');
  function openLightbox(src) {
    lightboxImg.src = src;
    lightbox.classList.add('show');
    document.body.style.overflow = 'hidden';
  }
  function closeLightbox() {
    lightbox.classList.remove('show');
    document.body.style.overflow = '';
  }
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') {
      if (lightbox.classList.contains('show')) closeLightbox();
      else if (panel.classList.contains('show')) closePanel();
    }
  });

  // ── Attachment renderer (shape from server.js mediaToWebAttachments) ─
  function renderAttachments(bubble, attachments) {
    if (!attachments || !attachments.length) return;
    const wrap = document.createElement('div');
    wrap.className = 'attachments';
    for (const a of attachments) {
      if (a.type === 'image_url' && a.url) {
        const img = document.createElement('img');
        img.className = 'att-img';
        img.src = a.url;
        img.alt = a.caption || '';
        img.title = 'Click to zoom';
        img.addEventListener('click', () => openLightbox(a.url));
        wrap.appendChild(img);
        if (a.caption) {
          const cap = document.createElement('div');
          cap.className = 'att-caption';
          cap.textContent = a.caption;
          wrap.appendChild(cap);
        }
      } else if (a.type === 'image' && a.base64) {
        const src = 'data:' + (a.mime || 'image/png') + ';base64,' + a.base64;
        const img = document.createElement('img');
        img.className = 'att-img';
        img.src = src;
        img.alt = a.name || '';
        img.title = (a.name || '') + ' — click to zoom';
        img.addEventListener('click', () => openLightbox(src));
        wrap.appendChild(img);
      } else if (a.type === 'document' && a.base64) {
        const url = 'data:' + (a.mime || 'application/octet-stream') + ';base64,' + a.base64;
        const link = document.createElement('a');
        link.className = 'att-doc';
        link.href = url;
        link.download = a.name || 'download';
        const icon = document.createElement('span'); icon.className = 'att-icon';
        icon.textContent = (a.mime || '').includes('pdf') ? '📄'
                         : (a.mime || '').includes('csv') ? '📊'
                         : (a.mime || '').includes('sheet') ? '📊' : '📎';
        const name = document.createElement('span'); name.className = 'att-name';
        name.textContent = a.name || 'Download';
        const meta = document.createElement('span'); meta.className = 'att-meta';
        const kb = Math.round((a.base64.length * 0.75) / 1024);
        meta.textContent = kb < 1024 ? kb + ' KB' : (kb / 1024).toFixed(1) + ' MB';
        link.appendChild(icon); link.appendChild(name); link.appendChild(meta);
        wrap.appendChild(link);
      }
    }
    bubble.appendChild(wrap);
  }

  // ── Message bubble factory ───────────────────────────────────────────
  function addMessage(role, content, opts) {
    opts = opts || {};
    const type = opts.type || 'text';
    const attachments = opts.attachments || [];

    const row = document.createElement('div');
    row.className = 'bubble-row ' + (role === 'user' ? 'user' : 'bot');

    const av = document.createElement('div');
    av.className = 'avatar ' + (role === 'user' ? 'user' : 'bot');
    av.textContent = role === 'user' ? 'U' : 'M';

    const col = document.createElement('div');
    col.className = 'bubble-col';

    const bubble = document.createElement('div');

    const hasHTML = type === 'html' || (typeof content === 'string' && /<table|<tr|<td|<th|<div/i.test(content));

    if (hasHTML && role === 'assistant') {
      bubble.className = 'bubble bot html';
      bubble.innerHTML = fixHTML(content);
      // Wait for the browser to actually paint the table (2 rAFs = one full
      // layout+paint cycle) instead of guessing with a fixed 200ms timeout —
      // renders as soon as it's ready rather than always waiting 200ms.
      requestAnimationFrame(() => requestAnimationFrame(() => {
        makeLinksClickable(bubble);
        tryBuildChart(bubble, opts.chartMeta || null);
        addDownloadButtons(bubble);
        renderAttachments(bubble, attachments);
      }));
    } else {
      bubble.className = 'bubble ' + (role === 'user' ? 'user' : 'bot');
      bubble.innerHTML = renderText(content || '') || (attachments.length ? '' : '&nbsp;');
      if (attachments.length) {
        requestAnimationFrame(() => renderAttachments(bubble, attachments));
      }
    }

    if (opts.typewriter) {
      bubble.classList.add('typing-cursor');
      typewriterTo(bubble, content || '', () => {
        bubble.classList.remove('typing-cursor');
        if (attachments.length) renderAttachments(bubble, attachments);
        polishBubble(bubble);   // polish AFTER typewriter finishes overwriting innerHTML
      });
    }

    const ts = document.createElement('div');
    ts.className = 'ts';
    const now = new Date();
    ts.textContent = String(now.getHours()).padStart(2,'0') + ':' + String(now.getMinutes()).padStart(2,'0');

    col.appendChild(bubble);
    col.appendChild(ts);
    row.appendChild(av);
    row.appendChild(col);
    chatStream.appendChild(row);
    chatStream.scrollTop = chatStream.scrollHeight;
    if (!opts.typewriter) polishBubble(bubble);   // typewriter path polishes in its own done callback
    return bubble;
  }

  // ── Polish: money pill + result-card detection ────────────────────────
  // Wraps every ₹X.XX (with optional Cr/L/K) inside a styled mono pill, and
  // tags bubbles that look like "📋 N results / 📊 Total across N" lists with
  // a `.result-card` class so CSS can give them a richer accent treatment.
  function polishBubble(bubble) {
    if (!bubble) return;
    if (bubble.dataset.polished === '1') return;
    bubble.dataset.polished = '1';
    if (bubble.classList.contains('html')) return;   // tables already styled

    // Money pill — match ₹ values like "₹12,34,567", "₹2.58 Cr", "₹76.94 L"
    let html = bubble.innerHTML;
    html = html.replace(
      /(₹\s?[\d,]+(?:\.\d+)?(?:\s*(?:Cr|L|K|cr|l|k))?)\b/g,
      function (full) {
        // mark "big" if accompanied by Cr / L (typical totals)
        const big = /\b(Cr|L)\b/.test(full) ? ' big' : '';
        return '<span class="money' + big + '">' + full + '</span>';
      }
    );
    bubble.innerHTML = html;

    // Result-card flag — list-shaped bot replies
    if (bubble.classList.contains('bot')) {
      const txt = bubble.textContent || '';
      if (/results:|Total across\b/i.test(txt) || /^📋|📊/.test(txt.trim())) {
        bubble.classList.add('result-card');
      }
    }
  }

  // Char-by-char typewriter for plain-text replies (skip for HTML).
  // Total duration is capped regardless of length — this is a visual flourish,
  // not something that should ever make a long reply feel slower than a short
  // one. (Previously scaled ~linearly with length: a 2000-char reply could take
  // 8+ seconds to finish rendering even though the data had already arrived.)
  function typewriterTo(el, text, done) {
    const safe = renderText(text);
    el.innerHTML = '';
    const len = safe.length;
    const TICK_MS = 16; // ~60fps
    const duration = Math.min(650, Math.max(160, len * 2)); // 160ms–650ms total, never more
    const totalTicks = Math.max(1, Math.round(duration / TICK_MS));
    const charsPerTick = Math.max(1, Math.ceil(len / totalTicks));
    let i = 0;
    function tick() {
      if (i >= len) { done && done(); return; }
      // Find safe slice end (avoid splitting tags)
      const next = safe.indexOf('<', i);
      let end = i + charsPerTick;
      if (next !== -1 && next > i && next < end) {
        const close = safe.indexOf('>', next);
        end = close === -1 ? len : close + 1;
      } else if (end > len) end = len;
      el.innerHTML = safe.slice(0, end);
      i = end;
      chatStream.scrollTop = chatStream.scrollHeight;
      setTimeout(tick, TICK_MS);
    }
    tick();
  }

  // ── Typing indicator ─────────────────────────────────────────────────
  function showTyping() {
    if (document.getElementById('typingRow')) return;
    const row = document.createElement('div');
    row.className = 'bubble-row bot';
    row.id = 'typingRow';
    row.innerHTML = '<div class="avatar bot">M</div>'
                  + '<div class="bubble-col"><div class="bubble bot typing-dots">'
                  + '<span></span><span></span><span></span>'
                  + '</div></div>';
    chatStream.appendChild(row);
    chatStream.scrollTop = chatStream.scrollHeight;
  }
  function removeTyping() {
    const t = document.getElementById('typingRow');
    if (t) t.remove();
  }

  // ── Chart rendering + Export buttons (ported from Node index.html) ───
  let chartCounter = 0;

  function tryBuildChart(container, chartMeta) {
    if (typeof Chart === 'undefined') return;
    const tables = container.querySelectorAll("table");
    if (!tables.length) return;
    const table = tables[0];
    const headers = [...table.querySelectorAll("th")].map(th => th.textContent.trim());
    const rows = [...table.querySelectorAll("tbody tr")].filter(r => {
      const first = r.cells[0]?.textContent?.trim().toLowerCase();
      return first && first !== "grand total" && first !== "total";
    });
    if (rows.length < 2 || rows.length > 100) return;

    const valCols = [];
    headers.forEach((h, i) => {
      if (i > 0 && /total|amount|sales|revenue|expense|price|ratio|pending|balance|salary|cost|profit|loss/i.test(h)) valCols.push(i);
    });
    if (!valCols.length) return;

    const sampleRow = rows[0];
    const hasRealNumbers = valCols.some(ci => {
      const txt = (sampleRow?.cells[ci]?.textContent || "").replace(/[Rs.\s,₹]/g, "");
      return txt.length > 0 && txt.length < 15 && !isNaN(parseFloat(txt));
    });
    if (!hasRealNumbers) return;

    const labels = rows.map(r => r.cells[0]?.textContent?.trim() || "");
    const parseNum = t => parseFloat((t || "").replace(/[Rs.,\s₹]/g, "")) || 0;
    const COLORS = ["#1a73e8","#e53935","#2e7d32","#f57c00","#7b1fa2","#00838f","#c62828","#558b2f","#ad1457","#1565c0","#4527a0","#00695c"];

    const serverType = chartMeta?.chartType;
    const serverTitle = chartMeta?.title;
    const isTimeSeries = labels.every(l => /jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|\d{4}-\d{2}/i.test(l));
    const isSingle = valCols.length === 1;

    let chartType, datasets, chartTitle;
    if (serverType === "pie" || serverType === "doughnut") {
      chartType = serverType;
      chartTitle = "🥧 " + (serverTitle || "Category Breakdown");
      datasets = [{ data: rows.map(r => parseNum(r.cells[valCols[0]]?.textContent)), backgroundColor: COLORS.slice(0, rows.length), borderWidth: 2 }];
    } else if (serverType === "line" || (!serverType && isTimeSeries && isSingle)) {
      chartType = "line";
      chartTitle = "📈 " + (serverTitle || "Trend Chart");
      datasets = valCols.map((ci, idx) => ({ label: headers[ci], data: rows.map(r => parseNum(r.cells[ci]?.textContent)), borderColor: COLORS[idx], backgroundColor: COLORS[idx] + "22", tension: 0.3, fill: true, pointRadius: 4, borderWidth: 2 }));
    } else if (isTimeSeries && !isSingle) {
      chartType = "line";
      chartTitle = "📈 " + (serverTitle || "Trend Chart");
      datasets = valCols.map((ci, idx) => ({ label: headers[ci], data: rows.map(r => parseNum(r.cells[ci]?.textContent)), borderColor: COLORS[idx], backgroundColor: COLORS[idx] + "22", tension: 0.3, fill: false, pointRadius: 4, borderWidth: 2 }));
    } else {
      chartType = "bar";
      chartTitle = "📊 " + (serverTitle || "Trend Chart");
      datasets = isSingle ? [{ label: headers[valCols[0]] || "Amount", data: rows.map(r => parseNum(r.cells[valCols[0]]?.textContent)), backgroundColor: rows.map((_, i) => COLORS[i % COLORS.length] + "cc"), borderColor: rows.map((_, i) => COLORS[i % COLORS.length]), borderWidth: 1 }] : valCols.slice(0, 4).map((ci, idx) => ({ label: headers[ci], data: rows.map(r => parseNum(r.cells[ci]?.textContent)), backgroundColor: COLORS[idx] + "cc", borderColor: COLORS[idx], borderWidth: 1 }));
    }

    const chartId = "chart_" + (++chartCounter);
    const wrap = document.createElement("div");
    wrap.className = "chart-wrap";
    wrap.innerHTML = '<div class="chart-title">' + chartTitle + '</div><canvas id="' + chartId + '" style="max-height:320px"></canvas>';
    container.appendChild(wrap);

    setTimeout(() => {
      const ctx = document.getElementById(chartId);
      if (!ctx) return;
      new Chart(ctx, {
        type: chartType,
        data: { labels, datasets },
        options: {
          responsive: true,
          plugins: { legend: { position: chartType === "pie" || chartType === "doughnut" ? "right" : "top", labels: { font: { size: 11 } } }, tooltip: { callbacks: { label: c => { const v = c.parsed.y !== undefined ? c.parsed.y : c.parsed; return " Rs. " + (v || 0).toLocaleString("en-IN"); } } } },
          scales: chartType !== "pie" && chartType !== "doughnut" ? { y: { ticks: { callback: v => v >= 10000000 ? "Rs." + (v/10000000).toFixed(1)+"Cr" : v >= 100000 ? "Rs." + (v/100000).toFixed(1)+"L" : v >= 1000 ? "Rs." + (v/1000).toFixed(0)+"K" : "Rs."+v, font: { size: 10 } } }, x: { ticks: { font: { size: 10 }, maxRotation: 45 } } } : {}
        }
      });
    }, 100);
  }

  function tableToCSV(table) {
    const rows = [];
    table.querySelectorAll("tr").forEach(r => {
      const cells = [...r.querySelectorAll("th,td")].map(c => '"' + c.textContent.trim().replace(/"/g, '""') + '"');
      rows.push(cells.join(","));
    });
    return rows.join("\n");
  }

  function addDownloadButtons(bubble) {
    const tables = bubble.querySelectorAll("table");
    if (!tables.length) return;
    const bar = document.createElement("div");
    bar.className = "download-bar";

    const pdfBtn = document.createElement("button");
    pdfBtn.className = "dl-btn pdf";
    pdfBtn.innerHTML = "⬇ Download PDF";
    pdfBtn.onclick = async () => {
      pdfBtn.textContent = "Generating...";
      try {
        const canvas = await html2canvas(bubble, { scale: 2, useCORS: true, backgroundColor: "#fff" });
        const imgData = canvas.toDataURL("image/png");
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF({ orientation: canvas.width > canvas.height ? "l" : "p", unit: "px", format: [canvas.width/2, canvas.height/2] });
        pdf.addImage(imgData, "PNG", 0, 0, canvas.width/2, canvas.height/2);
        pdf.save("MIS_Report_" + new Date().toISOString().split("T")[0] + ".pdf");
      } catch(e) { alert("PDF error: " + e.message); }
      pdfBtn.innerHTML = "⬇ Download PDF";
    };

    const imgBtn = document.createElement("button");
    imgBtn.className = "dl-btn img";
    imgBtn.innerHTML = "🖼 Save as Image";
    imgBtn.onclick = async () => {
      imgBtn.textContent = "Saving...";
      try {
        const canvas = await html2canvas(bubble, { scale: 2, useCORS: true, backgroundColor: "#fff" });
        const link = document.createElement("a");
        link.download = "MIS_Report_" + new Date().toISOString().split("T")[0] + ".png";
        link.href = canvas.toDataURL("image/png");
        link.click();
      } catch(e) { alert("Image error: " + e.message); }
      imgBtn.innerHTML = "🖼 Save as Image";
    };

    const csvBtn = document.createElement("button");
    csvBtn.className = "dl-btn csv";
    csvBtn.innerHTML = "📥 Export CSV";
    csvBtn.onclick = () => {
      const csv = tableToCSV(tables[0]);
      const blob = new Blob([csv], { type: "text/csv" });
      const link = document.createElement("a");
      link.download = "MIS_Data_" + new Date().toISOString().split("T")[0] + ".csv";
      link.href = URL.createObjectURL(blob);
      link.click();
    };

    bar.appendChild(pdfBtn);
    bar.appendChild(imgBtn);
    bar.appendChild(csvBtn);
    bubble.appendChild(bar);
  }

  // ── Send message → /chat ─────────────────────────────────────────────
  async function sendMessage(overrideText) {
    const text = (overrideText !== undefined ? overrideText : msgInput.value).trim();
    if (!text) return;

    hideChipsOnFirstMessage();
    addMessage('user', text);
    history.push({ role: 'user', content: text });
    logMsg('user', text, 'text');
    if (!overrideText) {
      msgInput.value = '';
      autosize(msgInput);
    }
    showTyping();

    try {
      const body = { message: text, history, session_id: SESSION_ID };
      if (PHONE) body.phone = PHONE;
      if (pendingExactName) { body.exactName = pendingExactName; pendingExactName = null; }

      const res = await window.MIS.chatFetch(body);
      const data = await res.json();
      removeTyping();

      const reply = data.reply || data.message || '';
      const type = data.type || 'text';
      const attachments = data.attachments || [];

      if (type === 'suggestions' && Array.isArray(data.options) && data.options.length) {
        // Inline disambiguation chips
        const bubble = addMessage('assistant', reply, { type: 'text' });
        const wrap = document.createElement('div');
        wrap.className = 'chips-row';
        wrap.style.cssText = 'padding:10px 0 0;justify-content:flex-start;';
        data.options.forEach((opt, i) => {
          const b = document.createElement('button');
          b.type = 'button';
          b.className = 'chip';
          b.dataset.i = String(i);
          b.dataset.action = 'chip';
          // Detect ledger context — same heuristic as legacy
          const last = [...document.querySelectorAll('.bubble.user')].pop();
          const isInvoice = last && /invoice|bill/i.test(last.textContent);
          if (['Show all sales','Show all expenses','Show pending payments','Show ledger'].includes(opt)) {
            b.dataset.prompt = opt;
          } else if (isInvoice) {
            b.dataset.prompt = 'give me invoice of ' + opt;
          } else {
            // ledger pick
            b.dataset.prompt = opt + ' ledger';
            b.dataset.exactName = opt;
          }
          b.innerHTML = '<i data-lucide="chevron-right"></i><span>' + escapeHTML(opt) + '</span>';
          wrap.appendChild(b);
        });
        bubble.appendChild(wrap);
        if (window.lucide) lucide.createIcons();
      } else {
        // Use typewriter only for plain text (HTML is rendered immediately)
        const wantsTypewriter = (type === 'text' || !type) && reply && !/<table|<tr|<td|<th|<div/i.test(reply);
        addMessage('assistant', reply, { type, attachments, typewriter: wantsTypewriter, chartMeta: data.chartMeta || null });
      }

      if (reply && type !== 'suggestions') { history.push({ role: 'assistant', content: reply }); logMsg('assistant', reply, type, attachments); }
    } catch (e) {
      removeTyping();
      addMessage('assistant', '⚠️ ' + (e.message || 'Server error. Please try again.'));
    }
  }

  // ── Load history — actual loader is `loadHistoryWithDividers` defined later
  //    (placed after polishBubble/addMessage wraps so date dividers work).

  // ── Voice mic + waveform (Web Audio API AnalyserNode) ────────────────
  let mediaRecorder = null;
  let audioChunks = [];
  let isRecording = false;
  let audioCtx = null;
  let analyser = null;
  let streamRef = null;
  let waveAnimId = null;
  let recStart = 0;
  let recTimerId = null;
  const waveformWrap = document.getElementById('waveformWrap');
  const waveformCanvas = document.getElementById('waveformCanvas');
  const recTimeEl = document.getElementById('recTime');
  const micBtn = document.getElementById('micBtn');

  async function micToggle() {
    if (isRecording) return micStop();
    if (!navigator.mediaDevices || !window.MediaRecorder) {
      alert('Voice not supported in this browser. Use latest Chrome / Safari / Edge.');
      return;
    }
    try {
      streamRef = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mimes = ['audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus','audio/mp4'];
      const mime = mimes.find(m => MediaRecorder.isTypeSupported(m)) || '';
      mediaRecorder = mime ? new MediaRecorder(streamRef, { mimeType: mime }) : new MediaRecorder(streamRef);
      audioChunks = [];

      mediaRecorder.ondataavailable = e => { if (e.data && e.data.size > 0) audioChunks.push(e.data); };
      mediaRecorder.onstop = onMicData;

      // Waveform analyser
      try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const src = audioCtx.createMediaStreamSource(streamRef);
        analyser = audioCtx.createAnalyser();
        analyser.fftSize = 256;
        src.connect(analyser);
        drawWaveform();
      } catch(e) { /* analyser optional */ }

      mediaRecorder.start();
      isRecording = true;
      micBtn.classList.add('recording');
      waveformWrap.classList.add('show');
      recStart = Date.now();
      recTimerId = setInterval(() => {
        const s = Math.floor((Date.now() - recStart) / 1000);
        recTimeEl.textContent = String(Math.floor(s/60)).padStart(2,'0') + ':' + String(s%60).padStart(2,'0');
        if (s >= 60) micStop();   // hard 60s safety cap
      }, 250);
    } catch (e) {
      alert('Mic access denied: ' + e.message);
    }
  }

  function micStop() {
    if (!isRecording) return;
    try { mediaRecorder.stop(); } catch(e) {}
    isRecording = false;
    micBtn.classList.remove('recording');
    waveformWrap.classList.remove('show');
    if (recTimerId) { clearInterval(recTimerId); recTimerId = null; }
    if (waveAnimId) { cancelAnimationFrame(waveAnimId); waveAnimId = null; }
    if (audioCtx) { try { audioCtx.close(); } catch(e){} audioCtx = null; }
    if (streamRef) { streamRef.getTracks().forEach(t => t.stop()); streamRef = null; }
  }

  function drawWaveform() {
    const ctx = waveformCanvas.getContext('2d');
    const w = waveformCanvas.width, h = waveformCanvas.height;
    const dataArr = new Uint8Array(analyser.frequencyBinCount);

    function frame() {
      analyser.getByteFrequencyData(dataArr);
      ctx.clearRect(0, 0, w, h);
      const bars = 48;
      const step = Math.floor(dataArr.length / bars);
      const bw = w / bars - 2;
      for (let i = 0; i < bars; i++) {
        let sum = 0;
        for (let j = 0; j < step; j++) sum += dataArr[i*step + j];
        const v = (sum / step) / 255;
        const bh = Math.max(2, v * h);
        // Gradient pink→purple
        const grd = ctx.createLinearGradient(0, h - bh, 0, h);
        grd.addColorStop(0, '#F43F5E');
        grd.addColorStop(1, '#8B5CF6');
        ctx.fillStyle = grd;
        const x = i * (bw + 2);
        ctx.fillRect(x, (h - bh) / 2, bw, bh);
      }
      waveAnimId = requestAnimationFrame(frame);
    }
    frame();
  }

  function onMicData() {
    if (!audioChunks.length) return;
    const blob = new Blob(audioChunks, { type: (mediaRecorder && mediaRecorder.mimeType) || 'audio/webm' });
    const reader = new FileReader();
    reader.onloadend = async () => {
      const dataUrl = reader.result;
      const base64 = (dataUrl || '').split(',')[1];
      if (!base64) { alert('Recording failed.'); return; }
      showTyping();
      try {
        const r = await fetch('/transcribe', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ audio_base64: base64, mime: blob.type })
        });
        const d = await r.json();
        removeTyping();
        if (!r.ok || !d.text) {
          addMessage('assistant', '⚠️ ' + (d.error || 'Transcription failed. Please try again.'));
          return;
        }
        msgInput.value = d.text;
        autosize(msgInput);
        sendMessage();
      } catch(e) {
        removeTyping();
        addMessage('assistant', '⚠️ Voice upload failed: ' + e.message);
      }
    };
    reader.readAsDataURL(blob);
  }

  // ── Slide-over panel ─────────────────────────────────────────────────
  const panel = document.getElementById('panel');
  const panelBackdrop = document.getElementById('panelBackdrop');
  function openPanel() { panel.classList.add('show'); panelBackdrop.classList.add('show'); }
  function closePanel() { panel.classList.remove('show'); panelBackdrop.classList.remove('show'); }

  // ── Document analyzer ────────────────────────────────────────────────
  async function analyzeDoc() {
    const input = document.getElementById('docUrlInput');
    const result = document.getElementById('docResult');
    const url = input.value.trim();
    if (!url) { input.focus(); return; }
    result.classList.add('show');
    result.textContent = '⏳ Reading document and indexing…';
    try {
      const phone = window.MIS && window.MIS.auth ? window.MIS.auth.getPhone() : '';
      const r = await fetch('/api/tenant/links/tools/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ doc_url: url, phone })
      });
      const d = await r.json();
      if (r.ok && d.summary) {
        result.innerHTML = '<b>✅ Analysis & Indexing</b><br><br>' + escapeHTML(d.summary || '').replace(/\n/g, '<br>');
      } else {
        result.textContent = '❌ ' + (d.error || 'Could not analyze');
      }
    } catch (e) {
      result.textContent = '❌ ' + e.message;
    }
  }

  // ── File upload ──────────────────────────────────────────────────────
  const dropZone = document.getElementById('dropZone');
  const fileInput = document.getElementById('fileInput');
  dropZone.addEventListener('click', () => fileInput.click());
  dropZone.addEventListener('dragover', e => { e.preventDefault(); dropZone.classList.add('dragover'); });
  dropZone.addEventListener('dragleave', () => dropZone.classList.remove('dragover'));
  dropZone.addEventListener('drop', e => {
    e.preventDefault();
    dropZone.classList.remove('dragover');
    const f = e.dataTransfer.files[0];
    if (f) processFile(f);
  });
  fileInput.addEventListener('change', e => {
    const f = e.target.files && e.target.files[0];
    if (f) processFile(f);
  });

  async function processFile(file) {
    const result = document.getElementById('fileResult');
    result.classList.add('show');
    result.textContent = '⏳ Uploading and indexing ' + file.name + '…';

    const phone = window.MIS && window.MIS.auth ? window.MIS.auth.getPhone() : '';
    const formData = new FormData();
    formData.append('file', file);
    formData.append('phone', phone);

    try {
      const r = await fetch('/api/tenant/links/tools/upload-file', {
        method: 'POST',
        body: formData
      });
      const d = await r.json();
      if (r.ok) {
        result.innerHTML = '<b>📄 ' + escapeHTML(file.name) + '</b><br><br>' + escapeHTML(d.summary || '').replace(/\n/g, '<br>');
      } else {
        result.textContent = '❌ ' + (d.error || 'Upload failed');
      }
    } catch (e) {
      result.textContent = '❌ ' + e.message;
    }
  }

  // ── Manual sync ─────────────────────────────────────────────────────
  async function doSync() {
    const label = document.getElementById('syncStatusLabel');
    const result = document.getElementById('syncResult');
    const btn1 = document.getElementById('topSyncBtn');
    const btn2 = document.getElementById('panelSyncBtn');
    if (label) label.textContent = 'Syncing…';
    if (btn1) btn1.classList.add('spin');
    if (btn2) btn2.disabled = true;
    if (result) { result.classList.add('show'); result.textContent = '⏳ Syncing latest data…'; }
    try {
      const phone = window.MIS && window.MIS.auth ? window.MIS.auth.getPhone() : '';
      const r = await fetch('/api/tenant/sync-now', { 
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone })
      });
      const d = await r.json();
      const ok = r.ok && (d.ok === undefined ? true : d.ok);
      if (label) label.textContent = ok ? 'Up to date' : 'Sync failed';
      if (result) result.innerHTML = ok ? '<b>✅ Synced</b><br><br>' + escapeHTML(JSON.stringify(d.results || d || {}, null, 2)).slice(0, 600) : '❌ ' + (d.error || 'Sync failed');
      if (ok) { lastSyncAt = Date.now(); refreshSubtitle(); }
    } catch (e) {
      if (label) label.textContent = 'Sync failed';
      if (result) result.textContent = '❌ ' + e.message;
    } finally {
      if (btn1) btn1.classList.remove('spin');
      if (btn2) btn2.disabled = false;
    }
  }

  // ── Clear chat ──────────────────────────────────────────────────────
  async function clearChat() {
    const ok = await window.MIS.confirm({
      title: 'Clear this conversation?',
      text: 'Your chat history for this session will be removed.',
      icon: 'warning',
      confirmText: 'Yes, clear it',
      danger: true,
    });
    if (!ok) return;
    fetch('/history/' + SESSION_ID, { method: 'DELETE' }).catch(() => {});
    try { localStorage.removeItem(CHATLOG_KEY); } catch (e) {}
    convo = [];
    chatStream.innerHTML = '';
    history = [];
    heroEl.style.display = '';
    chipsRow.style.display = '';
    loadChips();
    window.MIS.toast('Conversation cleared', 'ok');
  }

  // ── Sidebar toggle (mobile) ─────────────────────────────────────────
  function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
  }

  // ── Single delegated click handler (Sprint-1 lesson — no inline onclick) ──
  document.body.addEventListener('click', (e) => {
    const target = e.target.closest('[data-action]');
    if (!target) return;
    const action = target.dataset.action;
    switch (action) {
      case 'send':           sendMessage(); break;
      case 'mic-toggle':     micToggle(); break;
      case 'mic-stop':       micStop(); break;
      case 'open-panel':     openPanel(); break;
      case 'close-panel':    closePanel(); break;
      case 'analyze-doc':    analyzeDoc(); break;
      case 'sync':           doSync(); break;
      case 'clear-chat':     clearChat(); break;
      case 'logout':         e.preventDefault(); window.MIS.auth.logout(); break;
      case 'toggle-sidebar': toggleSidebar(); break;
      case 'close-lightbox': closeLightbox(); break;
      case 'scroll-bottom':  scrollToBottom(); break;
      case 'chip': {
        const prompt = target.dataset.prompt || target.textContent.trim();
        if (target.dataset.exactName) pendingExactName = target.dataset.exactName;
        sendMessage(prompt);
        break;
      }
    }
  });

  // ── Polish: cycling placeholder ──────────────────────────────────────
  // When the textarea is empty and unfocused, gently rotate the placeholder
  // through tenant chip prompts so the user always has fresh inspiration.
  const DEFAULT_PH = 'Type a message, or hold the mic to speak…';
  let phTimer = null;
  let phIdx = 0;
  function getCyclePrompts() {
    const chips = chipsRow.querySelectorAll('.chip[data-prompt]');
    const out = [DEFAULT_PH];
    chips.forEach(c => { if (c.dataset.prompt) out.push('Try: ' + c.dataset.prompt); });
    return out;
  }
  function startPlaceholderCycle() {
    if (phTimer) clearInterval(phTimer);
    phTimer = setInterval(() => {
      if (msgInput.value || document.activeElement === msgInput) return;
      const list = getCyclePrompts();
      if (list.length < 2) return;
      phIdx = (phIdx + 1) % list.length;
      msgInput.classList.remove('ph-fade');
      // Force reflow so re-applying the class restarts the fade animation
      void msgInput.offsetWidth;
      msgInput.placeholder = list[phIdx];
      msgInput.classList.add('ph-fade');
    }, 3500);
  }
  msgInput.addEventListener('focus', () => msgInput.classList.remove('ph-fade'));
  msgInput.addEventListener('blur', () => { phIdx = 0; msgInput.placeholder = DEFAULT_PH; });

  // ── Polish: scroll-to-bottom FAB ─────────────────────────────────────
  const scrollFab = document.createElement('button');
  scrollFab.type = 'button';
  scrollFab.className = 'scroll-fab';
  scrollFab.dataset.action = 'scroll-bottom';
  scrollFab.setAttribute('aria-label', 'Scroll to latest');
  scrollFab.innerHTML = '<i data-lucide="arrow-down"></i><span class="badge" id="scrollFabBadge" style="display:none;">1</span>';
  // Anchor to the chat page itself (position:absolute in CSS) rather than
  // document.body (position:fixed) — a body-fixed button has to guess its
  // horizontal position from the viewport width via a hardcoded formula, which
  // goes stale the moment the composer width or sidebar collapsed-state changes
  // (it was overlapping message bubbles after the composer was widened). Anchored
  // to #chatPage, it just inherits that container's actual box automatically.
  (document.getElementById('chatPage') || document.body).appendChild(scrollFab);
  let pendingNewMsg = 0;
  function updateFabVisibility() {
    const dist = chatStream.scrollHeight - chatStream.scrollTop - chatStream.clientHeight;
    const show = dist > 120;
    scrollFab.classList.toggle('show', show);
    if (!show) {
      pendingNewMsg = 0;
      const b = document.getElementById('scrollFabBadge');
      if (b) b.style.display = 'none';
    }
  }
  chatStream.addEventListener('scroll', updateFabVisibility, { passive: true });
  function scrollToBottom() {
    chatStream.scrollTo({ top: chatStream.scrollHeight, behavior: 'smooth' });
    pendingNewMsg = 0;
    const b = document.getElementById('scrollFabBadge');
    if (b) b.style.display = 'none';
  }
  // When a NEW assistant bubble arrives while user is scrolled up, increment badge
  const _origAddMessage = addMessage;
  addMessage = function (role, content, opts) {
    const dist = chatStream.scrollHeight - chatStream.scrollTop - chatStream.clientHeight;
    const wasScrolledUp = dist > 120;
    const result = _origAddMessage(role, content, opts);
    if (role === 'assistant' && wasScrolledUp) {
      pendingNewMsg++;
      const b = document.getElementById('scrollFabBadge');
      if (b) { b.textContent = String(pendingNewMsg); b.style.display = 'grid'; }
    }
    setTimeout(updateFabVisibility, 50);
    return result;
  };

  // ── Polish: date divider helper ──────────────────────────────────────
  function dayLabel(ts) {
    const d = new Date(ts);
    if (isNaN(d.getTime())) return null;
    const now = new Date(); now.setHours(0,0,0,0);
    const that = new Date(d); that.setHours(0,0,0,0);
    const diff = Math.floor((now - that) / 86400000);
    if (diff === 0) return 'Today';
    if (diff === 1) return 'Yesterday';
    if (diff > 0 && diff < 7) return d.toLocaleDateString('en-IN', { weekday: 'long' });
    return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: diff > 365 ? 'numeric' : undefined });
  }
  function addDateDivider(label) {
    if (!label) return;
    const last = chatStream.querySelector('.date-divider:last-of-type');
    if (last && last.textContent === label) return;   // dedupe consecutive
    const div = document.createElement('div');
    div.className = 'date-divider';
    div.textContent = label;
    chatStream.appendChild(div);
  }
  // Patch loadHistory's date awareness — wrap addMessage during initial load
  // by tracking the previous timestamp seen. We re-implement loadHistory here
  // so we can inject dividers at the right points.
  // Restore the saved conversation (localStorage) on load — survives reload + tab switch.
  // The old /history/<sid> backend endpoint was never ported to Laravel, so we persist
  // client-side keyed by phone. Heavy attachments (charts/PDFs) are not re-stored.
  (function restoreConvo() {
    try {
      const raw = localStorage.getItem(CHATLOG_KEY);
      if (!raw) return;
      const data = JSON.parse(raw);
      if (!Array.isArray(data) || data.length === 0) return;
      if (chatStream.querySelector('.bubble-row')) return;   // already populated
      convo = data;
      hideChipsOnFirstMessage();
      let lastDay = null;
      data.forEach(m => {
        if (m.ts) {
          const that = new Date(m.ts); that.setHours(0, 0, 0, 0);
          const key = that.getTime();
          if (key !== lastDay) { const label = dayLabel(m.ts); if (label) addDateDivider(label); lastDay = key; }
        }
        const content = m.content || '';
        const isHTML = content && /<table|<div|<tr|<td|<th/i.test(content);
        addMessage(m.role, content, { type: (m.type === 'html' || (isHTML && m.role === 'assistant')) ? 'html' : 'text', attachments: m.attachments || [] });
        history.push({ role: m.role, content });
      });
    } catch (e) { /* ignore */ }
  })();

  // ── Init ────────────────────────────────────────────────────────────
  if (window.lucide) lucide.createIcons();
  if (window.MIS.theme && window.MIS.theme.init) window.MIS.theme.init();

  // Theme toggle (was missing — clicking the row in the sidebar now flips theme)
  const _themeRow = document.getElementById('themeRow');
  if (_themeRow) {
    _themeRow.addEventListener('click', () => {
      window.MIS.theme.toggle();
    });
  }
  loadChips().finally(() => {
    // Once chips are in the DOM, kick off the cycling placeholder
    if (window.lucide) lucide.createIcons();   // pick up the FAB icon + chip icons
    startPlaceholderCycle();
  });

  // Add a tiny "spin" CSS for the topbar sync icon (page-local)
  const styleEl = document.createElement('style');
  styleEl.textContent = '.spin svg { animation: misSpin 700ms linear infinite; } @keyframes misSpin { to { transform: rotate(360deg); } }';
  document.head.appendChild(styleEl);

})();
