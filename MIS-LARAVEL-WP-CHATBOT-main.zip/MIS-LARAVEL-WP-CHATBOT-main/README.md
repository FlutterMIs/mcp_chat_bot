# MIS Laravel Chatbot System

An intelligent, multi-tenant conversational database assistant built with Laravel and PHP 8.3. The application connects to WhatsApp and Web interfaces, offering real-time natural language query resolution against relational SQL tables, financial ledger documents, and an indexed document knowledge base.

---

## 🚀 Key Features & Architecture

### 1. Unified RAG (Retrieval-Augmented Generation) Engine
The chatbot processes multiple data formats seamlessly by indexing them into a searchable vector-like store:
- **Relational SQL Database:** Schema-aware table-mapping automatically translates natural language queries into efficient SQL, executed dynamically against the tenant's database.
- **Documents & Spreadsheets:** Natively parses and indexes:
  - **PDF:** Content parsed via `Smalot\PdfParser\Parser`.
  - **DOCX / Word:** Custom high-speed native XML zip-extraction (`word/document.xml`).
  - **XLSX / Excel:** Custom native XML zip-extraction of worksheets and shared strings.
  - **CSV / Spreadsheet:** Row-by-row structured text conversion.
  - **TXT / Markdown:** Simple plain text ingestion.
- **RAG Chunking:** Documents are split into overlapping character segments, indexed in `tenant_pdf_chunks`, and retrieved using keyword-based similarity filters before being compiled into context for GPT-4o-mini response synthesis.

### 2. Multi-Level Access Control & Row-Level Security
To safeguard data privacy, queries are automatically filtered based on the requester's role relative to the tenant:
1. **User Role Classification:**
   - **Owner / Super-admin:** Full access to all tables, ledgers, and document links. Bypasses access control constraints.
   - **Team Member:** Registered in `user_databases` or matched via phone number logs. Restricted to rows matching their last-10-digit phone number if a `team_match_column` is configured for that tab.
   - **Guest / Client:** Any unknown phone number. Only permitted to access tables where `access_client` is enabled, and strictly row-level filtered:
     - **SQL Generation:** Every generated query is appended with a mandatory `WHERE client_match_column LIKE '%[phone]%'` constraint.
     - **Ledger Generation:** PDF ledger reports and name lookups are strictly bound by the client's phone match filter.
     - **RAG Knowledge Base:** Chunks are filtered by matching their source URLs with the allowed access level (`all` for clients, `all` + `team` for members). If no links are accessible, query returns empty.

### 3. Self-Healing SQL Pipeline
To ensure high resilience, the query engine runs a 3-attempt healing loop:
- **First Try:** Analyzes query context and extracts database memory if a high-confidence match is found.
- **On Schema Error:** If a column doesn't match, `SelfHeal::resolveColumnError` automatically corrects the column using Levenshtein distance calculations to prevent AI round-trips.
- **On Empty Result:** If SQL returns 0 rows, the engine automatically relaxes date constraints or query literals and retries.

### 4. Direct Upload & File Management
Through the **Links & Files Library** in Settings, owners can:
- Toggle between adding generic URL links and uploading local files directly.
- Choose access permission level for the document (`all`, `team`, `owner`).
- Delete uploads securely, automatically removing files from local public disk and cleaning up all associated text chunks in the database.

---

## 🛠️ Tech Stack & Setup

- **Backend:** Laravel 11/13, PHP 8.3
- **Database:** MySQL 8.x
- **Vite:** Asset compilation
- **Testing:** PHPUnit

### Setup & Installation
1. Clone the project and install dependencies:
   ```bash
   composer install
   npm install
   ```
2. Configure `.env` database details and OpenAI API credentials.
3. Link the public storage directory:
   ```bash
   php artisan storage:link
   ```
4. Run migrations:
   ```bash
   php artisan migrate
   ```
5. Build frontend assets:
   ```bash
   npm run build
   ```

---

## 🧪 Testing

Run the feature integration test suite (fully compatible with SQLite and MySQL):
```bash
php artisan test tests/Feature/MultiFormatKnowledgeTest.php
```
Test cases cover document parsing (PDF/TXT/CSV/DOCX/XLSX), direct upload indexing, storage delete hooks, and guest/owner access restrictions.
