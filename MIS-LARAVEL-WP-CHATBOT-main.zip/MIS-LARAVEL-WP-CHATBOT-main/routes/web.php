<?php

use App\Http\Controllers\CalendarController;
use App\Http\Controllers\WebhookController;
use Illuminate\Support\Facades\Route;

// ── Root redirect ────────────────────────────────────────────────────
Route::get('/', fn () => redirect('/login'));

// ── Auth & Onboard pages (standalone, no sidebar layout) ─────────────
Route::view('/login', 'auth.login');
Route::view('/register', 'auth.register');
Route::get('/onboard', fn () => view('auth.register'));

// ── App pages (extend layouts.app with sidebar) ──────────────────────
$bladePages = [
    'dashboard', 'chat', 'sales', 'outstanding', 'stock',
    'ledger', 'calendar', 'settings', 'reports', 'admin', 'access-control',
];

foreach ($bladePages as $page) {
    Route::get("/{$page}", fn () => view($page));
}

// ── Google Calendar OAuth (redirects, not JSON) ─────────────────────
Route::get('/google/callback', [CalendarController::class, 'callback']);
Route::controller(CalendarController::class)->prefix('api/tenant/calendar')->group(function () {
    Route::get('/auth', 'init');
    Route::get('/callback', 'callback'); // Keep for backward compatibility if needed
});

// ── WhatsApp webhooks ────────────────────────────────────────────────
Route::controller(WebhookController::class)->group(function () {
    Route::match(['get', 'post'], '/whatsapp', 'handle');
    Route::match(['get', 'post'], '/wh/{token}', 'handleByToken'); // Per-tenant unique webhook
});

// ── Fallback ─────────────────────────────────────────────────────────
Route::fallback(fn () => redirect('/login'));
