<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BriefingController;
use App\Http\Controllers\CalendarController;
use App\Http\Controllers\ChatController;
use App\Http\Controllers\ChatSuggestionsController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\MessageLogController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\OtpController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ReportsController;
use App\Http\Controllers\SearchController;
use App\Http\Controllers\SuperAdminController;
use App\Http\Controllers\TabAccessController;
use App\Http\Controllers\TenantApiKeyController;
use App\Http\Controllers\TenantController;
use App\Http\Controllers\TenantLinkController;
use App\Http\Controllers\TenantSheetController;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| All routes here are auto-prefixed with /api by bootstrap/app.php.
| Throttled at 60 req/min (config in bootstrap/app.php).
*/

// Health Check
Route::get('/health', function () {
    try {
        DB::selectOne('SELECT 1');
        $db = true;
    } catch (Throwable $e) {
        $db = false;
    }

    return response()->json(['status' => $db ? 'ok' : 'degraded', 'db' => $db, 'time' => now()->toIso8601String()]);
});

// General App Routes
Route::get('/dashboard', DashboardController::class);

Route::get('/page/{kind}', PageController::class)
    ->whereIn('kind', ['sales', 'outstanding', 'stock', 'ledger']);

Route::get('/briefing', BriefingController::class);
Route::get('/search', SearchController::class);
Route::get('/chat-suggestions', ChatSuggestionsController::class);
Route::get('/reports/list', ReportsController::class);

// Chat Routes
Route::middleware('chat-auth')->group(function () {
    Route::post('/chat', ChatController::class);
});
Route::get('/chat/history', [ChatController::class, 'getHistory']);

// Auth Route
Route::post('/auth/issue-token', [AuthController::class, 'issueToken']);

// Notifications
Route::controller(NotificationController::class)->prefix('notifications')->group(function () {
    Route::get('/', 'index');
    Route::post('/mark-all-read', 'markAllRead');
    Route::post('/{id}/read', 'read')->whereNumber('id');
});

// Tenant Routes
Route::prefix('tenant')->group(function () {
    // Tenant Profile & Setup
    Route::controller(TenantController::class)->group(function () {
        Route::post('/check-phone', 'checkPhone');
        Route::get('/profile', 'profile');
        Route::get('/ai-status', 'aiStatus');
        Route::get('/prompts', 'getPrompts');
        Route::post('/prompts', 'savePrompts');
        Route::post('/detect-schema', 'detectSchema');
        Route::post('/update-profile', 'updateProfile');
        Route::post('/signup', 'signup');
        Route::post('/sync-now', 'syncNow');
    });

    // OTP
    Route::controller(OtpController::class)->group(function () {
        Route::post('/send-otp', 'send');
        Route::post('/verify-otp', 'verify');
    });

    // Sheets (Z43)
    Route::controller(TenantSheetController::class)->prefix('sheets')->group(function () {
        Route::get('/', 'index');
        Route::post('/add', 'add');
        Route::delete('/{id}', 'remove')->whereUuid('id');
    });

    // Tab Access (Z43)
    Route::controller(TabAccessController::class)->group(function () {
        Route::get('/tab-access', 'index');
        Route::post('/tab-access', 'save');
        Route::get('/sheet-columns', 'columns');
    });

    // Links (Z44)
    Route::controller(TenantLinkController::class)->prefix('links')->group(function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::post('/upload', 'upload');
        Route::post('/tools/analyze', 'analyze');
        Route::post('/tools/upload-file', 'uploadFile');
        Route::delete('/{id}', 'destroy')->whereNumber('id');
        Route::post('/index-pdfs', 'indexPdfs');
    });

    // Message Logs (audit trail viewer)
    Route::get('/message-logs', [MessageLogController::class, 'index']);

    // API Keys
    Route::controller(TenantApiKeyController::class)->prefix('api-keys')->group(function () {
        Route::get('/', 'index');
        Route::post('/', 'store');
        Route::put('/{id}', 'update')->whereNumber('id');
        Route::delete('/{id}', 'destroy')->whereNumber('id');
    });

    // Calendar
    Route::controller(CalendarController::class)->prefix('calendar')->group(function () {
        Route::get('/events', 'events');
        Route::post('/book', 'book');
        Route::post('/reschedule', 'reschedule');
        Route::post('/cancel', 'cancel');
        Route::post('/disconnect', 'disconnect');
    });
});

// Admin endpoints
Route::middleware('admin-auth')->prefix('tenant')->controller(AdminController::class)->group(function () {
    Route::post('/sync-all', 'syncAll');
    Route::post('/{id}/resync', 'resync')->whereUuid('id');
});

// Super Admin Panel
Route::middleware('super-admin')->prefix('admin')->controller(SuperAdminController::class)->group(function () {
    Route::get('/stats', 'stats');
    Route::get('/clients', 'listClients');
    Route::get('/clients/trashed', 'listTrashedClients');
    Route::post('/clients', 'createClient');
    Route::delete('/clients/{id}', 'deleteClient')->whereUuid('id');
    Route::post('/clients/{id}/restore', 'restoreClient')->whereUuid('id');
    Route::delete('/clients/{id}/force', 'forceDeleteClient')->whereUuid('id');
    Route::post('/clients/{id}/sheet', 'updateSheet')->whereUuid('id');
    Route::post('/clients/{id}/provision', 'provision')->whereUuid('id');
    Route::post('/clients/{id}/remove-wa-key', 'removeWaKey')->whereUuid('id');
    Route::get('/members', 'listMembers');
    Route::post('/members', 'createMember');
    Route::put('/members/{id}', 'updateMember')->whereUuid('id');
    Route::delete('/members/{id}', 'deleteMember')->whereUuid('id');
    Route::get('/prompts', 'getPrompts');
    Route::post('/prompts', 'savePrompts');
    Route::get('/activity-logs', 'listActivityLogs');
});
