<?php

use App\Services\Cache\CacheWarmer;
use App\Services\Notifications\TenantNotificationService;
use App\Services\Sheets\TenantSyncService;
use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

// ── Phase 23D scheduler ────────────────────────────────────────────────────
// Requires the OS cron entry on the server:
//   * * * * * cd /path/to/laravel && php artisan schedule:run >> /dev/null 2>&1

// Sprint 1 — auto-sync every eligible tenant every 15 min. Drift alerts piggyback
// inside TenantSyncService (it calls TenantNotificationService::notifyDrift).
// Cache warming runs AFTER sync completes so fresh data is always cached.
Schedule::call(function () {
    TenantSyncService::syncAllTenants(['force' => false]);
    CacheWarmer::warm();
})
    ->everyFifteenMinutes()
    ->name('tenant-auto-sync')
    ->withoutOverlapping();

// Additional cache warming every 5 min (for between syncs — keeps cache fresh
// without waiting for the 15-min sync cycle).
Schedule::call(fn () => CacheWarmer::warm())
    ->everyFiveMinutes()
    ->name('cache-warm')
    ->withoutOverlapping();

// Sprint 2 — meeting reminders (15 min before). Runs every minute; per-event
// Cache dedup prevents double-sends.
Schedule::call(fn () => TenantNotificationService::checkReminders())
    ->everyMinute()
    ->name('tenant-reminders')
    ->withoutOverlapping();

// Sprint 3 — daily 8 AM IST schedule. The service guards the 08:00 hour + per-tenant
// per-day Cache dedup, so an hourly tick is enough (avoids needing a TZ-aware cron).
Schedule::call(fn () => TenantNotificationService::sendDailySchedules())
    ->hourly()
    ->name('tenant-daily-schedule')
    ->withoutOverlapping();

// External API data sync — every 30 min. Pulls delegation/checklist/leads/calls/visiting
// from apps.apimis.co.in into local MySQL tables for accurate SQL querying.
Schedule::command('sync:external-apis')
    ->everyThirtyMinutes()
    ->name('external-api-sync')
    ->withoutOverlapping();
