<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('tenant_query_logs')) {
            Schema::create('tenant_query_logs', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->uuid('tenant_id');
                $table->string('phone', 30)->nullable();
                $table->text('query')->nullable();
                $table->text('sql_generated')->nullable();
                $table->text('response')->nullable();
                $table->integer('tokens_used')->nullable();
                $table->timestamp('created_at')->useCurrent();

                $table->foreign('tenant_id')
                    ->references('id')->on('tenants')
                    ->cascadeOnDelete();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('tenant_query_logs');
    }
};
