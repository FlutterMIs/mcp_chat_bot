<?php

use Illuminate\Database\Migrations\Migration;

/**
 * PostgreSQL functions (pg_trgm, execute_ddl, tenant_fuzzy_search, etc.) are not
 * needed on MySQL. Their functionality is handled directly in PHP:
 *   - execute_ddl → DB::statement() directly
 *   - tenant_fuzzy_search → LIKE-based search in FuzzyFallback/LedgerEntityResolver
 *   - tenant_list_tables → information_schema query in PHP
 *   - tenant_drop_all_tables → PHP loop with DROP TABLE
 *
 * This migration is intentionally empty for MySQL compatibility.
 */
return new class extends Migration
{
    public function up(): void
    {
        // No-op on MySQL — all PG functions replaced with PHP logic
    }

    public function down(): void
    {
        // No-op
    }
};
