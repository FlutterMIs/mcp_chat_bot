<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->string('ai_vendor', 20)->nullable()->after('webhook_token');
            $table->string('ai_model', 50)->nullable()->after('ai_vendor');
            $table->text('ai_api_key')->nullable()->after('ai_model');
        });
    }

    public function down(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->dropColumn(['ai_vendor', 'ai_model', 'ai_api_key']);
        });
    }
};
