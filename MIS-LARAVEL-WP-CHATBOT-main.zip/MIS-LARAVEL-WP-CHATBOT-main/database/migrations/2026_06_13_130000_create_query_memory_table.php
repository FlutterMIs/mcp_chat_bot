<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        DB::statement("
            CREATE TABLE IF NOT EXISTS query_memory (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                tenant_id VARCHAR(36) NOT NULL,
                query_hash VARCHAR(64) NOT NULL,
                query_text VARCHAR(500) NOT NULL,
                sql_used TEXT NOT NULL,
                result_summary VARCHAR(500) DEFAULT NULL,
                confidence FLOAT DEFAULT 0.5,
                times_used INT DEFAULT 1,
                is_valid BOOLEAN DEFAULT TRUE,
                last_used_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY idx_tenant_hash (tenant_id, query_hash),
                INDEX idx_tenant_valid (tenant_id, is_valid)
            )
        ");
    }

    public function down(): void
    {
        DB::statement("DROP TABLE IF EXISTS query_memory");
    }
};
