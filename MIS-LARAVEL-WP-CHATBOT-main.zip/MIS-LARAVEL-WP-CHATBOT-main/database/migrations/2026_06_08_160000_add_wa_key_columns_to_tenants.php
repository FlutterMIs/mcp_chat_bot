<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->string('wa_key_mode', 10)->default('shared')->after('calendar_connected');
            $table->text('wa_api_key')->nullable()->after('wa_key_mode');
            $table->string('wa_connected_number', 20)->nullable()->after('wa_api_key');
        });
    }

    public function down(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->dropColumn(['wa_key_mode', 'wa_api_key', 'wa_connected_number']);
        });
    }
};
