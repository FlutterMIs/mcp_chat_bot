<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('tenant_data')) {
            Schema::create('tenant_data', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->uuid('tenant_id');
                $table->string('sheet_name', 100);
                $table->string('table_name', 100)->nullable();
                $table->json('row_data');
                $table->integer('row_index')->nullable();
                $table->timestamp('synced_at')->useCurrent();

                $table->foreign('tenant_id')
                    ->references('id')->on('tenants')
                    ->cascadeOnDelete();

                $table->index('tenant_id', 'idx_tenant_data_tenant');
                $table->index(['tenant_id', 'sheet_name'], 'idx_tenant_data_sheet');
                $table->index(['tenant_id', 'table_name'], 'idx_tenant_data_table');
            });
        } else {
            if (! Schema::hasColumn('tenant_data', 'table_name')) {
                Schema::table('tenant_data', function (Blueprint $table) {
                    $table->string('table_name', 100)->nullable();
                    $table->index(['tenant_id', 'table_name'], 'idx_tenant_data_table');
                });
            }
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('tenant_data');
    }
};
