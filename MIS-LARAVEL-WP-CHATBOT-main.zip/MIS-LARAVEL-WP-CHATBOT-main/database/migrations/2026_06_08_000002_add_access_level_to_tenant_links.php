<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('tenant_links', function (Blueprint $table) {
            $table->string('access_level', 10)->default('all')->after('category'); // all, team, owner
        });
    }

    public function down(): void
    {
        Schema::table('tenant_links', function (Blueprint $table) {
            $table->dropColumn('access_level');
        });
    }
};
