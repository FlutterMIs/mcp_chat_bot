<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('sheet_tab_access', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->uuid('tenant_id')->index();
            $table->uuid('tenant_sheet_id')->nullable();
            $table->string('tab_name', 100);
            $table->string('pg_table', 100)->nullable();
            $table->boolean('access_all')->default(false);
            $table->boolean('access_team')->default(false);
            $table->string('team_match_column', 100)->nullable();
            $table->boolean('access_client')->default(false);
            $table->string('client_match_column', 100)->nullable();
            $table->timestamps();

            $table->unique(['tenant_id', 'tenant_sheet_id', 'tab_name']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sheet_tab_access');
    }
};
