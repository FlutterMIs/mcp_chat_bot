<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('tenant_api_keys', function (Blueprint $table) {
            $table->tinyInteger('type')->default(3)->comment('1=Professional WA, 2=Unprofessional WA, 3=Other')->after('label');
            $table->string('device_id', 100)->nullable()->after('api_key');
        });

        Schema::table('tenants', function (Blueprint $table) {
            $table->dropColumn(['wa_api_key', 'wa_pro_api_key', 'wa_device_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('tenants', function (Blueprint $table) {
            $table->text('wa_api_key')->nullable()->after('wa_key_mode');
            $table->text('wa_pro_api_key')->nullable()->after('wa_api_key');
            $table->string('wa_device_id', 100)->nullable()->after('wa_channel_mode');
        });

        Schema::table('tenant_api_keys', function (Blueprint $table) {
            $table->dropColumn(['type', 'device_id']);
        });
    }
};
