<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('user_databases')) {
            Schema::create('user_databases', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->string('phone', 30);
                $table->uuid('tenant_id');
                $table->string('alias', 100)->nullable();
                $table->boolean('is_default')->default(false);
                $table->timestamp('created_at')->useCurrent();

                $table->foreign('tenant_id')
                    ->references('id')->on('tenants')
                    ->cascadeOnDelete();

                $table->unique(['phone', 'tenant_id']);
                $table->index('phone', 'idx_user_databases_phone');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('user_databases');
    }
};
