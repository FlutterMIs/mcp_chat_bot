<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('wp_sessions')) {
            Schema::create('wp_sessions', function (Blueprint $table) {
                $table->string('phone', 30)->primary();
                $table->json('data')->nullable();
                $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
            });
        }

        if (! Schema::hasTable('message_logs')) {
            Schema::create('message_logs', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('platform', 20);
                $table->string('direction', 5);
                $table->string('phone', 30)->nullable();
                $table->string('session_id', 100)->nullable();
                $table->string('message_type', 20)->default('text');
                $table->text('message')->nullable();
                $table->timestamp('created_at')->useCurrent();

                $table->index(['phone', 'created_at'], 'message_logs_phone_idx');
                $table->index('session_id', 'message_logs_session_idx');
            });
        }

        if (! Schema::hasTable('chat_history')) {
            Schema::create('chat_history', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('session_id', 100)->index();
                $table->string('role', 20);
                $table->text('content');
                $table->uuid('tenant_id')->nullable();
                $table->timestamp('created_at')->useCurrent();
            });
        }

        if (! Schema::hasTable('calendar_logs')) {
            Schema::create('calendar_logs', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('phone', 30)->nullable();
                $table->uuid('tenant_id')->nullable();
                $table->string('action', 30);
                $table->string('event_id', 255)->nullable();
                $table->string('title', 255)->nullable();
                $table->string('guest', 255)->nullable();
                $table->string('guest_email', 255)->nullable();
                $table->timestamp('starts_at')->nullable();
                $table->timestamp('ends_at')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamp('created_at')->useCurrent();

                $table->index(['phone', 'created_at'], 'calendar_logs_phone_idx');
            });
        }

        if (! Schema::hasTable('sync_log')) {
            Schema::create('sync_log', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('sheet_name', 100);
                $table->integer('rows_synced')->default(0);
                $table->string('status', 255);
                $table->timestamp('created_at')->useCurrent();

                $table->index('sheet_name', 'sync_log_sheet_idx');
                $table->index('created_at', 'sync_log_age_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('sync_log');
        Schema::dropIfExists('calendar_logs');
        Schema::dropIfExists('chat_history');
        Schema::dropIfExists('message_logs');
        Schema::dropIfExists('wp_sessions');
    }
};
