<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('user_databases') && ! Schema::hasColumn('user_databases', 'permissions')) {
            Schema::table('user_databases', function (Blueprint $table) {
                $table->json('permissions')->nullable()->after('is_default');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('user_databases', 'permissions')) {
            Schema::table('user_databases', function (Blueprint $table) {
                $table->dropColumn('permissions');
            });
        }
    }
};
