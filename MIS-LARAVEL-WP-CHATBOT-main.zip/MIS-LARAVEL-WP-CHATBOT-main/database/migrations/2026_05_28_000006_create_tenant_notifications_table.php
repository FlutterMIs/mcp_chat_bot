<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('tenant_notifications')) {
            Schema::create('tenant_notifications', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->uuid('tenant_id');
                $table->string('phone', 30)->nullable();
                $table->string('kind', 50);
                $table->string('title', 255);
                $table->text('message')->nullable();
                $table->json('metadata')->nullable();
                $table->string('severity', 20)->default('info');
                $table->timestamp('read_at')->nullable();
                $table->timestamp('created_at')->useCurrent();

                $table->foreign('tenant_id')
                    ->references('id')->on('tenants')
                    ->cascadeOnDelete();

                $table->index(['phone', 'created_at'], 'tenant_notifications_phone_idx');
                $table->index(['tenant_id', 'created_at'], 'tenant_notifications_tenant_idx');
                $table->index('created_at', 'tenant_notifications_age_idx');
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('tenant_notifications');
    }
};
