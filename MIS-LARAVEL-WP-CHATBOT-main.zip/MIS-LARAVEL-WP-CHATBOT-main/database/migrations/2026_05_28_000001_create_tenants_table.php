<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('tenants')) {
            Schema::create('tenants', function (Blueprint $table) {
                $table->uuid('id')->primary();
                $table->text('name');
                $table->string('phone', 30)->index('tenants_phone_lookup_idx');
                $table->text('email')->nullable();
                $table->text('sheet_url')->nullable();
                $table->text('sheet_id')->nullable();
                $table->text('business_description')->nullable();
                $table->text('system_prompt')->nullable();
                $table->json('schema_json')->nullable();
                $table->string('status', 20)->default('active');
                $table->string('plan', 20)->default('free');
                $table->integer('queries_this_month')->default(0);
                $table->integer('query_limit')->default(50);

                $table->text('calendar_id')->nullable();
                $table->text('calendar_refresh_token')->nullable();
                $table->boolean('calendar_connected')->default(false);

                $table->boolean('proper_tables_created')->default(false);
                $table->json('tables_metadata')->nullable();

                $table->timestamp('created_at')->useCurrent();
                $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
            });
        } else {
            Schema::table('tenants', function (Blueprint $table) {
                if (! Schema::hasColumn('tenants', 'calendar_id')) {
                    $table->text('calendar_id')->nullable();
                }
                if (! Schema::hasColumn('tenants', 'calendar_refresh_token')) {
                    $table->text('calendar_refresh_token')->nullable();
                }
                if (! Schema::hasColumn('tenants', 'calendar_connected')) {
                    $table->boolean('calendar_connected')->default(false);
                }
                if (! Schema::hasColumn('tenants', 'proper_tables_created')) {
                    $table->boolean('proper_tables_created')->default(false);
                }
                if (! Schema::hasColumn('tenants', 'tables_metadata')) {
                    $table->json('tables_metadata')->nullable();
                }
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('tenants');
    }
};
