<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tenant_prompts', function (Blueprint $table) {
            $table->id();
            $table->string('tenant_id', 36)->index();
            $table->string('prompt_key', 50);
            $table->text('prompt_value');
            $table->timestamp('updated_at')->useCurrent();
            $table->unique(['tenant_id', 'prompt_key']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tenant_prompts');
    }
};
