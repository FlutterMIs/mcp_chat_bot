<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('tenant_pdf_chunks', function (Blueprint $table) {
            $table->id();
            $table->string('tenant_id', 36)->index();
            $table->string('source_url', 1024);
            $table->string('title', 500)->nullable();
            $table->integer('chunk_index')->default(0);
            $table->text('content'); // chunk of PDF text
            $table->timestamps();

            $table->index(['tenant_id', 'title']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('tenant_pdf_chunks');
    }
};
