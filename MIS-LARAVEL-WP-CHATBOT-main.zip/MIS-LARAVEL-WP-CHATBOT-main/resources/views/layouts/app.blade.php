<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <title>@yield('title', 'Dashboard') · {{ config('app.name', 'MIS') }}</title>
    <meta name="theme-color" content="#00A4D2">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet"
        media="print" onload="this.media='all'">
    {{-- Cache-bust by file mtime, NOT time(): a fresh time() every request made the
       browser re-download the 150KB stylesheet on every single page load. filemtime
       only changes when the file actually changes, so it now caches between visits. --}}
    @php
        $cssPath = public_path('assets/css/style.css');
        $appJsPath = public_path('assets/js/app.js');
        $cssVer = is_file($cssPath) ? filemtime($cssPath) : '1';
        $appJsVer = is_file($appJsPath) ? filemtime($appJsPath) : '1';
    @endphp
    <link rel="stylesheet" href="/assets/css/style.css?v={{ $cssVer }}">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" media="print"
        onload="this.media='all'">
    {{-- app.js must stay synchronous — the inline auth-guard below reads window.MIS,
       which app.js defines. sweetalert2 is only used inside click handlers, so defer. --}}
    <script defer src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="/assets/js/app.js?v={{ $appJsVer }}"></script>
    <script>
        if (!window.MIS || !window.MIS.auth || !window.MIS.auth.getPhone()) {
            window.location.replace('/login');
        }
        // Restore sidebar collapsed state before first paint (avoids a flash of the
        // expanded sidebar snapping shut on load). Class lives on <html> so it's
        // present the instant .app-shell renders — CSS targets html.sidebar-collapsed.
        try {
            if (localStorage.getItem('mis_sidebar_collapsed') === '1') {
                document.documentElement.classList.add('sidebar-collapsed');
            }
        } catch (e) {}
    </script>
    {{-- Pinned + minified on jsdelivr (was @latest on unpkg — unversioned, redirect-heavy,
       uncacheable, liable to break on a major release). Kept synchronous on purpose: page
       scripts (chat.js, per-page inline blocks) call lucide.createIcons() at top level, so
       window.lucide must exist before those normal end-of-body scripts run — deferring it
       would leave icons unrendered on first paint. --}}
    <script src="https://cdn.jsdelivr.net/npm/lucide@0.469.0/dist/umd/lucide.min.js"></script>
    @stack('head')
    <style>
        @yield('styles')
    </style>
</head>

<body>
    <div class="app-shell">
        @include('layouts.partials.sidebar')

        <main class="main">
            <header class="topbar glass">
                <div style="display:flex; align-items:center; gap:14px;">
                    <button class="btn-icon mobile-toggle" id="sidebarToggle" type="button">
                        <i data-lucide="menu"></i>
                    </button>
                    <div class="tenant-avatar" id="tenantAvatar" aria-hidden="true">M</div>
                    <div class="greeting">
                        <div class="who">
                            <span id="tenant-name">Loading…</span>
                            <span class="status-dot" title="Connected"></span>
                        </div>
                        <div class="when" id="today-date">—</div>
                    </div>
                </div>
                <div style="display:flex; align-items:center; gap:12px;">
                    @hasSection('topbar-actions')
                        @yield('topbar-actions')
                    @else
                        <button class="btn-icon" id="refreshBtn" type="button" aria-label="Refresh"><i
                                data-lucide="refresh-cw"></i></button>
                    @endif
                    <button class="btn-icon" id="searchBtn" type="button" aria-label="Search" title="Search (⌘K)"><i
                            data-lucide="search"></i></button>
                    <button class="btn-icon" id="notifBtn" type="button" aria-label="Notifications"
                        style="position:relative;">
                        <i data-lucide="bell"></i>
                        <span class="notif-dot" id="notifDot" style="display:none"></span>
                        <span id="notifBadge"
                            style="display:none; position:absolute; top:-2px; right:-2px; min-width:16px; height:16px; padding:0 4px; border-radius:8px; background:rgb(239,68,68); color:white; font-size:10px; font-weight:700; line-height:16px; text-align:center; box-shadow:0 0 0 2px var(--surface-card);"></span>
                    </button>
                    <div class="user-menu" id="userMenu">
                        <button type="button" class="user-menu-trigger" id="userMenuTrigger" aria-haspopup="true"
                            aria-expanded="false" aria-label="Account menu">
                            <div class="avatar" id="avatar-init" title="Account">M</div>
                            <i data-lucide="chevron-down" class="user-menu-chevron"></i>
                        </button>
                        <div class="user-menu-panel" id="userMenuPanel" role="menu">
                            <a class="user-menu-item" href="/settings" role="menuitem">
                                <i data-lucide="settings"></i><span>Settings</span>
                            </a>
                            <a class="user-menu-item" href="/admin" role="menuitem" data-requires="super_admin">
                                <i data-lucide="shield"></i><span>Admin Panel</span>
                            </a>
                            <div class="user-menu-divider"></div>
                            <a class="user-menu-item danger" href="#" id="userMenuLogout" role="menuitem">
                                <i data-lucide="log-out"></i><span>Sign out</span>
                            </a>
                        </div>
                    </div>
                </div>
            </header>

            <div class="content-scrollable">
                @yield('content')
            </div>
        </main>

        @yield('drawers')
    </div><!-- .app-shell -->

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            if (window.lucide) lucide.createIcons();
            if (window.MIS) {
                if (window.MIS.theme && window.MIS.theme.init) window.MIS.theme.init();
                if (window.MIS.applySidebarAccess) window.MIS.applySidebarAccess();
            }
            // Mobile sidebar toggle
            const toggle = document.getElementById('sidebarToggle');
            if (toggle) toggle.addEventListener('click', () => document.getElementById('sidebar').classList.toggle(
                'open'));
            // Desktop sidebar collapse/expand — icon-only rail with hover tooltips when collapsed
            const collapseBtn = document.getElementById('sidebarCollapseBtn');
            if (collapseBtn) {
                collapseBtn.addEventListener('click', () => {
                    const collapsed = document.documentElement.classList.toggle('sidebar-collapsed');
                    try {
                        localStorage.setItem('mis_sidebar_collapsed', collapsed ? '1' : '0');
                    } catch (e) {}
                    collapseBtn.setAttribute('aria-label', collapsed ? 'Expand sidebar' :
                        'Collapse sidebar');
                    collapseBtn.setAttribute('title', collapsed ? 'Expand sidebar' : 'Collapse sidebar');
                });
            }
            // Theme toggle
            const cb = document.getElementById('themeSwitchCheckbox');
            if (cb) cb.addEventListener('change', () => {
                if (window.MIS && window.MIS.theme) window.MIS.theme.toggle();
            });
            // Logout (sidebar)
            const lo = document.getElementById('logoutLink');
            if (lo) lo.addEventListener('click', (e) => {
                e.preventDefault();
                window.MIS.confirmLogout();
            });

            // Navbar avatar dropdown — Settings / Admin Panel (super_admin only, gated by
            // the same data-requires="super_admin" mechanism applySidebarAccess() already
            // applies to the sidebar) / Sign out.
            const userMenu = document.getElementById('userMenu');
            const userMenuTrigger = document.getElementById('userMenuTrigger');
            if (userMenu && userMenuTrigger) {
                const closeUserMenu = () => {
                    userMenu.classList.remove('open');
                    userMenuTrigger.setAttribute('aria-expanded', 'false');
                };
                userMenuTrigger.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const willOpen = !userMenu.classList.contains('open');
                    userMenu.classList.toggle('open', willOpen);
                    userMenuTrigger.setAttribute('aria-expanded', willOpen ? 'true' : 'false');
                });
                document.addEventListener('click', (e) => {
                    if (userMenu.classList.contains('open') && !userMenu.contains(e.target))
                        closeUserMenu();
                });
                document.addEventListener('keydown', (e) => {
                    if (e.key === 'Escape') closeUserMenu();
                });
                const userMenuLogout = document.getElementById('userMenuLogout');
                if (userMenuLogout) {
                    userMenuLogout.addEventListener('click', (e) => {
                        e.preventDefault();
                        closeUserMenu();
                        window.MIS.confirmLogout();
                    });
                }
            }
        });
    </script>
    @stack('scripts')
</body>

</html>
