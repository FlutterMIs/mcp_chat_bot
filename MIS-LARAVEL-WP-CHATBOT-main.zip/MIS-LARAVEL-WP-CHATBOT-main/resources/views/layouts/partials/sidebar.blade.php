<aside class="sidebar glass" id="sidebar">
    <button class="sidebar-collapse-btn" id="sidebarCollapseBtn" type="button" aria-label="Collapse sidebar"
        title="Collapse sidebar">
        <i data-lucide="chevron-left"></i>
    </button>

    <div class="sidebar-brand">
        <div class="logo">{{ substr(config('app.name', 'M'), 0, 1) }}</div>
        <div class="brand-text">
            <div class="name">{{ config('app.name', 'MIS') }}</div>
            <div class="tag">Make It Simple</div>
        </div>
    </div>

    <div class="nav-section">
        <a class="nav-item @if (request()->is('dashboard')) active @endif" href="/dashboard"
            data-requires-perm="dashboard" data-tooltip="Dashboard">
            <i data-lucide="layout-dashboard"></i><span>Dashboard</span>
        </a>
        <a class="nav-item @if (request()->is('chat')) active @endif" href="/chat" data-requires-perm="chat"
            data-tooltip="Chatbot">
            <i data-lucide="message-square-text"></i><span>Chatbot</span>
        </a>
    </div>

    <div class="nav-section">
        <div class="nav-section-label">Insights</div>
        <a class="nav-item @if (request()->is('sales')) active @endif" href="/sales" data-requires-perm="sales"
            data-tooltip="Sales">
            <i data-lucide="trending-up"></i><span>Sales</span>
        </a>
        <a class="nav-item @if (request()->is('outstanding')) active @endif" href="/outstanding"
            data-requires-perm="outstanding" data-tooltip="Outstanding">
            <i data-lucide="hourglass"></i><span>Outstanding</span>
        </a>
        <a class="nav-item @if (request()->is('stock')) active @endif" href="/stock" data-requires-perm="stock"
            data-tooltip="Stock">
            <i data-lucide="package"></i><span>Stock</span>
        </a>
        <a class="nav-item @if (request()->is('ledger')) active @endif" href="/ledger" data-requires-perm="ledger"
            data-tooltip="Ledger">
            <i data-lucide="book-open"></i><span>Ledger</span>
        </a>
        <a class="nav-item @if (request()->is('calendar')) active @endif" href="/calendar"
            data-requires-perm="calendar" data-tooltip="Calendar">
            <i data-lucide="calendar"></i><span>Calendar</span>
        </a>
        <a class="nav-item @if (request()->is('reports')) active @endif" href="/reports" data-requires-perm="reports"
            data-tooltip="Reports">
            <i data-lucide="bar-chart-3"></i><span>Reports</span>
        </a>
    </div>

    {{-- Members management lives inside Settings → Team Members, so the standalone
       "Members" sidebar link was removed to avoid duplication. Access Control is now
       grouped under Admin (shown right after Admin Panel). The section is owner-visible;
       the Admin Panel link stays super-admin-only via its own data-requires. --}}
    <div class="nav-section" data-requires="owner">
        <div class="nav-section-label">Admin</div>
        <a class="nav-item @if (request()->is('admin')) active @endif" href="/admin" data-requires="super_admin"
            data-tooltip="Admin Panel">
            <i data-lucide="shield"></i><span>Admin Panel</span>
        </a>
        <a class="nav-item @if (request()->is('access-control')) active @endif" href="/access-control" data-requires="owner"
            data-tooltip="Access Control">
            <i data-lucide="shield-check"></i><span>Access Control</span>
        </a>
    </div>

    <div class="sidebar-footer">
        <a class="nav-item @if (request()->is('settings')) active @endif" href="/settings" data-tooltip="Settings">
            <i data-lucide="settings"></i><span>Settings</span>
        </a>
        <label class="theme-toggle" id="themeRow" style="cursor: pointer;" data-tooltip="Dark mode">
            <span style="display:flex; align-items:center; gap:10px;">
                <i data-lucide="moon" style="width:16px;height:16px;"></i>Dark mode
            </span>
            <input type="checkbox" id="themeSwitchCheckbox" style="display: none;" />
            <div class="toggle-switch" id="themeSwitch"></div>
        </label>
        <a class="nav-item" href="#" id="logoutLink" data-tooltip="Sign out">
            <i data-lucide="log-out"></i><span>Sign out</span>
        </a>
    </div>
</aside>
