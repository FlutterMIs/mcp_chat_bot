@extends('layouts.app')

@section('title', 'Outstanding')

@push('head')
  <script src="https://cdn.sheetjs.com/xlsx-0.20.2/package/dist/xlsx.full.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
@endpush

@section('content')
    <div class="page">
    <div class="page-header page-header-hero">
      <div class="page-header-bg">
        <div class="aurora aurora-1"></div>
        <div class="aurora aurora-2"></div>
        <div class="aurora aurora-3"></div>
        <div class="grid-overlay"></div>
      </div>
      <div class="page-header-content">
        <div class="page-icon-glow"><i data-lucide="hourglass"></i></div>
        <div class="page-header-text">
          <div class="page-title-row">
            <h1 class="t-h1 page-title-gradient">Outstanding</h1>
            <span class="live-pill"><span class="live-dot"></span>Live</span>
          </div>
          <p class="page-desc">Unpaid purchases · aging breakdown · top defaulters</p>
          <div class="page-chips">
            <span class="page-chip"><i data-lucide="layers" style="width:12px;height:12px;"></i> Aging buckets</span>
            <span class="page-chip"><i data-lucide="alert-triangle" style="width:12px;height:12px;"></i> Top defaulters</span>
            <span class="page-chip"><i data-lucide="file-spreadsheet" style="width:12px;height:12px;"></i> Excel export</span>
          </div>
          <div class="page-underline"></div>
        </div>
        <button id="exportCsvBtn" type="button" style="padding:9px 16px; border-radius:10px; background:var(--accent-violet); color:#fff; font-weight:600; font-size:13px; border:none; cursor:pointer; flex-shrink:0; align-self:flex-start;">⬇ Export Excel</button>
      </div>
    </div>

    <div class="page-grid">
      <div class="kpi-row" id="kpi-row">
        <div class="skel-kpi"><div class="skel skel-icon"></div><div class="skel skel-label"></div><div class="skel skel-value"></div><div class="skel skel-delta"></div></div>
        <div class="skel-kpi"><div class="skel skel-icon"></div><div class="skel skel-label"></div><div class="skel skel-value"></div><div class="skel skel-delta"></div></div>
        <div class="skel-kpi"><div class="skel skel-icon"></div><div class="skel skel-label"></div><div class="skel skel-value"></div><div class="skel skel-delta"></div></div>
        <div class="skel-kpi"><div class="skel skel-icon"></div><div class="skel skel-label"></div><div class="skel skel-value"></div><div class="skel skel-delta"></div></div>
      </div>

      <div class="charts-row">
        <div class="chart-card">
          <div class="chart-header">
            <div><div class="t-h3">Aging Buckets</div><div class="t-meta">By days outstanding</div></div>
            <div class="chart-icon"><i data-lucide="hourglass"></i></div>
          </div>
          <div class="body"><canvas id="chartAging"></canvas></div>
        </div>
        <div class="chart-card">
          <div class="chart-header">
            <div><div class="t-h3">Outstanding Trend</div><div class="t-meta">Daily accrual · last 90 days</div></div>
            <div class="chart-icon"><i data-lucide="activity"></i></div>
          </div>
          <div class="body"><canvas id="chartTrend"></canvas></div>
        </div>
      </div>

      <div class="defaulters">
        <div class="chart-header">
          <div><div class="t-h3">Top Defaulters</div><div class="t-meta" id="defMeta">—</div></div>
          <div class="chart-icon"><i data-lucide="alert-circle"></i></div>
        </div>
        <table>
          <thead><tr><th>Party</th><th class="num">Total Outstanding</th><th class="num">Invoices</th><th>Oldest Age</th><th>0-30</th><th>31-60</th><th>61-90</th><th>90+</th></tr></thead>
          <tbody id="defBody"></tbody>
        </table>
      </div>
    </div>
    </div>
@endsection

@push('scripts')
<script>
(function() {
  'use strict';

  const PHONE = window.MIS.auth.getPhone();
  const tName = window.MIS.auth.getTenantName() || '—';
  document.getElementById('tenant-name').textContent = tName;
  document.getElementById('tenantAvatar').textContent = (tName.charAt(0) || 'M').toUpperCase();

  if (window.MIS.theme && window.MIS.theme.init) window.MIS.theme.init();
  document.getElementById('themeRow').addEventListener('click', () => window.MIS.theme.toggle());
  document.getElementById('logoutLink').addEventListener('click', (e) => { e.preventDefault(); window.MIS.confirmLogout(); });
  document.getElementById('refreshBtn').addEventListener('click', () => loadPage());

  function applyChartDefaults() {
    if (!window.Chart) return;
    const dark = document.documentElement.getAttribute('data-theme') === 'dark';
    Chart.defaults.color = dark ? '#F5F5F7' : '#1D1D1F';
    Chart.defaults.borderColor = dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
  }
  applyChartDefaults();
  const charts = {};
  new MutationObserver(() => { applyChartDefaults(); Object.values(charts).forEach(c => { try { c.update('none'); } catch {} }); })
    .observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

  const inr = (v) => window.MIS.fmt.inr(v);
  const num = (v) => window.MIS.fmt.num(v);

  function destroyCharts() { Object.keys(charts).forEach(k => { try { charts[k].destroy(); } catch {} delete charts[k]; }); }

  function renderKpis(kpis) {
    const row = document.getElementById('kpi-row');
    row.innerHTML = '';
    const cards = [
      { id: 'total_outstanding', title: 'Total Outstanding', icon: 'wallet',     accent: 'rose' },
      { id: 'unpaid_count',      title: 'Unpaid Invoices',   icon: 'file-x',     accent: 'amber' },
      { id: 'bucket_90plus',     title: '90+ Days',          icon: 'alert-triangle', accent: 'rose' },
      { id: 'oldest_age',        title: 'Oldest (days)',     icon: 'clock',      accent: 'violet' }
    ];
    for (const c of cards) {
      const k = kpis[c.id];
      if (!k) continue;
      let v;
      if (c.id === 'oldest_age') v = num(k.value) + ' d';
      else v = (k.format === 'inr') ? inr(k.value) : num(k.value);
      const div = document.createElement('div');
      div.className = 'kpi tilt-card';
      div.style.cssText = `--kpi-color: var(--accent-${c.accent}); --kpi-soft: var(--accent-${c.accent}-soft); --kpi-glow: var(--accent-${c.accent}-glow);`;
      div.innerHTML = `<div class="kpi-top"><div class="kpi-icon-box"><i data-lucide="${c.icon}"></i></div></div><div class="kpi-label">${c.title}</div><div class="kpi-value">${v}</div>`;
      row.appendChild(div);
    }
    if (window.lucide) window.lucide.createIcons();
  }

  function renderAging(buckets) {
    const ctx = document.getElementById('chartAging').getContext('2d');
    const labels = ['0-30 days', '31-60 days', '61-90 days', '90+ days'];
    const data = [buckets['0-30'] || 0, buckets['31-60'] || 0, buckets['61-90'] || 0, buckets['90+'] || 0];
    const colors = ['#10B981', '#F59E0B', '#FB923C', '#F43F5E'];
    charts.aging = new Chart(ctx, {
      type: 'bar',
      data: { labels, datasets: [{ data, backgroundColor: colors.map(c => c + 'CC'), hoverBackgroundColor: colors, borderRadius: 8, barPercentage: 0.6 }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: { backgroundColor: 'rgba(15,15,20,0.92)', titleColor: '#F5F5F7', bodyColor: '#E5E5EA', callbacks: { label: (i) => '  ' + inr(i.parsed.y) } } },
        scales: {
          x: { grid: { display: false } },
          y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { maxTicksLimit: 5, callback: (v) => inr(v) } }
        }
      }
    });
  }

  function renderTrend(trend) {
    const ctx = document.getElementById('chartTrend').getContext('2d');
    const grad = ctx.createLinearGradient(0, 0, 0, 280);
    grad.addColorStop(0, 'rgba(244,63,94,0.40)'); grad.addColorStop(0.5, 'rgba(217,70,239,0.12)'); grad.addColorStop(1, 'rgba(0,0,0,0)');
    charts.trend = new Chart(ctx, {
      type: 'line',
      data: { labels: trend.labels, datasets: [{ data: trend.data, borderColor: '#F43F5E', backgroundColor: grad, borderWidth: 2.6, tension: 0.25, cubicInterpolationMode: 'monotone', fill: true, pointRadius: 0, pointHoverRadius: 6, pointHitRadius: 18, pointBackgroundColor: '#F43F5E', pointBorderColor: '#fff', pointBorderWidth: 2, spanGaps: true }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: { legend: { display: false }, tooltip: { backgroundColor: 'rgba(15,15,20,0.92)', titleColor: '#F5F5F7', bodyColor: '#E5E5EA', callbacks: { label: (i) => '  ' + inr(i.parsed.y) } } },
        scales: {
          x: { grid: { display: false }, ticks: { maxTicksLimit: 8, autoSkip: true, callback: function(v, i) { const raw = this.getLabelForValue ? this.getLabelForValue(v) : trend.labels[i]; if (typeof raw === 'string' && /^\d{4}-\d{2}-\d{2}/.test(raw)) { const dd = new Date(raw + 'T00:00:00'); return isNaN(dd) ? raw : dd.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }); } return raw; } } },
          y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { maxTicksLimit: 5, callback: (v) => inr(v) } }
        }
      }
    });
  }

  function renderDefaulters(rows) {
    const tbody = document.getElementById('defBody');
    tbody.innerHTML = '';
    if (!rows || !rows.length) {
      tbody.innerHTML = '<tr><td colspan="8" style="text-align:center; padding:30px; color:var(--color-text-tertiary);">No outstanding amounts.</td></tr>';
      document.getElementById('defMeta').textContent = '0 parties';
      return;
    }
    for (const r of rows) {
      const tr = document.createElement('tr');
      const ageBucket = r.oldest_age <= 30 ? 'bg-30' : r.oldest_age <= 60 ? 'bg-60' : r.oldest_age <= 90 ? 'bg-90' : 'bg-99';
      tr.innerHTML = `
        <td>${r.party}</td>
        <td class="num">${inr(r.total)}</td>
        <td class="num">${num(r.count)}</td>
        <td><span class="age-pill ${ageBucket}">${r.oldest_age} d</span></td>
        <td class="num">${r.buckets['0-30'] ? inr(r.buckets['0-30']) : '—'}</td>
        <td class="num">${r.buckets['31-60'] ? inr(r.buckets['31-60']) : '—'}</td>
        <td class="num">${r.buckets['61-90'] ? inr(r.buckets['61-90']) : '—'}</td>
        <td class="num">${r.buckets['90+'] ? inr(r.buckets['90+']) : '—'}</td>`;
      tbody.appendChild(tr);
    }
    document.getElementById('defMeta').textContent = `${rows.length} parties`;
  }

  async function loadPage() {
    destroyCharts();
    const res = await fetch(`/api/page/outstanding?phone=${encodeURIComponent(PHONE)}`);
    if (!res.ok) {
      document.getElementById('kpi-row').innerHTML = '<div class="empty-state"><div class="ic">⚠️</div>Failed to load.</div>';
      return;
    }
    const d = await res.json();
    LAST_DATA = d;
    if (d.tenant?.name) {
      document.getElementById('tenant-name').textContent = d.tenant.name;
      document.getElementById('tenantAvatar').textContent = (d.tenant.name.charAt(0) || 'M').toUpperCase();
    }
    if (d.empty) {
      document.getElementById('kpi-row').innerHTML = `<div class="empty-state"><div class="ic">📊</div>${d.message || 'No data'}</div>`;
      return;
    }
    renderKpis(d.kpis);
    renderAging(d.aging.buckets);
    if (d.trend && d.trend.labels.length) renderTrend(d.trend);
    renderDefaulters(d.top_defaulters);
  }

  let LAST_DATA = null;

  document.addEventListener('DOMContentLoaded', () => { if (window.lucide) window.lucide.createIcons(); loadPage(); });

  document.getElementById('exportCsvBtn').addEventListener('click', () => {
    if (!LAST_DATA || !LAST_DATA.top_defaulters) { alert('No data to export. Wait for load.'); return; }
    if (!window.MIS?.xlsx?.isReady()) { alert('Excel library still loading — please retry.'); return; }
    const sheets = [];
    sheets.push({ name: 'Info', headers: ['Field','Value'], rows: [
      ['Report', 'Outstanding Aging'],
      ['Tenant', LAST_DATA.tenant?.name || 'MIS'],
      ['As of', LAST_DATA.asOf || new Date().toISOString().slice(0,10)],
      ['Generated', new Date().toLocaleString('en-IN')]
    ]});
    const b = (LAST_DATA.aging && LAST_DATA.aging.buckets) || {};
    sheets.push({ name: 'Buckets', headers: ['Bucket','Count','Amount (₹)'],
      rows: ['0-30','31-60','61-90','90+'].map(k => [`${k} days`, Number(b[k]?.count || 0), Number(b[k]?.amount || 0)]) });
    sheets.push({ name: 'Top Defaulters', headers: ['Rank','Party','Outstanding (₹)','Bucket'],
      rows: (LAST_DATA.top_defaulters || []).map((d, i) => [i+1, d.party || '', Number(d.amount || 0), d.bucket || '']) });
    const ts = new Date().toISOString().split('T')[0];
    window.MIS.xlsx.download(`outstanding-${ts}.xlsx`, sheets);
  });
})();
</script>
@endpush
