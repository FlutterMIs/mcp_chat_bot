@extends('layouts.app')

@section('title', 'Reports')

@push('head')
  <script src="https://cdn.sheetjs.com/xlsx-0.20.2/package/dist/xlsx.full.min.js"></script>
@endpush

@section('content')
    <div class="page">
      <div class="page-header page-header-hero">
        <div class="page-header-bg">
          <div class="aurora aurora-1"></div>
          <div class="aurora aurora-2"></div>
          <div class="aurora aurora-3"></div>
          <div class="grid-overlay"></div>
        </div>
        <div class="page-header-content">
          <div class="page-icon-glow"><i data-lucide="bar-chart-3"></i></div>
          <div class="page-header-text">
            <div class="page-title-row">
              <h1 class="t-h1 page-title-gradient">Reports</h1>
              <span class="live-pill"><span class="live-dot"></span>Live</span>
            </div>
            <p class="page-desc">Generate PDF or Excel summaries from your data. Click any card.</p>
            <div class="page-chips">
              <span class="page-chip"><i data-lucide="layers" style="width:12px;height:12px;"></i> Multi-sheet XLSX</span>
              <span class="page-chip"><i data-lucide="filter" style="width:12px;height:12px;"></i> Date-range filter</span>
            </div>
            <div class="page-underline"></div>
          </div>
        </div>
      </div>

      <div class="filter-bar">
        <label>From <input id="fFrom" type="date"></label>
        <label>To <input id="fTo" type="date"></label>
        <button class="btn-secondary" id="resetFilter" type="button">Reset to last 30 days</button>
      </div>

      <div class="report-grid" id="reportGrid">
        <div id="reportGridLoader" style="grid-column:1/-1; padding:40px; text-align:center; color:var(--color-text-tertiary); font-size:13px;">
          <i data-lucide="loader-2" style="width:18px;height:18px;vertical-align:-3px;animation:spin 0.9s linear infinite;"></i>
          &nbsp;&nbsp;Loading available reports for your database…
        </div>
      </div>

@endsection

@section('drawers')
<!-- ──── Format picker modal ──── -->
<div class="modal-backdrop" id="formatModal">
  <div class="modal-card">
    <div class="modal-title" id="formatTitle">Select format</div>
    <div style="font-size:12.5px; color:var(--color-text-tertiary); margin-bottom:6px;" id="formatDateLine"></div>
    <div class="modal-options">
      <button class="format-btn" data-fmt="pdf">
        <div class="icon">📄</div>
        <div class="label">PDF</div>
        <div class="sub">Print-ready, formatted</div>
      </button>
      <button class="format-btn" data-fmt="xlsx">
        <div class="icon">📊</div>
        <div class="label">Excel (XLSX)</div>
        <div class="sub">Multi-sheet, opens directly in Excel/Numbers/Sheets</div>
      </button>
    </div>
    <div class="modal-actions">
      <button class="btn-secondary" id="formatCancel" type="button">Cancel</button>
      <button class="btn-primary" id="formatGenerate" type="button" disabled>Generate</button>
    </div>
  </div>
</div>

<div id="printArea" class="print-only"></div>
<div class="toast" id="toast"></div>
@endsection

@push('scripts')
<script>
(function() {
  'use strict';


  const PHONE = window.MIS.auth.getPhone();

  // Toast — delegates to the shared pretty SweetAlert2 toast component
  function toast(msg, kind = 'ok') { window.MIS.toast(msg, kind); }

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }
  function fmtInr(n) {
    if (n == null || isNaN(n)) return '—';
    n = Number(n);
    if (Math.abs(n) >= 1e7) return '₹' + (n / 1e7).toFixed(2) + ' Cr';
    if (Math.abs(n) >= 1e5) return '₹' + (n / 1e5).toFixed(2) + ' L';
    if (Math.abs(n) >= 1e3) return '₹' + (n / 1e3).toFixed(2) + ' K';
    return '₹' + n.toLocaleString('en-IN');
  }
  function fmtNum(n) {
    if (n == null || isNaN(n)) return '—';
    return Number(n).toLocaleString('en-IN');
  }
  function isoDate(d) { return d.toISOString().split('T')[0]; }

  // ─── Default date range ───
  function setDefaultRange() {
    const today = new Date();
    const monthAgo = new Date(today.getTime() - 30 * 86400000);
    document.getElementById('fFrom').value = isoDate(monthAgo);
    document.getElementById('fTo').value = isoDate(today);
  }
  setDefaultRange();
  document.getElementById('resetFilter').addEventListener('click', setDefaultRange);

  // ─── State ───
  let activeReport = null;       // report id
  let activeReportTitle = null;  // display title
  let activeReportSource = null; // 'sales' | 'purchases' | 'outstanding' | 'stock' | 'ledger' | 'expenses'
  let activeFormat = null;       // 'pdf' | 'xlsx'
  const REPORT_INDEX = {};       // id → {title, desc, icon, source}

  // ─── Load available reports for THIS tenant's DB ───
  async function loadReports() {
    const grid = document.getElementById('reportGrid');
    try {
      const res = await fetch(`/api/reports/list?phone=${encodeURIComponent(PHONE)}`);
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        grid.innerHTML = `<div style="grid-column:1/-1; padding:40px; text-align:center; color:var(--color-text-tertiary);">
          ${escapeHtml(err.error || 'Could not load reports.')}</div>`;
        return;
      }
      const data = await res.json();
      const reports = data.reports || [];
      if (!reports.length) {
        grid.innerHTML = `<div style="grid-column:1/-1; padding:40px; text-align:center; color:var(--color-text-tertiary);">
          No reports available for your database yet. Sync your sheets first.</div>`;
        return;
      }
      grid.innerHTML = reports.map(r => {
        REPORT_INDEX[r.id] = r;
        return `<div class="report-card" data-report="${r.id}">
          <div class="head">
            <div class="ic"><i data-lucide="${r.icon || 'file-text'}"></i></div>
            <div class="t">${escapeHtml(r.title)}</div>
          </div>
          <div class="desc">${escapeHtml(r.desc || '')}</div>
          <div class="formats"><span class="format-pill">PDF</span><span class="format-pill">XLSX</span></div>
        </div>`;
      }).join('');

      // Wire click → open format modal
      document.querySelectorAll('.report-card').forEach(card => {
        card.addEventListener('click', () => openFormatModal(card.dataset.report));
      });

      if (window.lucide) window.lucide.createIcons();
    } catch (e) {
      console.error('[loadReports]', e);
      grid.innerHTML = `<div style="grid-column:1/-1; padding:40px; text-align:center; color:var(--color-text-tertiary);">Network issue — please refresh.</div>`;
    }
  }

  function openFormatModal(reportId) {
    const r = REPORT_INDEX[reportId];
    if (!r) return;
    activeReport = reportId;
    activeReportTitle = r.title;
    activeReportSource = r.source;
    document.getElementById('formatTitle').textContent = r.title;
    const from = document.getElementById('fFrom').value;
    const to = document.getElementById('fTo').value;
    const usesRange = !['outstanding-aging', 'stock-valuation', 'ledger-summary'].includes(reportId);
    document.getElementById('formatDateLine').textContent = usesRange
      ? `Range: ${from || '—'} to ${to || '—'}`
      : 'Snapshot — current state';
    activeFormat = null;
    document.querySelectorAll('.format-btn').forEach(b => b.classList.remove('selected'));
    document.getElementById('formatGenerate').disabled = true;
    document.getElementById('formatModal').classList.add('open');
  }

  document.querySelectorAll('.format-btn').forEach(b => {
    b.addEventListener('click', () => {
      activeFormat = b.dataset.fmt;
      document.querySelectorAll('.format-btn').forEach(x => x.classList.remove('selected'));
      b.classList.add('selected');
      document.getElementById('formatGenerate').disabled = false;
    });
  });

  document.getElementById('formatCancel').addEventListener('click', () => {
    document.getElementById('formatModal').classList.remove('open');
  });
  document.getElementById('formatModal').addEventListener('click', (e) => {
    if (e.target.id === 'formatModal') document.getElementById('formatModal').classList.remove('open');
  });

  document.getElementById('formatGenerate').addEventListener('click', async () => {
    if (!activeReport || !activeFormat) return;
    const btn = document.getElementById('formatGenerate');
    btn.disabled = true; btn.textContent = 'Generating…';
    try {
      await generateReport(activeReport, activeFormat);
      document.getElementById('formatModal').classList.remove('open');
    } catch (e) {
      toast(e.message || 'Generation failed', 'err');
    } finally {
      btn.disabled = false; btn.textContent = 'Generate';
    }
  });

  // ─── Generate report — fetch data from the right /api/page/* ───
  async function generateReport(type, format) {
    const from = document.getElementById('fFrom').value;
    const to = document.getElementById('fTo').value;
    const source = activeReportSource || REPORT_INDEX[type]?.source || 'sales';
    const title = activeReportTitle || REPORT_INDEX[type]?.title || type;

    // Build URL based on source
    let url = `/api/page/${source}?phone=${encodeURIComponent(PHONE)}`;
    if (['sales', 'purchases', 'expenses'].includes(source)) {
      if (from) url += `&from=${from}`;
      if (to) url += `&to=${to}`;
    }
    const r = await fetch(url);
    if (!r.ok) throw new Error((await r.json().catch(()=>({}))).error || 'Failed to fetch report data');
    const data = await r.json();

    if (format === 'xlsx') {
      downloadXlsx(type, data, title);
    } else {
      printPdf(type, data, title, from, to);
    }
    toast('Report ready.', 'ok');
  }

  // ─── XLSX download (replaces CSV) ───
  function downloadXlsx(type, data, title) {
    const ts = new Date().toISOString().split('T')[0];
    const filename = title.replace(/\s+/g, '-').toLowerCase() + '-' + ts + '.xlsx';
    const sheets = [];

    // Metadata sheet — always included
    const tName = data.tenant?.name || 'MIS';
    sheets.push({
      name: 'Info',
      headers: ['Field', 'Value'],
      rows: [
        ['Report', title],
        ['Tenant', tName],
        ['Generated', new Date().toLocaleString('en-IN')],
        ['Date Range', (data.range?.from && data.range?.to) ? `${data.range.from} to ${data.range.to}` : '—']
      ]
    });

    if (type === 'sales-summary') {
      const k = data.kpis || {};
      sheets.push({ name: 'Summary', headers: ['Metric', 'Value'], rows: [
        ['Total Sales', Number(k.total_sales?.value || 0)],
        ['Invoice Count', Number(k.invoice_count?.value || 0)],
        ['Unique Parties', Number(k.unique_parties?.value || 0)],
        ['Avg Invoice', Number(k.avg_invoice?.value || 0)]
      ]});
      sheets.push({ name: 'Top Customers', headers: ['Customer', 'Sales (₹)'],
        rows: (data.charts?.top_parties?.labels || []).map((l, i) => [l, Number(data.charts.top_parties.data[i] || 0)]) });
      sheets.push({ name: 'Top Items', headers: ['Item', 'Revenue (₹)'],
        rows: (data.charts?.top_items?.labels || []).map((l, i) => [l, Number(data.charts.top_items.data[i] || 0)]) });
      sheets.push({ name: 'Invoices', headers: ['Date', 'Voucher', 'Party', 'Item', 'Amount (₹)'],
        rows: (data.invoices?.rows || []).map(r => [r.date, r.voucher, r.party, r.item, Number(r.amount || 0)]) });
    }
    else if (type === 'top-customers') {
      sheets.push({ name: 'Top Customers', headers: ['Rank', 'Customer', 'Sales (₹)'],
        rows: (data.charts?.top_parties?.labels || []).map((l, i) => [i+1, l, Number(data.charts.top_parties.data[i] || 0)]) });
    }
    else if (type === 'top-items') {
      sheets.push({ name: 'Top Items', headers: ['Rank', 'Item', 'Revenue (₹)'],
        rows: (data.charts?.top_items?.labels || []).map((l, i) => [i+1, l, Number(data.charts.top_items.data[i] || 0)]) });
    }
    else if (type === 'sales-by-city') {
      sheets.push({ name: 'Sales by City', headers: ['Rank', 'City', 'Revenue (₹)'],
        rows: (data.charts?.by_city?.labels || []).map((l, i) => [i+1, l, Number(data.charts.by_city.data[i] || 0)]) });
    }
    else if (type === 'purchase-summary') {
      // /api/page/purchases isn't implemented yet — graceful fallback to whatever fields exist
      const k = data.kpis || {};
      sheets.push({ name: 'Summary', headers: ['Metric', 'Value'], rows: Object.keys(k).map(key => [key, Number(k[key]?.value || k[key] || 0)]) });
      if (data.charts?.top_parties) {
        sheets.push({ name: 'Top Suppliers', headers: ['Supplier', 'Purchases (₹)'],
          rows: (data.charts.top_parties.labels || []).map((l, i) => [l, Number(data.charts.top_parties.data[i] || 0)]) });
      }
    }
    else if (type === 'top-suppliers') {
      sheets.push({ name: 'Top Suppliers', headers: ['Rank', 'Supplier', 'Purchases (₹)'],
        rows: (data.charts?.top_parties?.labels || []).map((l, i) => [i+1, l, Number(data.charts.top_parties.data[i] || 0)]) });
    }
    else if (type === 'outstanding-aging') {
      const k = data.kpis || {};
      sheets.push({ name: 'Aging Summary', headers: ['Bucket', 'Amount (₹)'], rows: [
        ['Total Outstanding', Number(k.total_outstanding?.value || 0)],
        ['Unpaid Count', Number(k.unpaid_count?.value || 0)],
        ['90+ days bucket', Number(k.bucket_90plus?.value || 0)],
        ['Oldest age (days)', Number(k.oldest_age?.value || 0)]
      ]});
      const aging = data.aging || data.charts?.aging || {};
      if (aging.labels && aging.data) {
        sheets.push({ name: 'Buckets', headers: ['Bucket', 'Amount (₹)'],
          rows: aging.labels.map((l, i) => [l, Number(aging.data[i] || 0)]) });
      }
      if (data.top_defaulters?.length) {
        sheets.push({ name: 'Top Defaulters', headers: ['Rank', 'Party', 'Outstanding (₹)', 'Bucket'],
          rows: data.top_defaulters.map((d, i) => [i+1, d.party, Number(d.amount || 0), d.bucket || '—']) });
      }
    }
    else if (type === 'stock-valuation') {
      const rows = data.items_table || [];
      const totalValue = rows.reduce((a, r) => a + (Number(r.value) || 0), 0);
      sheets.push({ name: 'Summary', headers: ['Metric', 'Value'], rows: [
        ['Total Stock Value (₹)', totalValue],
        ['SKU Count', rows.length],
        ['Slow Moving', (data.slow_moving || []).length],
        ['Low Stock', (data.low_stock || []).length]
      ]});
      sheets.push({ name: 'Items', headers: ['Item','Bought','Sold','Balance','Avg Price (₹)','Value (₹)','Status'],
        rows: rows.map(it => [it.item, Number(it.bought||0), Number(it.sold||0), Number(it.balance||0),
                              Number(it.avg_price||0), Number(it.value||0), it.status || '']) });
    }
    else if (type === 'ledger-summary') {
      const parties = data.parties || data.summary || [];
      sheets.push({ name: 'Ledger', headers: ['Party', 'Net Balance (₹)', 'Sales (₹)', 'Purchases (₹)'],
        rows: parties.map(p => [p.party || p.name || '—', Number(p.balance || p.net || 0),
                                Number(p.sales || 0), Number(p.purchases || 0)]) });
    }
    else if (type === 'expense-summary') {
      const k = data.kpis || {};
      sheets.push({ name: 'Summary', headers: ['Metric', 'Value'], rows: Object.keys(k).map(key => [key, Number(k[key]?.value || k[key] || 0)]) });
      if (data.rows || data.expenses) {
        const rows = data.rows || data.expenses || [];
        sheets.push({ name: 'Expenses', headers: ['Date', 'Category', 'Description', 'Amount (₹)'],
          rows: rows.map(r => [r.date, r.category || r.head, r.description || r.particulars, Number(r.amount || 0)]) });
      }
    }
    else {
      // Fallback — dump available KPIs as a single sheet
      const k = data.kpis || {};
      sheets.push({ name: 'Data', headers: ['Field', 'Value'],
        rows: Object.keys(k).map(key => [key, Number(k[key]?.value || k[key] || 0)]) });
    }

    if (window.MIS && window.MIS.xlsx && window.MIS.xlsx.isReady()) {
      window.MIS.xlsx.download(filename, sheets);
    } else {
      toast('Excel library still loading — please retry in a moment.', 'err');
    }
  }

  // ─── PDF via browser print ───
  function printPdf(type, data, title, from, to) {
    const tenant = data.tenant?.name || 'MIS';
    let body = `
      <h1>${escapeHtml(title)}</h1>
      <div class="meta">${escapeHtml(tenant)} · Generated ${new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
      ${from && to && (type === 'sales-summary' || type === 'top-customers' || type === 'top-items') ? ` · Range: ${from} to ${to}` : ''}
      </div>
    `;

    if (type === 'sales-summary') {
      const k = data.kpis || {};
      body += `<div class="summary">
        <div class="stat"><div class="lbl">Total Sales</div><div class="val">${fmtInr(k.total)}</div></div>
        <div class="stat"><div class="lbl">Invoices</div><div class="val">${fmtNum(k.count)}</div></div>
        <div class="stat"><div class="lbl">Avg Invoice</div><div class="val">${fmtInr(k.avg)}</div></div>
        <div class="stat"><div class="lbl">Top Customer</div><div class="val" style="font-size:13px;">${escapeHtml(k.top_party_name || '—')}</div></div>
      </div>`;
      if (data.charts?.top_parties?.length) {
        body += `<h2>Top Customers</h2><table><thead><tr><th>Rank</th><th>Customer</th><th class="num">Sales</th></tr></thead><tbody>`;
        data.charts.top_parties.forEach((p, i) => {
          body += `<tr><td>${i+1}</td><td>${escapeHtml(p.label)}</td><td class="num">${fmtInr(p.value)}</td></tr>`;
        });
        body += `</tbody></table>`;
      }
    }
    else if (type === 'top-customers') {
      body += `<table><thead><tr><th>Rank</th><th>Customer</th><th class="num">Total Sales</th></tr></thead><tbody>`;
      (data.charts?.top_parties || []).forEach((p, i) => {
        body += `<tr><td>${i+1}</td><td>${escapeHtml(p.label)}</td><td class="num">${fmtInr(p.value)}</td></tr>`;
      });
      body += `</tbody></table>`;
    }
    else if (type === 'top-items') {
      body += `<table><thead><tr><th>Rank</th><th>Item</th><th class="num">Revenue</th></tr></thead><tbody>`;
      (data.charts?.top_items || []).forEach((p, i) => {
        body += `<tr><td>${i+1}</td><td>${escapeHtml(p.label)}</td><td class="num">${fmtInr(p.value)}</td></tr>`;
      });
      body += `</tbody></table>`;
    }
    else if (type === 'outstanding-aging') {
      const a = data.aging || {};
      body += `<div class="summary">
        <div class="stat"><div class="lbl">0-30 days</div><div class="val">${fmtInr(a['0-30']?.amount)}</div></div>
        <div class="stat"><div class="lbl">31-60 days</div><div class="val">${fmtInr(a['31-60']?.amount)}</div></div>
        <div class="stat"><div class="lbl">61-90 days</div><div class="val">${fmtInr(a['61-90']?.amount)}</div></div>
        <div class="stat"><div class="lbl">90+ days</div><div class="val">${fmtInr(a['90+']?.amount)}</div></div>
      </div>`;
      body += `<h2>Top Defaulters</h2><table><thead><tr><th>Rank</th><th>Party</th><th class="num">Outstanding</th><th>Bucket</th></tr></thead><tbody>`;
      (data.top_defaulters || []).forEach((d, i) => {
        body += `<tr><td>${i+1}</td><td>${escapeHtml(d.party)}</td><td class="num">${fmtInr(d.amount)}</td><td>${escapeHtml(d.bucket || '—')}</td></tr>`;
      });
      body += `</tbody></table>`;
    }
    else if (type === 'stock-valuation') {
      const rows = data.items_table || [];
      const totalValue = rows.reduce((a, r) => a + (Number(r.value) || 0), 0);
      body += `<div class="summary">
        <div class="stat"><div class="lbl">Total Stock Value</div><div class="val">${fmtInr(totalValue)}</div></div>
        <div class="stat"><div class="lbl">SKU Count</div><div class="val">${fmtNum(rows.length)}</div></div>
        <div class="stat"><div class="lbl">Slow Moving</div><div class="val">${fmtNum((data.slow_moving || []).length)}</div></div>
        <div class="stat"><div class="lbl">Low Stock</div><div class="val">${fmtNum((data.low_stock || []).length)}</div></div>
      </div>`;
      body += `<h2>Item-wise Stock</h2><table><thead><tr><th>Item</th><th class="num">Bought</th><th class="num">Sold</th><th class="num">Balance</th><th class="num">Value</th><th>Status</th></tr></thead><tbody>`;
      rows.forEach(it => {
        body += `<tr><td>${escapeHtml(it.item)}</td><td class="num">${fmtNum(it.bought)}</td><td class="num">${fmtNum(it.sold)}</td><td class="num">${fmtNum(it.balance)}</td><td class="num">${fmtInr(it.value)}</td><td>${escapeHtml(it.status || '')}</td></tr>`;
      });
      body += `</tbody></table>`;
    }

    document.getElementById('printArea').innerHTML = body;
    setTimeout(() => {
      window.print();
    }, 100);
  }

  // ─── Theme + logout ───
  document.getElementById('themeRow').addEventListener('click', () => window.MIS.theme.toggle());
  document.getElementById('logoutLink').addEventListener('click', (e) => {
    e.preventDefault();
    window.MIS.confirmLogout();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') document.getElementById('formatModal').classList.remove('open');
  });

  document.addEventListener('DOMContentLoaded', () => {
    if (window.lucide) window.lucide.createIcons();
    const tName = window.MIS.auth.getTenantName() || 'Account';
    document.getElementById('tenant-name').textContent = tName;
    document.getElementById('tenantAvatar').textContent = (tName.charAt(0) || 'M').toUpperCase();
    loadReports();
  });

})();
</script>
@endpush

