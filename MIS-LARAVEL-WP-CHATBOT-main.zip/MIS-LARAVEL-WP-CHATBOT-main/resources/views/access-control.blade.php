@extends('layouts.app')

@section('title', 'Access Control')

@section('styles')
    /* Full-width Page Wrapper */
    .page {
    max-width: 100% !important;
    width: 100% !important;
    padding: 6px 8px 0 !important;
    }
    .settings-grid {
    grid-template-columns: 1fr !important;
    max-width: 100% !important;
    width: 100% !important;
    }
    .settings-card {
    max-width: 100% !important;
    width: 100% !important;
    border-radius: 16px;
    }

    /* Enhanced Table styling for wide display */
    .table-wrapper {
    width: 100%;
    overflow-x: auto;
    border: 1px solid var(--hairline);
    border-radius: 12px;
    margin-top: 4px;
    margin-bottom: 24px;
    background: var(--surface-bg);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.02);
    }
    table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13px;
    }
    th {
    background: var(--surface-card);
    text-align: left;
    padding: 11px 12px 9px;
    font-weight: 600;
    font-size: 11.5px;
    letter-spacing: .02em;
    text-transform: uppercase;
    color: var(--color-text-secondary);
    border-bottom: 1px solid var(--hairline);
    white-space: nowrap;
    }
    td {
    padding: 4px 12px;
    border-bottom: 1px solid var(--hairline);
    vertical-align: middle;
    color: var(--color-text-primary);
    }
    tr:last-child td {
    border-bottom: none;
    }
    /* First data row gets a touch more breathing room below the header */
    tbody tr:first-child td {
    padding-top: 7px;
    }

    /* Configured Row Badge */
    .badge-configured {
    display: inline-flex;
    align-items: center;
    padding: 3px 8px;
    background: rgba(16, 185, 129, 0.1);
    color: #10b981;
    border-radius: 6px;
    font-size: 11px;
    font-weight: 600;
    margin-top: 6px;
    }

    /* Dynamic selectors — small, compact variant */
    select {
    padding: 5px 9px;
    border: 1px solid var(--hairline);
    border-radius: 7px;
    background: var(--surface-bg);
    color: var(--color-text-primary);
    font-size: 12px;
    height: 30px;
    line-height: 1;
    width: 100%;
    max-width: 220px;
    min-width: 130px;
    transition: border-color 0.15s ease;
    }
    select:focus {
    border-color: var(--color-primary-400);
    outline: none;
    }
    input[type="checkbox"] {
    width: 17px;
    height: 17px;
    cursor: pointer;
    accent-color: var(--accent-cyan);
    }
    .chk-wrapper {
    display: flex;
    justify-content: center;
    }

    /* Column alignment — each header sits directly over its input.
    Checkbox columns: SAME fixed narrow width + centered on BOTH the header (th) and
    the cell (td), so the label sits exactly above the checkbox. Applying the width to
    th only (as before) left the cell a different width, so they didn't line up. */
    th:nth-child(2), td:nth-child(2),
    th:nth-child(4), td:nth-child(4),
    th:nth-child(6), td:nth-child(6) {
    text-align: center;
    width: 68px;
    }
    /* Match-col headers centered over their dropdowns */
    th:nth-child(3), th:nth-child(5) { text-align: center; min-width: 150px; }
    td:nth-child(3), td:nth-child(5) { text-align: center; }

    /* Highlight config status visually */
    .row-configured {
    background: rgba(0, 164, 210, 0.015);
    }
    [data-theme="dark"] .row-configured {
    background: rgba(255, 255, 255, 0.01);
    }
@endsection

@section('content')
    <div class="page">
        <div class="page-header page-header-hero">
            <div class="page-header-bg">
                <div class="aurora aurora-1"></div>
                <div class="aurora aurora-2"></div>
                <div class="aurora aurora-3"></div>
                <div class="grid-overlay"></div>
            </div>
            <div class="page-header-content">
                <div class="page-icon-glow" style="color:var(--accent-cyan); background:rgba(67, 97, 238, 0.1);"><i
                        data-lucide="shield-check"></i></div>
                <div class="page-header-text">
                    <div class="page-title-row">
                        <h1 class="t-h1 page-title-gradient">Access Control</h1>
                    </div>
                    <p class="page-desc">Configure who can see which tabs. Restrict row-level access by team or client phone
                        numbers.</p>
                </div>
            </div>
        </div>

        <div class="settings-grid" style="grid-template-columns: 1fr;">
            <!-- Card -->
            <div class="settings-card">
                <div class="settings-card-header"
                    style="justify-content: space-between; flex-wrap: wrap; gap: 12px; border-bottom: 1px solid var(--hairline); padding-bottom: 16px;">
                    <div style="display: flex; gap: 12px; align-items: center;">
                        <div class="ic" style="background:rgba(16, 185, 129, 0.1); color:#10b981;"><i
                                data-lucide="table"></i></div>
                        <div class="titles">
                            <div class="t">Sheet & Tab Access</div>
                            <div class="sub">Map tabs to users</div>
                        </div>
                    </div>
                    <button class="btn-primary" id="saveBtn" style="display:none; padding: 8px 16px; font-size: 13px;"
                        type="button">💾 Save Changes</button>
                </div>

                <div id="content" style="padding-top: 4px;">
                    <div style="padding:24px; text-align:center; color:var(--color-text-tertiary);">
                        <i data-lucide="loader-2" class="spin" style="margin-bottom:8px;"></i><br>
                        Loading configuration...
                    </div>
                </div>

            </div>
        </div>
    </div>

    <div class="toast" id="toast"></div>
@endsection

@push('scripts')
    <script>
        (function() {
            'use strict';

            // ─── Auth ───

            const PHONE = window.MIS.auth.getPhone();

            // ─── Toast ───
            let toastTimer;

            function toast(msg, kind = 'ok') {
                const t = document.getElementById('toast');
                t.textContent = msg;
                t.className = 'toast show ' + (kind || '');
                clearTimeout(toastTimer);
                toastTimer = setTimeout(() => {
                    t.classList.remove('show');
                }, 2400);
            }

            // ─── Data Loading ───
            let allConfigs = [];
            let allSheets = [];
            let allTabs = [];

            async function load() {
                try {
                    const [accessRes, colsRes] = await Promise.all([
                        fetch(`/api/tenant/tab-access?phone=${PHONE}`).then(r => r.json()),
                        fetch(`/api/tenant/sheet-columns?phone=${PHONE}`).then(r => r.json())
                    ]);
                    allSheets = accessRes.sheets || [];
                    allConfigs = accessRes.configs || [];
                    allTabs = colsRes.tabs || [];
                    render();
                    if (window.lucide) lucide.createIcons();
                } catch (e) {
                    document.getElementById('content').innerHTML =
                        `<div style="padding:24px; text-align:center; color:var(--color-error);"><i data-lucide="alert-triangle" style="margin-bottom:8px;"></i><br>Failed to load: ${e.message}</div>`;
                    if (window.lucide) lucide.createIcons();
                }
            }

            function render() {
                if (!allTabs.length) {
                    document.getElementById('content').innerHTML = `
        <div style="padding:24px; text-align:center; color:var(--color-text-secondary);">
          <i data-lucide="info" style="margin-bottom:8px; width:32px; height:32px; color:var(--color-text-tertiary);"></i><br>
          No synced sheets yet. Go to <a href="/settings" style="color:var(--accent-cyan);">Settings</a> → Add a sheet → Sync first.
        </div>`;
                    if (window.lucide) lucide.createIcons();
                    return;
                }

                let html = '';
                html += '<div class="table-wrapper">';
                html += '<table><thead><tr>';
                html +=
                    '<th>Tab Name</th><th class="col-chk">Team</th><th class="col-match">Team Match Col</th><th class="col-chk">Client</th><th class="col-match">Client Match Col</th><th class="col-chk">All</th>';
                html += '</tr></thead><tbody>';

                allTabs.forEach((tab, i) => {
                    const cfg = findConfig(tab.pg_table, tab.tab_name) || {};
                    const cols = tab.columns || [];
                    const colOpts = cols.map(c => `<option value="${c}">${c}</option>`).join('');
                    const hasConfig = cfg.access_team || cfg.access_client || cfg.access_all;

                    html +=
                        `<tr data-idx="${i}" data-pg="${tab.pg_table}" data-tab="${tab.tab_name}" class="${hasConfig?'row-configured':''}">`;
                    html +=
                        `<td><div style="font-weight:600; font-size:14px;">${esc(tab.tab_name)}</div>${hasConfig?'<span class="badge-configured"><i data-lucide="check" style="width:10px;height:10px;margin-right:2px;"></i> Configured</span>':''}<div style="font-size:11px;color:var(--color-text-tertiary);margin-top:2px;">${esc(tab.pg_table)}</div></td>`;
                    html +=
                        `<td><div class="chk-wrapper"><input type="checkbox" class="chk-team" ${cfg.access_team?'checked':''}></div></td>`;
                    html +=
                        `<td><select class="sel-team-col"><option value="">— Select Column —</option>${colOpts}</select></td>`;
                    html +=
                        `<td><div class="chk-wrapper"><input type="checkbox" class="chk-client" ${cfg.access_client?'checked':''}></div></td>`;
                    html +=
                        `<td><select class="sel-client-col"><option value="">— Select Column —</option>${colOpts}</select></td>`;
                    html +=
                        `<td><div class="chk-wrapper"><input type="checkbox" class="chk-all" ${cfg.access_all?'checked':''}></div></td>`;
                    html += '</tr>';
                });

                html += '</tbody></table></div>';
                document.getElementById('content').innerHTML = html;
                document.getElementById('saveBtn').style.display = 'block';

                // Set correctly selected values for dropdowns
                document.querySelectorAll('tr[data-pg]').forEach(tr => {
                    const pg = tr.dataset.pg;
                    const tab = tr.dataset.tab;
                    const cfg = findConfig(pg, tab) || {};
                    const selTeam = tr.querySelector('.sel-team-col');
                    const selClient = tr.querySelector('.sel-client-col');
                    if (cfg.team_match_column) selTeam.value = cfg.team_match_column;
                    if (cfg.client_match_column) selClient.value = cfg.client_match_column;
                });
            }

            function findConfig(pgTable, tabName) {
                return allConfigs.find(c => c.pg_table === pgTable || c.tab_name === tabName);
            }

            document.getElementById('saveBtn').addEventListener('click', async () => {
                const btn = document.getElementById('saveBtn');
                btn.disabled = true;
                btn.textContent = 'Saving…';

                const configs = [];
                document.querySelectorAll('tr[data-pg]').forEach(tr => {
                    configs.push({
                        tab_name: tr.dataset.tab,
                        pg_table: tr.dataset.pg,
                        tenant_sheet_id: allSheets[0]?.id || null,
                        access_team: tr.querySelector('.chk-team').checked,
                        team_match_column: tr.querySelector('.sel-team-col').value || null,
                        access_client: tr.querySelector('.chk-client').checked,
                        client_match_column: tr.querySelector('.sel-client-col').value ||
                            null,
                        access_all: tr.querySelector('.chk-all').checked,
                    });
                });

                try {
                    const res = await fetch('/api/tenant/tab-access', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            configs
                        })
                    });
                    const data = await res.json();
                    if (!res.ok) throw new Error(data.error || 'Failed');
                    toast('Saved! ' + data.saved + ' tab(s) updated.', 'ok');

                    // Auto-reload to reflect any new "Configured" badges
                    load();
                } catch (e) {
                    toast(e.message, 'err');
                }

                btn.disabled = false;
                btn.textContent = '💾 Save Changes';
            });

            const refBtn = document.getElementById('refreshBtn');
            if (refBtn) refBtn.addEventListener('click', load);

            function esc(s) {
                return String(s || '').replace(/[<>&"]/g, c => ({
                    '<': '&lt;',
                    '>': '&gt;',
                    '&': '&amp;',
                    '"': '&quot;'
                } [c]));
            }

            load();

        })();
    </script>
@endpush
