@extends('layouts.app')

@section('title', 'Ledger')

@push('head')
  <script src="https://cdn.sheetjs.com/xlsx-0.20.2/package/dist/xlsx.full.min.js"></script>
@endpush

@section('content')
    <div class="page">
    <div class="page-header page-header-hero">
      <div class="page-header-bg">
        <div class="aurora aurora-1"></div>
        <div class="aurora aurora-2"></div>
        <div class="aurora aurora-3"></div>
        <div class="grid-overlay"></div>
      </div>
      <div class="page-header-content">
        <div class="page-icon-glow"><i data-lucide="book-open"></i></div>
        <div class="page-header-text">
          <div class="page-title-row">
            <h1 class="t-h1 page-title-gradient">Ledger</h1>
            <span class="live-pill"><span class="live-dot"></span>Live</span>
          </div>
          <p class="page-desc">Party-wise account — search a customer or vendor to see their full transaction history</p>
          <div class="page-chips">
            <span class="page-chip"><i data-lucide="search" style="width:12px;height:12px;"></i> Party search</span>
            <span class="page-chip"><i data-lucide="scale" style="width:12px;height:12px;"></i> Net balance</span>
            <span class="page-chip"><i data-lucide="file-spreadsheet" style="width:12px;height:12px;"></i> Excel export</span>
          </div>
          <div class="page-underline"></div>
        </div>
        <button id="exportCsvBtn" type="button" style="padding:9px 16px; border-radius:10px; background:var(--accent-violet); color:#fff; font-weight:600; font-size:13px; border:none; cursor:pointer; flex-shrink:0; align-self:flex-start;">⬇ Export Excel</button>
      </div>
    </div>

    <div class="page-grid">
      <div class="filter-bar">
        <input id="partySearch" type="text" placeholder="Search party (customer or vendor) name..." />
        <button class="btn" id="searchBtn">Search</button>
        <button class="btn" id="clearBtn" style="background: var(--hairline); color: var(--color-text-secondary);">Clear</button>
      </div>

      <!-- Balance card (visible when party selected) -->
      <div id="balanceWrap"></div>

      <!-- Transaction timeline (visible when party selected) -->
      <div id="timelineWrap"></div>

      <!-- Summary table (always visible) -->
      <div class="timeline">
        <div style="display:flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
          <div><div class="t-h3">All Parties</div><div class="t-meta" id="summaryMeta">—</div></div>
        </div>
        <table>
          <thead><tr><th>Party</th><th class="num">Sales</th><th class="num">Purchases</th><th class="num">Net Balance</th><th class="num">Sales Cnt</th><th class="num">Purch Cnt</th></tr></thead>
          <tbody id="summaryBody"></tbody>
        </table>
      </div>
    </div>
    </div>
@endsection

@push('scripts')
<script>
(function() {
  'use strict';

  const PHONE = window.MIS.auth.getPhone();
  const tName = window.MIS.auth.getTenantName() || '—';
  document.getElementById('tenant-name').textContent = tName;
  document.getElementById('tenantAvatar').textContent = (tName.charAt(0) || 'M').toUpperCase();

  if (window.MIS.theme && window.MIS.theme.init) window.MIS.theme.init();
  document.getElementById('themeRow').addEventListener('click', () => window.MIS.theme.toggle());
  document.getElementById('logoutLink').addEventListener('click', (e) => { e.preventDefault(); window.MIS.confirmLogout(); });
  document.getElementById('refreshBtn').addEventListener('click', () => loadPage(CURRENT_Q));

  const inr = (v) => window.MIS.fmt.inr(v);
  const num = (v) => window.MIS.fmt.num(v);
  let CURRENT_Q = '';

  function escHtml(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' })[c]); }

  function renderBalance(detail) {
    const wrap = document.getElementById('balanceWrap');
    if (!detail) { wrap.innerHTML = ''; return; }
    const cls = detail.net_balance > 0 ? 'positive' : detail.net_balance < 0 ? 'negative' : '';
    const sign = detail.net_balance > 0 ? '+' : '';
    wrap.innerHTML = `
      <div class="balance-card">
        <div class="balance-stat party">
          <div class="lbl">Party</div>
          <div class="val">${escHtml(detail.query)}</div>
          <div style="color: var(--color-text-tertiary); font-size: 12px; margin-top: 4px;">${detail.matched_count} transactions</div>
        </div>
        <div class="balance-stat">
          <div class="lbl">Sales (debit)</div>
          <div class="val" style="color:#10B981;">${inr(detail.sales_total)}</div>
        </div>
        <div class="balance-stat">
          <div class="lbl">Purchases (credit)</div>
          <div class="val" style="color:#F59E0B;">${inr(detail.purchases_total)}</div>
        </div>
        <div class="balance-stat net">
          <div class="lbl">Net Balance</div>
          <div class="val ${cls}">${sign}${inr(Math.abs(detail.net_balance))}</div>
          <div style="color: var(--color-text-tertiary); font-size: 11px; margin-top: 4px;">${detail.net_balance > 0 ? 'Party owes us' : detail.net_balance < 0 ? 'We owe party' : 'Settled'}</div>
        </div>
      </div>`;
  }

  function renderTimeline(detail) {
    const wrap = document.getElementById('timelineWrap');
    if (!detail) { wrap.innerHTML = ''; return; }
    if (!detail.transactions || !detail.transactions.length) {
      wrap.innerHTML = `<div class="timeline"><div class="empty-state"><div class="ic">🔍</div>No transactions for "${escHtml(detail.query)}".</div></div>`;
      return;
    }
    let rowsHtml = '';
    for (const t of detail.transactions) {
      const dateStr = t.date ? new Date(t.date + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: '2-digit' }) : '—';
      rowsHtml += `<tr>
        <td>${dateStr}</td>
        <td><span class="kind-pill ${t.kind}">${t.kind}</span></td>
        <td>${escHtml(t.voucher) || '—'}</td>
        <td>${escHtml(t.party) || '—'}</td>
        <td>${escHtml(t.item) || '—'}</td>
        <td class="num" style="color:${t.kind === 'sale' ? '#10B981' : '#F59E0B'};">${inr(t.amount)}</td>
      </tr>`;
    }
    wrap.innerHTML = `
      <div class="timeline">
        <div style="display:flex; justify-content: space-between; align-items: flex-start; margin-bottom: 12px;">
          <div><div class="t-h3">Transaction Timeline</div><div class="t-meta">${detail.matched_count > detail.transactions_shown ? `Showing ${detail.transactions_shown} of ${detail.matched_count}` : detail.transactions.length + ' entries'} · most recent first</div></div>
        </div>
        <table>
          <thead><tr><th>Date</th><th>Type</th><th>Voucher</th><th>Party</th><th>Item</th><th class="num">Amount</th></tr></thead>
          <tbody>${rowsHtml}</tbody>
        </table>
      </div>`;
  }

  function renderSummary(rows) {
    const tbody = document.getElementById('summaryBody');
    tbody.innerHTML = '';
    if (!rows || !rows.length) {
      tbody.innerHTML = '<tr><td colspan="6" style="text-align:center; padding:30px; color:var(--color-text-tertiary);">No party data.</td></tr>';
      document.getElementById('summaryMeta').textContent = '0 parties';
      return;
    }
    for (const r of rows) {
      const cls = r.net_balance > 0 ? 'positive' : r.net_balance < 0 ? 'negative' : '';
      const sign = r.net_balance > 0 ? '+' : '';
      const tr = document.createElement('tr');
      tr.style.cursor = 'pointer';
      tr.innerHTML = `<td>${escHtml(r.party)}</td><td class="num">${inr(r.sales_amt)}</td><td class="num">${inr(r.purch_amt)}</td><td class="num" style="color:${cls === 'positive' ? '#10B981' : cls === 'negative' ? '#F43F5E' : 'inherit'};">${sign}${inr(Math.abs(r.net_balance))}</td><td class="num">${num(r.sales_count)}</td><td class="num">${num(r.purch_count)}</td>`;
      tr.addEventListener('click', () => {
        document.getElementById('partySearch').value = r.party;
        CURRENT_Q = r.party;
        loadPage(CURRENT_Q);
      });
      tbody.appendChild(tr);
    }
    document.getElementById('summaryMeta').textContent = `${rows.length} parties · click any row for detailed timeline`;
  }

  async function loadPage(q) {
    const params = new URLSearchParams({ phone: PHONE });
    if (q) params.set('q', q);
    const res = await fetch('/api/page/ledger?' + params);
    if (!res.ok) {
      document.getElementById('summaryBody').innerHTML = '<tr><td colspan="6" style="text-align:center; padding:30px;">Failed to load.</td></tr>';
      return;
    }
    const d = await res.json();
    LAST_DATA = d;
    if (d.tenant?.name) {
      document.getElementById('tenant-name').textContent = d.tenant.name;
      document.getElementById('tenantAvatar').textContent = (d.tenant.name.charAt(0) || 'M').toUpperCase();
    }
    if (d.empty) {
      document.getElementById('balanceWrap').innerHTML = `<div class="balance-card empty"><div class="empty-state"><div class="ic">📒</div>${d.message || 'No data'}</div></div>`;
      return;
    }
    renderBalance(d.party_detail);
    renderTimeline(d.party_detail);
    renderSummary(d.summary);
  }

  document.getElementById('searchBtn').addEventListener('click', () => { CURRENT_Q = document.getElementById('partySearch').value.trim(); loadPage(CURRENT_Q); });
  document.getElementById('partySearch').addEventListener('keydown', (e) => { if (e.key === 'Enter') { CURRENT_Q = e.target.value.trim(); loadPage(CURRENT_Q); } });
  document.getElementById('clearBtn').addEventListener('click', () => { CURRENT_Q = ''; document.getElementById('partySearch').value = ''; loadPage(); });

  let LAST_DATA = null;

  document.addEventListener('DOMContentLoaded', () => { if (window.lucide) window.lucide.createIcons(); loadPage(); });

  document.getElementById('exportCsvBtn').addEventListener('click', () => {
    if (!LAST_DATA) { alert('No data to export. Wait for load.'); return; }
    if (!window.MIS?.xlsx?.isReady()) { alert('Excel library still loading — please retry.'); return; }
    const ts = new Date().toISOString().split('T')[0];
    let filename, sheets;
    if (LAST_DATA.party_detail) {
      const pd = LAST_DATA.party_detail;
      const partyName = (pd.party || pd.name || 'unknown').toString();
      filename = `ledger-${partyName.replace(/\W+/g, '-').toLowerCase()}-${ts}.xlsx`;
      sheets = [
        { name: 'Info', headers: ['Field','Value'], rows: [
          ['Party', partyName],
          ['Net Balance (₹)', Number(pd.balance || 0)],
          ['Tenant', LAST_DATA.tenant?.name || 'MIS'],
          ['Generated', new Date().toLocaleString('en-IN')]
        ]},
        { name: 'Transactions',
          headers: ['Date','Voucher','Type','Debit (₹)','Credit (₹)','Running Balance (₹)'],
          rows: (pd.transactions || []).map(t => [
            t.date || '', t.voucher || '', t.type || '',
            Number(t.debit || 0), Number(t.credit || 0), Number(t.running_balance || 0)
          ]) }
      ];
    } else if (LAST_DATA.summary) {
      filename = `ledger-summary-${ts}.xlsx`;
      sheets = [
        { name: 'Info', headers: ['Field','Value'], rows: [
          ['Report', 'Ledger Summary'],
          ['Tenant', LAST_DATA.tenant?.name || 'MIS'],
          ['Generated', new Date().toLocaleString('en-IN')],
          ['Party Count', (LAST_DATA.summary.parties || []).length]
        ]},
        { name: 'Parties',
          headers: ['Party','Total Debit (₹)','Total Credit (₹)','Balance (₹)','Transactions'],
          rows: (LAST_DATA.summary.parties || []).map(p => [
            p.party || '',
            Number(p.total_debit || 0),
            Number(p.total_credit || 0),
            Number(p.balance || 0),
            Number(p.txn_count || 0)
          ]) }
      ];
    } else {
      alert('No exportable data found.'); return;
    }
    window.MIS.xlsx.download(filename, sheets);
  });
})();
</script>
@endpush
