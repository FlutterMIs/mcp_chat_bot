@extends('layouts.app')

@section('title', 'Sales')

@push('head')
  <script src="https://cdn.sheetjs.com/xlsx-0.20.2/package/dist/xlsx.full.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
@endpush

@section('content')
    <div class="page">
    <div class="page-header page-header-hero">
      <div class="page-header-bg">
        <div class="aurora aurora-1"></div>
        <div class="aurora aurora-2"></div>
        <div class="aurora aurora-3"></div>
        <div class="grid-overlay"></div>
      </div>
      <div class="page-header-content">
        <div class="page-icon-glow"><i data-lucide="trending-up"></i></div>
        <div class="page-header-text">
          <div class="page-title-row">
            <h1 class="t-h1 page-title-gradient">Sales</h1>
            <span class="live-pill"><span class="live-dot"></span>Live</span>
          </div>
          <p class="page-desc" id="page-sub">Detailed sales drill-down · last 90 days</p>
          <div class="page-chips">
            <span class="page-chip"><i data-lucide="calendar" style="width:12px;height:12px;"></i> Last 90 days</span>
            <span class="page-chip"><i data-lucide="users" style="width:12px;height:12px;"></i> Party search</span>
            <span class="page-chip"><i data-lucide="file-spreadsheet" style="width:12px;height:12px;"></i> Excel export</span>
          </div>
          <div class="page-underline"></div>
        </div>
      </div>
    </div>

    <div class="page-grid">
      <!-- Filter -->
      <div class="filter-bar">
        <input id="partySearch" type="text" placeholder="Search by party name..." />
        <button class="btn" id="searchBtn">Search</button>
        <button class="btn" id="clearBtn" style="background: var(--hairline); color: var(--color-text-secondary);">Clear</button>
        <button class="btn" id="exportCsvBtn" style="background: var(--accent-violet); margin-left: auto;" title="Export current invoices to Excel">⬇ Excel</button>
        <div class="meta" id="filterMeta"></div>
      </div>

      <!-- KPI cards -->
      <div class="kpi-row" id="kpi-row">
        <div class="skel-kpi"><div class="skel skel-icon"></div><div class="skel skel-label"></div><div class="skel skel-value"></div><div class="skel skel-delta"></div></div>
        <div class="skel-kpi"><div class="skel skel-icon"></div><div class="skel skel-label"></div><div class="skel skel-value"></div><div class="skel skel-delta"></div></div>
        <div class="skel-kpi"><div class="skel skel-icon"></div><div class="skel skel-label"></div><div class="skel skel-value"></div><div class="skel skel-delta"></div></div>
        <div class="skel-kpi"><div class="skel skel-icon"></div><div class="skel skel-label"></div><div class="skel skel-value"></div><div class="skel skel-delta"></div></div>
      </div>

      <!-- Charts row 1: Trend (wide) + Top Parties (donut) -->
      <div class="charts-row">
        <div class="chart-card">
          <div class="chart-header">
            <div><div class="t-h3">Sales Trend</div><div class="t-meta">Daily revenue</div></div>
            <div class="chart-icon"><i data-lucide="activity"></i></div>
          </div>
          <div class="body"><canvas id="chartTrend"></canvas></div>
        </div>
        <div class="chart-card">
          <div class="chart-header">
            <div><div class="t-h3">Top Customers</div><div class="t-meta">Distribution share</div></div>
            <div class="chart-icon"><i data-lucide="pie-chart"></i></div>
          </div>
          <div class="body"><canvas id="chartParties"></canvas></div>
        </div>
      </div>

      <!-- Charts row 2: Top Items + By City -->
      <div class="charts-row-2">
        <div class="chart-card">
          <div class="chart-header">
            <div><div class="t-h3">Top Items</div><div class="t-meta">Revenue contribution</div></div>
            <div class="chart-icon"><i data-lucide="bar-chart-3"></i></div>
          </div>
          <div class="body"><canvas id="chartItems"></canvas></div>
        </div>
        <div class="chart-card">
          <div class="chart-header">
            <div><div class="t-h3">By City</div><div class="t-meta">Top 8 locations</div></div>
            <div class="chart-icon"><i data-lucide="map-pin"></i></div>
          </div>
          <div class="body"><canvas id="chartCity"></canvas></div>
        </div>
      </div>

      <!-- Invoice table -->
      <div class="invoice-table">
        <div class="chart-header">
          <div><div class="t-h3">Recent Invoices</div><div class="t-meta" id="invMeta">—</div></div>
          <div class="chart-icon"><i data-lucide="receipt"></i></div>
        </div>
        <table>
          <thead><tr><th>Date</th><th>Voucher</th><th>Party</th><th>Item</th><th class="num">Amount</th></tr></thead>
          <tbody id="invoiceBody"></tbody>
        </table>
        <div class="pager">
          <div class="info" id="pageInfo">—</div>
          <button id="prevBtn"><i data-lucide="chevron-left"></i> Prev</button>
          <button id="nextBtn">Next <i data-lucide="chevron-right"></i></button>
        </div>
      </div>
    </div>
    </div>
@endsection

@push('scripts')
<script>
(function() {
  'use strict';

  const PHONE = window.MIS.auth.getPhone();

  // Tenant avatar + name
  const tName = window.MIS.auth.getTenantName() || '—';
  document.getElementById('tenant-name').textContent = tName;
  document.getElementById('tenantAvatar').textContent = (tName.charAt(0) || 'M').toUpperCase();

  // Theme init + toggle
  if (window.MIS.theme && window.MIS.theme.init) window.MIS.theme.init();
  document.getElementById('themeRow').addEventListener('click', () => window.MIS.theme.toggle());
  document.getElementById('logoutLink').addEventListener('click', (e) => { e.preventDefault(); window.MIS.confirmLogout(); });
  document.getElementById('refreshBtn').addEventListener('click', () => loadPage());

  // Theme observer for chart re-paint
  function applyChartDefaults() {
    if (!window.Chart) return;
    const dark = document.documentElement.getAttribute('data-theme') === 'dark';
    Chart.defaults.color = dark ? '#F5F5F7' : '#1D1D1F';
    Chart.defaults.borderColor = dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
  }
  applyChartDefaults();
  new MutationObserver(() => { applyChartDefaults(); Object.values(charts).forEach(c => { try { c.update('none'); } catch {} }); })
    .observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

  let CURRENT_PAGE = 1, CURRENT_Q = '';
  let LAST_DATA = null;
  const charts = {};
  const inr = (v) => window.MIS.fmt.inr(v);
  const num = (v) => window.MIS.fmt.num(v);

  function destroyCharts() { Object.keys(charts).forEach(k => { try { charts[k].destroy(); } catch {} delete charts[k]; }); }

  function renderKpis(kpis) {
    const row = document.getElementById('kpi-row');
    row.innerHTML = '';
    const cards = [
      { id: 'total_sales',    title: 'Total Sales',    icon: 'trending-up', accent: 'emerald' },
      { id: 'invoice_count',  title: 'Invoices',       icon: 'receipt',     accent: 'indigo' },
      { id: 'unique_parties', title: 'Customers',      icon: 'users',       accent: 'violet' },
      { id: 'avg_invoice',    title: 'Avg Invoice',    icon: 'calculator',  accent: 'cyan' }
    ];
    for (const c of cards) {
      const k = kpis[c.id];
      if (!k) continue;
      const v = (k.format === 'inr') ? inr(k.value) : num(k.value);
      const div = document.createElement('div');
      div.className = 'kpi tilt-card';
      div.style.cssText = `--kpi-color: var(--accent-${c.accent}); --kpi-soft: var(--accent-${c.accent}-soft); --kpi-glow: var(--accent-${c.accent}-glow);`;
      div.innerHTML = `
        <div class="kpi-top">
          <div class="kpi-icon-box"><i data-lucide="${c.icon}"></i></div>
        </div>
        <div class="kpi-label">${c.title}</div>
        <div class="kpi-value">${v}</div>`;
      row.appendChild(div);
    }
    if (window.lucide) window.lucide.createIcons();
  }

  function premiumTooltip(format) {
    return {
      backgroundColor: 'rgba(15,15,20,0.92)', titleColor: '#F5F5F7', bodyColor: '#E5E5EA',
      borderColor: 'rgba(0,164,210,0.3)', borderWidth: 1, padding: 11, cornerRadius: 10,
      titleFont: { family: 'Inter', size: 12, weight: '600' },
      bodyFont: { family: 'JetBrains Mono', size: 12.5, weight: '600' },
      callbacks: { label: (i) => '  ' + (format === 'inr' ? inr(i.parsed.y || i.parsed) : num(i.parsed.y || i.parsed)) }
    };
  }
  function renderTrend(d) {
    const ctx = document.getElementById('chartTrend').getContext('2d');
    const grad = ctx.createLinearGradient(0, 0, 0, 280);
    grad.addColorStop(0, 'rgba(0,164,210,0.45)'); grad.addColorStop(0.5, 'rgba(99,102,241,0.12)'); grad.addColorStop(1, 'rgba(0,0,0,0)');
    charts.trend = new Chart(ctx, {
      type: 'line',
      data: { labels: d.labels, datasets: [{ data: d.data, borderColor: '#00A4D2', backgroundColor: grad, borderWidth: 2.6, tension: 0.25, cubicInterpolationMode: 'monotone', fill: true, pointRadius: 0, pointHoverRadius: 6, pointHitRadius: 18, pointBackgroundColor: '#00A4D2', pointBorderColor: '#fff', pointBorderWidth: 2, spanGaps: true }] },
      options: {
        responsive: true, maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: { legend: { display: false }, tooltip: premiumTooltip('inr') },
        scales: {
          x: { grid: { display: false }, ticks: { maxTicksLimit: 8, autoSkip: true, callback: function(v, i) { const raw = this.getLabelForValue ? this.getLabelForValue(v) : d.labels[i]; if (typeof raw === 'string' && /^\d{4}-\d{2}-\d{2}/.test(raw)) { const dd = new Date(raw + 'T00:00:00'); return isNaN(dd) ? raw : dd.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }); } return raw; } } },
          y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { maxTicksLimit: 5, callback: (v) => inr(v) } }
        }
      }
    });
  }
  function renderDonut(d) {
    const palette = ['#10B981','#F59E0B','#6366F1','#8B5CF6','#F43F5E','#00A4D2','#0EA5E9','#D946EF'];
    const ctx = document.getElementById('chartParties').getContext('2d');
    charts.parties = new Chart(ctx, {
      type: 'doughnut',
      data: { labels: d.labels, datasets: [{ data: d.data, backgroundColor: palette.slice(0, d.data.length), borderWidth: 2, borderColor: 'rgba(255,255,255,0.8)', hoverOffset: 12, borderRadius: 6 }] },
      options: {
        responsive: true, maintainAspectRatio: false, cutout: '64%',
        plugins: {
          legend: { display: true, position: 'right', labels: { padding: 12, font: { family: 'Inter', size: 11.5, weight: '600' }, generateLabels: (chart) => {
            const dark = document.documentElement.getAttribute('data-theme') === 'dark';
            return chart.data.labels.map((label, i) => ({ text: label.length > 24 ? label.slice(0, 23) + '…' : label, fillStyle: chart.data.datasets[0].backgroundColor[i], pointStyle: 'circle', hidden: false, index: i, fontColor: dark ? '#F5F5F7' : '#1D1D1F' }));
          } } },
          tooltip: premiumTooltip('inr')
        }
      }
    });
  }
  function renderBar(canvasId, d, color = '#6366F1') {
    const palette = ['#10B981','#F59E0B','#6366F1','#8B5CF6','#F43F5E','#00A4D2','#0EA5E9','#D946EF'];
    const ctx = document.getElementById(canvasId).getContext('2d');
    return new Chart(ctx, {
      type: 'bar',
      data: { labels: d.labels, datasets: [{ data: d.data, backgroundColor: d.data.map((_, i) => palette[i % palette.length] + 'CC'), hoverBackgroundColor: d.data.map((_, i) => palette[i % palette.length]), borderRadius: 8, barPercentage: 0.72 }] },
      options: {
        indexAxis: 'y', responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false }, tooltip: premiumTooltip('inr') },
        scales: {
          x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { maxTicksLimit: 5, callback: (v) => inr(v) } },
          y: { grid: { display: false }, ticks: { autoSkip: false, callback: function(v) { const raw = (this.getLabelForValue ? this.getLabelForValue(v) : d.labels[v]) || ''; return typeof raw === 'string' && raw.length > 24 ? raw.slice(0, 23) + '…' : raw; } } }
        }
      }
    });
  }

  function renderInvoices(inv) {
    const tbody = document.getElementById('invoiceBody');
    tbody.innerHTML = '';
    if (!inv.rows.length) {
      tbody.innerHTML = '<tr><td colspan="5" style="text-align:center; padding:30px; color:var(--color-text-tertiary);">No invoices match this filter.</td></tr>';
      document.getElementById('invMeta').textContent = '0 invoices';
      document.getElementById('pageInfo').textContent = '';
      document.getElementById('prevBtn').disabled = true;
      document.getElementById('nextBtn').disabled = true;
      return;
    }
    for (const r of inv.rows) {
      const tr = document.createElement('tr');
      const dateStr = r.date ? new Date(r.date + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: '2-digit' }) : '—';
      tr.innerHTML = `<td>${dateStr}</td><td>${r.voucher || '—'}</td><td>${r.party || '—'}</td><td>${r.item || '—'}</td><td class="num">${inr(r.amount)}</td>`;
      tbody.appendChild(tr);
    }
    const start = (inv.page - 1) * inv.pageSize + 1;
    const end = Math.min(inv.page * inv.pageSize, inv.total);
    document.getElementById('invMeta').textContent = `${inv.total.toLocaleString('en-IN')} total · showing ${start}–${end}`;
    document.getElementById('pageInfo').textContent = `Page ${inv.page} of ${Math.ceil(inv.total / inv.pageSize)}`;
    document.getElementById('prevBtn').disabled = inv.page <= 1;
    document.getElementById('nextBtn').disabled = inv.page * inv.pageSize >= inv.total;
  }

  async function loadPage() {
    destroyCharts();
    const params = new URLSearchParams({ phone: PHONE, page: CURRENT_PAGE });
    if (CURRENT_Q) params.set('q', CURRENT_Q);
    const res = await fetch('/api/page/sales?' + params);
    if (!res.ok) {
      document.getElementById('kpi-row').innerHTML = '<div class="empty-state"><div class="ic">⚠️</div>Failed to load.</div>';
      return;
    }
    const d = await res.json();
    LAST_DATA = d;
    if (d.tenant?.name) {
      document.getElementById('tenant-name').textContent = d.tenant.name;
      document.getElementById('tenantAvatar').textContent = (d.tenant.name.charAt(0) || 'M').toUpperCase();
    }
    if (d.empty) {
      document.getElementById('kpi-row').innerHTML = `<div class="empty-state" style="grid-column:1/-1"><div class="ic">📊</div>${d.message || 'No data'}</div>`;
      return;
    }
    renderKpis(d.kpis);
    document.getElementById('filterMeta').textContent = CURRENT_Q ? `Filtered: ${CURRENT_Q}` : `Range: ${d.range.from} → ${d.range.to}`;
    if (d.charts.trend.labels.length) renderTrend(d.charts.trend);
    if (d.charts.top_parties.labels.length) renderDonut(d.charts.top_parties);
    if (d.charts.top_items.labels.length) charts.items = renderBar('chartItems', d.charts.top_items);
    if (d.charts.by_city.labels.length) charts.city = renderBar('chartCity', d.charts.by_city);
    renderInvoices(d.invoices);
  }

  // Search/filter wiring
  document.getElementById('searchBtn').addEventListener('click', () => { CURRENT_Q = document.getElementById('partySearch').value.trim(); CURRENT_PAGE = 1; loadPage(); });
  document.getElementById('partySearch').addEventListener('keydown', (e) => { if (e.key === 'Enter') { CURRENT_Q = e.target.value.trim(); CURRENT_PAGE = 1; loadPage(); } });
  document.getElementById('clearBtn').addEventListener('click', () => { CURRENT_Q = ''; document.getElementById('partySearch').value = ''; CURRENT_PAGE = 1; loadPage(); });
  document.getElementById('exportCsvBtn').addEventListener('click', () => {
    if (!LAST_DATA || !LAST_DATA.invoices || !LAST_DATA.invoices.length) { alert('No invoices to export. Load data first.'); return; }
    const rows = LAST_DATA.invoices.rows || LAST_DATA.invoices;
    const headers = ['Date', 'Voucher', 'Party', 'Item', 'Qty', 'Rate', 'Amount'];
    const xlsxRows = rows.map(r => [r.date || '', r.voucher || '', r.party || '', r.item || '', Number(r.qty || 0), Number(r.rate || 0), Number(r.amount || 0)]);
    const ts = new Date().toISOString().split('T')[0];
    const filename = `sales-${CURRENT_Q ? CURRENT_Q.replace(/\W+/g, '-') + '-' : ''}${ts}.xlsx`;
    if (!window.MIS?.xlsx?.isReady()) { alert('Excel library still loading — please retry.'); return; }
    window.MIS.xlsx.downloadSimple(filename, headers, xlsxRows, 'Invoices');
  });
  document.getElementById('prevBtn').addEventListener('click', () => { if (CURRENT_PAGE > 1) { CURRENT_PAGE--; loadPage(); } });
  document.getElementById('nextBtn').addEventListener('click', () => { CURRENT_PAGE++; loadPage(); });

  document.addEventListener('DOMContentLoaded', () => { if (window.lucide) window.lucide.createIcons(); loadPage(); });
})();
</script>
@endpush
