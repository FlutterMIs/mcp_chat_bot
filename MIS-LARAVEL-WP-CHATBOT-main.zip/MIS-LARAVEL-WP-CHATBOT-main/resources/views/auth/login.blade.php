<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title>Sign in · {{ config('app.name', 'MIS') }}</title>
  <meta name="theme-color" content="#00A4D2">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet"
    media="print" onload="this.media='all'">
  <link rel="stylesheet" href="/assets/css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script src="/assets/js/app.js"></script>
  <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
  <style>
    .auth-theme-toggle {
      position: fixed;
      top: 18px;
      right: 18px;
      width: 40px;
      height: 40px;
      border-radius: 999px;
      border: 1px solid var(--hairline);
      background: var(--surface-glass);
      backdrop-filter: blur(20px) saturate(180%);
      -webkit-backdrop-filter: blur(20px) saturate(180%);
      display: grid;
      place-items: center;
      cursor: pointer;
      color: var(--color-text-secondary);
      z-index: 100;
      transition: transform var(--motion-fast) var(--ease-pop),
        border-color var(--motion-fast) var(--ease-apple);
    }

    .auth-theme-toggle:hover {
      transform: scale(1.05);
      border-color: var(--color-primary-400);
      color: var(--color-primary-400);
    }

    .auth-theme-toggle svg {
      width: 18px;
      height: 18px;
    }

    .auth-theme-toggle .moon-ic {
      display: none;
    }

    .auth-theme-toggle .sun-ic {
      display: block;
    }

    [data-theme="dark"] .auth-theme-toggle .moon-ic {
      display: block;
    }

    [data-theme="dark"] .auth-theme-toggle .sun-ic {
      display: none;
    }

    /* ── Field row (dedicated — do NOT reuse the shared dashboard
       .form-row grid class here; it collides with this page's stacked
       label-above-input layout and its `input[type="tel"]` descendant
       selector overrides .input-group's flush input styling). ────── */
    .auth-row {
      display: block;
      margin-bottom: 16px;
    }

    .auth-row .field-label {
      display: block;
      margin-bottom: 8px;
    }

    /* ── Step indicator ─────────────────────────────────────────── */
    .step-labels {
      display: flex;
      justify-content: space-between;
      margin: -14px 0 22px;
      font-size: 11.5px;
      font-weight: 600;
      letter-spacing: 0.02em;
      text-transform: uppercase;
      color: var(--color-text-tertiary);
    }

    .step-labels span.active {
      color: var(--color-primary-400);
    }

    /* ── Sent-to confirmation row ───────────────────────────────── */
    .sent-to {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 10px;
      padding: 10px 14px;
      margin-bottom: 18px;
      border-radius: 12px;
      /* Theme-aware tint (not --color-primary-50, which is light-only and
         made the light-gray dark-mode text invisible against a pale-blue
         background). --accent-cyan-soft is redefined per theme. */
      background: var(--accent-cyan-soft, rgba(0, 164, 210, .12));
      border: 1px solid var(--accent-cyan-glow, rgba(0, 164, 210, .3));
      font-size: 13px;
      color: var(--color-text-secondary);
      animation: lift-in 320ms var(--ease-apple) both;
    }

    .sent-to strong {
      color: var(--color-text-primary);
      font-weight: 600;
    }

    .sent-to button {
      flex-shrink: 0;
      background: none;
      border: none;
      color: var(--color-primary-400);
      font-weight: 600;
      font-size: 12.5px;
      cursor: pointer;
      padding: 4px 6px;
      border-radius: 6px;
      transition: background .15s ease;
    }

    .sent-to button:hover {
      background: var(--accent-cyan-soft, rgba(0, 164, 210, .14));
    }

    .sent-to button:disabled {
      color: var(--color-text-tertiary);
      cursor: not-allowed;
      background: none;
    }

    /* ── Segmented OTP boxes ────────────────────────────────────── */
    .otp-boxes {
      display: flex;
      gap: 9px;
      justify-content: center;
      margin: 4px 0 6px;
    }

    .otp-boxes input {
      width: 46px;
      height: 56px;
      text-align: center;
      font-size: 24px;
      font-weight: 700;
      font-family: var(--font-mono);
      color: var(--color-text-primary);
      border: 1.5px solid var(--hairline-strong);
      border-radius: 12px;
      background: var(--surface-card);
      transition: border-color var(--motion-fast) var(--ease-apple),
        box-shadow var(--motion-fast) var(--ease-apple),
        transform 120ms ease;
    }

    .otp-boxes input:focus {
      outline: 0;
      border-color: var(--color-primary-400);
      box-shadow: var(--glow-brand);
      transform: translateY(-1px);
    }

    .otp-boxes input.filled {
      border-color: var(--color-primary-400);
    }

    .otp-boxes input.shake {
      animation: otp-shake 380ms ease;
      border-color: #ef4444 !important;
    }

    @keyframes otp-shake {

      10%,
      90% {
        transform: translateX(-1px);
      }

      20%,
      80% {
        transform: translateX(2px);
      }

      30%,
      50%,
      70% {
        transform: translateX(-4px);
      }

      40%,
      60% {
        transform: translateX(4px);
      }
    }

    /* ── Resend row ──────────────────────────────────────────────── */
    .resend-row {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      margin: 16px 0 4px;
      font-size: 13px;
      color: var(--color-text-tertiary);
    }

    .resend-row .countdown {
      font-family: var(--font-mono);
      font-weight: 600;
      color: var(--color-text-secondary);
      min-width: 34px;
      text-align: left;
    }

    .resend-row button {
      background: none;
      border: none;
      padding: 2px 4px;
      font-size: 13px;
      font-weight: 700;
      color: var(--color-primary-400);
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 5px;
      border-radius: 6px;
      transition: color .15s ease, transform .15s ease;
    }

    .resend-row button:not(:disabled):hover {
      color: var(--color-primary-500);
      transform: translateY(-1px);
    }

    .resend-row button:disabled {
      color: var(--color-text-tertiary);
      cursor: default;
    }

    .resend-row button svg {
      width: 14px;
      height: 14px;
    }

    .resend-row .spin {
      animation: mis-spin 850ms linear infinite;
    }

    @keyframes mis-spin {
      to {
        transform: rotate(360deg);
      }
    }

    /* ── Security note ───────────────────────────────────────────── */
    .security-note {
      display: flex;
      align-items: flex-start;
      gap: 8px;
      margin-top: 20px;
      padding: 10px 12px;
      border-radius: 10px;
      background: var(--surface-canvas);
      color: var(--color-text-tertiary);
      font-size: 11.5px;
      line-height: 1.5;
    }

    .security-note svg {
      width: 14px;
      height: 14px;
      flex-shrink: 0;
      margin-top: 1px;
      color: var(--color-text-tertiary);
    }
  </style>
</head>

<body>

  <button class="auth-theme-toggle" id="themeBtn" type="button" aria-label="Toggle theme">
    <i class="sun-ic" data-lucide="sun"></i>
    <i class="moon-ic" data-lucide="moon"></i>
  </button>

  <main class="auth-stage">
    <section class="auth-card" role="dialog" aria-labelledby="login-title">
      <div class="brand">
        <div class="logo">M</div>
        <div>
          <div class="name">MIS</div>
          <div class="t-meta" style="font-size:11px; margin-top:1px;">Make It Simple</div>
        </div>
      </div>

      <div class="stepper" id="loginStepper">
        <div class="step-pill active" data-step="1"></div>
        <div class="step-pill" data-step="2"></div>
      </div>
      <div class="step-labels">
        <span id="stepLabel1" class="active">1 · Phone number</span>
        <span id="stepLabel2">2 · Verify code</span>
      </div>

      <h1 id="login-title">Welcome back</h1>
      <p class="sub" id="login-sub">Sign in with your registered WhatsApp number to access your dashboard.</p>

      <form id="loginForm" novalidate>
        <div class="auth-row" id="phoneRow">
          <label class="field-label" for="phone">Phone number</label>
          <div class="input-group">
            <span class="prefix">+91</span>
            <input id="phone" name="phone" type="tel" inputmode="numeric" autocomplete="tel-national"
              placeholder="9999 XXX XXX" maxlength="15" required autofocus>
          </div>
        </div>

        <div id="otp-section" style="display:none;">
          <div class="sent-to" id="sentToRow">
            <span>🔐 Code sent to <strong id="sentToPhone">—</strong></span>
            <button type="button" id="changeNumberBtn">Change</button>
          </div>

          <label class="field-label" for="otp1" style="display:block;text-align:center;margin-bottom:10px;">Enter the
            6-digit code</label>
          <div class="otp-boxes" id="otpBoxes">
            <input type="tel" inputmode="numeric" maxlength="1" autocomplete="one-time-code" data-i="0">
            <input type="tel" inputmode="numeric" maxlength="1" data-i="1">
            <input type="tel" inputmode="numeric" maxlength="1" data-i="2">
            <input type="tel" inputmode="numeric" maxlength="1" data-i="3">
            <input type="tel" inputmode="numeric" maxlength="1" data-i="4">
            <input type="tel" inputmode="numeric" maxlength="1" data-i="5">
          </div>

          <div class="resend-row">
            <span id="resendIdle" style="display:none;">Didn't get the code?</span>
            <button type="button" id="resendBtn" disabled>
              <i data-lucide="refresh-cw"></i>
              <span id="resendLabel">Resend OTP in <span class="countdown" id="resendCountdown">1:00</span></span>
            </button>
          </div>
        </div>

        <div id="login-status" class="status"></div>

        <div class="actions">
          <button type="submit" class="btn btn-primary" id="loginBtn">
            <span class="btn-label">Send OTP</span>
            <i data-lucide="arrow-right" style="width:18px;height:18px;"></i>
          </button>
        </div>
      </form>

      <div class="security-note">
        <i data-lucide="shield-check"></i>
        <span>We never ask for your OTP over calls or email. This code expires in 5 minutes and is only valid for this
          sign-in.</span>
      </div>
    </section>
  </main>

  <script>
    (function () {
      'use strict';

      const RESEND_COOLDOWN = 60; // seconds — mirrors OtpService::RESEND_COOLDOWN server-side
      const RESEND_KEY = 'mis_otp_resend_until';

      let currentPhone = '';
      let resendTimer = null;
      let isSending = false;   // guards /send-otp against double-fire (spam clicks, Change→resend to same number)
      let isVerifying = false; // guards /verify-otp against double-fire (auto-submit + Enter racing)

      function showStatus(kind, msg) {
        const el = document.getElementById('login-status');
        el.className = 'status show ' + kind;
        el.textContent = msg;
      }
      function clearStatus() {
        const el = document.getElementById('login-status');
        el.className = 'status';
        el.textContent = '';
      }

      function setLoading(state, label) {
        const btn = document.getElementById('loginBtn');
        btn.disabled = !!state;
        btn.style.opacity = state ? '0.7' : '1';
        if (label) btn.querySelector('.btn-label').textContent = label;
      }

      function formatPhoneDisplay(stored) {
        // stored = "9198765xxxxx" (91 + 10-digit). Show "+91 98765 43210".
        const local = stored.replace(/^91/, '');
        if (local.length !== 10) return '+' + stored;
        return '+91 ' + local.slice(0, 5) + ' ' + local.slice(5);
      }

      // ── Step transitions ──────────────────────────────────────────
      function goToStep(step) {
        const pill1 = document.querySelector('.step-pill[data-step="1"]');
        const pill2 = document.querySelector('.step-pill[data-step="2"]');
        const label1 = document.getElementById('stepLabel1');
        const label2 = document.getElementById('stepLabel2');
        if (step === 2) {
          pill1.classList.add('done'); pill1.classList.remove('active');
          pill2.classList.add('active');
          label1.classList.remove('active'); label2.classList.add('active');
          document.getElementById('login-sub').textContent = 'Enter the code we just sent you to continue.';
        } else {
          pill1.classList.add('active'); pill1.classList.remove('done');
          pill2.classList.remove('active');
          label1.classList.add('active'); label2.classList.remove('active');
          document.getElementById('login-sub').textContent = 'Sign in with your registered WhatsApp number to access your dashboard.';
        }
      }

      // ── OTP segmented boxes ────────────────────────────────────────
      const otpBoxes = () => Array.from(document.querySelectorAll('.otp-boxes input'));

      function otpValue() {
        return otpBoxes().map(b => b.value).join('');
      }
      function clearOtpBoxes() {
        otpBoxes().forEach(b => { b.value = ''; b.classList.remove('filled'); });
      }
      function shakeOtpBoxes() {
        otpBoxes().forEach(b => {
          b.classList.add('shake');
          setTimeout(() => b.classList.remove('shake'), 400);
        });
      }
      function bindOtpBoxes() {
        const boxes = otpBoxes();
        boxes.forEach((box, i) => {
          box.addEventListener('input', () => {
            box.value = box.value.replace(/\D/g, '').slice(-1);
            box.classList.toggle('filled', !!box.value);
            if (box.value && boxes[i + 1]) boxes[i + 1].focus();
            if (otpValue().length === 6) doVerify();
          });
          box.addEventListener('keydown', (e) => {
            if (e.key === 'Backspace' && !box.value && boxes[i - 1]) {
              boxes[i - 1].focus();
            }
          });
          box.addEventListener('paste', (e) => {
            e.preventDefault();
            const digits = (e.clipboardData.getData('text') || '').replace(/\D/g, '').slice(0, 6);
            if (!digits) return;
            digits.split('').forEach((d, idx) => {
              if (boxes[idx]) { boxes[idx].value = d; boxes[idx].classList.add('filled'); }
            });
            const last = Math.min(digits.length, 6) - 1;
            if (boxes[last]) boxes[last].focus();
            if (digits.length === 6) doVerify();
          });
        });
      }

      // ── Resend countdown (server-synced) ───────────────────────────
      function startResendCountdown(seconds) {
        const until = Date.now() + seconds * 1000;
        localStorage.setItem(RESEND_KEY, String(until));
        renderCountdown(until);
      }
      function renderCountdown(until) {
        if (resendTimer) clearInterval(resendTimer);
        const btn = document.getElementById('resendBtn');
        const label = document.getElementById('resendLabel');
        const idle = document.getElementById('resendIdle');

        function tick() {
          const remaining = Math.max(0, Math.round((until - Date.now()) / 1000));
          if (remaining <= 0) {
            clearInterval(resendTimer);
            btn.disabled = false;
            idle.style.display = 'inline';
            label.innerHTML = '<i data-lucide="refresh-cw" style="width:14px;height:14px;"></i> Resend OTP';
            if (window.lucide) window.lucide.createIcons();
            localStorage.removeItem(RESEND_KEY);
            return;
          }
          btn.disabled = true;
          idle.style.display = 'none';
          const m = Math.floor(remaining / 60);
          const s = remaining % 60;
          document.getElementById('resendLabel').innerHTML =
            'Resend OTP in <span class="countdown" id="resendCountdown">' + m + ':' + String(s).padStart(2, '0') + '</span>';
        }
        tick();
        resendTimer = setInterval(tick, 1000);
      }

      // ── Network calls ──────────────────────────────────────────────
      async function requestOtp(phone, { isResend = false } = {}) {
        if (isSending) return; // already in flight — ignore the extra click entirely
        isSending = true;
        setChangeNumberEnabled(false);

        setLoading(true, isResend ? 'Resending…' : 'Sending…');
        if (isResend) {
          const btn = document.getElementById('resendBtn');
          btn.disabled = true;
          btn.querySelector('svg')?.classList.add('spin');
        }
        try {
          const res = await fetch('/api/tenant/send-otp', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone })
          });
          const data = await res.json();

          if (res.status === 429 && data.retry_after) {
            // Still cooling down server-side. Two cases:
            //  1. isResend (or already on the OTP step) — user is spamming Resend / multiple
            //     tabs. Just re-sync the visible countdown, no need to touch the rest of the UI.
            //  2. Fresh "Send OTP" for this exact number while NOT on the OTP step — this is
            //     the "Change number → immediately re-enter the same number" case. A valid code
            //     was already texted moments ago and is still good for 5 minutes; silently doing
            //     nothing here left the user stuck on the phone step with no explanation. Instead,
            //     resume the OTP step for that already-sent code rather than trying (and failing)
            //     to send a new one.
            if (!isResend && !otpSectionVisible()) {
              currentPhone = phone;
              document.getElementById('sentToPhone').textContent = formatPhoneDisplay(phone);
              document.getElementById('phoneRow').style.display = 'none';
              document.getElementById('otp-section').style.display = 'block';
              document.getElementById('loginBtn').style.display = 'none';
              goToStep(2);
              clearOtpBoxes();
              otpBoxes()[0].focus();
              startResendCountdown(data.retry_after);
              setLoading(false);
              showStatus('info', 'A code was already sent to this number a moment ago — enter it below.');
            } else {
              startResendCountdown(data.retry_after);
              if (isResend) showStatus('info', 'Please wait a little longer before requesting another code.');
              setLoading(false, otpSectionVisible() ? 'Verify OTP' : 'Send OTP');
            }
            return;
          }

          if (!data.ok) {
            setLoading(false, 'Send OTP');
            showStatus('error', data.error || data.message || 'Could not send OTP. Contact admin.');
            return;
          }

          currentPhone = phone;
          document.getElementById('sentToPhone').textContent = formatPhoneDisplay(phone);
          document.getElementById('phoneRow').style.display = 'none';
          document.getElementById('otp-section').style.display = 'block';
          document.getElementById('loginBtn').style.display = 'none';
          goToStep(2);
          clearOtpBoxes();
          otpBoxes()[0].focus();
          startResendCountdown(data.retry_after || RESEND_COOLDOWN);
          setLoading(false);
          showStatus('success', isResend ? '✅ A new code is on its way via WhatsApp.' : '✅ OTP sent to your WhatsApp. Enter it below.');
        } catch (err) {
          setLoading(false, 'Send OTP');
          showStatus('error', 'Network error. Please try again.');
        } finally {
          isSending = false;
          setChangeNumberEnabled(true);
        }
      }

      function otpSectionVisible() {
        return document.getElementById('otp-section').style.display !== 'none';
      }

      function setChangeNumberEnabled(enabled) {
        const btn = document.getElementById('changeNumberBtn');
        if (btn) btn.disabled = !enabled;
      }

      async function doVerify() {
        const code = otpValue();
        if (code.length !== 6 || !currentPhone) return;
        if (isVerifying) return; // already checking this code — ignore the duplicate trigger
        isVerifying = true;
        setChangeNumberEnabled(false);
        clearStatus();
        otpBoxes().forEach(b => b.disabled = true);

        try {
          const res = await fetch('/api/tenant/verify-otp', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ phone: currentPhone, otp: code })
          });
          const data = await res.json();
          if (data.verified) {
            const checkRes = await fetch('/api/tenant/check-phone', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ phone: currentPhone })
            });
            const checkData = await checkRes.json();
            if (checkData && checkData.exists) {
              window.MIS.auth.setPhone(currentPhone);
              const tName = (checkData.tenant && checkData.tenant.name) || checkData.tenant_name || checkData.name;
              if (tName) window.MIS.auth.setTenantName(tName);
              if (checkData.role) localStorage.setItem('mis_user_role', checkData.role);
              if (checkData.permissions) localStorage.setItem('mis_permissions', JSON.stringify(checkData.permissions));
              try { await window.MIS.auth.issueChatToken(currentPhone); } catch (_) { }
              localStorage.removeItem(RESEND_KEY);
              otpBoxes().forEach(b => { b.classList.add('filled'); });
              showStatus('success', '🎉 Welcome back! Redirecting…');
              setTimeout(() => window.location.replace('/dashboard'), 500);
            } else {
              otpBoxes().forEach(b => b.disabled = false);
              showStatus('error', 'Account not found. Please contact admin.');
            }
          } else {
            otpBoxes().forEach(b => b.disabled = false);
            shakeOtpBoxes();
            clearOtpBoxes();
            otpBoxes()[0].focus();
            showStatus('error', data.error || 'Invalid OTP. Try again.');
          }
        } catch (err) {
          otpBoxes().forEach(b => b.disabled = false);
          showStatus('error', 'Verification failed. Try again.');
        } finally {
          isVerifying = false;
          setChangeNumberEnabled(true);
        }
      }

      function resetToPhoneStep() {
        currentPhone = '';
        isSending = false;
        isVerifying = false;
        setChangeNumberEnabled(true);
        if (resendTimer) clearInterval(resendTimer);
        localStorage.removeItem(RESEND_KEY);
        clearStatus();
        clearOtpBoxes();
        document.getElementById('otp-section').style.display = 'none';
        document.getElementById('phoneRow').style.display = 'block';
        document.getElementById('loginBtn').style.display = 'inline-flex';
        document.getElementById('loginBtn').querySelector('.btn-label').textContent = 'Send OTP';
        document.getElementById('phone').disabled = false;
        document.getElementById('phone').focus();
        goToStep(1);
      }

      async function handleSubmit(e) {
        if (e) e.preventDefault();
        if (otpSectionVisible()) {
          // Step 2: manual submit fallback (auto-submit already fires at 6 digits)
          if (otpValue().length === 6) doVerify();
          else showStatus('error', 'Enter the full 6-digit code.');
          return false;
        }

        const raw = document.getElementById('phone').value.replace(/\D/g, '');
        if (raw.length < 10 || raw.length > 15) {
          showStatus('error', 'Please enter a valid phone number (10–15 digits).');
          return false;
        }
        let phone = raw;
        if (phone.length > 10 && phone.startsWith('91')) phone = phone.slice(2);
        if (phone.length === 11 && phone.startsWith('0')) phone = phone.slice(1);
        const stored = '91' + phone;

        document.getElementById('phone').disabled = true;
        await requestOtp(stored);
        document.getElementById('phone').disabled = true;
        return false;
      }

      document.addEventListener('DOMContentLoaded', () => {
        if (window.MIS && window.MIS.auth && window.MIS.auth.getPhone()) {
          window.location.replace('/dashboard');
          return;
        }
        bindOtpBoxes();

        const form = document.getElementById('loginForm');
        form.addEventListener('submit', handleSubmit);

        document.getElementById('changeNumberBtn').addEventListener('click', resetToPhoneStep);

        document.getElementById('resendBtn').addEventListener('click', () => {
          if (!currentPhone) return;
          requestOtp(currentPhone, { isResend: true });
        });

        // If a cooldown was already in progress (e.g. accidental refresh), resume it —
        // requires the user to re-enter their number since we don't persist the OTP
        // step itself, but this stops the resend button being spammable immediately.
        const savedUntil = parseInt(localStorage.getItem(RESEND_KEY) || '0', 10);
        if (savedUntil && savedUntil > Date.now()) {
          // Nothing visible to resume yet (still on phone step) — just leave the
          // stored value; requestOtp() will re-sync it from the server response.
        }

        const themeBtn = document.getElementById('themeBtn');
        themeBtn.addEventListener('click', () => {
          window.MIS.theme.toggle();
          if (window.lucide) window.lucide.createIcons();
        });
        if (window.lucide) window.lucide.createIcons();
      });
    })();
  </script>
</body>

</html>