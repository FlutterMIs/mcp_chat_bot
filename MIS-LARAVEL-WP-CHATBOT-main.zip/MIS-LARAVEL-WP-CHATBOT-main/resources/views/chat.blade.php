@extends('layouts.app')

@section('title', 'Chat')

@push('head')
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.7/dist/chart.umd.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jspdf@2.5.2/dist/jspdf.umd.min.js"></script>
@endpush

@section('topbar-actions')
  <button class="btn-icon" data-action="sync" id="topSyncBtn" title="Sync data" type="button">
    <i data-lucide="refresh-cw"></i>
  </button>
  <button class="btn-icon" data-action="open-panel" title="Tools" aria-label="Tools panel" type="button">
    <i data-lucide="panel-right-open"></i>
  </button>
  <button class="btn-icon" data-action="clear-chat" title="Clear chat" type="button">
    <i data-lucide="trash-2"></i>
  </button>
@endsection

@section('content')
    <!-- CHAT PAGE -->
    <section class="page chat-page" id="chatPage">

      <!-- Hero (visible until first message) -->
      <div class="chat-hero" id="chatHero">
        <h1 id="heroTitle">Hello there 👋</h1>
        <p id="heroSubtitle">Ask anything about your data — sales, ledger, charts, or just say hi.</p>
        <span class="underline"></span>
      </div>

      <!-- Suggestion chips -->
      <div class="chips-row" id="chipsRow" aria-label="Suggested prompts">
        <!-- Filled by /api/chat-suggestions -->
        <div class="chip" data-i="0" data-skeleton="true" style="opacity:0.5">
          <i data-lucide="sparkles"></i> Loading…
        </div>
      </div>

      <!-- Chat stream -->
      <div class="chat-stream" id="chatStream"></div>

      <!-- Composer -->
      <div class="composer-wrap">
        <!-- Voice waveform overlay (above composer) -->
        <div class="waveform-wrap" id="waveformWrap" aria-live="polite">
          <span class="rec-dot"></span>
          <span class="rec-time" id="recTime">00:00</span>
          <canvas id="waveformCanvas" width="480" height="36"></canvas>
          <button class="rec-stop" data-action="mic-stop" aria-label="Stop recording">
            <i data-lucide="square" style="width:14px;height:14px;"></i>
          </button>
        </div>

        <form class="composer" id="composer" autocomplete="off">
          <button type="button" class="composer-btn" data-action="open-panel" title="Tools">
            <i data-lucide="paperclip"></i>
          </button>
          <textarea
            class="composer-input"
            id="msgInput"
            rows="1"
            placeholder="Type a message, or hold the mic to speak…"
            aria-label="Message input"></textarea>
          <button type="button" class="composer-btn mic-btn" id="micBtn" data-action="mic-toggle" title="Voice (max 60s)">
            <i data-lucide="mic"></i>
          </button>
          <button type="submit" class="composer-btn send" data-action="send" title="Send" aria-label="Send">
            <i data-lucide="arrow-up"></i>
          </button>
        </form>
      </div>
    </section>
@endsection

@section('drawers')
<!-- ────────── SLIDE-OVER PANEL ────────── -->
<div class="slideover-backdrop" id="panelBackdrop" data-action="close-panel"></div>
<aside class="slideover" id="panel" role="dialog" aria-label="Tools panel">
  <div class="slideover-head">
    <h3>Tools</h3>
    <button class="slideover-close" data-action="close-panel" aria-label="Close">
      <i data-lucide="x" style="width:14px;height:14px;"></i>
    </button>
  </div>
  <div class="slideover-body">

    <!-- Document analyzer -->
    <div class="so-section">
      <h4>Document analyzer</h4>
      <div class="so-card">
        <div class="so-input-row">
          <input class="so-input" id="docUrlInput" type="url" placeholder="Paste a Google Sheet, Drive, or PDF link…">
          <button class="so-btn" data-action="analyze-doc" id="analyzeBtn">
            <i data-lucide="search" style="width:14px;height:14px;vertical-align:-2px;"></i>
          </button>
        </div>
        <div class="so-result" id="docResult"></div>
      </div>
    </div>

    <!-- File upload -->
    <div class="so-section">
      <h4>Upload document</h4>
      <label class="drop-zone" id="dropZone">
        <i data-lucide="upload-cloud"></i>
        <div>Drop PDF, DOCX, XLSX, CSV, TXT, MD here or <u>browse</u></div>
        <input type="file" id="fileInput" accept=".pdf,.docx,.xlsx,.xls,.csv,.txt,.md" hidden>
      </label>
      <div class="so-result" id="fileResult"></div>
    </div>

    <!-- Sync -->
    <div class="so-section">
      <h4>Data sync</h4>
      <div class="so-card">
        <div class="sync-row">
          <div class="sync-status" id="syncStatusText"><span class="ok-dot"></span><span id="syncStatusLabel">Up to date</span></div>
          <button class="so-btn ghost" data-action="sync" id="panelSyncBtn">
            <i data-lucide="refresh-cw" style="width:13px;height:13px;vertical-align:-2px;margin-right:4px;"></i> Sync now
          </button>
        </div>
        <div class="so-result" id="syncResult"></div>
      </div>
    </div>

    <!-- Clear chat -->
    <div class="so-section">
      <h4>Conversation</h4>
      <div class="so-card">
        <button class="so-btn ghost" data-action="clear-chat" style="width:100%;">
          <i data-lucide="trash-2" style="width:13px;height:13px;vertical-align:-2px;margin-right:4px;"></i> Clear this conversation
        </button>
      </div>
    </div>

  </div>
</aside>

<!-- ────────── IMAGE LIGHTBOX ────────── -->
<div class="lightbox" id="lightbox" data-action="close-lightbox" role="dialog" aria-label="Image preview">
  <button class="close" data-action="close-lightbox" aria-label="Close">×</button>
  <img id="lightboxImg" src="" alt="">
</div>
@endsection

@push('scripts')
<script src="/assets/js/chat.js"></script>
@endpush
