@extends('layouts.app')

@section('title', 'Admin Panel')

@section('content')
    <div class="page">
      <!-- Stats -->
      <div class="stat-cards" id="statsRow">
        <div class="stat-card"><div class="label">Total Clients</div><div class="value" id="statClients">—</div></div>
        <div class="stat-card"><div class="label">Total Members</div><div class="value" id="statMembers">—</div></div>
        <div class="stat-card"><div class="label">Chat Queries (today)</div><div class="value" id="statQueries">—</div></div>
        <div class="stat-card"><div class="label">WA Messages (today)</div><div class="value" id="statMessages">—</div></div>
      </div>

      <!-- Tabs -->
      <div class="admin-tabs">
        <div class="admin-tab active" data-tab="clients">Clients</div>
        <div class="admin-tab" data-tab="members">Members</div>
        <div class="admin-tab" data-tab="prompts">AI Settings</div>
        <div class="admin-tab" data-tab="trash">Trash</div>
        <div class="admin-tab" data-tab="logs">Activity Logs</div>
      </div>

      <!-- Clients Tab -->
      <div class="tab-panel active" id="panel-clients">
        <div class="card">
          <div class="card-header">
            <h3>All Clients</h3>
            <button class="btn-primary" id="addClientBtn">+ Add Client</button>
          </div>
          <div id="clientsTable"><div class="empty-state">Loading...</div></div>
        </div>
      </div>

      <!-- Members Tab -->
      <div class="tab-panel" id="panel-members">
        <div class="card">
          <div class="card-header">
            <h3>All Members</h3>
            <button class="btn-primary" id="addMemberBtn">+ Add Member</button>
          </div>
          <div id="membersTable"><div class="empty-state">Loading...</div></div>
        </div>
      </div>

      <!-- AI Settings Tab -->
      <div class="tab-panel" id="panel-prompts">
        <div class="card">
          <div class="card-header">
            <h3>🤖 AI Prompt Settings</h3>
          </div>
          <div style="padding:1rem">
            <p style="color:var(--text-secondary);margin-bottom:1rem">Customize how the AI bot responds. Select a client first, then edit their prompts.</p>
            <div style="margin-bottom:1rem">
              <label style="font-weight:600;display:block;margin-bottom:0.3rem">Select Client</label>
              <select id="promptTenantSelect" style="width:100%;padding:0.5rem;border-radius:6px;border:1px solid var(--border)">
                <option value="">-- Select --</option>
              </select>
            </div>
            <div id="promptFields" style="display:none">
              <div style="margin-bottom:1rem">
                <label style="font-weight:600;display:block;margin-bottom:0.3rem">📝 Response Style</label>
                <p style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:0.3rem">How bot answers website/PDF questions (e.g. "Be detailed", "Answer in Hindi")</p>
                <textarea id="prompt_response_style" rows="3" style="width:100%;padding:0.5rem;border-radius:6px;border:1px solid var(--border);resize:vertical" placeholder="e.g. Always give detailed answers in Hindi-English mix. Use emojis."></textarea>
              </div>
              <div style="margin-bottom:1rem">
                <label style="font-weight:600;display:block;margin-bottom:0.3rem">📊 Data Format</label>
                <p style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:0.3rem">How bot formats data query results (e.g. "Always show totals", "Use short format")</p>
                <textarea id="prompt_data_format" rows="3" style="width:100%;padding:0.5rem;border-radius:6px;border:1px solid var(--border);resize:vertical" placeholder="e.g. Always show grand total at the end. Keep responses concise."></textarea>
              </div>
              <div style="margin-bottom:1rem">
                <label style="font-weight:600;display:block;margin-bottom:0.3rem">🎭 Bot Personality</label>
                <p style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:0.3rem">Tone, greeting style, sign-off (e.g. "Be formal", "Call yourself MIS Bot")</p>
                <textarea id="prompt_bot_personality" rows="3" style="width:100%;padding:0.5rem;border-radius:6px;border:1px solid var(--border);resize:vertical" placeholder="e.g. Be professional and friendly. Start with 🙏 Namaste. Sign off with - MIS Bot"></textarea>
              </div>
              <div style="margin-bottom:1rem">
                <label style="font-weight:600;display:block;margin-bottom:0.3rem">🏢 Company Context</label>
                <p style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:0.3rem">Background info about the business (injected into all AI answers)</p>
                <textarea id="prompt_company_context" rows="3" style="width:100%;padding:0.5rem;border-radius:6px;border:1px solid var(--border);resize:vertical" placeholder="e.g. We are MIS Work India Pvt Ltd, a printing & packaging company based in Delhi with 50+ clients."></textarea>
              </div>
              <button class="btn-primary" id="savePromptsBtn">💾 Save Prompts</button>
              <button class="btn-sm" id="resetPromptsBtn" style="margin-left:0.5rem;background:#e74c3c;color:#fff;border:none;padding:0.5rem 1rem;border-radius:6px;cursor:pointer">🔄 Reset All</button>
            </div>
          </div>
        </div>
      </div>

      <!-- Trash Tab -->
      <div class="tab-panel" id="panel-trash">
        <div class="card">
          <div class="card-header">
            <h3>Deleted Clients</h3>
          </div>
          <div id="trashTable"><div class="empty-state">Loading...</div></div>
        </div>
      </div>

      <!-- Activity Logs Tab -->
      <div class="tab-panel" id="panel-logs">
        <div class="card">
          <div class="card-header">
            <h3>Administrative Activity Logs</h3>
          </div>
          <div id="logsTable"><div class="empty-state">Loading...</div></div>
        </div>
      </div>
    </div>
@endsection

@section('drawers')
<!-- Add Client Modal -->
<div class="modal-overlay" id="clientModal">
  <div class="modal">
    <h3>Add New Client</h3>
    <div class="form-group"><label>Phone (with 91)</label><input id="cPhone" placeholder="919876543210"></div>
    <div class="form-group"><label>Business Name</label><input id="cName" placeholder="Kaizen Enterprises"></div>
    <div class="form-group"><label>Email (optional)</label><input id="cEmail" placeholder="owner@company.com"></div>
    <div class="form-group"><label>Google Sheet URL (optional)</label><input id="cSheet" placeholder="https://docs.google.com/spreadsheets/d/..."></div>
    <div class="form-group">
      <label>WhatsApp API Key</label>
      <div style="display:flex;gap:12px;margin-top:4px;">
        <label style="font-size:13px;cursor:pointer;"><input type="radio" name="cWaMode" value="shared" checked> MIS Shared Key</label>
        <label style="font-size:13px;cursor:pointer;"><input type="radio" name="cWaMode" value="own"> Owner's Own Key</label>
      </div>
    </div>
    <div id="cSyncStatus" style="display:none;margin-top:10px;font-size:12px;color:var(--color-text-secondary);"></div>
    <div class="modal-actions">
      <button class="btn-sm" onclick="closeClientModal()">Cancel</button>
      <button class="btn-primary" id="saveClientBtn">Save Client</button>
    </div>
  </div>
</div>

<!-- Add Member Modal -->
<div class="modal-overlay" id="memberModal">
  <div class="modal">
    <h3>Add New Member</h3>
    <div class="form-group"><label>Phone (with 91)</label><input id="mPhone" placeholder="919876543210"></div>
    <div class="form-group"><label>Assign to Client</label><select id="mClient"><option value="">Select client...</option></select></div>
    <div class="form-group"><label>Alias (optional)</label><input id="mAlias" placeholder="Rahul - Sales Team"></div>
    <div class="form-group">
      <label>Permissions</label>
      <div class="perm-grid">
        <label><input type="checkbox" value="dashboard" checked> Dashboard</label>
        <label><input type="checkbox" value="chat" checked> Chat</label>
        <label><input type="checkbox" value="sales"> Sales</label>
        <label><input type="checkbox" value="outstanding"> Outstanding</label>
        <label><input type="checkbox" value="stock"> Stock</label>
        <label><input type="checkbox" value="ledger"> Ledger</label>
        <label><input type="checkbox" value="calendar"> Calendar</label>
        <label><input type="checkbox" value="reports"> Reports</label>
      </div>
    </div>
    <div class="modal-actions">
      <button class="btn-sm" onclick="document.getElementById('memberModal').classList.remove('show')">Cancel</button>
      <button class="btn-primary" id="saveMemberBtn">Save Member</button>
    </div>
  </div>
</div>

<!-- Edit Member Modal -->
<div class="modal-overlay" id="editMemberModal">
  <div class="modal">
    <h3>Edit Member Permissions</h3>
    <input type="hidden" id="emId">
    <div class="form-group"><label>Alias</label><input id="emAlias" placeholder="Optional alias"></div>
    <div class="form-group">
      <label>Permissions</label>
      <div class="perm-grid" id="emPerms">
        <label><input type="checkbox" value="dashboard"> Dashboard</label>
        <label><input type="checkbox" value="chat"> Chat</label>
        <label><input type="checkbox" value="sales"> Sales</label>
        <label><input type="checkbox" value="outstanding"> Outstanding</label>
        <label><input type="checkbox" value="stock"> Stock</label>
        <label><input type="checkbox" value="ledger"> Ledger</label>
        <label><input type="checkbox" value="calendar"> Calendar</label>
        <label><input type="checkbox" value="reports"> Reports</label>
      </div>
    </div>
    <div class="modal-actions">
      <button class="btn-sm" onclick="document.getElementById('editMemberModal').classList.remove('show')">Cancel</button>
      <button class="btn-primary" id="saveEditMemberBtn">Save</button>
    </div>
  </div>
</div>

<!-- Connect Sheet Modal -->
<div class="modal-overlay" id="sheetModal">
  <div class="modal">
    <h3>Connect Google Sheet</h3>
    <p style="font-size:13px;color:var(--color-text-secondary);margin-bottom:16px" id="sheetModalInfo">Connecting sheet for <strong></strong></p>
    <div class="form-group"><label>Google Sheet URL <span style="color:#ef4444">*</span></label><input id="sSheet" placeholder="https://docs.google.com/spreadsheets/d/..."></div>
    <div id="sSyncStatus" style="display:none;margin-top:10px;font-size:12px;color:var(--color-text-secondary);"></div>
    <div class="modal-actions">
      <button class="btn-sm" onclick="document.getElementById('sheetModal').classList.remove('show')">Cancel</button>
      <button class="btn-primary" id="saveSheetBtn">Connect & Sync</button>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>
@endsection

@push('scripts')
<script>
(function() {
  'use strict';


  // Page-level guard: only super_admin can access admin panel
  const role = localStorage.getItem('mis_user_role') || '';
  if (role !== 'super_admin') { location.href = '/dashboard'; return; }

  const PHONE = window.MIS.auth.getPhone();
  const H = { 'Content-Type': 'application/json', 'X-Phone': PHONE };



  // Helper: append phone to URL as query param (backup for servers that strip custom headers)
  function adminUrl(path) { return path + (path.includes('?') ? '&' : '?') + 'phone=' + PHONE; }

  // Toast — delegates to the shared pretty SweetAlert2 toast component
  function toast(m, k='ok') { window.MIS.toast(m, k); }

  // Tabs
  document.querySelectorAll('.admin-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById('panel-' + tab.dataset.tab).classList.add('active');
      if (tab.dataset.tab === 'trash') {
        loadTrashedClients();
      } else if (tab.dataset.tab === 'logs') {
        loadActivityLogs();
      }
    });
  });

  // Topbar
  const tName = window.MIS.auth.getTenantName() || 'Admin';
  document.getElementById('tenant-name').textContent = tName;
  document.getElementById('tenantAvatar').textContent = (tName.charAt(0)||'A').toUpperCase();

  // Theme
  document.getElementById('themeRow').addEventListener('click', () => { window.MIS.theme.toggle(); if(window.lucide) lucide.createIcons(); });
  document.getElementById('logoutLink').addEventListener('click', e => { e.preventDefault(); window.MIS.confirmLogout(); });
  document.getElementById('sidebarToggle')?.addEventListener('click', () => document.getElementById('sidebar').classList.toggle('open'));

  // ─── Load Stats ───
  async function loadStats() {
    try {
      const r = await fetch(adminUrl('/api/admin/stats'), { headers: H });
      if (!r.ok) { console.error('stats', r.status, await r.text()); return; }
      const d = await r.json();
      document.getElementById('statClients').textContent = d.total_clients ?? '—';
      document.getElementById('statMembers').textContent = d.total_members ?? '—';
      document.getElementById('statQueries').textContent = d.queries_today ?? '—';
      document.getElementById('statMessages').textContent = d.messages_today ?? '—';
    } catch(e) { console.error('stats error', e); }
  }

  // ─── Load Clients ───
  let clients = [];
  async function loadClients() {
    try {
      const r = await fetch(adminUrl('/api/admin/clients'), { headers: H });
      clients = await r.json();
      const el = document.getElementById('clientsTable');
      if (!clients.length) { el.innerHTML = '<div class="empty-state">No clients yet. Click "+ Add Client" to start.</div>'; return; }
      el.innerHTML = `<table class="data-table"><thead><tr><th>Name</th><th>Phone</th><th>Database</th><th>Status</th><th>Created</th><th>Actions</th></tr></thead><tbody>${
        clients.map(c => `<tr>
          <td><strong>${esc(c.name)}</strong></td>
          <td style="font-family:var(--font-mono);font-size:12px">${c.phone||'—'}</td>
          <td>${c.proper_tables_created ? '<span class="badge badge-green">Yes</span>' : '<span class="badge badge-red">No</span>'}</td>
          <td><span class="badge badge-green">Active</span></td>
          <td style="font-size:12px">${c.created_at ? new Date(c.created_at).toLocaleDateString('en-IN') : '—'}</td>
          <td class="actions-cell">
            ${!c.proper_tables_created ? `<button class="btn-sm" style="border-color:var(--accent-cyan);color:var(--accent-cyan)" onclick="connectSheet('${c.id}','${c.phone}','${esc(c.name)}')">Connect Sheet</button>` : ''}
            ${c.wa_key_mode === 'own' ? `<button class="btn-sm" style="border-color:#e57300;color:#e57300" onclick="removeWaKey('${c.id}','${esc(c.name)}')">Remove Key</button>` : ''}
            <button class="btn-sm" onclick="loginAs('${c.phone}')">Login As</button>
            <button class="btn-danger-sm" onclick="deleteClient('${c.id}')">Remove</button>
          </td>
        </tr>`).join('')
      }</tbody></table>`;
      // Populate member modal dropdown
      const sel = document.getElementById('mClient');
      sel.innerHTML = '<option value="">Select client...</option>' + clients.map(c => `<option value="${c.id}">${esc(c.name)}</option>`).join('');
    } catch(e) { console.warn('clients error', e); }
  }

  // ─── Load Members ───
  async function loadMembers() {
    try {
      const r = await fetch(adminUrl('/api/admin/members'), { headers: H });
      const members = await r.json();
      const el = document.getElementById('membersTable');
      if (!members.length) { el.innerHTML = '<div class="empty-state">No members yet. Click "+ Add Member" to start.</div>'; return; }
      el.innerHTML = `<table class="data-table"><thead><tr><th>Phone</th><th>Client</th><th>Alias</th><th>Permissions</th><th>Actions</th></tr></thead><tbody>${
        members.map(m => `<tr>
          <td style="font-family:var(--font-mono);font-size:12px">${m.phone}</td>
          <td>${esc(m.tenant_name||'—')}</td>
          <td>${esc(m.alias||'—')}</td>
          <td style="font-size:11px">${(m.permissions||['dashboard','chat']).join(', ')}</td>
          <td class="actions-cell">
            <button class="btn-sm" onclick="editMember('${m.id}','${btoa(JSON.stringify(m.permissions))}','${esc(m.alias||'')}')">Edit</button>
            <button class="btn-danger-sm" onclick="deleteMember('${m.id}')">Remove</button>
          </td>
        </tr>`).join('')
      }</tbody></table>`;
    } catch(e) { console.warn('members error', e); }
  }

  // ─── Add Client ───
  window.closeClientModal = function() {
    document.getElementById('clientModal').classList.remove('show');
    document.getElementById('cPhone').value = '';
    document.getElementById('cName').value = '';
    document.getElementById('cEmail').value = '';
    document.getElementById('cSheet').value = '';
    document.getElementById('cSyncStatus').style.display = 'none';
    document.querySelector('input[name="cWaMode"][value="shared"]').checked = true;
  };
  document.getElementById('addClientBtn').addEventListener('click', () => document.getElementById('clientModal').classList.add('show'));
  document.getElementById('saveClientBtn').addEventListener('click', async () => {
    const phone = document.getElementById('cPhone').value.replace(/[^0-9]/g,'');
    const name = document.getElementById('cName').value.trim();
    const sheet_url = document.getElementById('cSheet').value.trim();
    if (!phone || phone.length < 10 || !name) { toast('Phone and name required','error'); return; }
    if (sheet_url && !sheet_url.includes('docs.google.com/spreadsheets')) { toast('Invalid Google Sheet URL','error'); return; }
    const btn = document.getElementById('saveClientBtn');
    const status = document.getElementById('cSyncStatus');
    btn.disabled = true; btn.textContent = 'Creating...';
    status.style.display = 'block'; status.textContent = '⏳ Creating client...';
    try {
      // Step 1: Create client
      const waMode = document.querySelector('input[name="cWaMode"]:checked')?.value || 'shared';
      const r = await fetch(adminUrl('/api/admin/clients'), { method:'POST', headers:H, body: JSON.stringify({
        phone, name, email: document.getElementById('cEmail').value.trim(), sheet_url, wa_key_mode: waMode
      })});
      const d = await r.json();
      if (!r.ok) { toast(d.error||'Failed','error'); status.textContent='❌ '+( d.error||'Failed'); btn.disabled=false; btn.textContent='Save Client'; return; }

      // Step 2: Provision (only if sheet_url provided)
      if (sheet_url) {
        status.textContent = '⏳ Syncing sheet data...';
        const syncRes = await fetch(adminUrl('/api/admin/clients/' + d.id + '/provision'), { method:'POST', headers:H });
        const syncData = await syncRes.json();
        if (syncData.ok) {
          status.textContent = '✅ Synced ' + (syncData.rows || 0) + ' rows across ' + (syncData.tabs || 0) + ' tabs!';
        } else {
          status.textContent = '⚠️ Client created. ' + (syncData.error || 'Sync pending — client can sync from Settings.');
        }
      } else {
        status.textContent = '✅ Client created! Sheet can be added later from Settings.';
      }

      toast('Client added!');
      loadClients(); loadStats();
      setTimeout(() => closeClientModal(), 2000);
    } catch(e) { toast('Network error','error'); status.textContent='❌ Error: '+e.message; }
    finally { btn.disabled=false; btn.textContent='Save Client'; }
  });

  // ─── Add Member ───
  document.getElementById('addMemberBtn').addEventListener('click', () => { loadClients(); document.getElementById('memberModal').classList.add('show'); });
  document.getElementById('saveMemberBtn').addEventListener('click', async () => {
    const phone = document.getElementById('mPhone').value.replace(/[^0-9]/g,'');
    const tenant_id = document.getElementById('mClient').value;
    if (!phone || phone.length < 10 || !tenant_id) { toast('Phone and client required','error'); return; }
    const perms = [...document.querySelectorAll('#memberModal .perm-grid input:checked')].map(i=>i.value);
    try {
      const r = await fetch('/api/admin/members', { method:'POST', headers:H, body: JSON.stringify({
        phone, tenant_id, alias: document.getElementById('mAlias').value.trim(), permissions: perms
      })});
      const d = await r.json();
      if (!r.ok) { toast(d.error||'Failed','error'); return; }
      toast('Member added!');
      document.getElementById('memberModal').classList.remove('show');
      document.getElementById('mPhone').value=''; document.getElementById('mAlias').value='';
      loadMembers(); loadStats();
    } catch(e) { toast('Network error','error'); }
  });

  // ─── Actions ───
  window.loginAs = function(phone) {
    if (!phone) return;
    window.MIS.auth.setPhone(phone);
    // Re-check to get role+permissions for that phone
    fetch('/api/tenant/check-phone', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({phone}) })
      .then(r=>r.json()).then(d => {
        if (d.exists) {
          if(d.tenant) window.MIS.auth.setTenantName(d.tenant.name);
          if(d.role) localStorage.setItem('mis_user_role', d.role);
          if(d.permissions) localStorage.setItem('mis_permissions', JSON.stringify(d.permissions));
        }
        window.location.href = '/dashboard';
      });
  };
  window.deleteClient = async function(id) {
    const ok = await window.MIS.confirmDelete('this client', { text: 'They will be moved to the Trash — you can restore them later.' });
    if (!ok) return;
    const r = await fetch(adminUrl('/api/admin/clients/'+id), { method:'DELETE', headers:H });
    if (r.ok) { toast('Client moved to Trash'); loadClients(); loadStats(); } else { toast('Failed','error'); }
  };
  async function loadTrashedClients() {
    try {
      const r = await fetch(adminUrl('/api/admin/clients/trashed'), { headers: H });
      const trashed = await r.json();
      const el = document.getElementById('trashTable');
      if (!trashed.length) { el.innerHTML = '<div class="empty-state">Trash is empty.</div>'; return; }
      el.innerHTML = `<table class="data-table"><thead><tr><th>Name</th><th>Phone</th><th>Deleted By</th><th>Deleted At</th><th>Actions</th></tr></thead><tbody>${
        trashed.map(c => `<tr>
          <td><strong>${esc(c.name)}</strong></td>
          <td style="font-family:var(--font-mono);font-size:12px">${c.phone||'—'}</td>
          <td>${c.deleted_by ? esc(c.deleted_by) : '—'}</td>
          <td style="font-size:12px">${c.deleted_at ? new Date(c.deleted_at).toLocaleString('en-IN') : '—'}</td>
          <td class="actions-cell">
            <button class="btn-sm" style="border-color:#27ae60;color:#27ae60" onclick="restoreClient('${c.id}')">Restore</button>
            <button class="btn-danger-sm" onclick="forceDeleteClient('${c.id}')">Delete Permanently</button>
          </td>
        </tr>`).join('')
      }</tbody></table>`;
    } catch(e) { console.warn('trash error', e); }
  }
  async function loadActivityLogs() {
    try {
      const r = await fetch(adminUrl('/api/admin/activity-logs'), { headers: H });
      const logs = await r.json();
      const el = document.getElementById('logsTable');
      if (!logs.length) { el.innerHTML = '<div class="empty-state">No activity logs recorded yet.</div>'; return; }
      el.innerHTML = `<table class="data-table"><thead><tr><th>Action</th><th>Performed By</th><th>Target Client</th><th>Date & Time</th><th>Details</th></tr></thead><tbody>${
        logs.map(l => {
          let detailsStr = '—';
          if (l.details) {
            if (l.details.dropped_tables) {
              detailsStr = 'Dropped tables: ' + l.details.dropped_tables.join(', ');
            } else if (l.details.sheet_url) {
              detailsStr = 'Sheet URL: ' + esc(l.details.sheet_url);
            } else {
              detailsStr = esc(JSON.stringify(l.details));
            }
          }
          let actionLabel = l.action;
          let badgeClass = 'badge';
          if (l.action === 'create_client') { actionLabel = 'Create Client'; badgeClass = 'badge badge-green'; }
          else if (l.action === 'soft_delete_client') { actionLabel = 'Soft Delete'; badgeClass = 'badge badge-orange'; }
          else if (l.action === 'restore_client') { actionLabel = 'Restore Client'; badgeClass = 'badge badge-green'; }
          else if (l.action === 'force_delete_client') { actionLabel = 'Permanent Delete'; badgeClass = 'badge badge-red'; }

          return `<tr>
            <td><span class="${badgeClass}">${actionLabel}</span></td>
            <td style="font-family:var(--font-mono);font-size:12px">${esc(l.performed_by)}</td>
            <td><strong>${esc(l.target_name || '—')}</strong><br><span style="font-size:10px;color:var(--text-secondary);font-family:var(--font-mono)">${l.target_id || ''}</span></td>
            <td style="font-size:12px">${l.created_at ? new Date(l.created_at).toLocaleString('en-IN') : '—'}</td>
            <td style="font-size:11px;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(detailsStr)}">${detailsStr}</td>
          </tr>`;
        }).join('')
      }</tbody></table>`;
    } catch(e) { console.warn('logs error', e); }
  }
  window.restoreClient = async function(id) {
    const ok = await window.MIS.confirm({
      title: 'Restore this client?',
      text: 'They will be moved back to the active list.',
      icon: 'question',
      confirmText: 'Yes, restore',
    });
    if (!ok) return;
    try {
      const r = await fetch(adminUrl('/api/admin/clients/' + id + '/restore'), { method: 'POST', headers: H });
      if (r.ok) {
        toast('Client restored successfully!');
        loadTrashedClients();
        loadClients();
        loadStats();
      } else {
        toast('Failed to restore client', 'error');
      }
    } catch(e) { toast('Network error', 'error'); }
  };
  window.forceDeleteClient = async function(id) {
    const ok = await window.MIS.confirm({
      title: 'Permanently delete this client?',
      text: 'This drops ALL their dynamic data tables and CANNOT be undone.',
      icon: 'error',
      confirmText: 'Yes, delete permanently',
      danger: true,
    });
    if (!ok) return;
    try {
      const r = await fetch(adminUrl('/api/admin/clients/' + id + '/force'), { method: 'DELETE', headers: H });
      if (r.ok) {
        toast('Client permanently deleted!');
        loadTrashedClients();
        loadStats();
      } else {
        toast('Failed to delete permanently', 'error');
      }
    } catch(e) { toast('Network error', 'error'); }
  };
  window.removeWaKey = async function(id, name) {
    const ok = await window.MIS.confirm({
      title: `Remove WA API key for "${name}"?`,
      text: 'They will switch back to the MIS shared key.',
      icon: 'warning',
      confirmText: 'Yes, remove',
      danger: true,
    });
    if (!ok) return;
    const r = await fetch('/api/admin/clients/'+id+'/remove-wa-key', { method:'POST', headers:H });
    if (r.ok) { toast('WA key removed — switched to shared'); loadClients(); } else { toast('Failed','error'); }
  };
  window.deleteMember = async function(id) {
    const ok = await window.MIS.confirmDelete('this member');
    if (!ok) return;
    const r = await fetch('/api/admin/members/'+id, { method:'DELETE', headers:H });
    if (r.ok) { toast('Member removed'); loadMembers(); loadStats(); } else { toast('Failed','error'); }
  };

  // ─── Edit Member ───
  window.editMember = function(id, permsB64, alias) {
    document.getElementById('emId').value = id;
    document.getElementById('emAlias').value = alias;
    const perms = JSON.parse(atob(permsB64));
    document.querySelectorAll('#emPerms input[type=checkbox]').forEach(cb => {
      cb.checked = perms.includes(cb.value);
    });
    document.getElementById('editMemberModal').classList.add('show');
  };
  document.getElementById('saveEditMemberBtn').addEventListener('click', async () => {
    const id = document.getElementById('emId').value;
    const perms = [...document.querySelectorAll('#emPerms input:checked')].map(i=>i.value);
    const alias = document.getElementById('emAlias').value.trim();
    try {
      const r = await fetch('/api/admin/members/'+id, { method:'PUT', headers:H, body: JSON.stringify({ permissions: perms, alias }) });
      if (r.ok) { toast('Permissions updated!'); document.getElementById('editMemberModal').classList.remove('show'); loadMembers(); }
      else { toast('Failed','error'); }
    } catch(e) { toast('Network error','error'); }
  });

  // ─── Connect Sheet ───
  let connectTarget = {};
  window.connectSheet = function(id, phone, name) {
    connectTarget = { id, phone, name };
    document.getElementById('sheetModalInfo').innerHTML = 'Connecting sheet for <strong>' + esc(name) + '</strong>';
    document.getElementById('sSheet').value = '';
    document.getElementById('sSyncStatus').style.display = 'none';
    document.getElementById('sheetModal').classList.add('show');
  };
  document.getElementById('saveSheetBtn').addEventListener('click', async () => {
    const sheet_url = document.getElementById('sSheet').value.trim();
    if (!sheet_url || !sheet_url.includes('docs.google.com/spreadsheets')) { toast('Valid Google Sheet URL required','error'); return; }
    const btn = document.getElementById('saveSheetBtn');
    const status = document.getElementById('sSyncStatus');
    btn.disabled = true; btn.textContent = 'Connecting...';
    status.style.display = 'block'; status.textContent = '⏳ Syncing sheet data...';
    try {
      const r = await fetch(adminUrl('/api/admin/clients/' + connectTarget.id + '/provision'), { method:'POST', headers:H, body: JSON.stringify({ sheet_url }) });
      const data = await r.json();
      if (data.ok) {
        status.textContent = '✅ Synced ' + (data.rows || 0) + ' rows across ' + (data.tabs || 0) + ' tabs!';
        toast('Sheet connected & synced!');
        loadClients();
        setTimeout(() => { document.getElementById('sheetModal').classList.remove('show'); status.style.display='none'; }, 2000);
      } else {
        status.textContent = '⚠️ ' + (data.error || 'Sync failed');
      }
    } catch(e) { status.textContent = '❌ Error: ' + e.message; toast('Network error','error'); }
    finally { btn.disabled=false; btn.textContent='Connect & Sync'; }
  });

  function esc(s) { const d=document.createElement('div'); d.textContent=s; return d.innerHTML; }

  // ─── Init ───
  loadStats();
  // AI Prompts
  const promptSelect = document.getElementById('promptTenantSelect');
  const promptFields = document.getElementById('promptFields');
  const PROMPT_KEYS = ['response_style', 'data_format', 'bot_personality', 'company_context'];

  function populatePromptSelect() {
    fetch(adminUrl('/api/admin/clients'), {headers: H}).then(r=>r.json()).then(clients => {
      promptSelect.innerHTML = '<option value="">-- Select Client --</option>';
      (clients || []).forEach(c => {
        promptSelect.innerHTML += `<option value="${c.id}">${c.name} (${c.phone})</option>`;
      });
    });
  }
  promptSelect.addEventListener('change', function() {
    if (!this.value) { promptFields.style.display = 'none'; return; }
    fetch(adminUrl('/api/admin/prompts?tenant_id=' + this.value), {headers: H})
      .then(r=>r.json()).then(data => {
        PROMPT_KEYS.forEach(k => { document.getElementById('prompt_' + k).value = data[k] || ''; });
        promptFields.style.display = 'block';
      });
  });
  document.getElementById('savePromptsBtn').addEventListener('click', function() {
    const tid = promptSelect.value;
    if (!tid) { toast('Select a client first', 'error'); return; }
    const btn = this;
    btn.disabled = true;
    btn.textContent = '⏳ Saving...';
    const body = { tenant_id: tid };
    PROMPT_KEYS.forEach(k => { body[k] = document.getElementById('prompt_' + k).value; });
    fetch(adminUrl('/api/admin/prompts'), { method: 'POST', headers: H, body: JSON.stringify(body) })
      .then(r=>r.json()).then(d => {
        btn.disabled = false;
        if(d.ok) { btn.textContent = '✅ Saved!'; btn.style.background='#27ae60'; setTimeout(()=>{btn.textContent='💾 Save Prompts';btn.style.background='';},2000); toast('Prompts saved!'); }
        else { btn.textContent = '❌ Failed'; setTimeout(()=>{btn.textContent='💾 Save Prompts';},2000); toast(d.error||'Error', 'error'); }
      }).catch(e => { btn.disabled=false; btn.textContent='💾 Save Prompts'; toast('Error: '+e.message, 'error'); });
  });
  document.getElementById('resetPromptsBtn').addEventListener('click', async function() {
    const tid = promptSelect.value;
    if (!tid) { toast('Select a client first', 'error'); return; }
    const ok = await window.MIS.confirm({
      title: 'Reset all prompts to default?',
      text: 'Any custom AI prompt settings for this client will be cleared.',
      icon: 'warning',
      confirmText: 'Yes, reset',
      danger: true,
    });
    if (!ok) return;
    const btn = this;
    btn.disabled = true;
    const body = { tenant_id: tid };
    PROMPT_KEYS.forEach(k => { body[k] = ''; });
    fetch(adminUrl('/api/admin/prompts'), { method: 'POST', headers: H, body: JSON.stringify(body) })
      .then(r=>r.json()).then(d => {
        btn.disabled = false;
        if(d.ok) { PROMPT_KEYS.forEach(k => { document.getElementById('prompt_' + k).value = ''; }); toast('All prompts reset to default!'); }
        else toast(d.error||'Error', 'error');
      }).catch(e => { btn.disabled=false; toast('Error: '+e.message, 'error'); });
  });
  populatePromptSelect();

  loadClients();
  loadMembers();
})();
</script>
@endpush
