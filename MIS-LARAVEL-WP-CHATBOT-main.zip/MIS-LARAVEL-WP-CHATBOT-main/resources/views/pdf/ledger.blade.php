<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{{ $entityName }} — Ledger</title>
    {{--
        Ledger PDF Blade template.
        Rendered by App\Services\Chat\LedgerPdfBuilder via barryvdh/laravel-dompdf
        in A4 landscape. Visual style cloned from Node helpers/tenant-ledger-pdf.js
        for parity:
          - Dark navy header (#1a1a2e) with tenant name + entity + date range
          - 7-column transaction table: Date | Type (To/By) | Particulars | Vch Type | Vch No | Debit | Credit
          - Opening balance row (#f0f4ff)
          - Zebra-striped txns (#fff/#f9f9f9)
          - Closing balance row (#e8eaf6 bold)
          - Grand total row (#c8c8c8)
    --}}
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            padding: 0;
            font-family: 'Helvetica', sans-serif;
            font-size: 9px;
            color: #000;
        }
        .page-header {
            background: #1a1a2e;
            color: #fff;
            padding: 12px 16px;
            text-align: center;
        }
        .page-header .db-name {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 2px;
        }
        .page-header .source-tab {
            font-size: 9px;
            font-weight: normal;
            opacity: 0.85;
            margin-bottom: 5px;
        }
        .page-header .ledger-line {
            font-size: 11px;
            font-weight: bold;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 0;
            table-layout: fixed;
        }
        thead th {
            background: #333355;
            color: #fff;
            font-size: 8.5px;
            font-weight: bold;
            padding: 5px 4px;
            text-align: left;
            border: 1px solid #2a2a40;
        }
        thead th.right { text-align: right; }
        thead th.center { text-align: center; }
        tbody td {
            padding: 4px;
            font-size: 8px;
            border: 1px solid #ddd;
            vertical-align: top;
            word-wrap: break-word;
            overflow: hidden;
        }
        tbody td.right { text-align: right; }
        tbody td.center { text-align: center; }
        tr.zebra-odd  td { background: #ffffff; }
        tr.zebra-even td { background: #f9f9f9; }
        tr.opening td { background: #f0f4ff; font-weight: bold; }
        tr.closing td { background: #e8eaf6; font-weight: bold; font-size: 8.5px; }
        tr.grand-total td { background: #c8c8c8; font-weight: bold; font-size: 8.5px; }

        /* Column widths — sum should = 100% */
        col.c-date       { width: 11%; }
        col.c-type       { width: 4%; }
        col.c-particular { width: 33%; }
        col.c-vch-type   { width: 12%; }
        col.c-vch-no     { width: 13%; }
        col.c-debit      { width: 13.5%; }
        col.c-credit     { width: 13.5%; }
    </style>
</head>
<body>
    <div class="page-header">
        <div class="db-name">{{ $dbName }}</div>
        <div class="source-tab">Auto-generated ledger from "{{ $tabName }}"</div>
        <div class="ledger-line">
            Ledger: {{ $entityName }}@if ($firstDate && $lastDate)
                &nbsp;&nbsp;|&nbsp;&nbsp;{{ $firstDate }} to {{ $lastDate }}
            @endif
        </div>
    </div>

    <table>
        <colgroup>
            <col class="c-date">
            <col class="c-type">
            <col class="c-particular">
            <col class="c-vch-type">
            <col class="c-vch-no">
            <col class="c-debit">
            <col class="c-credit">
        </colgroup>
        <thead>
            <tr>
                <th>Date</th>
                <th class="center"></th>
                <th>Particulars</th>
                <th>Vch Type</th>
                <th>Vch No.</th>
                <th class="right">Debit (Rs.)</th>
                <th class="right">Credit (Rs.)</th>
            </tr>
        </thead>
        <tbody>
            {{-- Opening balance row --}}
            <tr class="opening">
                <td>{{ $firstDate }}</td>
                <td class="center">To</td>
                <td>Opening Balance</td>
                <td></td>
                <td></td>
                <td class="right">{{ $openBal > 0 ? $fmtAmt($openBal) : '' }}</td>
                <td class="right">{{ $openBal < 0 ? $fmtAmt(abs($openBal)) : '' }}</td>
            </tr>

            {{-- Transaction rows --}}
            @foreach ($txns as $i => $r)
                @php
                    $debitVal  = isset($mapping['debitCol'])  ? (float) ($r[$mapping['debitCol']]  ?? 0) : 0;
                    $creditVal = isset($mapping['creditCol']) ? (float) ($r[$mapping['creditCol']] ?? 0) : 0;
                    $isDr = $debitVal > 0;
                    $particular = $mapping['particularCol'] ? mb_substr((string) ($r[$mapping['particularCol']] ?? ''), 0, 60) : '';
                    $vchType    = $mapping['vchTypeCol']    ? mb_substr((string) ($r[$mapping['vchTypeCol']]    ?? ''), 0, 22) : '';
                    $vchNo      = $mapping['vchNoCol']      ? mb_substr((string) ($r[$mapping['vchNoCol']]      ?? ''), 0, 22) : '';
                    $rowDate    = $mapping['dateCol'] ? $fmtDate($r[$mapping['dateCol']] ?? '') : '';
                @endphp
                <tr class="{{ $i % 2 === 0 ? 'zebra-odd' : 'zebra-even' }}">
                    <td>{{ $rowDate }}</td>
                    <td class="center">{{ $isDr ? 'To' : 'By' }}</td>
                    <td>{{ $particular }}</td>
                    <td>{{ $vchType }}</td>
                    <td>{{ $vchNo }}</td>
                    <td class="right">{{ $isDr ? $fmtAmt($debitVal) : '' }}</td>
                    <td class="right">{{ ! $isDr && $creditVal > 0 ? $fmtAmt($creditVal) : '' }}</td>
                </tr>
            @endforeach

            {{-- Closing balance row.
                 In standard Tally double-entry format the closing balance is a BALANCING
                 entry, shown on the OPPOSITE side from where the actual balance sits:
                   - Dr ledger balance (closeBal > 0): shown in the Cr column as "By Closing Balance"
                   - Cr ledger balance (closeBal < 0): shown in the Dr column as "To Closing Balance"
                 This makes the grand totals (Dr = Cr) balance, which is the whole point of
                 double-entry. The label can stay generic since the side itself indicates direction.
            --}}
            <tr class="closing">
                <td colspan="5">Closing Balance</td>
                <td class="right">{{ $closeBal < 0 ? $fmtAmt(abs($closeBal)) : '' }}</td>
                <td class="right">{{ $closeBal > 0 ? $fmtAmt($closeBal) : '' }}</td>
            </tr>

            {{-- Grand total row --}}
            <tr class="grand-total">
                <td colspan="5">Grand Total</td>
                <td class="right">{{ $fmtAmt($grandDr) }}</td>
                <td class="right">{{ $fmtAmt($grandCr) }}</td>
            </tr>
        </tbody>
    </table>
</body>
</html>
