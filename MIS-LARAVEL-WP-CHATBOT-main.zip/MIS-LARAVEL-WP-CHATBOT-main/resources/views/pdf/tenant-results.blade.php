<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>{{ $dbName }} — {{ $title }}</title>
    {{--
        Generic tenant-results PDF Blade template.
        Rendered by App\Services\Chat\TenantPdfBuilder via barryvdh/laravel-dompdf
        in A4 landscape. Visual style cloned from Node helpers/tenant-pdf.js for parity:
          - Dark navy header (#1a1a2e) with db name + title + optional query line
          - Dark slate column headers (#333355)
          - Zebra-striped data rows (#fff / #f5f5fa)
          - Footer with total row count + aggregate sums across numeric columns

        $cells / $headers / $footerLines are pre-formatted in PHP — the template just renders.
    --}}
    <style>
        * { box-sizing: border-box; }
        body {
            margin: 0;
            padding: 0;
            font-family: 'Helvetica', sans-serif;
            font-size: {{ $fontSize ?? 7 }}px;
            color: #000;
        }
        .page-header {
            background: #1a1a2e;
            color: #fff;
            padding: 8px 16px 10px;
            text-align: center;
        }
        .page-header .title {
            font-size: 11px;
            font-weight: bold;
        }
        .page-header .query {
            font-size: 8px;
            color: #aab;
            font-style: italic;
            margin-top: 4px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 0;
            table-layout: fixed;
        }
        thead th {
            background: #333355;
            color: #fff;
            font-size: {{ $fontSize ?? 7 }}px;
            font-weight: bold;
            padding: 4px 4px;
            text-align: left;
            border: 1px solid #2a2a40;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        thead th.right { text-align: right; }
        tbody td {
            padding: 3px 4px;
            font-size: {{ $fontSize ?? 7 }}px;
            border: 1px solid #ddd;
            vertical-align: top;
            word-wrap: break-word;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }
        tbody td.right { text-align: right; }
        tr.zebra-odd  td { background: #ffffff; }
        tr.zebra-even td { background: #f5f5fa; }
        .footer {
            margin-top: 8px;
            padding: 6px 12px;
            font-size: 8px;
            color: #444;
        }
        .footer .totals {
            color: #666;
            font-size: 7px;
            margin-left: 12px;
        }
    </style>
</head>
<body>
    <div class="page-header">
        <div class="title">{{ $dbName }} — {{ $title }}</div>
        @if ($query)
            <div class="query">Query: {{ $query }}</div>
        @endif
    </div>

    <table>
        <thead>
            <tr>
                @foreach ($headers as $i => $h)
                    <th class="{{ in_array($columnRoles[$i] ?? 'text', ['currency','quantity','count','number','rate','percent'], true) ? 'right' : '' }}">{{ $h }}</th>
                @endforeach
            </tr>
        </thead>
        <tbody>
            @foreach ($cells as $i => $row)
                <tr class="{{ $i % 2 === 0 ? 'zebra-odd' : 'zebra-even' }}">
                    @foreach ($row as $j => $value)
                        <td class="{{ in_array($columnRoles[$j] ?? 'text', ['currency','quantity','count','number','rate','percent'], true) ? 'right' : '' }}">{{ $value }}</td>
                    @endforeach
                </tr>
            @endforeach
        </tbody>
    </table>

    <div class="footer">
        <strong>Total Rows: {{ $rowCount }}</strong>
        @if (! empty($footerLines))
            <span class="totals">{{ implode('  |  ', $footerLines) }}</span>
        @endif
    </div>
</body>
</html>
