@extends('layouts.app')

@section('title', 'Calendar')

@section('content')
    <div class="page">
      <div class="page-header page-header-hero">
        <div class="page-header-bg">
          <div class="aurora aurora-1"></div>
          <div class="aurora aurora-2"></div>
          <div class="aurora aurora-3"></div>
          <div class="grid-overlay"></div>
        </div>
        <div class="page-header-content">
          <div class="page-icon-glow"><i data-lucide="calendar"></i></div>
          <div class="page-header-text">
            <div class="page-title-row">
              <h1 class="t-h1 page-title-gradient">Calendar</h1>
              <span class="live-pill"><span class="live-dot"></span>Synced</span>
            </div>
            <p class="page-desc">Your Google Calendar events. Click any day to book a new meeting.</p>
            <div class="page-chips">
              <span class="page-chip"><i data-lucide="zap" style="width:12px;height:12px;"></i> Live Google sync</span>
              <span class="page-chip"><i data-lucide="mouse-pointer-click" style="width:12px;height:12px;"></i> Click-to-book</span>
              <span class="page-chip"><i data-lucide="repeat" style="width:12px;height:12px;"></i> Reschedule + cancel</span>
            </div>
            <div class="page-underline"></div>
          </div>
        </div>
      </div>

      <div class="cal-toolbar">
        <div class="cal-nav">
          <button id="prevMonth" title="Previous month"><i data-lucide="chevron-left"></i></button>
          <div class="month-label" id="monthLabel">…</div>
          <button id="nextMonth" title="Next month"><i data-lucide="chevron-right"></i></button>
          <button id="todayBtn" class="btn-secondary" type="button">Today</button>
        </div>
        <button class="btn-primary" id="newBookBtn" type="button">
          <i data-lucide="plus"></i> New booking
        </button>
      </div>

      <div id="calContainer">
        <div class="empty-state"><div class="ic">📅</div>Loading…</div>
      </div>
    </div>
@endsection

@section('drawers')
<!-- ──── Booking modal ──── -->
<div class="modal-backdrop" id="bookModal">
  <div class="modal-card">
    <div class="modal-title" id="bookTitle">Book a meeting</div>
    <div id="bookConflict"></div>
    <form id="bookForm" autocomplete="off">
      <input type="hidden" id="bookEventId">
      <div class="modal-row">
        <label>Title*</label>
        <input id="bookT" type="text" maxlength="200" required>
      </div>
      <div class="modal-row">
        <label>Date*</label>
        <input id="bookD" type="date" required>
      </div>
      <div class="modal-row" style="display:grid; grid-template-columns:1fr 1fr; gap:10px;">
        <div>
          <label>Start time*</label>
          <input id="bookSt" type="time" required>
        </div>
        <div>
          <label>End time</label>
          <input id="bookEt" type="time">
        </div>
      </div>
      <div class="modal-row">
        <label>Guests (comma-separated emails)</label>
        <input id="bookG" type="text" placeholder="rahul@example.com, priya@example.com">
      </div>
      <div class="modal-row">
        <label>Description</label>
        <textarea id="bookDesc" maxlength="1000"></textarea>
      </div>
      <div class="modal-actions">
        <button type="button" class="btn-secondary" id="bookCancel">Cancel</button>
        <button type="submit" class="btn-primary" id="bookSave">Save</button>
      </div>
    </form>
  </div>
</div>

<!-- ──── Event detail modal ──── -->
<div class="modal-backdrop" id="detailModal">
  <div class="modal-card">
    <div class="modal-title" id="detTitle">Event details</div>
    <div id="detBody"></div>
    <div class="modal-actions">
      <button type="button" class="btn-secondary" id="detClose">Close</button>
      <button type="button" class="btn-secondary" id="detEdit">Reschedule</button>
      <button type="button" class="btn-danger" id="detCancel">Cancel meeting</button>
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>
@endsection

@push('scripts')
<script>
(function() {
  'use strict';


  const PHONE = window.MIS.auth.getPhone();

  // Toast — delegates to the shared pretty SweetAlert2 toast component
  function toast(msg, kind = 'ok') { window.MIS.toast(msg, kind); }

  // ─── State ───
  let currentMonth = new Date();
  currentMonth.setDate(1);
  let eventsCache = []; // current loaded events
  let activeEvent = null;

  function escapeHtml(s) {
    return String(s || '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  }
  function pad2(n) { return String(n).padStart(2, '0'); }
  function isoDate(d) { return d.getFullYear() + '-' + pad2(d.getMonth() + 1) + '-' + pad2(d.getDate()); }
  function fmtTime(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', hour12: true });
  }
  function fmtDateLong(iso) {
    if (!iso) return '';
    return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric', weekday: 'long' });
  }

  // ─── Render month grid ───
  function renderMonth() {
    const y = currentMonth.getFullYear();
    const m = currentMonth.getMonth();
    document.getElementById('monthLabel').textContent =
      currentMonth.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' });

    const firstDay = new Date(y, m, 1);
    const startWeekday = firstDay.getDay();
    const start = new Date(y, m, 1 - startWeekday);

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let html = '<div class="cal-grid">';
    ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].forEach(d => html += `<div class="cal-day-head">${d}</div>`);

    for (let i = 0; i < 42; i++) {
      const d = new Date(start);
      d.setDate(start.getDate() + i);
      const isOther = d.getMonth() !== m;
      const isToday = d.getTime() === today.getTime();
      const dayKey = isoDate(d);
      const dayEvents = eventsCache.filter(e => {
        const ed = new Date(e.start);
        return isoDate(ed) === dayKey;
      });

      html += `<div class="cal-cell ${isOther ? 'other-month' : ''} ${isToday ? 'today' : ''}" data-date="${dayKey}">`;
      html += `<div class="date">${d.getDate()}</div><div class="events">`;
      const visible = dayEvents.slice(0, 3);
      visible.forEach(ev => {
        html += `<div class="cal-event" data-event-id="${ev.id}">
          <span class="t-time">${fmtTime(ev.start)}</span>${escapeHtml(ev.title)}
        </div>`;
      });
      if (dayEvents.length > 3) html += `<div class="cal-event-more" data-date="${dayKey}">+${dayEvents.length - 3} more</div>`;
      html += `</div></div>`;
    }
    html += '</div>';
    document.getElementById('calContainer').innerHTML = html;

    // Wire up clicks
    document.querySelectorAll('.cal-cell').forEach(cell => {
      cell.addEventListener('click', (e) => {
        if (e.target.closest('.cal-event')) return; // event click handled separately
        openBookModal({ date: cell.dataset.date });
      });
    });
    document.querySelectorAll('.cal-event').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const evId = el.dataset.eventId;
        const ev = eventsCache.find(x => x.id === evId);
        if (ev) openDetailModal(ev);
      });
    });
  }

  // ─── Load events for current view ───
  async function loadEvents() {
    const y = currentMonth.getFullYear();
    const m = currentMonth.getMonth();
    const from = new Date(y, m - 1, 1);
    const to = new Date(y, m + 2, 0);
    try {
      const res = await fetch(`/api/tenant/calendar/events?phone=${encodeURIComponent(PHONE)}&from=${isoDate(from)}&to=${isoDate(to)}`);
      if (res.status === 412) {
        document.getElementById('calContainer').innerHTML = `
          <div class="empty-state">
            <div class="ic">🔌</div>
            <div style="margin-bottom:14px;">Google Calendar not connected.</div>
            <a class="btn-primary" href="/settings">Go to Settings to connect</a>
          </div>`;
        return;
      }
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || 'Load failed');
      }
      const data = await res.json();
      eventsCache = data.events || [];
      if (data.tenant?.name) {
        document.getElementById('tenant-name').textContent = data.tenant.name;
        document.getElementById('tenantAvatar').textContent = (data.tenant.name.charAt(0) || 'M').toUpperCase();
      }
      renderMonth();
    } catch (e) {
      console.error(e);
      toast('Could not load events. ' + e.message, 'err');
    }
  }

  // ─── Booking modal ───
  function openBookModal(opts) {
    document.getElementById('bookConflict').innerHTML = '';
    document.getElementById('bookEventId').value = opts?.eventId || '';
    document.getElementById('bookTitle').textContent = opts?.eventId ? 'Reschedule meeting' : 'Book a meeting';
    document.getElementById('bookT').value = opts?.title || '';
    document.getElementById('bookD').value = opts?.date || isoDate(new Date());
    document.getElementById('bookSt').value = opts?.start || '10:00';
    document.getElementById('bookEt').value = opts?.end || '11:00';
    document.getElementById('bookG').value = (opts?.guests || []).join(', ');
    document.getElementById('bookDesc').value = opts?.description || '';
    document.getElementById('bookModal').classList.add('open');
    setTimeout(() => document.getElementById('bookT').focus(), 60);
  }
  function closeBookModal() {
    document.getElementById('bookModal').classList.remove('open');
  }

  document.getElementById('bookCancel').addEventListener('click', closeBookModal);
  document.getElementById('newBookBtn').addEventListener('click', () => openBookModal({}));
  document.getElementById('bookModal').addEventListener('click', (e) => {
    if (e.target.id === 'bookModal') closeBookModal();
  });

  document.getElementById('bookForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const eventId = document.getElementById('bookEventId').value;
    const t = document.getElementById('bookT').value.trim();
    const date = document.getElementById('bookD').value;
    const st = document.getElementById('bookSt').value;
    const et = document.getElementById('bookEt').value;
    const guests = document.getElementById('bookG').value.split(',').map(g => g.trim()).filter(Boolean);
    const desc = document.getElementById('bookDesc').value.trim();
    const startISO = new Date(date + 'T' + st + ':00').toISOString();
    const endISO = et ? new Date(date + 'T' + et + ':00').toISOString() : null;

    const btn = document.getElementById('bookSave');
    btn.disabled = true; btn.textContent = 'Saving…';

    try {
      let res, data;
      if (eventId) {
        res = await fetch('/api/tenant/calendar/reschedule', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone: PHONE, event_id: eventId, new_start: startISO, new_end: endISO })
        });
        data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Reschedule failed');
        toast('Meeting rescheduled.', 'ok');
      } else {
        res = await fetch('/api/tenant/calendar/book', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone: PHONE, title: t, start: startISO, end: endISO, guests, description: desc })
        });
        data = await res.json();
        if (res.status === 409) {
          // Conflict — show conflicts and let user force
          const list = (data.conflicts || []).map(c => `<li><strong>${escapeHtml(c.title)}</strong> · ${fmtTime(c.start)}–${fmtTime(c.end)}</li>`).join('');
          document.getElementById('bookConflict').innerHTML =
            `<div class="conflict-list">⚠️ Time slot conflicts with existing event(s):<ul>${list}</ul>
              <button type="button" class="btn-danger" id="forceBookBtn" style="margin-top:8px;">Book anyway</button>
            </div>`;
          document.getElementById('forceBookBtn').addEventListener('click', async () => {
            const r2 = await fetch('/api/tenant/calendar/book', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ phone: PHONE, title: t, start: startISO, end: endISO, guests, description: desc, force: true })
            });
            if (!r2.ok) { toast('Booking failed', 'err'); return; }
            toast('Meeting booked.', 'ok');
            closeBookModal();
            loadEvents();
          });
          return;
        }
        if (!res.ok) throw new Error(data.error || 'Booking failed');
        toast('Meeting booked.', 'ok');
      }
      closeBookModal();
      loadEvents();
    } catch (err) {
      toast(err.message || 'Save failed', 'err');
    } finally {
      btn.disabled = false; btn.textContent = 'Save';
    }
  });

  // ─── Detail modal ───
  function openDetailModal(ev) {
    activeEvent = ev;
    document.getElementById('detTitle').textContent = ev.title;
    let html = '';
    html += `<div class="event-detail-row"><div class="lab">When</div><div>${fmtDateLong(ev.start)} · ${fmtTime(ev.start)}–${fmtTime(ev.end)}</div></div>`;
    if ((ev.attendees || []).length) {
      html += `<div class="event-detail-row"><div class="lab">Guests</div><div>${ev.attendees.map(escapeHtml).join(', ')}</div></div>`;
    }
    if (ev.location) {
      html += `<div class="event-detail-row"><div class="lab">Location</div><div>${escapeHtml(ev.location)}</div></div>`;
    }
    if (ev.meet_link) {
      html += `<div class="event-detail-row"><div class="lab">Video</div><div><a href="${ev.meet_link}" target="_blank" rel="noopener">${escapeHtml(ev.meet_link)}</a></div></div>`;
    }
    if (ev.description) {
      // Strip the auto-added meet link from description for display
      const cleanDesc = ev.description.replace(/🔗 Video Call:.*$/m, '').trim();
      if (cleanDesc) {
        html += `<div class="event-detail-row"><div class="lab">Notes</div><div style="white-space:pre-wrap;">${escapeHtml(cleanDesc)}</div></div>`;
      }
    }
    document.getElementById('detBody').innerHTML = html;
    document.getElementById('detailModal').classList.add('open');
  }
  function closeDetailModal() {
    document.getElementById('detailModal').classList.remove('open');
    activeEvent = null;
  }
  document.getElementById('detClose').addEventListener('click', closeDetailModal);
  document.getElementById('detailModal').addEventListener('click', (e) => {
    if (e.target.id === 'detailModal') closeDetailModal();
  });

  document.getElementById('detEdit').addEventListener('click', () => {
    if (!activeEvent) return;
    const startD = new Date(activeEvent.start);
    const endD = new Date(activeEvent.end);
    closeDetailModal();
    openBookModal({
      eventId: activeEvent.id,
      title: activeEvent.title,
      date: isoDate(startD),
      start: pad2(startD.getHours()) + ':' + pad2(startD.getMinutes()),
      end:   pad2(endD.getHours())   + ':' + pad2(endD.getMinutes()),
      guests: activeEvent.attendees,
      description: activeEvent.description
    });
  });

  document.getElementById('detCancel').addEventListener('click', async () => {
    if (!activeEvent) return;
    const ok = await window.MIS.confirm({
      title: `Cancel "${activeEvent.title}"?`,
      text: 'This sends a notification to attendees.',
      icon: 'warning',
      confirmText: 'Yes, cancel meeting',
      danger: true,
    });
    if (!ok) return;
    try {
      const res = await fetch('/api/tenant/calendar/cancel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: PHONE, event_id: activeEvent.id })
      });
      if (!res.ok) throw new Error('Cancel failed');
      toast('Meeting cancelled.', 'ok');
      closeDetailModal();
      loadEvents();
    } catch (e) {
      toast(e.message || 'Cancel failed', 'err');
    }
  });

  // ─── Nav ───
  document.getElementById('prevMonth').addEventListener('click', () => {
    currentMonth.setMonth(currentMonth.getMonth() - 1);
    loadEvents();
  });
  document.getElementById('nextMonth').addEventListener('click', () => {
    currentMonth.setMonth(currentMonth.getMonth() + 1);
    loadEvents();
  });
  document.getElementById('todayBtn').addEventListener('click', () => {
    currentMonth = new Date();
    currentMonth.setDate(1);
    loadEvents();
  });
  document.getElementById('refreshBtn').addEventListener('click', loadEvents);

  document.getElementById('themeRow').addEventListener('click', () => window.MIS.theme.toggle());
  document.getElementById('logoutLink').addEventListener('click', (e) => {
    e.preventDefault();
    window.MIS.confirmLogout();
  });

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { closeBookModal(); closeDetailModal(); }
  });

  document.addEventListener('DOMContentLoaded', () => {
    if (window.lucide) window.lucide.createIcons();
    const tName = window.MIS.auth.getTenantName() || 'Account';
    document.getElementById('tenant-name').textContent = tName;
    document.getElementById('tenantAvatar').textContent = (tName.charAt(0) || 'M').toUpperCase();
    loadEvents();
  });

})();
</script>
@endpush

