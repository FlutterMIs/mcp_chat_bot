@extends('layouts.app')

@section('title', 'Settings')

@section('content')

    <div class="page">
        <div class="page-header page-header-hero">
            <div class="page-header-bg">
                <div class="aurora aurora-1"></div>
                <div class="aurora aurora-2"></div>
                <div class="aurora aurora-3"></div>
                <div class="grid-overlay"></div>
            </div>
            <div class="page-header-content">
                <div class="page-icon-glow"><i data-lucide="settings"></i></div>
                <div class="page-header-text">
                    <div class="page-title-row">
                        <h1 class="t-h1 page-title-gradient">Settings</h1>
                        <span class="live-pill"><span class="live-dot"></span>Live</span>
                    </div>
                    <p class="page-desc">Manage your profile, databases, and integrations</p>
                    <div class="page-chips">
                        <span class="page-chip"><i data-lucide="user" style="width:12px;height:12px;"></i> Profile</span>
                        <span class="page-chip"><i data-lucide="database" style="width:12px;height:12px;"></i>
                            Databases</span>
                        <span class="page-chip"><i data-lucide="calendar-check" style="width:12px;height:12px;"></i>
                            Calendar</span>
                        <span class="page-chip"><i data-lucide="message-circle" style="width:12px;height:12px;"></i>
                            WhatsApp</span>
                    </div>
                    <div class="page-underline"></div>
                </div>
            </div>
        </div>

        <div class="settings-grid">

            <!-- ─── Profile ─── -->
            <div class="settings-card">
                <div class="settings-card-header">
                    <div class="ic"><i data-lucide="user"></i></div>
                    <div class="titles">
                        <div class="t">Profile</div>
                        <div class="sub">Your name, email, and contact</div>
                    </div>
                </div>
                <form id="profileForm" autocomplete="off">
                    <div class="form-row">
                        <label for="prof-name">Name</label>
                        <input id="prof-name" type="text" maxlength="100" placeholder="Your name" required>
                    </div>
                    <div class="form-row">
                        <label for="prof-email">Email</label>
                        <input id="prof-email" type="email" maxlength="254" placeholder="you@example.com">
                    </div>
                    <div class="form-row">
                        <label for="prof-phone">Phone</label>
                        <input id="prof-phone" type="tel" disabled>
                    </div>
                    <div class="form-actions">
                        <button type="submit" class="btn-primary" id="profSave">Save changes</button>
                        <span class="status-line" id="profStatus"></span>
                    </div>
                </form>
            </div>

            <!-- ─── Database ─── -->
            <div class="settings-card">
                <div class="settings-card-header">
                    <div class="ic"><i data-lucide="database"></i></div>
                    <div class="titles">
                        <div class="t">Databases</div>
                        <div class="sub">Connected Tally workbooks · click to switch active</div>
                    </div>
                </div>
                <div class="db-list" id="dbList">
                    <div class="empty-msg">Loading…</div>
                </div>
            </div>

            <!-- ─── Calendar ─── -->
            <div class="settings-card">
                <div class="settings-card-header">
                    <div class="ic"><i data-lucide="calendar"></i></div>
                    <div class="titles">
                        <div class="t">Google Calendar</div>
                        <div class="sub">Booking confirmation emails + reminders</div>
                    </div>
                </div>
                <div id="calendarBlock">
                    <div class="status-line" style="margin-bottom: 14px;">
                        Status: <span class="badge" id="calBadge">…</span>
                        <span id="calMeta" style="margin-left: 8px;"></span>
                    </div>
                    <div class="form-actions" id="calActions"></div>
                </div>
            </div>

            <!-- ─── Connect Sheet (shows when no database) ─── -->
            <div class="settings-card" id="connectSheetSection" style="display:none;">
                <div class="settings-card-header">
                    <div class="ic" style="background:rgba(16,185,129,.08);color:#10b981;"><i data-lucide="table"></i>
                    </div>
                    <div class="titles">
                        <div class="t">Connect Google Sheet</div>
                        <div class="sub">Paste your sheet URL to create your database</div>
                    </div>
                </div>
                <div style="margin-top:12px;">
                    <input id="sheetUrlInput" placeholder="https://docs.google.com/spreadsheets/d/..."
                        style="width:100%;padding:10px 14px;border:1px solid var(--hairline);border-radius:8px;font-size:14px;background:var(--surface-bg);color:var(--color-text-primary);margin-bottom:12px;">
                    <button class="btn-primary" id="connectSheetBtn" type="button">Detect Schema & Sync</button>
                    <div id="sheetSyncStatus" style="margin-top:10px;font-size:12px;color:var(--color-text-secondary);">
                    </div>
                </div>
            </div>

            <!-- ─── Sync ─── -->
            <div class="settings-card">
                <div class="settings-card-header">
                    <div class="ic"><i data-lucide="refresh-cw"></i></div>
                    <div class="titles">
                        <div class="t">Connected Sheets</div>
                        <div class="sub">Manage Google Sheets connected to your database</div>
                    </div>
                </div>
                <div class="status-line" style="margin-bottom: 12px;">
                    Last sync: <span id="lastSync">—</span>
                </div>

                <!-- Sheet list -->
                <div id="sheetList" style="margin-bottom:14px;"></div>

                <!-- Add sheet form -->
                <div style="border-top:1px solid var(--hairline);padding-top:14px;margin-bottom:14px;">
                    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                        <input id="newSheetUrl" placeholder="https://docs.google.com/spreadsheets/d/..."
                            style="flex:1;min-width:200px;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:12px;background:var(--surface-bg);color:var(--color-text-primary);">
                        <input id="newSheetLabel" placeholder="Label (optional)"
                            style="width:140px;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:12px;background:var(--surface-bg);color:var(--color-text-primary);">
                        <button class="btn-primary" id="addSheetBtn" type="button"
                            style="font-size:12px;white-space:nowrap;">+ Add
                            Sheet</button>
                    </div>
                </div>

                <div class="form-actions">
                    <button class="btn-primary" id="syncNow" type="button">Sync All Now</button>
                    <span class="status-line" id="syncStatus"></span>
                    <div id="syncProgress"
                        style="display:none;margin-top:10px;width:100%;background:#e9ecef;border-radius:8px;height:8px;overflow:hidden">
                        <div id="syncBar"
                            style="height:100%;width:0%;background:linear-gradient(90deg,#4361ee,#7c3aed);border-radius:8px;transition:width 0.3s ease">
                        </div>
                    </div>
                </div>
            </div>

            <!-- ─── AI Configuration ─── -->
            <div class="settings-card" id="aiSection">
                <div class="settings-card-header">
                    <div class="ic"><i data-lucide="brain"></i></div>
                    <div class="titles">
                        <div class="t">AI Configuration</div>
                        <div class="sub">Set your own ChatGPT or Gemini API key</div>
                    </div>
                </div>
                <div style="padding:12px 0;">
                    <div style="display:flex;flex-direction:column;gap:12px;">
                        <div>
                            <label
                                style="font-size:12px;color:var(--color-text-secondary);margin-bottom:4px;display:block;">AI
                                Vendor*</label>
                            <select id="aiVendor"
                                style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                                <option value="">Select AI</option>
                                <option value="openai">ChatGPT</option>
                                <option value="gemini">Gemini</option>
                            </select>
                        </div>
                        <div>
                            <label
                                style="font-size:12px;color:var(--color-text-secondary);margin-bottom:4px;display:block;">Model</label>
                            <select id="aiModel"
                                style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                                <option value="">Select Model</option>
                            </select>
                        </div>
                        <div>
                            <label
                                style="font-size:12px;color:var(--color-text-secondary);margin-bottom:4px;display:block;">API
                                Key*</label>
                            <input id="aiApiKey" type="password" placeholder="Enter your API key"
                                style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                        </div>
                        <div style="display:flex;gap:8px;">
                            <button class="btn-primary" id="saveAiConfig" type="button" style="font-size:13px;">💾
                                Save</button>
                            <button class="btn-outline" id="testAiKey" type="button" style="font-size:13px;">🧪 Test
                                Key</button>
                        </div>
                        <div id="aiStatus" style="font-size:12px;color:var(--color-text-secondary);"></div>

                        <!-- Currently-active (resolved) model + system-prompt viewer -->
                        <div style="margin-top:6px;padding-top:12px;border-top:1px dashed var(--hairline);">
                            <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;">
                                <span style="font-size:12px;color:var(--color-text-secondary);">Currently running:</span>
                                <span id="activeModelBadge" class="badge" style="font-size:12px;">Loading…</span>
                                <button class="btn-outline" id="viewPromptBtn" type="button"
                                    style="font-size:12px;margin-left:auto;">📄 View system prompt</button>
                            </div>
                            <div style="font-size:11px;color:var(--color-text-tertiary);margin-top:6px;"
                                id="activeModelNote"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System-prompt viewer modal -->
            <div id="promptModal"
                style="display:none;position:fixed;inset:0;z-index:1000;background:rgba(15,23,42,.55);align-items:center;justify-content:center;padding:20px;">
                <div
                    style="background:var(--surface-card);border-radius:14px;max-width:820px;width:100%;max-height:85vh;overflow:hidden;display:flex;flex-direction:column;box-shadow:0 20px 50px rgba(0,0,0,.3);">
                    <div
                        style="display:flex;align-items:center;justify-content:space-between;padding:16px 20px;border-bottom:1px solid var(--hairline);">
                        <div style="font-weight:600;font-size:15px;color:var(--color-text-primary);">AI System Prompt</div>
                        <button class="btn-icon" id="promptModalClose" type="button" aria-label="Close"><i
                                data-lucide="x"></i></button>
                    </div>
                    <div style="padding:16px 20px;overflow-y:auto;">
                        <div style="font-size:12px;color:var(--color-text-secondary);margin-bottom:6px;">Base system prompt
                            (what the bot follows for every query):</div>
                        <pre id="promptBase"
                            style="white-space:pre-wrap;word-break:break-word;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;line-height:1.5;background:var(--surface-bg);border:1px solid var(--hairline);border-radius:8px;padding:12px;color:var(--color-text-primary);margin:0 0 16px;"></pre>
                        <div id="promptAddWrap" style="display:none;">
                            <div style="font-size:12px;color:var(--color-text-secondary);margin-bottom:6px;">Additional
                                custom instructions (set in Admin Panel):</div>
                            <pre id="promptAdd"
                                style="white-space:pre-wrap;word-break:break-word;font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:12px;line-height:1.5;background:var(--surface-bg);border:1px solid var(--hairline);border-radius:8px;padding:12px;color:var(--color-text-primary);margin:0;"></pre>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ─── Chatbot Prompts (owner-editable overlays on the base prompt) ─── -->
            <div class="settings-card" id="promptsSection">
                <div class="settings-card-header">
                    <div class="ic"><i data-lucide="message-square-text"></i></div>
                    <div class="titles">
                        <div class="t">Chatbot Prompts</div>
                        <div class="sub">Fine-tune how your assistant replies — added on top of the base prompt</div>
                    </div>
                </div>
                <div style="padding:12px 0;display:flex;flex-direction:column;gap:14px;" id="promptsEditor">
                    <div>
                        <label
                            style="font-size:12px;color:var(--color-text-primary);font-weight:600;display:block;margin-bottom:2px;">Bot
                            personality &amp; greeting</label>
                        <div style="font-size:11px;color:var(--color-text-tertiary);margin-bottom:5px;">Tone + the greeting
                            shown on the web chat. e.g. "Namaste! Main aapka MIS assistant hoon 🙏"</div>
                        <textarea id="pmt_bot_personality" rows="2" placeholder="Default: Hello! I am your data assistant…"
                            style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);resize:vertical;"></textarea>
                    </div>
                    <div>
                        <label
                            style="font-size:12px;color:var(--color-text-primary);font-weight:600;display:block;margin-bottom:2px;">Data
                            reply format</label>
                        <div style="font-size:11px;color:var(--color-text-tertiary);margin-bottom:5px;">How data-query
                            results are formatted. e.g. "Show amounts as ₹X.XX L, party name first, add a Grand Total row."
                        </div>
                        <textarea id="pmt_data_format" rows="3" placeholder="Default: automatic table / list formatting"
                            style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);resize:vertical;"></textarea>
                    </div>
                    <div>
                        <label
                            style="font-size:12px;color:var(--color-text-primary);font-weight:600;display:block;margin-bottom:2px;">Response
                            style (documents &amp; website answers)</label>
                        <div style="font-size:11px;color:var(--color-text-tertiary);margin-bottom:5px;">Tone/length for
                            answers from PDFs, docs &amp; links. e.g. "Answer in 2–3 short lines, no preamble."</div>
                        <textarea id="pmt_response_style" rows="2" placeholder="Default: clear and concise"
                            style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);resize:vertical;"></textarea>
                    </div>
                    <div>
                        <label
                            style="font-size:12px;color:var(--color-text-primary);font-weight:600;display:block;margin-bottom:2px;">Company
                            context</label>
                        <div style="font-size:11px;color:var(--color-text-tertiary);margin-bottom:5px;">Background facts
                            the bot should know. e.g. "FY runs Apr–Mar. 'Party' = customer. Amounts in ₹."</div>
                        <textarea id="pmt_company_context" rows="3" placeholder="Default: none"
                            style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);resize:vertical;"></textarea>
                    </div>
                    <div style="display:flex;gap:8px;align-items:center;">
                        <button class="btn-primary" id="savePromptsBtn" type="button" style="font-size:13px;">💾 Save
                            prompts</button>
                        <span id="promptsSaveNote" style="font-size:11px;color:var(--color-text-tertiary);"></span>
                    </div>
                    <div
                        style="font-size:11px;color:var(--color-text-tertiary);border-top:1px dashed var(--hairline);padding-top:8px;">
                        Leave a field blank to use the built-in default. These are layered on top of the base system prompt
                        — they don't replace it.
                    </div>
                </div>
            </div>

            <!-- ─── WhatsApp API Configuration ─── -->
            <div class="settings-card" id="waSection">
                <div class="settings-card-header">
                    <div class="ic"><i data-lucide="message-circle"></i></div>
                    <div class="titles">
                        <div class="t">WhatsApp API</div>
                        <div class="sub">API key used for sending messages</div>
                    </div>
                </div>
                <div id="waKeyContent">
                    <!-- Populated by JS based on role + wa_key_mode -->
                </div>
            </div>

            <!-- ─── Team Members (Owner only) ─── -->
            <div class="settings-card" id="teamSection">
                <div class="settings-card-header">
                    <div class="ic"><i data-lucide="users"></i></div>
                    <div class="titles">
                        <div class="t">Team Members</div>
                        <div class="sub">Manage who can access your data</div>
                    </div>
                </div>
                <div id="teamList" style="margin-bottom:14px;"></div>
                <div style="border-top:1px solid var(--hairline);padding-top:14px;">
                    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                        <input id="newMemberPhone" placeholder="Phone (919876543210)"
                            style="flex:1;min-width:160px;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                        <button class="btn-primary" id="addMemberBtn" type="button" style="font-size:13px;">+ Add
                            Member</button>
                    </div>
                    <div style="margin-top:8px;">
                        <input id="newMemberSheet" placeholder="Google Sheet URL (optional — member's own sheet)"
                            style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:12px;background:var(--surface-bg);color:var(--color-text-primary);">
                    </div>
                    <div style="margin-top:10px;">
                        <label
                            style="font-size:11px;font-weight:600;color:var(--color-text-tertiary);display:block;margin-bottom:6px;">Permissions
                            for new member:</label>
                        <div style="display:flex;flex-wrap:wrap;gap:8px;" id="newMemberPerms">
                            <label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;"><input
                                    type="checkbox" value="dashboard" checked> Dashboard</label>
                            <label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;"><input
                                    type="checkbox" value="chat" checked> Chat</label>
                            <label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;"><input
                                    type="checkbox" value="sales"> Sales</label>
                            <label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;"><input
                                    type="checkbox" value="outstanding"> Outstanding</label>
                            <label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;"><input
                                    type="checkbox" value="stock"> Stock</label>
                            <label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;"><input
                                    type="checkbox" value="ledger"> Ledger</label>
                            <label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;"><input
                                    type="checkbox" value="calendar"> Calendar</label>
                            <label style="font-size:12px;display:flex;align-items:center;gap:4px;cursor:pointer;"><input
                                    type="checkbox" value="reports"> Reports</label>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ─── Links Library ─── -->
            <div class="settings-card" id="linksSection">
                <div class="settings-card-header">
                    <div class="ic"><i data-lucide="link"></i></div>
                    <div class="titles">
                        <div class="t">Links & Files Library</div>
                        <div class="sub">Add PDF/website links, or upload DOCX/XLSX/CSV/TXT/MD files. AI will answer
                            from these when users ask.</div>
                    </div>
                </div>

                <div id="linksList" style="margin:12px 0;"></div>

                <!-- Link Type Toggle -->
                <div
                    style="display:flex; gap:16px; margin-bottom:12px; border-bottom:1px solid var(--hairline); padding-bottom:8px;">
                    <label
                        style="font-size:13px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:6px; color:var(--color-text-primary);">
                        <input type="radio" name="linkTypeRadio" value="url" checked
                            onchange="toggleLinkInputType(this.value)"> 🌐 Add URL Link
                    </label>
                    <label
                        style="font-size:13px; font-weight:600; cursor:pointer; display:flex; align-items:center; gap:6px; color:var(--color-text-primary);">
                        <input type="radio" name="linkTypeRadio" value="file"
                            onchange="toggleLinkInputType(this.value)"> 📁 Upload File
                    </label>
                </div>

                <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:end;">
                    <div style="flex:1; min-width:150px; display:flex; flex-direction:column; gap:4px;">
                        <label style="font-size:11px; color:var(--color-text-secondary); font-weight:600;">Title*</label>
                        <input id="linkTitle" placeholder="e.g. Product Catalog"
                            style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                    </div>

                    <div id="linkUrlWrapper"
                        style="flex:2; min-width:200px; display:flex; flex-direction:column; gap:4px;">
                        <label style="font-size:11px; color:var(--color-text-secondary); font-weight:600;">URL*</label>
                        <input id="linkUrl" placeholder="https://..."
                            style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                    </div>

                    <div id="linkFileWrapper"
                        style="flex:2; min-width:200px; display:none; flex-direction:column; gap:4px;">
                        <label style="font-size:11px; color:var(--color-text-secondary); font-weight:600;">Choose File
                            (PDF, DOCX, XLSX, XLS, CSV, TXT, MD)*</label>
                        <input id="linkFile" type="file" accept=".pdf,.docx,.xlsx,.xls,.csv,.txt,.md"
                            style="width:100%;padding:6px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                    </div>

                    <div style="flex:1; min-width:150px; display:flex; flex-direction:column; gap:4px;">
                        <label style="font-size:11px; color:var(--color-text-secondary); font-weight:600;">Description
                            (optional)</label>
                        <input id="linkDesc" placeholder="e.g. Technical sheet v2"
                            style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                    </div>

                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <label style="font-size:11px; color:var(--color-text-secondary); font-weight:600;">Access
                            Level</label>
                        <select id="linkAccess"
                            style="padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary); height:37px;">
                            <option value="all">🌐 All</option>
                            <option value="team">👥 Team Only</option>
                            <option value="owner">🔒 Owner Only</option>
                        </select>
                    </div>

                    <button id="addLinkBtn"
                        style="padding:8px 16px;background:var(--accent-cyan);color:white;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer;white-space:nowrap; height:37px;">+
                        Save</button>
                </div>
                <div id="linkUploadProgress"
                    style="display:none; margin-top:10px; font-size:12px; color:var(--accent-cyan);">
                    <i data-lucide="loader-2" class="spin"
                        style="display:inline-block; width:12px; height:12px; vertical-align:middle; margin-right:4px;"></i>
                    Uploading and indexing file...
                </div>
            </div>

            <!-- ─── External API Keys (Owner/Admin only) ─── -->
            <div class="settings-card" id="apiKeysSection" style="display:none;">
                <div class="settings-card-header">
                    <div class="ic"><i data-lucide="key"></i></div>
                    <div class="titles">
                        <div class="t">External API Keys</div>
                        <div class="sub">Connect external APIs. Control who can access each one.</div>
                    </div>
                </div>
                <div id="apiKeysList" style="margin:12px 0;"></div>
                <div style="border-top:1px solid var(--hairline);padding-top:12px;margin-top:8px;">
                    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:end;">
                        <input id="akLabel" placeholder="Label (e.g. MIS Delegation)"
                            style="flex:1;min-width:140px;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                        <input id="akKey" placeholder="API Key"
                            style="flex:1;min-width:140px;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                        <input id="akUrl" placeholder="Base URL (e.g. https://apps.apimis.co.in/api)"
                            style="flex:2;min-width:200px;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                        <select id="akAccess"
                            style="padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
                            <option value="owner">🔒 Owner Only</option>
                            <option value="team">👥 Team Only</option>
                            <option value="everyone">🌐 Everyone</option>
                        </select>
                        <button onclick="addApiKey()"
                            style="padding:8px 16px;background:var(--accent-cyan);color:white;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer;">+
                            Add Key</button>
                    </div>
                </div>
            </div>

            <!-- ─── Sign out ─── -->
            <div class="settings-card">
                <div class="settings-card-header">
                    <div class="ic" style="background: rgba(239, 68, 68, 0.08); color: rgb(239, 68, 68);"><i
                            data-lucide="log-out"></i></div>
                    <div class="titles">
                        <div class="t">Sign out</div>
                        <div class="sub">Clear local session and return to login</div>
                    </div>
                </div>
                <div class="form-actions">
                    <button class="btn-danger" id="signOutBtn" type="button">Sign out of MIS</button>
                </div>
            </div>

        </div>
    </div>

@endsection

@section('drawers')

    <!-- Edit Team Member Modal -->
    <div id="teamEditModal"
        style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:1000;place-items:center;">
        <div style="background:var(--surface-card);border-radius:16px;padding:28px;width:90%;max-width:400px;">
            <h3 style="margin-bottom:16px;font-size:18px;">Edit Member</h3>
            <input type="hidden" id="tmEditId">
            <div style="margin-bottom:12px;"><label
                    style="font-size:12px;font-weight:600;display:block;margin-bottom:4px;">Alias</label><input
                    id="tmEditAlias"
                    style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);"
                    placeholder="Optional alias"></div>
            <div style="margin-bottom:16px;">
                <label style="font-size:12px;font-weight:600;display:block;margin-bottom:6px;">Permissions</label>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;" id="tmEditPerms">
                    <label style="font-size:12px;display:flex;align-items:center;gap:6px;cursor:pointer;"><input
                            type="checkbox" value="dashboard"> Dashboard</label>
                    <label style="font-size:12px;display:flex;align-items:center;gap:6px;cursor:pointer;"><input
                            type="checkbox" value="chat"> Chat</label>
                    <label style="font-size:12px;display:flex;align-items:center;gap:6px;cursor:pointer;"><input
                            type="checkbox" value="sales"> Sales</label>
                    <label style="font-size:12px;display:flex;align-items:center;gap:6px;cursor:pointer;"><input
                            type="checkbox" value="outstanding"> Outstanding</label>
                    <label style="font-size:12px;display:flex;align-items:center;gap:6px;cursor:pointer;"><input
                            type="checkbox" value="stock"> Stock</label>
                    <label style="font-size:12px;display:flex;align-items:center;gap:6px;cursor:pointer;"><input
                            type="checkbox" value="ledger"> Ledger</label>
                    <label style="font-size:12px;display:flex;align-items:center;gap:6px;cursor:pointer;"><input
                            type="checkbox" value="calendar"> Calendar</label>
                    <label style="font-size:12px;display:flex;align-items:center;gap:6px;cursor:pointer;"><input
                            type="checkbox" value="reports"> Reports</label>
                </div>
            </div>
            <div style="display:flex;gap:10px;justify-content:flex-end;">
                <button onclick="document.getElementById('teamEditModal').style.display='none'"
                    style="padding:8px 16px;border:1px solid var(--hairline);background:var(--surface-card);border-radius:8px;cursor:pointer;font-size:13px;">Cancel</button>
                <button id="tmEditSaveBtn"
                    style="padding:8px 18px;background:var(--accent-cyan);color:white;border:none;border-radius:8px;font-weight:600;font-size:13px;cursor:pointer;">Save</button>
            </div>
        </div>
    </div>

    <div class="toast" id="toast"></div>
@endsection

@push('scripts')
    <!-- ─── External API Keys Section (Owner/Admin only) ─── -->
    <script>
        (function() {
            'use strict';

            // ─── Auth gate ───

            const PHONE = window.MIS.auth.getPhone();

            // ─── Toast — delegates to the shared pretty SweetAlert2 toast component ───
            function toast(msg, kind = 'ok') {
                window.MIS.toast(msg, kind);
            }

            // ─── Topbar fill ───
            const tName = window.MIS.auth.getTenantName() || 'Account';
            document.getElementById('tenant-name').textContent = tName;
            document.getElementById('tenantAvatar').textContent = (tName.charAt(0) || 'M').toUpperCase();

            // ─── Load profile ───
            async function loadProfile() {
                try {
                    const res = await fetch(`/api/tenant/profile?phone=${encodeURIComponent(PHONE)}`);
                    if (!res.ok) throw new Error('Profile load failed');
                    const p = await res.json();
                    document.getElementById('prof-name').value = p.name || '';
                    document.getElementById('prof-email').value = p.email || '';
                    document.getElementById('prof-phone').value = p.phone || PHONE;

                    // WA API Key section
                    renderWaSection(p);

                    // Calendar status
                    const cb = document.getElementById('calBadge');
                    const cm = document.getElementById('calMeta');
                    const ca = document.getElementById('calActions');
                    if (p.calendar_connected) {
                        cb.textContent = 'Connected';
                        cb.className = 'badge ok';
                        cm.textContent = p.calendar_email ? '· ' + p.calendar_email : '';
                        ca.innerHTML =
                            '<button class="btn-secondary" id="calDisconnect" type="button">Disconnect</button>';
                        document.getElementById('calDisconnect').addEventListener('click', disconnectCalendar);
                    } else {
                        cb.textContent = 'Not connected';
                        cb.className = 'badge off';
                        cm.textContent = '';
                        ca.innerHTML = '<a class="btn-primary" id="calConnect">Connect Google Calendar</a>';
                        document.getElementById('calConnect').href =
                            `/api/tenant/calendar/auth?tenant_id=${p.tenant_id}`;
                        document.getElementById('calConnect').target = '_blank';
                    }

                    // Last sync
                    document.getElementById('lastSync').textContent = p.last_sync_at ?
                        formatRelative(new Date(p.last_sync_at)) :
                        'never';

                    // AI Configuration
                    if (p.ai_vendor) document.getElementById('aiVendor').value = p.ai_vendor;
                    updateModelDropdown();
                    if (p.ai_model) document.getElementById('aiModel').value = p.ai_model;
                    if (p.ai_api_key) document.getElementById('aiApiKey').value = p.ai_api_key;

                    // Currently-active (resolved) model + system prompt
                    loadAiStatus();
                    // Editable chatbot prompt overlays
                    loadPrompts();

                    // Databases
                    renderDbList(p.databases || [], p.active_db_id);
                } catch (e) {
                    console.error(e);
                    toast('Could not load profile.', 'err');
                }
            }
            window.loadProfile = loadProfile;

            // Listen for OAuth popup messages
            window.addEventListener('message', (e) => {
                if (e.data && e.data.type === 'CALENDAR_AUTH') {
                    toast(e.data.message, e.data.status === 'ok' ? 'ok' : 'err');
                    if (e.data.status === 'ok') {
                        loadProfile();
                    }
                }
            });

            function formatRelative(date) {
                const sec = Math.floor((Date.now() - date.getTime()) / 1000);
                if (sec < 60) return 'just now';
                if (sec < 3600) return Math.floor(sec / 60) + 'm ago';
                if (sec < 86400) return Math.floor(sec / 3600) + 'h ago';
                return date.toLocaleDateString('en-IN', {
                    day: 'numeric',
                    month: 'short',
                    year: 'numeric'
                });
            }

            function renderDbList(dbs, activeId) {
                const list = document.getElementById('dbList');
                if (!dbs.length) {
                    list.innerHTML =
                        '<div class="empty-msg">No databases connected. <a href="/register">Add one</a>.</div>';
                    return;
                }
                list.innerHTML = dbs.map(d => `
        <div class="db-row ${d.tenant_id === activeId ? 'active' : ''}" data-id="${d.tenant_id}">
          <div>
            <div class="name">${escapeHtml(d.name)}</div>
            <div class="meta">${escapeHtml(d.role || 'Owner')} · ${d.tenant_id.slice(0, 8)}</div>
          </div>
          <button class="btn-secondary db-switch" data-id="${d.tenant_id}" ${d.tenant_id === activeId ? 'disabled' : ''}>
            ${d.tenant_id === activeId ? 'Active' : 'Switch'}
          </button>
        </div>
      `).join('');
                list.querySelectorAll('.db-switch').forEach(btn => {
                    btn.addEventListener('click', () => switchDb(btn.dataset.id));
                });
            }

            async function switchDb(tenantId) {
                try {
                    const res = await fetch('/api/tenant/switch-db', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            tenant_id: tenantId
                        })
                    });
                    if (!res.ok) throw new Error('Switch failed');
                    toast('Active database switched.', 'ok');
                    loadProfile();
                } catch (e) {
                    toast('Could not switch database.', 'err');
                }
            }

            function escapeHtml(s) {
                return String(s || '').replace(/[&<>"']/g, c => ({
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#39;'
                } [c]));
            }

            // ─── Save profile ───
            document.getElementById('profileForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                const btn = document.getElementById('profSave');
                btn.disabled = true;
                btn.textContent = 'Saving…';
                try {
                    const res = await fetch('/api/tenant/update-profile', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            name: document.getElementById('prof-name').value.trim(),
                            email: document.getElementById('prof-email').value.trim()
                        })
                    });
                    const data = await res.json();
                    if (!res.ok) throw new Error(data.error || 'Save failed');
                    toast('Profile saved.', 'ok');
                    if (data.name) window.MIS.auth.setTenantName(data.name);
                } catch (e) {
                    toast(e.message || 'Could not save.', 'err');
                } finally {
                    btn.disabled = false;
                    btn.textContent = 'Save changes';
                }
            });

            // ─── Calendar disconnect ───
            async function disconnectCalendar() {
                const ok = await window.MIS.confirm({
                    title: 'Disconnect Google Calendar?',
                    text: "You'll need to re-authorize to book meetings via chat.",
                    icon: 'warning',
                    confirmText: 'Yes, disconnect',
                    danger: true,
                });
                if (!ok) return;
                try {
                    const res = await fetch('/api/tenant/calendar/disconnect', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE
                        })
                    });
                    if (!res.ok) throw new Error('Disconnect failed');
                    toast('Calendar disconnected.', 'ok');
                    loadProfile();
                } catch (e) {
                    toast('Could not disconnect.', 'err');
                }
            }

            // ─── Edit/Save Sheet URL ───
            // ─── Multi-Sheet Management ───
            async function loadSheets() {
                try {
                    const res = await fetch(`/api/tenant/sheets?phone=${PHONE}`);
                    const data = await res.json();
                    renderSheetList(data.sheets || []);
                } catch (e) {
                    console.error(e);
                }
            }

            function renderSheetList(sheets) {
                const el = document.getElementById('sheetList');
                if (!sheets.length) {
                    el.innerHTML =
                        '<div style="color:var(--color-text-tertiary);font-size:13px;padding:8px 0;">No sheets connected yet. Add one below.</div>';
                    return;
                }
                el.innerHTML = sheets.map(s => `
        <div style="display:flex;align-items:center;gap:10px;padding:10px 12px;border:1px solid var(--hairline);border-radius:8px;margin-bottom:8px;background:var(--surface-bg);">
          <div style="flex:1;min-width:0;">
            <div style="font-weight:600;font-size:13px;color:var(--color-text-primary);">📊 ${escapeHtml(s.label || 'Sheet')}</div>
            <div style="font-size:11px;color:var(--color-text-tertiary);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${escapeHtml(s.sheet_url)}</div>
            <div style="font-size:10px;color:var(--color-text-tertiary);margin-top:2px;">Synced: ${s.last_synced_at ? formatRelative(new Date(s.last_synced_at)) : 'never'} · ${s.status}</div>
          </div>
          <button class="btn-sm" style="font-size:11px;color:#e63946;border-color:#e63946;" onclick="removeSheet('${s.id}')">Remove</button>
        </div>
      `).join('');
            }

            document.getElementById('addSheetBtn').addEventListener('click', async () => {
                const url = document.getElementById('newSheetUrl').value.trim();
                const label = document.getElementById('newSheetLabel').value.trim();
                if (!url || !url.includes('docs.google.com/spreadsheets')) {
                    toast('Valid Google Sheet URL required', 'err');
                    return;
                }
                const btn = document.getElementById('addSheetBtn');
                btn.disabled = true;
                btn.textContent = 'Adding…';
                try {
                    const res = await fetch('/api/tenant/sheets/add', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            sheet_url: url,
                            label
                        })
                    });
                    const data = await res.json();
                    if (!res.ok) throw new Error(data.error || 'Failed');
                    toast(data.sync ? `Sheet added! ${data.sync.rows} rows synced.` : 'Sheet added!', 'ok');
                    document.getElementById('newSheetUrl').value = '';
                    document.getElementById('newSheetLabel').value = '';
                    loadSheets();
                } catch (e) {
                    toast(e.message, 'err');
                }
                btn.disabled = false;
                btn.textContent = '+ Add Sheet';
            });

            window.removeSheet = async function(id) {
                const ok = await window.MIS.confirmDelete('this sheet', {
                    text: 'Historical data will be preserved.'
                });
                if (!ok) return;
                try {
                    const res = await fetch(`/api/tenant/sheets/${id}?phone=${PHONE}`, {
                        method: 'DELETE'
                    });
                    const data = await res.json();
                    if (!res.ok) throw new Error(data.error || 'Failed');
                    toast('Sheet disconnected.', 'ok');
                    loadSheets();
                } catch (e) {
                    toast(e.message, 'err');
                }
            };

            // ─── Sync All Now ───
            document.getElementById('syncNow').addEventListener('click', async () => {
                const btn = document.getElementById('syncNow');
                const status = document.getElementById('syncStatus');
                const progress = document.getElementById('syncProgress');
                const bar = document.getElementById('syncBar');
                btn.disabled = true;
                btn.textContent = 'Syncing…';
                status.textContent = '';
                progress.style.display = 'block';
                bar.style.width = '0%';

                let pct = 0;
                const interval = setInterval(() => {
                    pct += Math.random() * 12;
                    if (pct > 90) pct = 90;
                    bar.style.width = pct + '%';
                }, 400);

                try {
                    const res = await fetch('/api/tenant/sync-now', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE
                        })
                    });
                    const data = await res.json();
                    clearInterval(interval);
                    if (!res.ok) throw new Error(data.error || 'Sync failed');
                    bar.style.width = '100%';
                    toast('Sync complete.', 'ok');
                    status.textContent = data.message || 'Done.';
                    loadProfile();
                    loadSheets();
                    setTimeout(() => {
                        progress.style.display = 'none';
                    }, 1500);
                } catch (e) {
                    clearInterval(interval);
                    bar.style.width = '100%';
                    bar.style.background = '#e63946';
                    toast(e.message || 'Sync failed.', 'err');
                    status.textContent = '';
                    setTimeout(() => {
                        progress.style.display = 'none';
                        bar.style.background = 'linear-gradient(90deg,#4361ee,#7c3aed)';
                    }, 2000);
                } finally {
                    btn.disabled = false;
                    btn.textContent = 'Sync All Now';
                }
            });

            // Load sheets on init
            loadSheets();

            // ─── Sign out ───
            document.getElementById('signOutBtn').addEventListener('click', () => window.MIS.confirmLogout());
            document.getElementById('logoutLink').addEventListener('click', (e) => {
                e.preventDefault();
                window.MIS.confirmLogout();
            });

            // ─── Theme + sidebar ───
            document.getElementById('themeRow').addEventListener('click', () => window.MIS.theme.toggle());
            document.getElementById('sidebarToggle').addEventListener('click', () => {
                document.getElementById('sidebar').classList.toggle('open');
            });
            document.getElementById('refreshBtn').addEventListener('click', loadProfile);

            // ─── Active model + system prompt viewer ───
            let AI_STATUS = null;

            async function loadAiStatus() {
                const badge = document.getElementById('activeModelBadge');
                const note = document.getElementById('activeModelNote');
                if (!badge) return;
                try {
                    const res = await fetch(`/api/tenant/ai-status?phone=${encodeURIComponent(PHONE)}`);
                    if (!res.ok) throw new Error('load failed');
                    AI_STATUS = await res.json();
                    const m = AI_STATUS.model || {};
                    if (!m.ok) {
                        badge.textContent = 'Not configured';
                        badge.className = 'badge off';
                        note.textContent = m.error || 'Add an AI key above to activate the chatbot.';
                        return;
                    }
                    const vendorLabel = m.vendor === 'gemini' ? 'Gemini' : 'ChatGPT';
                    badge.textContent = `${vendorLabel} · ${m.model}`;
                    badge.className = 'badge ok';
                    const srcLabel = {
                        own_key: 'using your own API key',
                        shared: 'using the shared MIS key',
                        none: ''
                    } [m.source] || '';
                    note.textContent = srcLabel;
                } catch (e) {
                    badge.textContent = 'Unknown';
                    badge.className = 'badge off';
                    note.textContent = 'Could not load active model.';
                }
            }

            (function wirePromptViewer() {
                const modal = document.getElementById('promptModal');
                const openBtn = document.getElementById('viewPromptBtn');
                const closeBtn = document.getElementById('promptModalClose');
                if (!modal || !openBtn) return;

                const close = () => {
                    modal.style.display = 'none';
                };
                openBtn.addEventListener('click', () => {
                    if (!AI_STATUS) {
                        toast('AI status still loading…', 'warn');
                        return;
                    }
                    document.getElementById('promptBase').textContent =
                        AI_STATUS.system_prompt || '(no system prompt available)';
                    const add = AI_STATUS.additional_prompts || {};
                    const parts = [];
                    const labels = {
                        response_style: 'Response style',
                        data_format: 'Data format',
                        bot_personality: 'Bot personality',
                        company_context: 'Company context'
                    };
                    Object.keys(labels).forEach(k => {
                        if (add[k] && String(add[k]).trim() !== '') {
                            parts.push(`# ${labels[k]}\n${add[k]}`);
                        }
                    });
                    const wrap = document.getElementById('promptAddWrap');
                    if (parts.length) {
                        document.getElementById('promptAdd').textContent = parts.join('\n\n');
                        wrap.style.display = 'block';
                    } else {
                        wrap.style.display = 'none';
                    }
                    modal.style.display = 'flex';
                    if (window.lucide) lucide.createIcons();
                });
                closeBtn?.addEventListener('click', close);
                modal.addEventListener('click', (e) => {
                    if (e.target === modal) close();
                });
                document.addEventListener('keydown', (e) => {
                    if (e.key === 'Escape') close();
                });
            })();

            // ─── Editable chatbot prompt overlays ───
            const PROMPT_FIELDS = ['bot_personality', 'data_format', 'response_style', 'company_context'];

            async function loadPrompts() {
                if (!document.getElementById('savePromptsBtn')) return;
                try {
                    const res = await fetch(`/api/tenant/prompts?phone=${encodeURIComponent(PHONE)}`);
                    if (!res.ok) return; // e.g. no tenant for this phone — leave blank
                    const data = await res.json();
                    const p = data.prompts || {};
                    PROMPT_FIELDS.forEach(k => {
                        const el = document.getElementById('pmt_' + k);
                        if (el) el.value = p[k] || '';
                    });
                } catch (e) {
                    /* non-fatal */ }
            }

            (function wirePromptsSave() {
                const btn = document.getElementById('savePromptsBtn');
                if (!btn) return;
                btn.addEventListener('click', async () => {
                    btn.disabled = true;
                    const note = document.getElementById('promptsSaveNote');
                    if (note) note.textContent = 'Saving…';
                    const body = {
                        phone: PHONE
                    };
                    PROMPT_FIELDS.forEach(k => {
                        const el = document.getElementById('pmt_' + k);
                        body[k] = el ? el.value.trim() : '';
                    });
                    try {
                        const res = await fetch('/api/tenant/prompts', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json'
                            },
                            body: JSON.stringify(body)
                        });
                        const data = await res.json();
                        if (!res.ok) throw new Error(data.error || 'Save failed');
                        toast('Chatbot prompts saved.', 'ok');
                        if (note) note.textContent = 'Saved just now.';
                        // Refresh the read-only "additional instructions" view in the modal
                        loadAiStatus();
                    } catch (e) {
                        toast(e.message, 'err');
                        if (note) note.textContent = '';
                    }
                    btn.disabled = false;
                });
            })();

            // ─── AI Configuration ───
            const AI_MODELS = {
                openai: ['gpt-4o-mini', 'gpt-4o', 'gpt-4-turbo', 'gpt-3.5-turbo'],
                gemini: ['gemini-1.5-flash', 'gemini-1.5-pro', 'gemini-2.0-flash']
            };

            function updateModelDropdown() {
                const vendor = document.getElementById('aiVendor').value;
                const sel = document.getElementById('aiModel');
                const current = sel.value;
                sel.innerHTML = '<option value="">Select Model</option>';
                (AI_MODELS[vendor] || []).forEach(m => {
                    sel.innerHTML += `<option value="${m}" ${m === current ? 'selected' : ''}>${m}</option>`;
                });
            }

            document.getElementById('aiVendor').addEventListener('change', updateModelDropdown);

            document.getElementById('saveAiConfig').addEventListener('click', async () => {
                const vendor = document.getElementById('aiVendor').value;
                const model = document.getElementById('aiModel').value;
                const key = document.getElementById('aiApiKey').value;
                const status = document.getElementById('aiStatus');

                if (!vendor && !key) {
                    // Clear AI config
                    const res = await fetch('/api/tenant/profile', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            ai_api_key: ''
                        })
                    });
                    status.textContent = res.ok ? '✅ AI config cleared' : '❌ Failed';
                    return;
                }
                if (!vendor || !key || key.startsWith('…')) {
                    status.textContent = '⚠️ Please select vendor and enter API key';
                    return;
                }

                const res = await fetch('/api/tenant/profile', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        phone: PHONE,
                        ai_vendor: vendor,
                        ai_model: model || null,
                        ai_api_key: key
                    })
                });
                status.textContent = res.ok ? '✅ AI config saved!' : '❌ Failed to save';
                if (res.ok) document.getElementById('aiApiKey').value = '…' + key.slice(-6);
            });

            document.getElementById('testAiKey').addEventListener('click', async () => {
                const status = document.getElementById('aiStatus');
                status.textContent = '🧪 Testing...';
                try {
                    const res = await fetch('/api/chat', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-Chat-Token': localStorage.getItem('mis_chat_token') || ''
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            message: 'hi'
                        })
                    });
                    const d = await res.json();
                    status.textContent = (d.reply && !d.auth_error) ? '✅ Key works! AI responded.' : '❌ ' +
                        (d.auth_error || d.reply || 'Failed');
                } catch (e) {
                    status.textContent = '❌ Test failed: ' + e.message;
                }
            });

            // ─── WA API Key Section ───
            function renderWaSection(p) {
                const el = document.getElementById('waKeyContent');
                const role = localStorage.getItem('mis_user_role') || 'owner';
                const isOwner = role === 'owner' || role === 'super_admin';
                const channelMode = p.wa_channel_mode || 'unprofessional';

                if (!isOwner) {
                    el.innerHTML = `
          <div class="status-line">
            Status: <strong>${channelMode === 'professional' ? 'Professional (Cloud API)' : 'Gateway (Unofficial)'}</strong>
          </div>
          ${p.wa_connected_number ? `<div class="status-line" style="margin-top:6px;">Connected Number: <strong>+${p.wa_connected_number}</strong></div>` : ''}
          <div class="status-line" style="margin-top:8px;font-size:12px;color:var(--color-text-tertiary);">Contact your owner to change WA settings.</div>
        `;
                    return;
                }

                el.innerHTML = `
        <div style="display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap;">
          <!-- Unprofessional Card -->
          <div id="waCard-unprofessional" style="flex:1;min-width:260px;border:1px solid var(--hairline);border-radius:12px;padding:16px;background:${channelMode === 'unprofessional' ? 'var(--bg-primary)' : 'var(--surface-bg)'};box-shadow:${channelMode === 'unprofessional' ? '0 0 0 2px var(--accent-cyan)' : 'none'}">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
              <div style="font-weight:600;font-size:14px;">Gateway (Unofficial)</div>
              ${channelMode === 'unprofessional' ? '<span class="badge ok">Active</span>' : '<button class="btn-sm" onclick="window.setWaMode(\'unprofessional\')">Activate</button>'}
            </div>
            <div style="font-size:12px;color:var(--color-text-secondary);margin-bottom:12px;">Standard WhatsApp automation.</div>
            <div style="font-size:13px;margin-bottom:4px;">API Key: <code>${p.wa_api_key || 'Not set'}</code></div>
            ${p.wa_connected_number && channelMode === 'unprofessional' ? `<div style="font-size:13px;margin-bottom:6px;">Number: <strong>+${p.wa_connected_number}</strong></div>` : ''}
            <button class="btn-secondary" onclick="window.editWaKey('unprofessional', '${p.wa_connected_number || ''}')" style="font-size:12px;padding:6px 12px;margin-top:8px;">Update Key</button>
          </div>

          <!-- Professional Card -->
          <div id="waCard-professional" style="flex:1;min-width:260px;border:1px solid var(--hairline);border-radius:12px;padding:16px;background:${channelMode === 'professional' ? 'var(--bg-primary)' : 'var(--surface-bg)'};box-shadow:${channelMode === 'professional' ? '0 0 0 2px var(--accent-cyan)' : 'none'}">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">
              <div style="font-weight:600;font-size:14px;">Cloud API (Professional)</div>
              ${channelMode === 'professional' ? '<span class="badge ok">Active</span>' : '<button class="btn-sm" onclick="window.setWaMode(\'professional\')">Activate</button>'}
            </div>
            <div style="font-size:12px;color:var(--color-text-secondary);margin-bottom:12px;">Official Meta WhatsApp API.</div>
            <div style="font-size:13px;margin-bottom:4px;">API Key: <code>${p.wa_pro_api_key || 'Not set'}</code></div>
            <div style="font-size:13px;margin-bottom:6px;">Phone ID: <code>${p.wa_device_id || 'Not set'}</code></div>
            ${p.wa_connected_number && channelMode === 'professional' ? `<div style="font-size:13px;margin-bottom:6px;">Number: <strong>+${p.wa_connected_number}</strong></div>` : ''}
            <button class="btn-secondary" onclick="window.editWaKey('professional', '${p.wa_connected_number || ''}')" style="font-size:12px;padding:6px 12px;margin-top:8px;">Update Key</button>
          </div>
        </div>
        <div style="background:var(--surface-bg);border:1px solid var(--hairline);border-radius:8px;padding:12px;">
          <div style="font-size:12px;font-weight:600;color:var(--color-text-tertiary);margin-bottom:6px;">Webhook URL (Paste this in your Provider/Meta App)</div>
          <div style="display:flex;align-items:center;gap:8px;">
            <code id="waWhUrlTxt" style="flex:1;padding:6px 10px;background:var(--bg-primary);border-radius:4px;font-size:12px;word-break:break-all;">${p.webhook_token ? window.location.origin + '/wh/' + p.webhook_token : window.location.origin + '/whatsapp'}</code>
            <button type="button" id="waCopyUrl" style="padding:4px 10px;font-size:11px;border:1px solid var(--hairline);border-radius:6px;cursor:pointer;background:var(--surface-bg);color:var(--color-text-primary);">📋 Copy</button>
          </div>
        </div>
      `;

                document.getElementById('waCopyUrl').addEventListener('click', () => {
                    navigator.clipboard.writeText(document.getElementById('waWhUrlTxt').textContent)
                        .then(() => toast('Webhook URL copied!', 'ok'))
                        .catch(() => toast('Copy failed', 'err'));
                });
            }

            window.setWaMode = async function(mode) {
                try {
                    const r = await fetch('/api/tenant/update-profile', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            wa_channel_mode: mode
                        })
                    });
                    if (r.ok) {
                        toast('Switched to ' + mode, 'ok');
                        loadProfile();
                    } else {
                        toast('Failed', 'err');
                    }
                } catch (e) {
                    toast('Network error', 'err');
                }
            };

            window.editWaKey = function(type, currentNum) {
                if (type === 'unprofessional') {
                    const el = document.getElementById('waCard-unprofessional');
                    el.innerHTML = `
          <div style="margin-bottom:10px;">
            <label style="font-size:12px;font-weight:600;color:var(--color-text-tertiary);display:block;margin-bottom:4px;">Gateway API Key</label>
            <input id="waKeyInput" type="text" placeholder="Your API key" style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
          </div>
          <div style="margin-bottom:12px;">
            <label style="font-size:12px;font-weight:600;color:var(--color-text-tertiary);display:block;margin-bottom:4px;">Connected WhatsApp Number (with country code)</label>
            <input id="waNumInput" type="text" placeholder="919876543210" value="${currentNum || ''}" style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
          </div>
          <div id="waError-unprofessional" style="color:#e63946;font-size:12px;margin-bottom:8px;font-weight:500;"></div>
          <div style="display:flex;gap:8px;">
            <button class="btn-primary" id="waSaveBtn-unprofessional" onclick="window.saveWaKey('unprofessional')">Save</button>
            <button class="btn-sm" onclick="window.loadProfile()">Cancel</button>
          </div>
        `;
                } else {
                    const el = document.getElementById('waCard-professional');
                    el.innerHTML = `
          <div style="margin-bottom:10px;">
            <label style="font-size:12px;font-weight:600;color:var(--color-text-tertiary);display:block;margin-bottom:4px;">Meta Cloud API Key (Token)</label>
            <input id="waProKeyInput" type="text" placeholder="Your Meta token" style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
          </div>
          <div style="margin-bottom:10px;">
            <label style="font-size:12px;font-weight:600;color:var(--color-text-tertiary);display:block;margin-bottom:4px;">Phone Number ID</label>
            <input id="waDeviceIdInput" type="text" placeholder="e.g. 10234567890" style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
          </div>
          <div style="margin-bottom:12px;">
            <label style="font-size:12px;font-weight:600;color:var(--color-text-tertiary);display:block;margin-bottom:4px;">Connected WhatsApp Number (with country code)</label>
            <input id="waNumInputPro" type="text" placeholder="919876543210" value="${currentNum || ''}" style="width:100%;padding:8px 12px;border:1px solid var(--hairline);border-radius:8px;font-size:13px;background:var(--surface-bg);color:var(--color-text-primary);">
          </div>
          <div id="waError-professional" style="color:#e63946;font-size:12px;margin-bottom:8px;font-weight:500;"></div>
          <div style="display:flex;gap:8px;">
            <button class="btn-primary" id="waSaveBtn-professional" onclick="window.saveWaKey('professional')">Save</button>
            <button class="btn-sm" onclick="window.loadProfile()">Cancel</button>
          </div>
        `;
                }
            };

            window.saveWaKey = async function(type) {
                const errorEl = document.getElementById('waError-' + type);
                const btnEl = document.getElementById('waSaveBtn-' + type);
                errorEl.textContent = '';
                btnEl.disabled = true;
                btnEl.textContent = 'Saving...';

                let payload = {
                    phone: PHONE
                };
                if (type === 'unprofessional') {
                    const key = document.getElementById('waKeyInput').value.trim();
                    const num = document.getElementById('waNumInput').value.replace(/[^0-9]/g, '');
                    if (!key) {
                        errorEl.textContent = 'API key is required';
                        btnEl.disabled = false;
                        btnEl.textContent = 'Save';
                        return;
                    }
                    payload.wa_api_key = key;
                    payload.wa_connected_number = num;
                } else {
                    const key = document.getElementById('waProKeyInput').value.trim();
                    const did = document.getElementById('waDeviceIdInput').value.trim();
                    const num = document.getElementById('waNumInputPro').value.replace(/[^0-9]/g, '');
                    if (!key) {
                        errorEl.textContent = 'API key is required';
                        btnEl.disabled = false;
                        btnEl.textContent = 'Save';
                        return;
                    }
                    payload.wa_pro_api_key = key;
                    if (did) payload.wa_device_id = did;
                    payload.wa_connected_number = num;
                }

                try {
                    const r = await fetch('/api/tenant/update-profile', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(payload)
                    });
                    if (r.ok) {
                        toast('Key saved!', 'ok');
                        window.loadProfile();
                    } else {
                        const d = await r.json();
                        errorEl.textContent = d.error || 'Failed to save settings';
                        btnEl.disabled = false;
                        btnEl.textContent = 'Save';
                    }
                } catch (e) {
                    errorEl.textContent = 'Network error: could not connect';
                    btnEl.disabled = false;
                    btnEl.textContent = 'Save';
                }
            };

            // ─── Team Members (Owner/Super Admin only) ───
            const userRole = localStorage.getItem('mis_user_role') || 'owner';
            if (userRole === 'member') {
                document.getElementById('teamSection').style.display = 'none';
            } else {
                loadTeam();
            }

            // ─── Connect Sheet (shows when no database) ───
            async function checkIfDbExists() {
                try {
                    const r = await fetch(`/api/tenant/profile?phone=${PHONE}`);
                    const p = await r.json();
                    if (p.tenant_id && !p.last_sync_at && (!p.databases || !p.databases.length)) {
                        document.getElementById('connectSheetSection').style.display = '';
                    }
                } catch (e) {}
            }
            checkIfDbExists();

            document.getElementById('connectSheetBtn').addEventListener('click', async () => {
                const url = document.getElementById('sheetUrlInput').value.trim();
                if (!url || !url.includes('docs.google.com/spreadsheets')) {
                    toast('Valid Google Sheet URL required', 'err');
                    return;
                }
                const btn = document.getElementById('connectSheetBtn');
                const status = document.getElementById('sheetSyncStatus');
                btn.disabled = true;
                btn.textContent = 'Detecting...';
                status.textContent = '⏳ Detecting schema...';
                try {
                    const schemaRes = await fetch('/api/tenant/detect-schema', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            sheet_url: url
                        })
                    });
                    const schema = await schemaRes.json();
                    if (!schema || !schema.tables) {
                        status.textContent =
                            '❌ Could not detect schema. Check if sheet is shared publicly.';
                        btn.disabled = false;
                        btn.textContent = 'Detect Schema & Sync';
                        return;
                    }
                    status.textContent = '⏳ Syncing ' + schema.total_rows + ' rows...';
                    const profileRes = await fetch(`/api/tenant/profile?phone=${PHONE}`);
                    const profile = await profileRes.json();
                    const syncRes = await fetch('/api/tenant/signup', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            name: profile.name || tName,
                            sheet_url: url,
                            schema,
                            add_to_existing: true,
                            tenant_id: profile.tenant_id
                        })
                    });
                    const syncData = await syncRes.json();
                    if (syncData.sync_done) {
                        status.textContent = '✅ Database created! ' + (syncData.sync?.synced_rows || 0) +
                            ' rows synced.';
                        toast('Sheet synced!');
                        document.getElementById('connectSheetSection').style.display = 'none';
                        loadProfile();
                    } else {
                        status.textContent = '⚠️ ' + (syncData.message || 'Sync pending');
                    }
                } catch (e) {
                    status.textContent = '❌ Error: ' + e.message;
                } finally {
                    btn.disabled = false;
                    btn.textContent = 'Detect Schema & Sync';
                }
            });

            async function loadTeam() {
                try {
                    const r = await fetch(`/api/admin/members?phone=${PHONE}`, {
                        headers: {
                            'X-Phone': PHONE
                        }
                    });
                    if (r.status === 403) {
                        document.getElementById('teamSection').style.display = 'none';
                        return;
                    }
                    const members = await r.json();
                    const el = document.getElementById('teamList');
                    const profileRes = await fetch(`/api/tenant/profile?phone=${PHONE}`);
                    const profile = await profileRes.json();
                    const myTenantId = profile.tenant_id;
                    const myMembers = members.filter(m => m.tenant_id === myTenantId);

                    if (!myMembers.length) {
                        el.innerHTML =
                            '<div style="color:var(--color-text-tertiary);font-size:13px;">No team members yet. Add one below.</div>';
                        return;
                    }
                    el.innerHTML = `<table style="width:100%;border-collapse:collapse;font-size:13px;">
          <thead><tr style="border-bottom:1px solid var(--hairline);">
            <th style="text-align:left;padding:8px 4px;font-size:11px;text-transform:uppercase;color:var(--color-text-tertiary);">Phone</th>
            <th style="text-align:left;padding:8px 4px;font-size:11px;text-transform:uppercase;color:var(--color-text-tertiary);">Alias</th>
            <th style="text-align:left;padding:8px 4px;font-size:11px;text-transform:uppercase;color:var(--color-text-tertiary);">Permissions</th>
            <th style="text-align:left;padding:8px 4px;font-size:11px;text-transform:uppercase;color:var(--color-text-tertiary);">Actions</th>
          </tr></thead><tbody>${myMembers.map(m => `<tr style="border-bottom:1px solid var(--hairline);">
                                    <td style="padding:10px 4px;font-family:var(--font-mono);font-size:12px;">${m.phone}</td>
                                    <td style="padding:10px 4px;">${escapeHtml(m.alias || '—')}</td>
                                    <td style="padding:10px 4px;font-size:11px;">${(m.permissions || []).join(', ')}</td>
                                    <td style="padding:10px 4px;display:flex;gap:6px;">
                                      <button onclick="editTeamMember('${m.id}','${btoa(JSON.stringify(m.permissions))}','${escapeHtml(m.alias || '')}')" style="padding:4px 10px;font-size:11px;border:1px solid var(--hairline);background:transparent;border-radius:6px;cursor:pointer;">Edit</button>
                                      <button onclick="removeMember('${m.id}')" style="padding:4px 10px;font-size:11px;border:1px solid rgba(239,68,68,.3);background:transparent;color:#ef4444;border-radius:6px;cursor:pointer;">Remove</button>
                                    </td>
                                  </tr>`).join('')}</tbody></table>`;
                } catch (e) {
                    console.warn('team load error', e);
                }
            }

            window.removeMember = async function(id) {
                const ok = await window.MIS.confirmDelete('this member');
                if (!ok) return;
                const r = await fetch('/api/admin/members/' + id, {
                    method: 'DELETE',
                    headers: {
                        'X-Phone': PHONE
                    }
                });
                if (r.ok) {
                    toast('Member removed.');
                    loadTeam();
                } else {
                    toast('Failed to remove.', 'err');
                }
            };

            window.editTeamMember = function(id, permsB64, alias) {
                document.getElementById('tmEditId').value = id;
                document.getElementById('tmEditAlias').value = alias;
                const perms = JSON.parse(atob(permsB64));
                document.querySelectorAll('#tmEditPerms input[type=checkbox]').forEach(cb => {
                    cb.checked = perms.includes(cb.value);
                });
                document.getElementById('teamEditModal').style.display = 'grid';
            };
            document.getElementById('tmEditSaveBtn').addEventListener('click', async () => {
                const id = document.getElementById('tmEditId').value;
                const perms = [...document.querySelectorAll('#tmEditPerms input:checked')].map(i => i
                    .value);
                const alias = document.getElementById('tmEditAlias').value.trim();
                const r = await fetch('/api/admin/members/' + id, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Phone': PHONE
                    },
                    body: JSON.stringify({
                        permissions: perms,
                        alias
                    })
                });
                if (r.ok) {
                    toast('Updated!');
                    document.getElementById('teamEditModal').style.display = 'none';
                    loadTeam();
                } else {
                    toast('Failed', 'err');
                }
            });

            document.getElementById('addMemberBtn').addEventListener('click', async () => {
                const phone = document.getElementById('newMemberPhone').value.replace(/[^0-9]/g, '');
                if (!phone || phone.length < 10) {
                    toast('Enter valid phone number.', 'err');
                    return;
                }
                const perms = [...document.querySelectorAll('#newMemberPerms input:checked')].map(i => i
                    .value);
                // Get my tenant_id
                const profileRes = await fetch(`/api/tenant/profile?phone=${PHONE}`);
                const profile = await profileRes.json();
                const r = await fetch('/api/admin/members', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-Phone': PHONE
                    },
                    body: JSON.stringify({
                        phone,
                        tenant_id: profile.tenant_id,
                        permissions: perms
                    })
                });
                const d = await r.json();
                if (r.ok) {
                    toast('Member added!');
                    document.getElementById('newMemberPhone').value = '';
                    loadTeam();
                } else {
                    toast(d.error || 'Failed to add.', 'err');
                }
            });

            // ─── Init ───
            document.addEventListener('DOMContentLoaded', () => {
                if (window.lucide) window.lucide.createIcons();
                loadProfile();
                // Scroll to team section if #team hash
                if (location.hash === '#team') {
                    setTimeout(() => {
                        document.getElementById('teamSection')?.scrollIntoView({
                            behavior: 'smooth'
                        });
                    }, 500);
                }
            });

            // ─── Links Library ───
            async function loadLinks() {
                try {
                    const res = await fetch(`/api/tenant/links?phone=${PHONE}`);
                    const data = await res.json();
                    const el = document.getElementById('linksList');
                    if (!data.links || data.links.length === 0) {
                        el.innerHTML =
                            '<div style="color:var(--color-text-tertiary);font-size:13px;">No links yet.</div>';
                        return;
                    }
                    el.innerHTML = data.links.map(l => {
                        const badge = l.access_level === 'owner' ? '🔒 Owner' : l.access_level === 'team' ?
                            '👥 Team' : '🌐 All';
                        return `<div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--hairline);">
          <div style="flex:1;"><strong style="font-size:13px;">${l.title}</strong> <span style="font-size:10px;padding:2px 6px;border-radius:4px;background:var(--surface-canvas);color:var(--color-text-secondary);">${badge}</span>${l.description ? '<br><span style="font-size:11px;color:var(--color-text-secondary);">' + l.description + '</span>' : ''}<br><a href="${l.url}" target="_blank" style="font-size:11px;color:var(--accent-cyan);word-break:break-all;">${l.url.substring(0, 60)}${l.url.length > 60 ? '...' : ''}</a></div>
          <button onclick="removeLink(${l.id})" style="padding:4px 10px;border:1px solid #e53935;color:#e53935;background:none;border-radius:6px;font-size:11px;cursor:pointer;">Remove</button>
        </div>`;
                    }).join('');
                } catch (e) {}
            }
            window.removeLink = async function(id) {
                const ok = await window.MIS.confirmDelete('this link/file', {
                    text: 'This will also delete its indexed content.'
                });
                if (!ok) return;
                try {
                    const res = await fetch(`/api/tenant/links/${id}?phone=${PHONE}`, {
                        method: 'DELETE'
                    });
                    if (!res.ok) throw new Error('Failed to remove');
                    toast('Link removed.', 'ok');
                } catch (e) {
                    toast(e.message || 'Failed to remove.', 'err');
                }
                loadLinks();
            };

            window.toggleLinkInputType = function(type) {
                const urlWrapper = document.getElementById('linkUrlWrapper');
                const fileWrapper = document.getElementById('linkFileWrapper');
                if (type === 'file') {
                    urlWrapper.style.display = 'none';
                    fileWrapper.style.display = 'flex';
                } else {
                    urlWrapper.style.display = 'flex';
                    fileWrapper.style.display = 'none';
                }
            };

            document.getElementById('addLinkBtn').addEventListener('click', async () => {
                const title = document.getElementById('linkTitle').value.trim();
                const desc = document.getElementById('linkDesc').value.trim();
                const access_level = document.getElementById('linkAccess').value;
                const linkType = document.querySelector('input[name="linkTypeRadio"]:checked').value;

                if (!title) return alert('Title is required');

                if (linkType === 'url') {
                    const url = document.getElementById('linkUrl').value.trim();
                    if (!url) return alert('URL is required');

                    const r = await fetch('/api/tenant/links', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            title,
                            url,
                            description: desc,
                            access_level
                        })
                    });

                    if (r.ok) {
                        document.getElementById('linkUrl').value = '';
                        document.getElementById('linkTitle').value = '';
                        document.getElementById('linkDesc').value = '';
                        document.getElementById('linkAccess').value = 'all';
                        loadLinks();
                    } else {
                        const data = await r.json();
                        alert(data.error || 'Failed to add link');
                    }
                } else {
                    const fileInput = document.getElementById('linkFile');
                    if (fileInput.files.length === 0) return alert('Please choose a file to upload');
                    const file = fileInput.files[0];

                    // 10MB limit check
                    if (file.size > 10 * 1024 * 1024) {
                        return alert('File is too large. Maximum size is 10MB.');
                    }

                    const formData = new FormData();
                    formData.append('file', file);
                    formData.append('phone', PHONE);
                    formData.append('title', title);
                    formData.append('description', desc);
                    formData.append('access_level', access_level);

                    const progress = document.getElementById('linkUploadProgress');
                    progress.style.display = 'block';
                    document.getElementById('addLinkBtn').disabled = true;

                    try {
                        const r = await fetch('/api/tenant/links/upload', {
                            method: 'POST',
                            body: formData
                        });
                        const resData = await r.json();
                        progress.style.display = 'none';
                        document.getElementById('addLinkBtn').disabled = false;

                        if (r.ok) {
                            alert(resData.message || 'File uploaded and indexed!');
                            document.getElementById('linkTitle').value = '';
                            document.getElementById('linkDesc').value = '';
                            document.getElementById('linkFile').value = '';
                            document.getElementById('linkAccess').value = 'all';
                            loadLinks();
                        } else {
                            alert(resData.error || 'Failed to upload file.');
                        }
                    } catch (e) {
                        progress.style.display = 'none';
                        document.getElementById('addLinkBtn').disabled = false;
                        alert('Upload failed: ' + e.message);
                    }
                }
            });
            loadLinks();

            // ─── External API Keys ───
            const role = localStorage.getItem('mis_user_role') || '';
            if (role === 'owner' || role === 'super_admin') {
                document.getElementById('apiKeysSection').style.display = '';
                loadApiKeys();
            }

            function loadApiKeys() {
                fetch(`/api/tenant/api-keys?phone=${PHONE}`).then(r => r.json()).then(keys => {
                    const el = document.getElementById('apiKeysList');
                    if (!keys || !keys.length) {
                        el.innerHTML =
                            '<div style="color:var(--text-secondary);font-size:13px;padding:8px;">No API keys added yet.</div>';
                        return;
                    }
                    el.innerHTML = keys.map(k => `<div style="display:flex;align-items:center;gap:8px;padding:8px;border:1px solid var(--border);border-radius:8px;margin-bottom:6px;">
          <span style="font-size:10px;color:${k.status === 'active' ? '#27ae60' : '#e67e22'}">●</span>
          <strong style="flex:1">${k.label}</strong>
          <span style="font-size:12px;color:var(--text-secondary)">${k.api_key_masked}</span>
          <span style="font-size:11px;background:var(--bg-tertiary);padding:2px 8px;border-radius:4px;">${k.access_level === 'everyone' ? '🌐 All' : k.access_level === 'team' ? '👥 Team' : '🔒 Owner'}</span>
          <button onclick="toggleApiKey(${k.id},'${k.status === 'active' ? 'paused' : 'active'}')" style="font-size:11px;padding:4px 8px;border:1px solid var(--border);border-radius:4px;background:none;cursor:pointer;">${k.status === 'active' ? '⏸ Pause' : '▶ Resume'}</button>
          <button onclick="removeApiKey(${k.id})" style="font-size:11px;padding:4px 8px;border:1px solid #e74c3c;border-radius:4px;background:none;color:#e74c3c;cursor:pointer;">✕</button>
        </div>`).join('');
                });
            }

            window.addApiKey = function() {
                const label = document.getElementById('akLabel').value.trim();
                const api_key = document.getElementById('akKey').value.trim();
                const base_url = document.getElementById('akUrl').value.trim();
                const access_level = document.getElementById('akAccess').value;
                if (!label || !api_key || !base_url) return toast('Fill all fields', 'err');
                fetch(`/api/tenant/api-keys?phone=${PHONE}`, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            label,
                            api_key,
                            base_url,
                            access_level
                        })
                    })
                    .then(r => r.json()).then(d => {
                        if (d.ok) {
                            document.getElementById('akLabel').value = '';
                            document.getElementById('akKey').value = '';
                            document.getElementById('akUrl').value = '';
                            loadApiKeys();
                            toast('API key added.', 'ok');
                        } else toast(d.error || 'Failed to add key.', 'err');
                    });
            };
            window.toggleApiKey = function(id, status) {
                fetch(`/api/tenant/api-keys/${id}?phone=${PHONE}`, {
                        method: 'PUT',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE,
                            status
                        })
                    })
                    .then(r => r.json()).then(() => {
                        loadApiKeys();
                        toast(status === 'active' ? 'Key resumed.' : 'Key paused.', 'ok');
                    });
            };
            window.removeApiKey = async function(id) {
                const ok = await window.MIS.confirmDelete('this API key');
                if (!ok) return;
                try {
                    const res = await fetch(`/api/tenant/api-keys/${id}?phone=${PHONE}`, {
                        method: 'DELETE',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify({
                            phone: PHONE
                        })
                    });
                    if (!res.ok) throw new Error('Failed to remove');
                    toast('API key removed.', 'ok');
                } catch (e) {
                    toast(e.message || 'Failed to remove.', 'err');
                }
                loadApiKeys();
            };

        })();
    </script>
@endpush
