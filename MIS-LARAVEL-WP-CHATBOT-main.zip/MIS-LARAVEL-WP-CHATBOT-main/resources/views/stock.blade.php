@extends('layouts.app')

@section('title', 'Stock')

@push('head')
  <script src="https://cdn.sheetjs.com/xlsx-0.20.2/package/dist/xlsx.full.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
@endpush

@section('content')
  <div class="page">
    <div class="page-header page-header-hero">
      <div class="page-header-bg">
        <div class="aurora aurora-1"></div>
        <div class="aurora aurora-2"></div>
        <div class="aurora aurora-3"></div>
        <div class="grid-overlay"></div>
      </div>
      <div class="page-header-content">
        <div class="page-icon-glow"><i data-lucide="package"></i></div>
        <div class="page-header-text">
          <div class="page-title-row">
            <h1 class="t-h1 page-title-gradient">Stock</h1>
            <span class="live-pill"><span class="live-dot"></span>Live</span>
          </div>
          <p class="page-desc">Item-level inventory — derived from purchases minus sales</p>
          <div class="page-chips">
            <span class="page-chip"><i data-lucide="boxes" style="width:12px;height:12px;"></i> Auto-derived</span>
            <span class="page-chip"><i data-lucide="trending-down" style="width:12px;height:12px;"></i> Slow-moving
              alerts</span>
            <span class="page-chip"><i data-lucide="file-spreadsheet" style="width:12px;height:12px;"></i> Excel
              export</span>
          </div>
          <div class="page-underline"></div>
        </div>
        <button id="exportCsvBtn" type="button"
          style="padding:9px 16px; border-radius:10px; background:var(--accent-violet); color:#fff; font-weight:600; font-size:13px; border:none; cursor:pointer; flex-shrink:0; align-self:flex-start;">⬇
          Export Excel</button>
      </div>
    </div>

    <div class="page-grid">
      <div class="kpi-row" id="kpi-row">
        <div class="skel-kpi">
          <div class="skel skel-icon"></div>
          <div class="skel skel-label"></div>
          <div class="skel skel-value"></div>
          <div class="skel skel-delta"></div>
        </div>
        <div class="skel-kpi">
          <div class="skel skel-icon"></div>
          <div class="skel skel-label"></div>
          <div class="skel skel-value"></div>
          <div class="skel skel-delta"></div>
        </div>
        <div class="skel-kpi">
          <div class="skel skel-icon"></div>
          <div class="skel skel-label"></div>
          <div class="skel skel-value"></div>
          <div class="skel skel-delta"></div>
        </div>
        <div class="skel-kpi">
          <div class="skel skel-icon"></div>
          <div class="skel skel-label"></div>
          <div class="skel skel-value"></div>
          <div class="skel skel-delta"></div>
        </div>
      </div>

      <div class="charts-row">
        <div class="chart-card">
          <div class="chart-header">
            <div>
              <div class="t-h3">Top Items by Stock Value</div>
              <div class="t-meta">Highest inventory worth</div>
            </div>
            <div class="chart-icon"><i data-lucide="package"></i></div>
          </div>
          <div class="body"><canvas id="chartTopValue"></canvas></div>
        </div>
        <div class="chart-card">
          <div class="chart-header">
            <div>
              <div class="t-h3">Slow-Moving Items</div>
              <div class="t-meta">No sale in 30+ days</div>
            </div>
            <div class="chart-icon" style="background: rgba(245,158,11,0.12); color: #F59E0B;"><i
                data-lucide="alert-triangle"></i></div>
          </div>
          <div class="body"><canvas id="chartSlow"></canvas></div>
        </div>
      </div>

      <div class="stock-table">
        <div class="chart-header">
          <div>
            <div class="t-h3">All Items</div>
            <div class="t-meta" id="itemsMeta">—</div>
          </div>
          <div class="chart-icon"><i data-lucide="list"></i></div>
        </div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th class="num">Bought</th>
              <th class="num">Sold</th>
              <th class="num">Balance</th>
              <th class="num">Avg Price</th>
              <th class="num">Value</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody id="itemsBody"></tbody>
        </table>
      </div>
    </div>
  </div>
@endsection

@push('scripts')
  <script>
    (function () {
      'use strict';

      const PHONE = window.MIS.auth.getPhone();
      const tName = window.MIS.auth.getTenantName() || '—';
      document.getElementById('tenant-name').textContent = tName;
      document.getElementById('tenantAvatar').textContent = (tName.charAt(0) || 'M').toUpperCase();

      if (window.MIS.theme && window.MIS.theme.init) window.MIS.theme.init();
      document.getElementById('themeRow').addEventListener('click', () => window.MIS.theme.toggle());
      document.getElementById('logoutLink').addEventListener('click', (e) => { e.preventDefault(); window.MIS.confirmLogout(); });
      document.getElementById('refreshBtn').addEventListener('click', () => loadPage());

      function applyChartDefaults() {
        if (!window.Chart) return;
        const dark = document.documentElement.getAttribute('data-theme') === 'dark';
        Chart.defaults.color = dark ? '#F5F5F7' : '#1D1D1F';
        Chart.defaults.borderColor = dark ? 'rgba(255,255,255,0.08)' : 'rgba(0,0,0,0.08)';
      }
      applyChartDefaults();
      const charts = {};
      new MutationObserver(() => { applyChartDefaults(); Object.values(charts).forEach(c => { try { c.update('none'); } catch { } }); })
        .observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });

      const inr = (v) => window.MIS.fmt.inr(v);
      const num = (v) => window.MIS.fmt.num(v);

      function destroyCharts() { Object.keys(charts).forEach(k => { try { charts[k].destroy(); } catch { } delete charts[k]; }); }

      function renderKpis(kpis) {
        const row = document.getElementById('kpi-row');
        row.innerHTML = '';
        const cards = [
          { id: 'total_value', title: 'Stock Value', icon: 'wallet', accent: 'emerald' },
          { id: 'sku_count', title: 'SKUs Tracked', icon: 'package', accent: 'indigo' },
          { id: 'low_stock_count', title: 'Low Stock', icon: 'alert-triangle', accent: 'rose' },
          { id: 'slow_moving_count', title: 'Slow Moving', icon: 'clock', accent: 'amber' }
        ];
        for (const c of cards) {
          const k = kpis[c.id];
          if (!k) continue;
          const v = (k.format === 'inr') ? inr(k.value) : num(k.value);
          const div = document.createElement('div');
          div.className = 'kpi tilt-card';
          div.style.cssText = `--kpi-color: var(--accent-${c.accent}); --kpi-soft: var(--accent-${c.accent}-soft); --kpi-glow: var(--accent-${c.accent}-glow);`;
          div.innerHTML = `<div class="kpi-top"><div class="kpi-icon-box"><i data-lucide="${c.icon}"></i></div></div><div class="kpi-label">${c.title}</div><div class="kpi-value">${v}</div>`;
          row.appendChild(div);
        }
        if (window.lucide) window.lucide.createIcons();
      }

      function renderHorizBar(canvasId, items, valueKey, color) {
        if (!items || !items.length) return;
        const palette = ['#10B981', '#F59E0B', '#6366F1', '#8B5CF6', '#F43F5E', '#00A4D2', '#0EA5E9', '#D946EF'];
        const ctx = document.getElementById(canvasId).getContext('2d');
        const labels = items.map(it => (it.item || '').slice(0, 28) + ((it.item || '').length > 28 ? '…' : ''));
        const data = items.map(it => Number(it[valueKey]) || 0);
        return new Chart(ctx, {
          type: 'bar',
          data: { labels, datasets: [{ data, backgroundColor: data.map((_, i) => palette[i % palette.length] + 'CC'), hoverBackgroundColor: data.map((_, i) => palette[i % palette.length]), borderRadius: 8, barPercentage: 0.72 }] },
          options: {
            indexAxis: 'y', responsive: true, maintainAspectRatio: false,
            plugins: { legend: { display: false }, tooltip: { backgroundColor: 'rgba(15,15,20,0.92)', titleColor: '#F5F5F7', bodyColor: '#E5E5EA', callbacks: { label: (i) => '  ' + (valueKey === 'stock_value' ? inr(i.parsed.x) : num(i.parsed.x)) } } },
            scales: {
              x: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' }, ticks: { maxTicksLimit: 5, callback: (v) => valueKey === 'stock_value' ? inr(v) : num(v) } },
              y: { grid: { display: false } }
            }
          }
        });
      }

      function renderItems(items) {
        const tbody = document.getElementById('itemsBody');
        tbody.innerHTML = '';
        if (!items || !items.length) {
          tbody.innerHTML = '<tr><td colspan="7" style="text-align:center; padding:30px; color:var(--color-text-tertiary);">No items.</td></tr>';
          document.getElementById('itemsMeta').textContent = '0 items';
          return;
        }
        for (const it of items) {
          const tr = document.createElement('tr');
          const status = it.balance_qty <= 0 ? '<span class="badge low">Low Stock</span>'
            : (it.last_sale_at && (Date.now() - new Date(it.last_sale_at).getTime()) > 30 * 86_400_000) ? '<span class="badge slow">Slow</span>'
              : '<span class="badge healthy">Healthy</span>';
          tr.innerHTML = `<td>${it.item}</td><td class="num">${num(Math.round(it.bought_qty))}</td><td class="num">${num(Math.round(it.sold_qty))}</td><td class="num">${num(Math.round(it.balance_qty))}</td><td class="num">${inr(it.avg_price)}</td><td class="num">${inr(it.stock_value)}</td><td>${status}</td>`;
          tbody.appendChild(tr);
        }
        document.getElementById('itemsMeta').textContent = `${items.length} items`;
      }

      async function loadPage() {
        destroyCharts();
        const res = await fetch(`/api/page/stock?phone=${encodeURIComponent(PHONE)}`);
        if (!res.ok) {
          document.getElementById('kpi-row').innerHTML = '<div class="empty-state"><div class="ic">⚠️</div>Failed to load.</div>';
          return;
        }
        const d = await res.json();
        LAST_DATA = d;
        if (d.tenant?.name) {
          document.getElementById('tenant-name').textContent = d.tenant.name;
          document.getElementById('tenantAvatar').textContent = (d.tenant.name.charAt(0) || 'M').toUpperCase();
        }
        if (d.empty) {
          document.getElementById('kpi-row').innerHTML = `<div class="empty-state"><div class="ic">📦</div>${d.message || 'No data'}</div>`;
          return;
        }
        renderKpis(d.kpis);
        if (d.top_value_items?.length) charts.topValue = renderHorizBar('chartTopValue', d.top_value_items.slice(0, 8), 'stock_value');
        if (d.slow_moving?.length) charts.slow = renderHorizBar('chartSlow', d.slow_moving.slice(0, 8), 'balance_qty');
        renderItems(d.items_table);
      }

      let LAST_DATA = null;

      document.addEventListener('DOMContentLoaded', () => { if (window.lucide) window.lucide.createIcons(); loadPage(); });

      document.getElementById('exportCsvBtn').addEventListener('click', () => {
        if (!LAST_DATA || !LAST_DATA.items_table || !LAST_DATA.items_table.length) { alert('No items to export. Wait for data to load.'); return; }
        if (!window.MIS?.xlsx?.isReady()) { alert('Excel library still loading — please retry.'); return; }
        const headers = ['Item', 'Bought', 'Sold', 'Balance', 'Avg Price (₹)', 'Stock Value (₹)', 'Status'];
        const rows = LAST_DATA.items_table.map(it => [
          it.item || '', Number(it.bought || 0), Number(it.sold || 0), Number(it.balance || 0),
          Number(it.avg_price || 0), Number(it.value || 0), it.status || ''
        ]);
        const ts = new Date().toISOString().split('T')[0];
        const sheets = [
          {
            name: 'Info', headers: ['Field', 'Value'], rows: [
              ['Report', 'Stock Valuation'],
              ['Tenant', LAST_DATA.tenant?.name || 'MIS'],
              ['Generated', new Date().toLocaleString('en-IN')],
              ['SKU Count', rows.length]
            ]
          },
          { name: 'Items', headers, rows }
        ];
        window.MIS.xlsx.download(`stock-${ts}.xlsx`, sheets);
      });
    })();
  </script>
@endpush