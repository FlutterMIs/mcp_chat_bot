<?php

/*
|--------------------------------------------------------------------------
| MIS Chatbot custom config
|--------------------------------------------------------------------------
| Central map for all non-framework env keys. App code reads these via
| config('mis.*') so Laravel's config:cache works without force-loading
| Dotenv in public_html/index.php. env() is only called here (at config
| build time), per Laravel convention.
*/

return [
    // WhatsApp (Unprofessional API - app.mis.work)
    'wa_unpro_api_key' => env('WA_UNPRO_API_KEY', env('WA_ACCESS_TOKEN', '')),
    'wa_unpro_phone_id' => env('WA_UNPRO_PHONE_ID', env('WA_PHONE_ID', '')),
    'wa_unpro_connected_number' => env('WA_UNPRO_CONNECTED_NUMBER', env('WA_CONNECTED_NUMBER', '')),

    // WhatsApp (Professional API - wa.apimis.in)
    'wa_pro_api_key'   => env('WA_PRO_API_KEY', ''),
    'wa_pro_phone_id'  => env('WA_PRO_PHONE_ID', ''),
    'wa_pro_connected_number' => env('WA_PRO_CONNECTED_NUMBER', ''),

    // Backward compatibility for existing settings (used widely across the app)
    'wa_access_token' => env('WA_ACCESS_TOKEN', env('WA_UNPRO_API_KEY', '')),
    'wa_phone_id'     => env('WA_PHONE_ID', env('WA_UNPRO_PHONE_ID', '')),
    'wa_connected_number' => env('WA_CONNECTED_NUMBER', env('WA_UNPRO_CONNECTED_NUMBER', '')),

    // Webhook verification
    'webhook_strict' => env('WEBHOOK_STRICT', false),
    'webhook_secret' => env('WEBHOOK_SECRET', ''),

    // Suppresses real WhatsApp sends during tests
    'testing_mode' => env('TESTING_MODE', false),

    // Google OAuth (per-tenant Calendar)
    // GOOGLE_REDIRECT_URI is optional — when unset, derived from APP_URL. Google's
    // OAuth requires an EXACT string match against Console's "Authorized redirect
    // URIs", so APP_URL is trimmed here to avoid a trailing slash silently producing
    // ".../google//callback" and causing a redirect_uri_mismatch.
    'google_client_id'     => env('GOOGLE_CLIENT_ID', ''),
    'google_client_secret' => env('GOOGLE_CLIENT_SECRET', ''),
    'google_redirect_uri'  => env('GOOGLE_REDIRECT_URI', rtrim((string) env('APP_URL', ''), '/').'/google/callback'),
    // Tenant-facing "connect your calendar" chat link base — NOT the Google-registered
    // redirect_uri (that's google_redirect_uri above). Kept separate since it's shown
    // to end users in WhatsApp/web chat, not sent to Google.
    'public_base_url'      => env('PUBLIC_BASE_URL', 'http://localhost:8000'),

    // Super Admin phone numbers (env-only — no defaults in code)
    'super_admin_phones' => array_filter(explode(',', env('SUPER_ADMIN_PHONES', '919999408444,917011047783,918750285420'))),

    // Admin endpoint key
    'admin_api_key' => env('ADMIN_API_KEY', ''),

    // OpenAI — primary key + optional fallback keys (comma-separated)
    'openai_api_key'  => env('OPENAI_API_KEY', ''),
    'openai_api_keys' => array_filter(explode(',', env('OPENAI_API_KEYS', env('OPENAI_API_KEY', '')))),

    // Chat phone-token auth
    'chat_token_secret' => env('CHAT_TOKEN_SECRET', ''),
    'chat_auth_strict'  => env('CHAT_AUTH_STRICT', false),

    // Gmail SMTP (notifications)
    'gmail_app_password' => env('GMAIL_APP_PASSWORD', ''),
    'gmail_user'         => env('GMAIL_USER', 'saranshrajput1301@gmail.com'),

];
