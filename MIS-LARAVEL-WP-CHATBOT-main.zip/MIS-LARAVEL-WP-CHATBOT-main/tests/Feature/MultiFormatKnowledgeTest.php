<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\Tenant;
use App\Models\TenantLink;
use App\Models\TenantPdfChunk;
use App\Services\Chat\PdfKnowledgeService;
use App\Services\Chat\LedgerEntityResolver;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class MultiFormatKnowledgeTest extends TestCase
{
    use RefreshDatabase;

    private Tenant $tenant;

    protected function setUp(): void
    {
        parent::setUp();

        // Create a dummy tenant
        $this->tenant = Tenant::create([
            'id' => 'test-tenant-123',
            'name' => 'Test Company',
            'phone' => '919999999999',
            'email' => 'test@example.com',
            'wa_key_mode' => 'shared',
            'wa_channel_mode' => 'unprofessional',
        ]);
    }

    /**
     * Test direct file upload of a text file and indexing.
     */
    public function test_txt_upload_and_indexing(): void
    {
        Storage::fake('public');

        $txtContent = "This is a plain text file content for indexing tests.";
        $file = UploadedFile::fake()->createWithContent('test_doc.txt', $txtContent);

        $response = $this->postJson('/api/tenant/links/upload', [
            'phone' => '919999999999',
            'title' => 'Plain Text Catalog',
            'description' => 'Test txt file description',
            'access_level' => 'all',
            'file' => $file,
        ]);

        $response->assertStatus(200)
                 ->assertJsonPath('ok', true)
                 ->assertJsonPath('link.title', 'Plain Text Catalog')
                 ->assertJsonPath('link.category', 'file');

        // Assert file exists in fake storage
        $storedLink = TenantLink::first();
        $this->assertNotNull($storedLink);
        $this->assertStringContainsString('/storage/tenant_files/' . $this->tenant->id . '/', $storedLink->url);

        // Assert text chunks were created
        $chunks = TenantPdfChunk::where('tenant_id', $this->tenant->id)->get();
        $this->assertGreaterThan(0, $chunks->count());
        $this->assertStringContainsString('plain text file content', $chunks->first()->content);
    }

    /**
     * Test deleting a link also cleans up DB chunks and physical files.
     */
    public function test_link_deletion_cleanup(): void
    {
        Storage::fake('public');

        $file = UploadedFile::fake()->createWithContent('test_doc.txt', "Hello World. This is a longer text document content that will pass the 20-character check.");

        // 1. Upload
        $this->postJson('/api/tenant/links/upload', [
            'phone' => '919999999999',
            'title' => 'Delete Me Document',
            'access_level' => 'all',
            'file' => $file,
        ]);

        $link = TenantLink::first();
        $this->assertNotNull($link);
        $this->assertDatabaseHas('tenant_pdf_chunks', ['tenant_id' => $this->tenant->id]);

        // Extract path
        $relativePath = substr($link->url, strpos($link->url, '/storage/') + 9);
        Storage::disk('public')->assertExists(rawurldecode($relativePath));

        // 2. Delete
        $deleteResponse = $this->deleteJson("/api/tenant/links/{$link->id}?phone=919999999999");
        $deleteResponse->assertStatus(200);

        // 3. Verify
        $this->assertDatabaseMissing('tenant_links', ['id' => $link->id]);
        $this->assertDatabaseMissing('tenant_pdf_chunks', ['tenant_id' => $this->tenant->id]);
        Storage::disk('public')->assertMissing(rawurldecode($relativePath));
    }

    /**
     * Test text extractor for Word (.docx) documents.
     */
    public function test_docx_extractor(): void
    {
        $tempPath = tempnam(sys_get_temp_dir(), 'test_docx');
        $docxPath = $tempPath . '.docx';

        // Create programmatically a simple Zip archive representing a DOCX document.xml
        $zip = new \ZipArchive();
        if ($zip->open($docxPath, \ZipArchive::CREATE) === true) {
            $zip->addFromString('word/document.xml', '<?xml version="1.0" encoding="UTF-8"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:p><w:t>Hello world, this is a test DOCX file text contents.</w:t></w:p></w:body></w:document>');
            $zip->close();
        }

        try {
            $extractedText = PdfKnowledgeService::extractText($docxPath, 'docx');
            $this->assertNotNull($extractedText);
            $this->assertStringContainsString('Hello world, this is a test DOCX file text contents.', $extractedText);
        } finally {
            @unlink($tempPath);
            @unlink($docxPath);
        }
    }

    /**
     * Test text extractor for CSV spreadsheets.
     */
    public function test_csv_extractor(): void
    {
        $tempPath = tempnam(sys_get_temp_dir(), 'test_csv');
        $csvPath = $tempPath . '.csv';

        $csvContent = "Name,Age,Role\nAlice,30,Developer\nBob,40,Manager";
        file_put_contents($csvPath, $csvContent);

        try {
            $extractedText = PdfKnowledgeService::extractText($csvPath, 'csv');
            $this->assertNotNull($extractedText);
            $this->assertStringContainsString('Row 1: Name = Alice; Age = 30; Role = Developer;', $extractedText);
            $this->assertStringContainsString('Row 2: Name = Bob; Age = 40; Role = Manager;', $extractedText);
        } finally {
            @unlink($tempPath);
            @unlink($csvPath);
        }
    }

    /**
     * Test text extractor for Excel (.xlsx) spreadsheets.
     */
    public function test_xlsx_extractor(): void
    {
        $tempPath = tempnam(sys_get_temp_dir(), 'test_xlsx');
        $xlsxPath = $tempPath . '.xlsx';

        // Create programmatically a simple Zip archive representing an XLSX spreadsheet structure
        $zip = new \ZipArchive();
        if ($zip->open($xlsxPath, \ZipArchive::CREATE) === true) {
            $zip->addFromString('xl/sharedStrings.xml', '<?xml version="1.0" encoding="UTF-8"?><sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><si><t>Company A</t></si><si><t>Company B</t></si></sst>');
            $zip->addFromString('xl/worksheets/sheet1.xml', '<?xml version="1.0" encoding="UTF-8"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData><row><c t="s"><v>0</v></c><c><v>500</v></c></row><row><c t="s"><v>1</v></c><c><v>750</v></c></row></sheetData></worksheet>');
            $zip->close();
        }

        try {
            $extractedText = PdfKnowledgeService::extractText($xlsxPath, 'xlsx');
            $this->assertNotNull($extractedText);
            $this->assertStringContainsString('Row 1: Company A | 500', $extractedText);
            $this->assertStringContainsString('Row 2: Company B | 750', $extractedText);
        } finally {
            @unlink($tempPath);
            @unlink($xlsxPath);
        }
    }

    /**
     * Test RAG knowledge base access control restrictions.
     */
    public function test_rag_client_access_restriction(): void
    {
        // Create an owner-only document link and a public link
        $ownerLink = TenantLink::create([
            'tenant_id' => $this->tenant->id,
            'title' => 'Owner Manual',
            'url' => 'https://example.com/owner.pdf',
            'access_level' => 'owner',
        ]);

        $publicLink = TenantLink::create([
            'tenant_id' => $this->tenant->id,
            'title' => 'Public Manual',
            'url' => 'https://example.com/public.pdf',
            'access_level' => 'all',
        ]);

        // Seed chunks for both documents
        TenantPdfChunk::create([
            'tenant_id' => $this->tenant->id,
            'source_url' => $ownerLink->url,
            'title' => $ownerLink->title,
            'chunk_index' => 0,
            'content' => 'Top secret owner data about budget and strategy.',
        ]);

        TenantPdfChunk::create([
            'tenant_id' => $this->tenant->id,
            'source_url' => $publicLink->url,
            'title' => $publicLink->title,
            'chunk_index' => 0,
            'content' => 'Generic public help content about standard features.',
        ]);

        // Search with guest/client phone (access level: all only)
        config(['mis.openai_api_key' => 'fake-key']);

        $guestAnswer = PdfKnowledgeService::search($this->tenant->id, 'secret budget', '918888888888');
        $this->assertNull($guestAnswer);

        // Search with owner phone (access level: owner)
        try {
            PdfKnowledgeService::search($this->tenant->id, 'secret budget', '919999999999');
        } catch (\Throwable $e) {
            // Assert that it proceeded to OpenAI API call (which means chunks were loaded!)
            $this->assertTrue(
                str_contains($e->getMessage(), 'OpenAI') ||
                str_contains($e->getMessage(), 'ApiKey') ||
                str_contains($e->getMessage(), 'API')
            );
        }
    }

    /**
     * Test Ledger access control row-level restrictions.
     */
    public function test_ledger_client_access_restriction(): void
    {
        // 1. Create a dummy ledger table using SQL
        \Illuminate\Support\Facades\Schema::create('tenant_test_ledger', function ($table) {
            $table->string('party_name');
            $table->string('client_phone');
            $table->string('particular');
            $table->decimal('debit')->default(0);
            $table->decimal('credit')->default(0);
        });

        // Insert rows for different clients
        \Illuminate\Support\Facades\DB::table('tenant_test_ledger')->insert([
            ['party_name' => 'Client X', 'client_phone' => '9999999999', 'particular' => 'Invoice 1', 'debit' => 100, 'credit' => 0],
            ['party_name' => 'Client X', 'client_phone' => '8888888888', 'particular' => 'Invoice 2', 'debit' => 200, 'credit' => 0],
        ]);

        // Setup access control config for client
        \Illuminate\Support\Facades\DB::table('sheet_tab_access')->insert([
            'id' => (string) \Illuminate\Support\Str::uuid(),
            'tenant_id' => $this->tenant->id,
            'tab_name' => 'Ledger',
            'pg_table' => 'tenant_test_ledger',
            'access_all' => false,
            'access_team' => false,
            'access_client' => true,
            'client_match_column' => 'client_phone',
        ]);

        $ledgerInfo = [
            'pgTable' => 'tenant_test_ledger',
            'mapping' => [
                'nameCol' => 'party_name',
                'debitCol' => 'debit',
                'creditCol' => 'credit',
                'particularCol' => 'particular',
            ],
        ];

        // Fetch ledger with constraint for phone A (9999999999)
        $whereConstraint = "`client_phone` LIKE '%9999999999%'";
        $rowsA = LedgerEntityResolver::fetchLedgerForName($ledgerInfo, 'Client X', $whereConstraint);

        $this->assertCount(1, $rowsA);
        $this->assertEquals('Invoice 1', $rowsA[0]['particular']);

        // Fetch ledger with constraint for phone B (8888888888)
        $whereConstraintB = "`client_phone` LIKE '%8888888888%'";
        $rowsB = LedgerEntityResolver::fetchLedgerForName($ledgerInfo, 'Client X', $whereConstraintB);

        $this->assertCount(1, $rowsB);
        $this->assertEquals('Invoice 2', $rowsB[0]['particular']);

        // Clean up
        \Illuminate\Support\Facades\Schema::dropIfExists('tenant_test_ledger');
    }

    /**
     * Test tools analyze url endpoint.
     */
    public function test_tools_analyze_url(): void
    {
        // Mock download response inside indexFromUrl logic
        \Illuminate\Support\Facades\Http::fake([
            'https://example.com/test_doc.txt' => \Illuminate\Support\Facades\Http::response("This is document content that will be downloaded and summarized.", 200)
        ]);

        config(['mis.openai_api_key' => 'fake-key']);

        $response = $this->postJson('/api/tenant/links/tools/analyze', [
            'phone' => '919999999999',
            'doc_url' => 'https://example.com/test_doc.txt',
            'title' => 'Direct Analyzed URL'
        ]);

        $response->assertStatus(200)
                 ->assertJsonPath('ok', true);

        $this->assertDatabaseHas('tenant_links', [
            'tenant_id' => $this->tenant->id,
            'title' => 'Direct Analyzed URL',
            'url' => 'https://example.com/test_doc.txt',
        ]);
    }

    /**
     * Test tools upload file endpoint.
     */
    public function test_tools_upload_file(): void
    {
        Storage::fake('public');

        config(['mis.openai_api_key' => 'fake-key']);

        $fileContent = "This is a document file content uploaded via tools panel to index and summarize.";
        $file = UploadedFile::fake()->createWithContent('tools_upload.txt', $fileContent);

        $response = $this->postJson('/api/tenant/links/tools/upload-file', [
            'phone' => '919999999999',
            'file' => $file,
        ]);

        $response->assertStatus(200)
                 ->assertJsonPath('ok', true);

        $storedLink = TenantLink::where('title', 'tools_upload.txt')->first();
        $this->assertNotNull($storedLink);
        $this->assertDatabaseHas('tenant_pdf_chunks', [
            'tenant_id' => $this->tenant->id,
            'source_url' => $storedLink->url,
        ]);
    }
}
