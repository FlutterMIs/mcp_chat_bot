# Prompt & accuracy tuning guide

Reference map of every AI prompt in the codebase — where it lives, what it
controls, and how to change it. Also lists the non-AI rule/keyword lists that
affect answer quality, and the bugs fixed on 2026-07-28 (for context on what
changed and why).

All prompts now branch on a `$webMode` flag (`true` = web chat panel, clean
Markdown; `false` = WhatsApp, `*bold*`/emoji-bullets). That flag originates
from `TenantRouter::handle()`'s `$waMode` parameter (`$webMode = !$waMode`)
and is threaded down as a plain function argument — search any function
below for `$webMode` to see both branches side by side.

---

## 1. SQL generation (channel-agnostic — same for web & WhatsApp)

**`app/Services/Chat/PromptBuilder.php`**

- `buildSqlMessages()` (~line 147) — the main prompt. Tells the model the
  exact table/column schema (`buildSchemaBlock()`, ~line 310) and 20 "CRITICAL
  RULES" for SQL correctness (date filtering, GST handling, dedup logic,
  fuzzy LIKE matching, table-size preference, etc.).
  **Edit here to**: fix a systematically wrong SQL pattern (e.g. the model
  keeps summing the wrong column, or mis-handles a date phrase). Add a new
  numbered rule near the existing ones — the model responds well to explicit
  numbered rules with a concrete example query → SQL pair.
- Mode variants appended via `$modeNote` in the same function: `'chart'`
  (~line 174), `'images'` (~line 189), `'pivot'` (~line 200). Edit the
  relevant `<<<'...NOTE'` block to change how chart/image/pivot SQL is shaped.
- `generateSystemPrompt()` / `fallbackPrompt()` (~line 35, 85) — legacy path
  for tenants still on the old JSONB cache (`proper_tables_created=false`).
  Rare in practice; most tenants are on the modern `buildSqlMessages()` path.

**Confidence signal**: the SQL prompt asks the model to prefix its answer
with `HIGH:`/`MEDIUM:`/`LOW:` (`PromptBuilder.php` ~line 296). It's parsed in
`TenantRouter.php` ~line 1580 — `LOW` triggers a clarifying question instead
of guessing; `MEDIUM`/`HIGH` are currently treated identically (no behavior
difference). **Tuning opportunity**: if you want the bot to be more
conservative, you could make `MEDIUM` also add a "results may be
approximate" caveat to the reply instead of answering exactly like `HIGH`.

## 2. Tool routing / orchestrator decision (channel-agnostic)

**`app/Services/AI/AiOrchestrator.php`**

- `buildSystemPrompt()` (~line 180) — decides WHICH tool to use
  (`query_database` / `query_external_api` / `search_knowledge` /
  `manage_calendar` / `get_ledger` / answer directly). Edit the "Decision
  rules" list here if the bot is picking the wrong tool for a category of
  question (e.g. routing ledger questions to plain SQL instead of
  `get_ledger`).
- `buildToolDefinitions()` (~line 193) — the actual function-calling schemas
  GPT picks from. If you add a new capability (new external API type, new
  chart type), it needs a matching tool definition here.

## 3. Reply formatting (channel-aware — web Markdown vs WhatsApp)

These are the prompts that turn raw rows/stats into user-facing text. Each
has a **web branch** (standard Markdown: `**bold**`, `-`/`1.` lists,
`[label](url)` links) and a **WhatsApp branch** (`*bold*`, emoji bullets, no
markdown headers) — unchanged from before for WhatsApp.

| File | Function | Triggers when |
|---|---|---|
| `app/Services/AI/AiOrchestrator.php` | `formatResponse()` (~line 62) | Orchestrator explicitly picked `query_database` with a `format_instruction` |
| `app/Services/Chat/SmartFormatter.php` | `aiPrettyFormat()` (~line 199) | Plain `DATA_QUERY` with >15 rows and no orchestrator format instruction |
| `app/Services/Chat/MultiStepAgent.php` | `synthesize()` (~line 169) | Complex/multi-table questions (`MULTI_STEP_QUERY`). On web + tabular result, deliberately asks for a **one-line intro only** (table renders the detail) — see §5 below |
| `app/Services/Chat/PdfKnowledgeService.php` | `search()` (~line 265) | RAG answers from uploaded documents / indexed webpages |
| `app/Services/Chat/ExternalApiService.php` | `aiFormatSummary()` (~line 442), `aiFormatList()` (~line 460) | Delegation/checklist/call-log/lead/visiting-card questions |

**Edit here to**: change tone, add a house style ("always end with a
follow-up question"), change how currency/dates are phrased in prose (note:
currency values are already pre-formatted in ₹X.XX L/Cr form by
`SmartFormatter::formatValue()` before the AI ever sees them — the prompts
say "keep as-is", so fix `SmartFormatter.php` for number-formatting changes,
not these prompts).

**Tenant-level custom format (admin panel)**: every one of the 5 functions
above also checks `TenantPrompt::getFormatInstruction($tenantId, $webMode)` —
this is the admin-configurable "custom format" set per tenant at
`resources/views/admin.blade.php`'s Prompts panel (4 fields: `response_style`,
`data_format`, `bot_personality`, `company_context`; backed by
`GET/POST /api/admin/prompts` → `SuperAdminController::getPrompts/savePrompts`
→ `TenantPrompt` model). Confirmed fully wired end-to-end — if a tenant
reports their custom format isn't being followed, check that admin setting
first before touching code. `getFormatInstruction()` itself now also takes
`$webMode` (2026-07-28 fix, see §5.6) — it used to hardcode "Always use
WhatsApp *bold*" into every custom format regardless of channel, which
silently broke web-Markdown rendering for any tenant using this feature.

Note: **`bot_personality`'s custom greeting only applies on web**, not
WhatsApp (`TenantRouter.php` ~line 132) — WhatsApp intentionally stays silent
on plain greetings ("hi"/"thanks") to avoid unnecessary outbound messages.
This looks deliberate (same silence pattern used for unregistered numbers),
not a bug, but worth knowing if a tenant asks why their custom greeting
doesn't show up on WhatsApp.

## 4. Non-AI rule/keyword lists (also affect accuracy — not prompts, but same idea)

These are deterministic PHP rules, not AI prompts, but they gate what the AI
ever gets to see — wrong here means the AI never even gets asked the right
question.

- **`TenantRouter::isBusinessRelated()`** (`TenantRouter.php` ~line 1342) —
  WhatsApp-only keyword allow-list. If a legitimate business term gets
  rejected as "personal chatter" on WhatsApp, add it to `$domainKeywords`.
  (Not applied on web — web has no relevance gate.)
- **`TenantRouter::detectIntent()`** (~line 1307) — regex-based
  greeting/small-talk/switch-db detection. Edit the regexes here to catch
  more greeting phrasings.
- **`ExternalApiService::detectEndpoint()`** (~line 65) — keyword → API
  endpoint map. Add keywords here if a phrasing isn't routing to the right
  external API (call logs vs. leads vs. delegation, etc.).
- **`SmartFormatter::inferRoleFromKey()`** (`SmartFormatter.php` ~line 354) —
  regex-based column-role inference (currency/quantity/date/entity/etc.) used
  whenever a column isn't in `tables_metadata`'s explicit role mapping. If a
  new tenant's amount column isn't getting ₹-formatted, check whether its
  name matches one of these patterns.

## 5. Bugs fixed 2026-07-28 (accuracy, not formatting)

Found by auditing the SQL self-heal, caching, and result-validation layers
that weren't touched by the earlier formatting fix. All confirmed against
actual code/DB behavior before fixing (not just suspected).

1. **`SelfHeal::classifyError`** (`SelfHeal.php` ~line 63-68) — regexes were
   written for PostgreSQL error wording (`column ... does not exist`,
   `relation ... does not exist`), but the DB is MySQL, which says
   `Unknown column 'x' in 'field list'` / `Table 'x' doesn't exist`. Real
   schema errors were silently falling through to `SQL_SYNTAX`/`UNKNOWN`, so
   the cheap Levenshtein column-name auto-fix (`resolveColumnError`) never
   fired — every wrong-column-name error paid for a full extra AI round-trip
   (or exhausted all 3 attempts) instead of a free local fix. Fixed the
   regexes to match actual MySQL phrasing.
2. **Chat response cache key missing `tenant_id`** (`TenantRouter.php`
   ~line 744) — one phone number can be linked to multiple tenants via
   `SWITCH_DB` (`UserDatabase.is_default`). The cache key was
   `phone+mode+query` only, so switching tenants and re-asking the same
   question within the 5-minute cache TTL served the **previous tenant's**
   cached answer. Added `tenant_id` to the key.
3. **`query_memory` table missing a UNIQUE index** — `QueryMemory::save()`
   relies on `INSERT ... ON DUPLICATE KEY UPDATE` to raise confidence on
   repeat questions, but the original migration
   (`2026_06_13_130000_create_query_memory_table.php`) only had a plain
   (non-unique) index, so MySQL never triggered the update path — confidence
   was stuck at the 0.5 default forever, meaning the `>= 0.7` "memory fast
   path" in `TenantRouter.php` ~line 765 (skip AI SQL regeneration for a
   previously-confirmed question) could never activate, and the table grew
   with duplicate rows indefinitely. Fixed by editing that original
   migration in place (`INDEX` → `UNIQUE KEY` on `idx_tenant_hash`) rather
   than adding a new migration file, since it's a single-environment dev DB
   — the equivalent dedup + index swap was then applied directly to the live
   DB via a one-off statement so the running database matches what the
   migration file now describes. Any fresh install picks up the correct
   schema automatically; no separate patch migration exists.
4. **`ResultValidator::retryWithAlternative`** (`ResultValidator.php`
   ~line 58) — the "aggregate came back 0, try a different amount column"
   retry used `stripos`/`str_ireplace` (blind substring matching), so a
   column like `discount_amount` or `sale_amount` would get its `amount`
   substring corrupted into `discounttaxable_value` — an invalid column
   name. Switched to word-boundary-anchored regex matching so only whole
   identifiers get swapped.
5. **`ExternalApiService` wasn't channel-aware** (`ExternalApiService.php`
   `aiFormatSummary`/`aiFormatList`, ~line 442/460) — missed in the original
   formatting pass; delegation/checklist/call-log/lead answers were still
   forced into WhatsApp `*bold*`/emoji style on the web panel. Also found and
   fixed a **dead variable**: both functions fetched the tenant's custom
   format instruction (`TenantPrompt::getFormatInstruction`) but never
   actually appended it to the prompt — a tenant's configured custom output
   format was silently ignored for every external-API question. Both fixed.
6. **`TenantPrompt::getFormatInstruction()` was WhatsApp-only regardless of
   caller** (`app/Models/TenantPrompt.php` ~line 65) — every one of the 5
   channel-aware formatting functions in §3 calls this shared helper to pull
   in the admin panel's `data_format` custom prompt, but the helper itself
   hardcoded `"Always use WhatsApp *bold*"` into its returned text no matter
   who called it — so any tenant using the admin panel's custom-format
   feature (§3/§4) had that override silently forced back into WhatsApp
   style on the web panel, undermining the channel-awareness fix for exactly
   the tenants most likely to notice/care. Added a `$webMode` param to the
   helper itself and threaded it through all 4 call sites
   (`AiOrchestrator.php`, `TenantRouter.php`, `SmartFormatter.php`,
   `ExternalApiService.php` ×2).

## 6. Two separate WhatsApp implementations exist — only one is live

`app/Http/Controllers/WebhookController.php` is the **active** WhatsApp
pipeline (`POST /whatsapp`, registered in `routes/web.php`). It handles both
gateway modes — "professional" (Meta Cloud API,
`object=whatsapp_business_account` payload shape) and "unprofessional" (flat
payload, e.g. wa.apimis.in) — through the exact same code path: both call
`TenantRouter::handle($phone, $text, waMode: true, ...)`, so every accuracy
and formatting fix in this document applies identically regardless of which
gateway mode a tenant uses. The professional/unprofessional distinction only
affects which outbound API `Client::resolveChannelConfig` picks when sending
the reply back — not how the reply is generated or formatted.

`app/Http/Controllers/WhatsappWebhookController.php` is a **separate, older
implementation** — different services (`WhatsappMisService`), different
models (`ChatBot`, `LedgerList`, `OrderListV2`, `PartyLedgerV2`, ...), and it
does **not** go through `TenantRouter` at all, so none of today's fixes apply
to it. It is confirmed **not registered in any route file** (`routes/api.php`
or `routes/web.php`) and not referenced anywhere else in the codebase —
appears to be dead/legacy code from an earlier version of the project. Left
untouched (not deleted) since removing code wasn't asked for, but flagging it
here because it could cause confusion if someone edits it expecting it to be
live.

## 7. Known limitations (not bugs — architectural, worth knowing before you tune prompts)

- **RAG retrieval is top-k, not exhaustive.** `PdfKnowledgeService::search()`
  takes the top 8 keyword/semantic-matched chunks + up to 4 adjacent chunks
  (~12 chunks max) across *all* the tenant's accessible documents combined.
  Good for "what does document X say about Y" style questions; not
  guaranteed complete for "summarize everything I've uploaded" or
  cross-document comparison questions — one document's chunks can crowd out
  another's in the ranking. If this becomes a real problem, the fix is
  raising `$limit` in `findRelevantChunks()`/`findRelevantChunksByEmbedding()`
  (`PdfKnowledgeService.php` ~line 404/327) or adding a per-document minimum
  chunk guarantee — not a prompt change.
- **Sheet/table data and documents are two separate pipelines.** Table
  questions never go through `PdfKnowledgeService` — they go through SQL
  generation (§1). If someone says "the chatbot doesn't know about my
  spreadsheet," check `tables_metadata`/sync status, not the RAG prompts.
- **`MultiStepAgent::synthesize()`'s web short-intro mode** (§3 above) only
  activates when the last SQL step returned >1 rows — a single-row
  multi-step result still gets the fuller narrative prompt, which can look
  slightly redundant next to its (single-row) table. Minor, left as-is
  intentionally since duplication risk is low with one row.
